# Lakeflow Informix Community Connector

This connector discovers Informix user tables, takes an initial snapshot, and then captures committed changes through the Informix CDC API. The SQLI client, SmartLOB framing, CDC decoding, transaction handling, and checkpoint recovery are implemented in Python. It requires no JVM, database driver, JAR staging, or native Informix client and is intended to run on serverless Lakeflow Connect compute.

The pure-Python protocol implementation has completed authentication, query, discovery, snapshot, and end-to-end transactional INSERT/UPDATE/DELETE CDC validation against a disposable Informix 15 fixture. It has also completed a serverless Lakeflow Connect pipeline run over TLS, including multi-table discovery, snapshots, checkpointed CDC flow execution, deletes, and SCD Type 2 materialization. Validate it against your Informix version, topology, security policy, and workload before broader use.

## Contents

- [Prerequisites](#prerequisites)
- [Setup](#setup)
  - [Connection parameters](#connection-parameters)
  - [Create a connection with the Databricks CLI](#create-a-connection-with-the-databricks-cli)
  - [Update a connection with the Databricks CLI](#update-a-connection-with-the-databricks-cli)
  - [Create a connection with the Python API](#create-a-connection-with-the-python-api)
  - [Authentication, redirects, and TLS](#authentication-redirects-and-tls)
- [Supported objects and naming](#supported-objects-and-naming)
  - [CDC type support](#cdc-type-support)
  - [Variable-scale decimals](#variable-scale-decimals)
- [Snapshot, CDC, and deletes](#snapshot-cdc-and-deletes)
  - [Snapshot isolation](#snapshot-isolation)
  - [Checkpoints and log retention](#checkpoints-and-log-retention)
  - [Schema evolution without full refresh](#schema-evolution-without-full-refresh)
- [Keyless tables](#keyless-tables)
  - [Which tables count as keyless](#which-tables-count-as-keyless)
  - [Choosing an approach](#choosing-an-approach)
  - [The default change log](#the-default-change-log)
  - [Keyed on a set of columns](#keyed-on-a-set-of-columns)
  - [Keyed on the whole row](#keyed-on-the-whole-row)
    - [Why not a row hash](#why-not-a-row-hash)
  - [Soft deletes](#soft-deletes)
  - [A change log with a key](#a-change-log-with-a-key)
  - [Snapshot-only ingestion](#snapshot-only-ingestion)
  - [Loading existing rows](#loading-existing-rows)
  - [Limits](#limits)
  - [Option reference](#option-reference)
- [Table configuration](#table-configuration)
  - [Column selection](#column-selection)
  - [Column renames](#column-renames)
  - [Value transforms](#value-transforms)
  - [Row filtering](#row-filtering)
  - [Snapshot modes](#snapshot-modes)
    - [Migrating a table without a re-snapshot](#migrating-a-table-without-a-re-snapshot)
    - [Incremental snapshot and append-only targets](#incremental-snapshot-and-append-only-targets)
    - [File-sourced initial snapshot](#file-sourced-initial-snapshot)
    - [Reference recipe: extracting `.unl` files and their manifest](#reference-recipe-extracting-unl-files-and-their-manifest)
  - [SCD Type 2 sequencing and validity columns](#scd-type-2-sequencing-and-validity-columns)
  - [Lakebase-backed shared state](#lakebase-backed-shared-state)
- [Operational guidance](#operational-guidance)
- [References](#references)

## Prerequisites

- An Informix SQLI endpoint reachable from serverless Lakeflow Connect compute. Configure firewalls, private connectivity, and DNS as appropriate. Protocol redirects are disabled by default and require the explicit controls described below.
- A reachable SQLI endpoint. TLS is enabled by default and strongly recommended; its certificate must be trusted by Python's system CA store and match `hostname`. Plaintext transport is available only by explicitly setting `encrypt=false`.
- Transaction logging enabled for the source database. Retained logical logs must extend back to the oldest connector checkpoint.
- The Informix CDC API installed by an administrator. Run `$INFORMIXDIR/etc/syscdcv1.sql` (commonly with `dbaccess sysadmin`) to create the `syscdcv1` database and `cdc_*` routines.
- A normal username/password account that can read source catalog metadata and selected tables, use the required `syscdcv1` routines, and enable full-row logging. The validated reference setup grants DBA-level access to `syscdcv1`.
- The connector's message text deployed with its source. It is kept in `informix_messages.json`, next to `informix.py` and the merged `_generated_informix_python_source.py`, rather than in the code Spark ships to each worker, and each worker reads it from there. A deployment of this folder (a Git folder or the connector's wheel) includes it, and so does a zip of the sources imported from the archive; one that copies only the merged file must copy it too, or messages are reported by number.
- The exact `INFORMIXSERVER` value. `DB_LOCALE` defaults to `en_US.819` and `CLIENT_LOCALE` defaults to `en_US.utf8`; override either when the source requires another locale because the connector does not discover them.

The connector enables full-row logging for captured tables and leaves it enabled when a finite poll ends, avoiding capture gaps between polls. Ensure this operational change is acceptable on the source system.

Initial CDC preparation is automatic. For each table, its upsert reader enables
full-row logging, captures one LSN, and atomically publishes it as a state
record. The independently scheduled delete reader waits for and uses that exact
LSN. State lives in a Lakebase Postgres endpoint that the connector provisions on
first use, so no shared directory has to be prepared; the only Volume needed is
`snapshot.staging.location`, for snapshot page payloads.

A delete reader that has no offset of its own is bootstrapping, which is exactly the
state a **full refresh** produces. It waits for the record *this* update's upsert reader
publishes: the boundary of a fresh snapshot, or — for an upsert reader that *resumed* a
checkpoint — its resume position, which it republishes in every update so the wait is
bounded. A resume position can sit well past the snapshot the destination rows were
captured at, and bootstrapping there would skip every delete committed in between
(including the old-key delete of a primary-key change). The upsert reader therefore
also records a durable, per-pipeline **delete floor** — the snapshot boundary, keyed by
table and pipeline id so it survives update-scope cleanup, and moved forward only by a
later resnapshot — and a bootstrapping delete reader anchors at the lower of the two,
re-reading a range no delete checkpoint has consumed (idempotent for the target). A
floor that has aged out of the retained logical log, or that was captured under an
earlier schema generation, is reported in the event log and the resume position is used
instead; the deletes between the two can then no longer be replicated — run a full
refresh if the destination must match the source exactly. If the source's logical log
is reinitialized (a server rebuild, `oninit -iy`), a boundary naming a higher `uniqid`
than the server has reached makes the delete channel wait for a new snapshot generation
rather than start from an unrelated position.

## Setup

### Connection parameters

| Option | Required | Default | Description |
|---|---:|---:|---|
| `hostname` | Yes | | Informix SQLI hostname or IP address. It is also used for TLS hostname verification. |
| `database` | Yes | | Database to discover, snapshot, and capture. |
| `user` | Yes | | Informix normal-auth user with metadata, snapshot, and CDC privileges. |
| `password` | Yes | | Password for `user`; store it as a secret. |
| `server` | Yes | | Exact `INFORMIXSERVER` name sent during SQLI authentication. |
| `snapshot.staging.location` | Yes | | Writable Unity Catalog Volume directory for gzip-compressed immutable initial-snapshot pages, for example `/Volumes/main/informix_cdc/staging`. This is the only Volume the connector uses; everything else lives in Lakebase. Restrict `READ VOLUME`: staged files contain source row values. Pages older than the checkpoint start page are removed incrementally; remaining staging is removed after the checkpoint reaches CDC. Abandoned scopes use `snapshot.staging.retention.days`. |
| `snapshot.staging.retention.days` | No | `4` | Age threshold for the **background retention sweep** that reclaims abandoned snapshot staging; minimum `1`. Normal cleanup removes consumed pages incrementally and the whole stage at the snapshot→CDC transition — this sweep is the safety net for a `runs/<snapshot_lsn>` subtree left behind by a crash, an abandoned resnapshot, or a superseded schema/scope. It runs **asynchronously** (off the read path, on the same background pool as page deletion), at most once per table per reader, and once per `state.gc.interval.hours` over every table staged under the location by whichever reader claims it in Lakebase, and deletes only runs whose newest page file is older than this window, so an active run (recent writes) is never touched. Best-effort: a leftover only wastes Volume space, never affects correctness. It also removes spilled CDC pages left behind (see [Large transactions](#large-transactions)), whose Lakebase records expire after the same window. The location-wide sweep applies the claiming reader's retention, so connections sharing a staging location should set the same value. |
| `DB_LOCALE` | No | `en_US.819` | Database locale. Set it explicitly when the database uses another locale. |
| `CLIENT_LOCALE` | No | `en_US.utf8` | Client locale. Its codeset controls Python row decoding. |
| `port` | No | `9088` | Informix SQLI port; range `1`–`65535`. |
| `encrypt` | No | `true` | Enables TLS. Boolean values must be `1`, `true`, `yes`, `0`, `false`, or `no`, case-insensitively. Setting `false` uses plaintext TCP and exposes credentials, authentication exchanges, queries, and row data to the network; use it only on a trusted private network. |
| `ssl.ca.file` | No | system CA store | Path to a PEM CA bundle available on the pipeline worker. Hostname verification remains enabled. |
| `authentication.mode` | No | `password` | `password` or non-interactive `pam`. Other modes fail closed. |
| `authentication.provider.factory` | No | built-in provider | Trusted Python factory in `module:callable` form. It receives all connection options and returns a non-interactive PAM response provider. |
| `authentication.pam.echo.response` | No | `password` | Secret response used by the built-in provider for PAM echo-on prompts. Echo-off prompts use `password`. |
| `authentication.pam.max.rounds` | No | `16` | Maximum PAM challenge rounds before login fails. Each encoded response is limited to 512 bytes. |
| `authentication.login.timeout` | No | `30` | Overall login deadline in seconds, shared by connection, authentication, and all redirect attempts. |
| `max.concurrent.connections` | No | `16` | Maximum concurrent SQLI connections to one hostname, port, and `INFORMIXSERVER`, coordinated through the Lakebase `conn_slots` table; range `1`–`9999`. Capacity is the number of seeded rows, so it can be changed without stopping pipelines: acquisition bounds `slot_id` by the configured limit, so lowering it takes effect immediately while surplus rows are left in place rather than deleted (removing a row a live reader holds would silently revoke its lease), and raising it seeds additional rows idempotently. A claim is one `UPDATE ... FOR UPDATE SKIP LOCKED` that takes the lowest free or expired slot and increments an `epoch`; that epoch is required to renew or release, so a reader stalled past its 120s lease cannot resurrect it — and, more importantly, cannot free a slot its successor legitimately holds. A lease nobody releases simply expires. A reader blocked on a slot waits in a **fair queue**: it enqueues a ticket in Lakebase, so acquisition is **first-come per slot** instead of a raw race — no reader is lapped indefinitely while others churn the pool. Ordering is *per slot*, not global: an older reader reserved to high slots (a CDC daemon, say) never blocks a younger reader from a low slot it could not use anyway. Service rotates across **requester classes** — consumer reads, the CDC shard daemon, the snapshot drain — so each class gets a turn no matter how many tickets another holds, and a burst of consumer bootstrap/fallback tickets can't crowd out the few CDC-daemon tickets by sheer count. Tickets heartbeat each sweep and are dropped the instant a reader wins or gives up; a crashed reader's ticket ages out (≈15s) and is reaped by the next heartbeat, so it never wedges the queue. A reader that finds its own ticket reaped (it stalled longer than the TTL between two sweeps) takes a fresh ticket at the back of its class's rotation and logs a warning, rather than sweeping on with a ticket that can never win. The queue bounds waiting under contention but does **not** create capacity — if demand exceeds supply, waiters still time out with `ConnectionCapacityUnavailable`, just in order. |
| `connection.wait.timeout.seconds` | No | `600` | Maximum time a microbatch blocks while acquiring an Informix connection-capacity slot; minimum `1`. A **triggered** read that exhausts it fails with `ConnectionCapacityUnavailable` rather than returning an empty successful batch: triggered flows drain and terminate, so they release their slots, pressure is transient, and an empty batch is how `AvailableNow` recognises a drained source. A **continuous** read does not wait this long at all — see `capacity.retry.max.delay.seconds`. It also governs the **shared snapshot drain** (the daemon-pool drain) as a *per-progress liveness window*, not a hard cap: the drain worker resets it every time it stages a page **and** — while it is still waiting for its connection slot — every time the pool claims a slot (turnover), so a drain queued behind a busy backfill waits it out rather than failing. The worker gives up only when the pool is genuinely **wedged** (no slot claimed for a whole window), raising `ConnectionCapacityUnavailable` with a message that says the pool made no progress (distinct from a drain that connected but then stalled its scan). The consumer's watchdog fails only if the worker goes dark without recording an error. So raising this makes a drain both more patient waiting out a busy pool and more tolerant of long stalls. The **CDC shard daemon** waits for its slot on the same turnover-based window: while catching up it keeps its queue ticket and resets the window on each pool slot claim, so the round-robin rotation has time to reach it — a round is paid in slot turnover, not wall-clock — instead of failing fast on a short budget and re-queuing at the back (the pattern that let a consumer fallback herd wedge the shared session on a saturated small pool). It gives up only when the pool is wedged, then degrades its consumers to direct reads. Consumer reads keep the plain deadline. |
| `connection.startup.jitter.seconds` | No | `0` | One-shot jittered delay (fractional seconds) a reader sleeps before its **first** connection, so a pipeline that starts many flows at once does not open all their Informix CDC sessions in the same instant. The syscdcv1 CDC subsystem can stall under many concurrent session open/teardowns at startup, surfacing as a socket read timeout inside `validate_initial_lsn`; spreading the first connects over a window avoids the pile-up. Each reader sleeps a random duration in `[0, this)` exactly once, **before** it acquires a connection slot (so it holds nothing while waiting). Default `0` disables it; steady-state polls and reconnects are never delayed (the delay is one-shot per reader). Set it to a few seconds on a large multi-table pipeline that intermittently fails at startup with `validate_initial_lsn` timeouts. Must be a number `>= 0`. |
| `string.null.byte` | No | `null` | How a decoded string value that contains an embedded **NUL** (`\x00`) is sanitized. Many downstream consumers cannot store a NUL, and it is **genuine content** here — the connector already trims real (space) CHAR padding and VARCHAR is length-delimited, so a NUL that reaches the output was embedded in the value, not padding. `null` (default): a string containing any NUL becomes **NULL** — the honest, downstream-detectable signal that the value was unrepresentable, rather than silently altering it. `empty`: **strip** the NUL characters, preserving the rest of the string. `keep`: pass the NUL through unchanged (previous behavior). Applies to both the CDC and snapshot/query decode paths. ⚠️ **Key-column caveat:** a promoted unique-index / `primary.keys` key column is required non-null; if such a text key value contains a NUL, `null` mode would null it and break keyset pagination / the merge on that row — use `empty` if key columns may carry NULs. Accepts `null`/`empty`/`keep` (`empty_string` is an alias for `empty`). |
| `primary.key.from.unique.index` | No | `true` | Whether a table with **no primary-key constraint** is promoted to **keyed** on a `UNIQUE` index. Default `true`: the connector discovers the table's unique indexes and, if any qualifies, uses its columns as the primary key — so the table takes the resumable keyed path (keyset-paginated snapshots, CDC dedup, `cdc_with_deletes`) instead of the one-shot key-less drain. Selection is deterministic: only indexes whose columns are **all `NOT NULL`** qualify (a primary key must be non-null for keyset pagination and dedup to be sound); among those, the index with the **fewest columns** wins, and ties are broken by **index name in ascending order**. An explicit `primary.keys` option still overrides the discovered key. The discovered key is catalog-derived, so a schema refresh re-derives it. Set `false` to keep the old behavior (only a real primary key makes a table keyed; otherwise it is key-less). Note this changes a table's keyed/key-less classification, which changes its schema fingerprint — enabling it on an already-running key-less table requires a full refresh. Accepts `true`/`false` (`1`/`yes`, `0`/`no`). |
| `capacity.retry.max.delay.seconds` | No | `5` | Enables capacity backpressure for **continuous** pipelines, where every flow is a permanent standing consumer of a fixed slot count so contention is the steady state rather than a fault. Instead of blocking for the whole `connection.wait.timeout.seconds` and then failing, a continuous reader spends a short bounded budget trying to claim a slot and then returns an empty batch, waiting up to this many seconds (jittered) first. With a positive value this also caps each acquisition attempt to a short, miss-scaled budget: the budget grows with the number of consecutive reads that reader has finished without ever getting a slot, so a reader starved longest presses hardest; acquiring a slot resets that count. The default `5` spaces starved readers apart with jittered backoff, floored at `0.1s` so a low draw cannot re-sweep almost immediately. It was briefly `8` with a `0.5s` floor to reduce how often starved readers touched the shared Volume, whose FUSE mount disconnects with `ENOTCONN` under sustained write frequency. Slots are Postgres rows now — a measured 247–266 req/s at 120 concurrent connections held latency flat with no errors — so that traffic is no longer a constraint and the narrower range is restored for faster slot handoff. This value applies only to the steady-state **stream** (CDC) phase: the blocking **snapshot** is bulk, latency-tolerant work, so it always uses an effective delay of `0` regardless of this setting — it blocks the full `connection.wait.timeout.seconds` per attempt to patiently wait out contention for a slot, and the **incremental** snapshot reader phase does the same by default (governed by `snapshot.incremental.blocking`). Setting `0` extends that full-block behavior to the stream phase too for a **continuous** flow: the acquisition attempt blocks the full `connection.wait.timeout.seconds` (maximum chance to claim a slot before giving up) and there is no inter-read delay before the next attempt — prompt re-scan with no spacing, which raises shared-Volume metadata load under heavy contention. Either way a continuous flow **always yields** an empty batch on exhaustion rather than failing, bounded by `capacity.retry.max.retries` consecutive misses; the returned offset carries the count so the stream stays live and never reaches a durable checkpoint. Once that cap is reached the flow logs an error and fails with `ConnectionCapacityUnavailable`, so an undersized endpoint cannot pass unnoticed — prefer a triggered pipeline, a higher `max.concurrent.connections`, or fewer flows when readers outnumber slots. This value is irrelevant to a **triggered** flow, which always blocks the full wait and raises on exhaustion. Must be `>= 0`. |
| `capacity.retry.max.retries` | No | `500` | Consecutive capacity misses a **continuous** flow tolerates before it stops yielding and fails with `ConnectionCapacityUnavailable`. A reader that never claims a slot yields empty batches, which is indistinguishable from an idle source; this bound makes a permanently undersized endpoint fail loudly instead of replicating nothing forever. Acquiring a slot resets the count, so it only ever measures a current run of misses. Minimum `1`. Irrelevant to a triggered flow, which raises on the first exhausted wait. |
| `dropped.mount.max.retries` | No | `10` | Consecutive reads that find the snapshot staging Volume's FUSE mount disconnected (`ENOTCONN`) before the flow stops yielding empty batches and fails with `InformixError`. A dropped mount is normally transient — the connector yields an empty batch and the next read proceeds once the mount returns, leaving the checkpoint untouched — but a mount that never comes back leaves every flow yielding empties while the pipeline reports `RUNNING` and commits zero-row Delta versions on schedule, which is indistinguishable from an idle source. This bound surfaces that outage as a flow failure instead of a silent stall. The count measures **reads, not seconds**, so the wall-clock tolerance is this many microbatch intervals (the default is roughly 5 minutes at a 30s interval); raise it for a long trigger interval. Any read that reaches the Volume resets the count, so a flapping mount does not accumulate toward the cap. The partitioned reader's planning of a staged-page or `.unl` microbatch cannot yield, because an empty batch there would end a triggered update early: it retries in place, six attempts with backoff, and then fails the batch. Minimum `1`. |
| `transform.hash.key` | No | none | Secret of at least 16 characters that keys `HASH` in `transform_columns` (HMAC-SHA256). Set it on the connection, not in a pipeline spec. Changing it fails closed on running tables that use `HASH` until a full refresh. See [Value transforms](#value-transforms). |
| `lakebase.password` | **Yes** | | Password for `informix_state_user`, the long-lived Postgres role all state access authenticates as. Required, because it is the credential the running pipeline uses for every read and write of state, so nothing in that path depends on a token that can expire. It is the source of truth: a role whose password differs is repaired to match, which invalidates the previous password. The role name is fixed and not configurable — every pipeline sharing an endpoint must agree on which role owns the state tables. |
| `lakebase.admin_user` | No | ambient identity | Postgres role used **only** to provision `informix_state_user`, which requires CREATEROLE. Separate from the state role on purpose, so the credential every reader holds cannot create roles. Defaults to `DATABRICKS_CLIENT_ID` for a service principal, otherwise the workspace user. |
| `lakebase.admin_password` | No | OAuth credential | Password for `lakebase.admin_user`. When unset the admin authenticates with a short-lived OAuth credential minted for the pipeline's identity, which is the usual case. Not the same as `lakebase.password`. |
| `lakebase.project.id` | No | derived | Overrides the project id derived from `hostname`, `port`, and `server`. Set the same id on several connections to keep their state in one project, or set it to adopt a pre-created project. Rows stay separate per Informix server and database, so sharing a project doesn't pool capacity between servers; see [Sharing one project across Informix servers](#sharing-one-project-across-informix-servers). |
| `lakebase.autoscale.min.cu` | No | `0.5` | Minimum Lakebase compute units; `0.5` is the smallest the API accepts. Applied only when the connector creates the project. |
| `lakebase.autoscale.max.cu` | No | `2` | Maximum Lakebase compute units. Applied only at project creation. |
| `lakebase.suspend.timeout.seconds` | No | `60` | Idle seconds before the endpoint scales to zero compute. Applied only at project creation, because the API accepts it solely through a project's `default_endpoint_settings` and never retroactively. |
| `lakebase.provision.timeout.seconds` | No | `180` | Absolute deadline for project/endpoint provisioning and for waiting on concurrent provisioning. |
| `lakebase.database` | No | `databricks_postgres` | Postgres database holding the state tables. |
| `lakebase.workspace.host` | No | resolved | Workspace host for Lakebase control-plane calls (project and endpoint provisioning). Normally resolved from the pipeline's driver credential, `DATABRICKS_HOST`, or the Databricks SDK; set it only when none of those is available. |
| `lakebase.workspace.token` | No | resolved | Bearer token for those control-plane calls, resolved alongside `lakebase.workspace.host`. Set it only when the ambient credential cannot be resolved. |
| `state.gc.retention.days` | No | `30` | Age in days after which unreferenced per-table state records (activity markers for pipelines that no longer read the table) become eligible for best-effort garbage collection; minimum `1`. |
| `state.gc.interval.hours` | No | `24` | Minimum hours between garbage-collection sweeps for a table, and the window within which a reader touches its activity marker; must be `> 0`. Also the interval of the connection-wide staging sweep (see `snapshot.staging.retention.days`). |
| `state.gc.drop.unused.projects` | No | `false` | Whether to also drop Lakebase projects unused within `state.gc.project.retention.days`. Accepts `true` or `false`. |
| `state.gc.project.retention.days` | No | `90` | Age in days after which an unused Lakebase project becomes eligible for removal when `state.gc.drop.unused.projects` is `true`; must be `>=` `state.gc.retention.days`. |
| `connection.backlog.hint.enabled` | No | `true` | Whether readers publish and consume connection-backlog hints. A reader waiting for a connection slot cannot measure how far behind it is: reading the server log position requires a connection, which requires the very slot it is waiting for. A reader that already holds a slot therefore publishes the server log position into the `backlog_hints` table, and a waiter subtracts its own checkpoint from that value to estimate its backlog, then presses proportionally harder (a larger per-attempt acquisition budget) so scarce slots skew toward the readers furthest behind. Publication is one `INSERT ... ON CONFLICT DO UPDATE` that takes `GREATEST(existing, new)`, so a hint can never regress no matter which reader writes last or in what order. A waiter reads only rows updated within the last 45 seconds, so a stale hint is simply invisible rather than misleading. Purely advisory and fail-open: an absent, stale, malformed, or unreadable hint leaves acquisition behaving exactly as it does with hints disabled, so this can never affect correctness or fail a read. Note the published value is the **whole server's** log position, so it over-states the backlog of a low-traffic table (the log advances because other tables are written); it measures staleness rather than a row count and is therefore bucketed on a log scale into 8 ranks. Set to `false` to disable both halves of the protocol. |
| `snapshot.incremental.blocking` | No | `true` | Whether the in-progress **incremental** snapshot reader phase (primary-key chunks interleaved with CDC, before the copy completes) blocks for a connection-capacity slot. Default `true`: it blocks the full `connection.wait.timeout.seconds` per attempt to patiently claim a slot, like the consistent snapshot, since bulk copying is latency-tolerant and benefits from pressing for a slot rather than yielding empty. Set `false` to treat the incremental reader phase as steady-state **stream** instead — it then uses the continuous miss-scaled yield budget and `capacity.retry.max.delay.seconds` inter-read backoff, freeing the worker between attempts at the cost of a slower copy under contention. Only affects **continuous** pipelines; a **triggered** flow always blocks fully. Once the incremental snapshot completes and the reader becomes pure CDC, this option no longer applies. |
| `redirect.enabled` | No | `false` | Opts into protocol redirects. Boolean values are validated strictly; a redirect still fails unless its destination is explicitly allowed. |
| `redirect.allowlist` | No | empty | Comma-separated exact `host:numeric-port` redirect destinations. See the security rules below. |
| `redirect.max` | No | `3` | Maximum redirects within one login; revisiting a destination is rejected as a loop. |
| `padVarchar` | No | `false` | Enables fixed-width padded decoding for ordinary SQL `VARCHAR`/`NVARCHAR` snapshot and metadata results. A result that also holds an `LVARCHAR` or opaque column (`BOOLEAN` included) always comes back variable-length, its `VARCHAR`s length-prefixed, so this applies only to results without one. Boolean values are validated strictly. Use only when required by the negotiated server tuple format. |
| `table.include.list` | No | all eligible tables | Comma-separated shell-style table patterns. |
| `tables` | No | | Alias for `table.include.list`; ignored when that option is set. |
| `table.exclude.list` | No | none | Comma-separated shell-style patterns excluded after inclusion filtering. |
| `decimal.variable.type` | No | `decimal(38,18)` | Per-table option. Target Spark type for variable-scale `DECIMAL(p)`/`NUMERIC(p)` columns: `string`, `double`, `integer` (truncated), or `decimal(p,s)`. Explicit `DECIMAL(p,s)` remains fixed-scale. See [Variable-scale decimals](#variable-scale-decimals). |
| `decimal.variable.column.type` | No | none | Per-table option. Comma-separated `column:type` overrides of `decimal.variable.type` for specific columns, e.g. `agt_no:decimal(9,0),bnk_acct_no:string`. |
| `snapshot.mode` | No | `incremental` | Per-table snapshot policy: `incremental`, `initial`, `initial_only`, `cdc_only`, `auto_snapshot`, or `recovery`. See [Snapshot modes](#snapshot-modes). |
| `snapshot.source` | No | none | Per-table (also connection-scope) UC Volume directory of Informix UNLOAD (`.unl` or gzip `.unl.gz`) extract files. With `snapshot.mode=initial`, the initial snapshot is served from those files instead of a live scan, then transitions to CDC at the boundary. Files must be newline-terminated delimited text — UNLOAD (`\|` delimiter, backslash escaping, empty field = NULL) or **HPL DELIMITED** output (set `snapshot.unl.delimiter`/`snapshot.unl.escape` when its job uses a different pair; HPL fixed-position/COBOL/binary formats are not supported). Parallel executor reads use ranged GETs over the Files REST API, splitting each plain file into ~`snapshot.split.bytes` (default 50 MiB) pieces at record boundaries. A gzip file (detected by magic bytes, not name) is not seekable, so it is one non-splittable unit — for compressed extracts, parallelism comes from using **multiple `.unl.gz` files**, and mid-snapshot resume from multiple files or `snapshot.gzip.records.per.batch`. The operator must ensure the extract reflects the table at ingest time (quiesce, or extract-then-ingest); the connector does not verify alignment. Once the snapshot starts, the connector pins each file's name, size, modification time and a sampled content fingerprint, and fails with a full-refresh error if a later read finds any file added, removed or changed. Producing the `.unl` files via UNLOAD/HPL is out of scope. See [File-sourced initial snapshot](#file-sourced-initial-snapshot). |
| `snapshot.boundary.lsn` | No | self-pin | Per-table (also connection-scope) operator-supplied CDC boundary LSN for a `snapshot.source` extract — the LSN the extract was captured at, so the CDC stream resumes at exactly that position. **Resolution per table, first hit wins:** this option; else a `_manifest.json` file in the `snapshot.source` directory containing `{"boundary_lsn": "<X>"}` (other keys ignored); else the connector self-pins its own registration LSN. A supplied boundary is validated against the source's retained/current log range and **fails closed** if below the minimum retained LSN (the logical log recycled past it → gap) or above current. Non-negative integer. |
| `snapshot.split.bytes` | No | `52428800` | Per-table (also connection-scope) target byte size for each parallel `.unl` split — each executor reads roughly this many bytes, snapped up to the next record boundary. Splitting by bytes rather than rows lets the connector plan splits with a few small reads instead of scanning the whole file. Positive integer; default 50 MiB. Only meaningful with `snapshot.source`. |
| `snapshot.gzip.records.per.batch` | No | `0` | Per-table (also connection-scope) number of records of a gzip `.unl.gz` file to serve per microbatch, so a gzip file resumes mid-file after a failure instead of being re-read whole. `0` (default) keeps today's behaviour: each gzip file is one split, read whole on an executor in one microbatch. With a positive value, each gzip file is served on the driver that many records per microbatch, and the checkpoint records how many of its records are done. The driver keeps the file's decompressor open between microbatches, so normal progress is still one pass over the file; after a restart it reopens the file and skips the records already ingested, which re-decompresses that prefix but never re-ingests it. Each microbatch's rows pass through the driver, and a gzip file is no longer read in parallel with other splits, so this suits a few large gzip files rather than many small ones; keep the value moderate, for example tens of thousands to a few hundred thousand records. Plain `.unl` files still fan out to executors. Clearing the option while a file is part-served finishes that file in one microbatch. A file replaced while part-served fails the read with a full-refresh error rather than resuming into different content. Applies to the partitioned reader (the default). Only meaningful with `snapshot.source`. |
| `snapshot.unl.delimiter` | No | `\|` | Per-table (also connection-scope) field delimiter for a `snapshot.source` extract; a single character. Default `\|` (Informix UNLOAD). Set it when the extract is **HPL DELIMITED** output whose ipload job uses a non-pipe delimiter — HPL does not honor `DBDELIMITER`, so the delimiter is whatever the job set. Record terminator is always newline. Must differ from `snapshot.unl.escape`. Only meaningful with `snapshot.source`. |
| `snapshot.unl.escape` | No | `\` | Per-table (also connection-scope) escape character for a `snapshot.source` extract; a single character. Default `\` (UNLOAD backslash escaping: `\n`/`\r`/`\t` → control chars, `\<other>` → literal). Set it to match an HPL job's escape character, or to the **empty string** to disable escape processing for an HPL job that writes no escapes. Must differ from `snapshot.unl.delimiter`. Only meaningful with `snapshot.source`. |
| `table.migration` | No | `false` | Per-table (also connection-scope) boolean. When `true`, the table runs a two-run checkpoint handoff instead of its normal read, so it can move to a new Lakeflow flow — an SCD Type 1 → append-only switch, or a destination relocation — **without re-snapshotting**. Orthogonal to `snapshot.mode`, which the table keeps unchanged. Migration never streams: every read records a checkpoint, emits no rows, and stops. Clearing it (Restore) resumes normal reads from the recorded offset. See [Migrating a table without a re-snapshot](#migrating-a-table-without-a-re-snapshot). Accepts `true`/`false`. |
| `snapshot.page.size` | No | `20000` | Rows per page for **keyed** tables — keyset-paged incremental chunks and the keyed blocking `initial` snapshot; minimum `1`. Pages are read under one repeatable-read transaction and delivered through checkpointed Lakeflow microbatches. A keyless `initial` snapshot uses `keyless.snapshot.page.size` instead. |
| `keyless.snapshot.page.size` | No | `50000` | Rows per immutable staged Volume page for a **keyless** `initial` snapshot (an append-only keyless table with `snapshot.mode=initial`); minimum `1`. Such a table drains positionally (no seek cursor), so a larger page means fewer manifest entries and round trips for the same rows. A per-page byte ceiling still applies, and `snapshot.max.rows`/`snapshot.max.bytes` cap the whole drain. |
| `snapshot.filter` | No | none | Per-table Informix SQL predicate appended to snapshot `SELECT` statements, without the `WHERE` keyword. It filters blocking, incremental, append-only initial, and snapshot-only copies. CDC events after the snapshot are not filtered; use `row_filter` to filter them too. Semicolons, SQL comments, control characters, and predicates longer than 8,192 characters are rejected. |
| `row_filter` | No | none | Per-table predicate, without `WHERE`, that keeps only matching rows in snapshots, file-sourced snapshots, and the change stream. An update that moves a row out of the filter deletes it. See [Row filtering](#row-filtering). |
| `include_columns` | No | all columns | Per-table list of the columns to ingest (comma-separated or a JSON array). Columns added to the source later stay out. See [Column selection](#column-selection). |
| `exclude_columns` | No | none | Per-table list of columns to leave out (comma-separated or a JSON array). Columns added to the source later come in. Can't be combined with `include_columns`. See [Column selection](#column-selection). |
| `transform_columns` | No | none | Per-table object from column name to an expression replacing its value as rows leave the connector, such as `{"ssn": "MASK(ssn, 4)"}`; keys take only `HASH`. See [Value transforms](#value-transforms). |
| `rename_columns` | No | none | Per-table new destination names for columns, as a JSON object (`{"cust_nm": "customer_name"}`) or `source:destination` pairs. Other options keep using source names. See [Column renames](#column-renames). |
| `snapshot.isolation` | No | `committed_read_last_committed` | Per-table isolation level for the monolithic `snapshot.mode=initial` full-table snapshot. `committed_read_last_committed` (default) reads the last-committed image of a locked row instead of holding shared locks, so the snapshot does **not** lock the table against writers. `repeatable_read` restores the exactly-once, table-locking behavior. Tokens are case- and whitespace-insensitive; unknown values are rejected. **⚠️ Duplicate-row warning:** under `committed_read_last_committed` the table is no longer frozen at the snapshot LSN, so a row inserted **during** the scan can be captured by both the snapshot and the change stream. A keyed table de-duplicates these by primary key, but a **keyless (append-only) table has no key to de-duplicate on and may therefore emit duplicate rows**. Use `repeatable_read` for keyless tables that require exactly-once, or run the `initial` backfill during a quiet window. See [Snapshot isolation](#snapshot-isolation). |
| `snapshot.scan` | No | `keyset` | Per-table (also connection-scope) read strategy for a **keyed** table's one-pass snapshot. `keyset` (default) pages in key order: each page is its own query ordered by the key columns, which an index on those columns serves cheaply. Without such an index every page can scan and sort the table, so the cost grows with pages times table size, which is the usual case for a `primary.keys` override and especially the `"*"` wildcard. `cursor` reads the table through one forward-only cursor with no sorting, as a keyless table is read, while the key still drives the destination merge and delete handling. It also avoids keyset paging's trouble with NULL key values. Pages are sized by `keyless.snapshot.page.size`. Rows committed during a non-locking scan can reach both the snapshot and the change stream, which the key de-duplicates; set `snapshot.isolation=repeatable_read` for an exactly-once scan that locks the table. With `snapshot.mode=incremental` or `auto_snapshot`, a cursor scan has no key ranges to chunk by, so a new snapshot uses the one-pass snapshot instead of the chunked one; a chunked copy already in progress finishes as it started. A keyless table always reads through the cursor. Accepts `keyset`/`cursor`. |
| `snapshot.incremental.datetime.as.string` | No | `true` | Per-table boolean, also accepted at connection scope. When `true`, an incremental snapshot of a table whose primary key includes one or more `DATETIME` columns chunks by a fixed-width string cast of each `DATETIME` key column instead of falling back to the blocking snapshot. Any contiguous qualifier is supported, including `HOUR`-anchored time-of-day ranges, and `DATETIME` key columns alongside other key columns. Set `false` to force the blocking snapshot for such tables. |
| `stream.partitioned` | No | `true` | Whether the connector uses the **partitioned stream reader**. When enabled (default), the staged-snapshot page-serve phase **fans out**: a microbatch spans up to `stream.partitioned.snapshot.pages.per.batch` immutable staged pages, each read and decoded on a **separate Spark executor** instead of one page per microbatch on the driver — the parallel-read win for large snapshots. The first microbatch, which stages the snapshot, serves its first page from the stage the same way. Every other phase (the live CDC/incremental stream, snapshot→CDC transitions, deletes) is **computed on the driver**, its rows byte-for-byte the current output, just wrapped, in partitions of at most 16 MiB of row JSON each (an executor parses a partition's rows all at once, under serverless's 1 GB Python memory limit) — **CDC is never parallelized here** (the shard daemon remains the CDC lever; see `cdc.shared.session`). Applies only to tables with a bounded staged-snapshot→stream lifecycle (keyed CDC tables and append-only tables); snapshot-only tables always use the simple reader. Both readers persist the **same offset**, so this can be flipped on a **running** pipeline and it resumes the existing checkpoint in place with **no full refresh** (verified: serverless SDP resumes across the reader-class swap). The exception is a `snapshot.source` (`.unl`) snapshot part-way through its serve: only the partitioned reader continues its split windows, so turning this off then fails the table with an error saying to turn it back on until the snapshot has finished; no full refresh is needed. It relies on the shared CDC session, which is always on (`cdc.shared.session` is `host` or `process`), because an embedded CDC microbatch that Spark re-plans after a driver restart is recomputed from its committed start offset **bounded at its committed end offset** — the recompute must reach exactly that `end` and fails closed on a shortfall, the same contract as the simple reader's `readBetweenOffsets` — and only the shared session's accumulating buffer lets a bounded replay of a range larger than one `cdc.max.records` poll converge (a direct per-table poll is capped per read and could never satisfy the bound). Set `false` to force the simple single-partition driver reader. Accepts `true`/`false`. |
| `stream.partitioned.snapshot.pages.per.batch` | No | `8` | Maximum staged snapshot pages a single partitioned microbatch spans — the executor fan-out per batch; minimum `1`. Only meaningful when `stream.partitioned=true`. Larger values read more pages in parallel per microbatch at the cost of a larger batch. Independent of this value, the driver reads one boundary page's header per microbatch to record the resume cursor (`last_pk`). **Also governs a `snapshot.source` (`.unl`) serve**: it advances that many byte splits per microbatch, so the file snapshot drains over several bounded, resumable microbatches instead of one. |
| `snapshot.staging.transport` | No | `auto` | How snapshot page payloads are written to the staging Volume. `fuse` uses the UC Volume FUSE mount (historical behavior). `rest` writes them through the **Files REST API**, which never touches the mount and so avoids the FUSE `ENOTCONN` disconnects that recur under sustained write frequency; it needs the workspace to permit **personal-access-token creation** for the pipeline's identity. `auto` (default) uses `rest` when a token can be minted and **falls back to `fuse`** when token creation is forbidden or the reader's starting credential has expired (it lasts about an hour, and each reader mints its first token from it). Page *writes* and `snapshot.source` (`.unl`) reads use this transport; page reads and cleanup use the mount. One of `auto`, `rest`, `fuse`. |
| `snapshot.staging.token.lifetime.seconds` | No | `86400` | Lifetime of the personal access token minted for the `rest`/`auto` staging transport. The token is refreshed at half this value, or at half the lifetime the workspace grants when a maximum-token-lifetime policy grants less; the current token mints its successor, so a long-running pipeline never lets it expire while each token stays short-lived at rest. A token the Files API rejects anyway (HTTP 401) is replaced once, minted from the reader's starting credential, and the request retried. When nothing can replace it (that credential lasts about an hour), `auto` stages over FUSE from then on and `rest` fails. Each reader process mints its own token, tagged with the pipeline and update ids. A mint revokes that reader's previous token and the tokens of the pipeline's earlier updates, never those other flows of the same update are using. Minimum `600`. |
| `snapshot.staging.pipeline` | No | `true` | Whether a **keyless** `initial` drain on the `rest` transport overlaps its next page fetch with the previous page's shape-and-upload, through one bounded background uploader — roughly halving wall-clock for an I/O-bound keyless drain, at the cost of a few more pages resident in memory. Only engaged for a keyless drain on the REST transport (pipelining FUSE writes would raise the mount's write frequency, which REST exists to avoid); keyed drains are unaffected. Set `false` to force serial staging. |
| `snapshot.read.timeout.seconds` | No | `300` | SQLI socket read timeout while fetching transactional snapshot pages and while reading the incremental-snapshot key bound that seeds a keyed table; raise it if a large table's key-bound read times out. Minimum `1`. |
| `cdc.read.timeout.seconds` | No | `60` | SQLI socket read timeout for CDC session setup and teardown (open/start/activate/end/close) when validating the initial CDC boundary. Raise it if `syscdcv1` teardown stalls under many concurrent CDC sessions. |
| `snapshot.max.rows` | No | `0` | Optional total row bound for a staged CDC snapshot. `0` disables the bound. Snapshot-only tables remain limited to 100,000 rows when this option is `0`. |
| `append.only.ingestion` | No | `auto` | Tri-state: `auto` (default), `true`, or `false`. `auto` appends only CDC-streamable tables **without** a primary key — the connector reports `ingestion_type=append` with a cursor and streams changes instead of repeatedly reading a bounded snapshot — and leaves keyed tables on their normal CDC path (so keyed tables follow the pipeline `scd_type`, default `SCD_TYPE_1`). For a keyless table `auto` is equivalent to `true`. `true` forces append for every capturable table, including keyed ones; `false` forces the normal CDC/snapshot path, opting a keyless table into bounded snapshot-only ingestion. Append output is a **change log**, not current state: an update appends its after-image as a `u` row, and a delete appends a `d` **tombstone** row carrying the full before-image (see `append.delete.tombstones`). On a keyless table a tombstone is a change-log record, not an applied delete — there is no key to pair it with — so consumers wanting current state filter on `_informix_op`; use `false` for a mutable keyless table that needs merge semantics. To append a **keyed** table also set `scd_type: APPEND_ONLY`; the connector cannot read that pipeline setting. Columns of an unsupported type are left out (see [CDC type support](#cdc-type-support)), and append-only tables have no delete channel. |
| `append.delete.tombstones` | No | `true` | Per-table boolean, also accepted at connection scope (the table option wins). Applies only to a table on the append path (`append.only.ingestion`) and has no effect elsewhere. When `true`, a source `DELETE` lands on the upsert channel as a `d` tombstone row carrying the **full before-image** plus the usual `_informix_change_lsn`, `_informix_commit_lsn`, `_informix_tx_id` and `_informix_commit_time` columns, so the change log is lossless (an update already lands as a `u` row). On a keyed table forced to append, a key-changing update also removes the old key, so it lands the old row's before-image as a `d` tombstone ahead of the new key's `u` row. That tombstone's `_informix_change_lsn` is the before-image's own log position, strictly lower than the `u` row's, so ordering by the cursor applies them in the right order. Every CDC session enables full-row logging, so the before-image is always available. On a keyless table a tombstone is a change-log record, not an applied delete — there is no key to pair it with — so consumers wanting current state filter on `_informix_op`. A genuinely insert-only table never deletes, so the default costs it nothing. Set `false` for an archive-style table where retention purges would otherwise append one tombstone per purged row; the delete is then dropped. A keyed table on the normal CDC path ignores this option: its deletes are applied only through the separate delete flow. Accepts `true`/`false`. |
| `primary.keys` | No | *(catalog key)* | Per-table override of the table's primary key — a comma-separated list (or JSON array) of column names. When set, the connector treats the table as **keyed** on those columns even if it is physically keyless: it reports `ingestion_type=cdc_with_deletes`, reads incrementally with keyset-paginated snapshots and delete identification, and reports the keys so the pipeline uses them as the destination merge key too (no separate `primary_keys` needed). The columns must exist in the table, and naming one of an unsupported type fails the table (see [CDC type support](#cdc-type-support)). **You must guarantee they are unique per row** — a non-unique override corrupts upserts, delete identification, and snapshot pagination. A key column declared nullable may hold NULL: a delete carries the NULL through, and the pipeline's delete flow matches NULL key values, so updates and deletes of that row apply normally. A NULL in a `NOT NULL` key column still fails the pipeline as a broken log record. A NULL key value can still make a snapshot skip rows or fail, because keyset snapshot paging compares key values; `snapshot.scan=cursor` avoids that. Leave unset to use the catalog's primary key, then a `UNIQUE` index if the connection has `primary.key.from.unique.index` enabled (the default), and otherwise none. Set `"*"` (or `["*"]`) to key on **every column**, in catalog column order, so the whole row is its identity; columns of an unsupported type are left out of the table and so of the key. Set `"* except(c1, c2)"` to key on every column but those; it follows the schema the same way, and a column added later joins the key unless the list names it. `except` and the names match ignoring case, and every name must be a column of the table, so a misspelt one fails the table. See [Keyed on the whole row](#keyed-on-the-whole-row). This suits a keyless table whose rows are unique as a whole, such as a junction or lookup table. Nullable columns join the wildcard key too, so the NULL behaviour above applies to every nullable column. On an append-only table with `snapshot.mode=cdc_only`, its default, nothing pages by key, so NULLs are harmless there. It also follows the schema: a column appended to the table joins the key. Once the table is streaming changes, a nullable column added without a default extends the key without a full refresh, as described in [Schema evolution without full refresh](#schema-evolution-without-full-refresh). A column added with a default, or added while an incremental copy is still running, still needs a full refresh. Keyset snapshot paging sorts and compares on every column, so for a large table set `snapshot.scan=cursor`, or use an explicit key that matches an index. |
| `allow.nullable.index` | No | `false` | Per-table opt-in that lets a `UNIQUE` index containing **nullable** column(s) be promoted to the key when the table has **no primary key and no all-`NOT NULL` unique index**. Normally such an index is rejected because a key column is expected to be non-null; setting this `true` asserts the columns are **unique for every row**. A row that does hold NULL in one of them is still updated and deleted correctly: as for a `primary.keys` override, a delete carries the NULL through and the pipeline's delete flow matches NULL key values. What a NULL can still break is keyset snapshot paging, which compares key values and may skip the row or fail; `snapshot.scan=cursor` avoids that. Only takes effect when `primary.key.from.unique.index` is enabled (the default) and no non-null key exists; an all-`NOT NULL` unique index and an explicit `primary.keys` both still win. Promoting a table changes its keyed/key-less classification and schema fingerprint, so enable it before first ingest or run a full refresh. Accepts `true`/`false`. |
| `snapshot.max.bytes` | No | `0` | Optional estimated decoded Python byte bound for the complete staged snapshot. The default `0` disables the limit and byte accounting. Each encoded staged page also has a fixed 256 MiB safety bound. |
| `metadata.max.bytes` | No | `67108864` | Maximum estimated decoded Python bytes retained by an individual catalog query and by complete discovery. Set `0` to disable the limit and byte accounting. |
| `max.records.per.batch` | No | `10000` | Target maximum projected CDC rows; minimum `1`. A complete transaction may exceed it. |
| `cdc.timeout` | No | `5` | CDC idle-read timeout in seconds; minimum `1`. Zero is rejected because it can select an unbounded native wait. |
| `cdc.shared.state.wait.seconds` | No | `300` | Maximum time a delete reader waits for its table's upsert reader to publish initialization, trigger-boundary, or schema-transition state. When the upsert reader refuses a schema change, it records why for the current update, and the delete reader fails at once with that error rather than waiting. Otherwise, in a triggered update, a delete reader still waiting this long for a schema transition fails, naming the upsert reader, whose flow has most likely failed: the update would never end. A continuous update needs no such bound, since one failed flow fails it. It also sets how long a CDC shard keeps a table subscribed after its last poll: a flow that stops polling, or whose process exits, is dropped from its shard after this long, so it can't hold back the shard's restart position. |
| `cdc.max.records` | No | `256` | Soft native record target per CDC session; range `1`–`256`. Defaults to the source's own per-session ceiling because each poll pays a connection slot plus a full CDC session open/activate/close, so a smaller window amortises that fixed cost over less log progress. Once reached, records continue until every transaction already observed commits, rolls back, or Informix returns TIMEOUT. |
| `cdc.max.frame.bytes` | No | `16777216` | Maximum accepted native CDC frame size (16 MiB by default; minimum `16`). |
| `cdc.max.transaction.records` | No | `100000` | Maximum change records that all open transactions together hold in memory in one CDC poll. Exceeding it fails without emitting uncommitted data. With `cdc.spill.records` on (the default), a transaction is spilled once it alone holds more than that, and when several interleaved ones together reach this bound the largest is spilled, so the poll fails only with spilling off. |
| `cdc.spill.records` | No | `50000` | Change records an open transaction may hold in memory in one CDC poll. Past it, the transaction's changes go to the staging Volume (`snapshot.staging.location`) in pages of up to 10,000 (fewer for wide rows), and its batch is served from those pages by executors, so a transaction of any size neither fails nor fills the reader's memory. See [Large transactions](#large-transactions). `0` keeps every transaction in memory, bounded by `cdc.max.transaction.records`. |
| `cdc.max.poll.records` | No | `200000` | Total decoded-record bound for one native CDC poll, including committed records interleaved with a long-running transaction. Reaching it ends the poll and returns the transactions that already committed, so the checkpoint advances and the next poll resumes from the oldest still-open transaction. It fails only when no transaction completed, since then there is no progress to checkpoint. |
| `cdc.max.poll.bytes` | No | `0` | Optional estimated retained-byte bound per CDC poll, counting native frames plus recursively sized decoded Python values. Changes a transaction spills to the staging Volume stop counting once they leave memory. Reaching it truncates the poll on the same terms as `cdc.max.poll.records`. The default `0` disables the bound and byte accounting. |
| `cdc.read.bytes` | No | `32000` | Bytes requested in each SmartLOB CDC read. |
| `cdc.shared.session` | No | `host` | Sharded daemon-reader CDC, always on: `host` (the default) or `process`. Serverless SDP runs each streaming flow's reader in its own Python process on the driver, so with `process` every process keeps its own shards and serves only its own flow's table: each flow opens its own CDC session and the flows compete for connection slots. With `host` the flow processes on one host share the shards: the first process to lock a shard's lock file in the local temp directory leads it, running its daemon as below and serving the other processes' polls over a Unix socket next to the lock, authenticated with a key in a file that only the pipeline's own user can read. When the leader's process exits, the lock is released and the next poll takes it over within milliseconds; the new leader starts an empty shard, and each table reads directly until the shard covers it again, as after a restart. A follower that can't reach a live leader reads directly for that poll; a host that can't lock files or open Unix sockets shares within each process, as `process` does. Tables are partitioned into K shards and a bounded pool of K driver-resident daemon threads each hold one shared CDC session over their shard's tables, fanning changes out in memory — so concurrent CDC sessions drop from ~N to K and reads run in parallel across the K threads. In steady state a streaming poll reads schema, log bounds, and change records from the shard and touches Informix for nothing. A daemon checks its tables' definitions every 60 seconds in one catalog query, comparing each table's `systables.version`, and reads again, in one batch, only the tables that changed; a table is read as soon as it joins the shard. A column change needs the pipelines stopped anyway (see [Schema evolution without full refresh](#schema-evolution-without-full-refresh)), so what a check picks up is an index or key constraint created or dropped while the table is captured. Accepts `host` or `process`. Each shard's log-retention floor tracks that shard's slowest table. A table reads from its shard only once a daemon read activated at or below the table's checkpoint has covered it; until then its polls fall back to direct reads, and the daemon never advances the shard's shared restart past an uncovered table's floor — so a table that subscribes (or re-subscribes after the idle TTL) while a read is in flight cannot have the log between its checkpoint and that read's end skipped. |
| `cdc.shared.reader.threads` | No | `max(1, max.concurrent.connections // 4)` | Number of shards (K) **per channel**, each one daemon thread holding one shared CDC session over its shard's tables; minimum `1`. A table's shard is a stable hash of its identity modulo K, the same on every driver and after a restart. The upsert and delete channels shard independently, so a table sits in the same-numbered shard of each, and K threads mean up to **2K** daemon connection slots. With `cdc.shared.session=host` (the default) the K shards per channel are shared by every flow on the pipeline's driver host, so the pipeline runs at most 2K CDC sessions however many tables it reads. With `process`, each flow process creates only the shard its own table hashes to, so in practice each flow runs its own session whatever K is. A daemon holds its slot only across consecutive reads that return changes, releases it before any idle wait, and claims at or above `daemon.connection.reservation`. The default (a quarter of the pool → ~half the pool in total daemon slots) leaves room for consumer bootstrap reads and the snapshot drain; the previous default of `max.concurrent.connections` targeted 2N slots against an N-slot pool and could pin the entire daemon reservation band. A smaller K means fewer sessions and slots, and opening and closing a CDC session costs time per session, not per table. But a shard's tables share one reader thread, the shard's shared restart (and so its log-retention floor) follows its slowest table, and one table reaching `cdc.shared.buffer.max.records` defers reads for the whole shard. A larger K spreads tables across more parallel readers and isolates them better, at the cost of connection slots. Hashing can leave shards uneven, and some empty when K approaches the number of tables. Changing K reassigns tables to shards and is safe across a restart: shards live only in memory, and each table keeps its own checkpoint. |
| `cdc.shared.buffer.max.records` | No | `200000` | Connection-level option that caps each table's buffered-but-unconsumed transactions in a shard; minimum `1`. Set on the connection (not per table), it applies the same per-table buffer limit to every table. When a table reaches it, that shard's daemon defers new reads (throttle to the slowest reader) until the backlog drains, bounding driver memory. |
| `snapshot.reader.threads` | No | `max(1, daemon.connection.reservation − 1)` | Number of daemon workers that drain `initial` snapshots concurrently, which is also the ceiling on connection slots one process's snapshots hold at once; minimum `1`. An `initial`-mode snapshot's full-table drain always runs on this pool, off the microbatch thread, so it can't starve streaming readers while it holds a connection slot for the whole scan: the consumer waits, holding no slot, for a worker to stage the table and publish its manifest, then serves the staged pages exactly as a resumed snapshot does. The pool belongs to one Python process, and serverless SDP runs each flow in its own, so its bound applies per flow. Keyless (append-only, no primary key) tables drain **one-at-a-time** through this pool, so a single worker serializes every keyless table's initial scan and the later tables sit queued behind it. The default is **one below the CDC-daemon reservation** (`daemon.connection.reservation`, itself `≈ max.concurrent.connections / 3`), so the snapshot-drain floor (`daemon.connection.reservation − snapshot.reader.threads`) never collapses to `0`: a low slot always stays reachable by consumer bootstrap reads even while the drains hold their slots for whole scans — a drain that grabbed the lowest slots and held them would otherwise starve consumer/CDC reads on a small pool. It parallelizes drains only once the pool is large enough to spare a drain band and still keep a consumer floor (e.g. a 6-slot pool → reservation 2 → 1 worker; a 16-slot pool → reservation 5 → 4 workers). A large keyless table is not capped by a total-duration timeout: the consumer waits as long as the drain keeps staging pages (see `connection.wait.timeout.seconds`), so the levers for a big table are a larger pool (which raises this default) or declaring `primary.keys` (moves it onto the resumable keyed path). |
| `daemon.connection.reservation` | No | `0` | Connection slots the **sharded CDC daemon** may not claim, guaranteeing them to consumer bootstrap/snapshot/incremental reads; range `0` to `max.concurrent.connections − 1`. Unlike a consumer read, a daemon never releases its slot per microbatch — a busy CDC shard re-reads in a tight loop — so without this the CDC daemon can pin **every** slot (each of its two channels runs `cdc.shared.reader.threads` threads, a quarter of the pool by default) and a fresh bootstrap read times out and fails the query. Default `0`, interpreted as **one third of the pool** — `floor(max.concurrent.connections / 3)`, rounded up to at least `1` whenever the pool has 2+ slots (`0` only for a single-slot pool). Set a positive value to give the CDC daemon more of the pool (down to reserving a single slot). A floor, not a partition — beyond the reserved slots the CDC daemon uses all remaining capacity. The **snapshot drain daemon** is treated separately: because it must finish to unblock its append-only consumer, it floors one band *below* the CDC daemon (at `daemon.connection.reservation − snapshot.reader.threads`), reserving `snapshot.reader.threads` slots the CDC daemon cannot claim so a saturated CDC daemon cannot starve the drain. Keep `daemon.connection.reservation` **greater than** `snapshot.reader.threads` so a slot also remains below the drain for consumer bootstrap; otherwise the drain floor collapses to `0` and it competes with consumer reads for the CDC-free low band. |

Because per-table options are supported, configure the Unity Catalog connection with this exact `externalOptionsAllowList`:

```text
qualified_source_table,decimal.variable.type,decimal.variable.column.type,snapshot.mode,snapshot.source,snapshot.boundary.lsn,snapshot.split.bytes,snapshot.gzip.records.per.batch,snapshot.unl.delimiter,snapshot.unl.escape,snapshot.page.size,keyless.snapshot.page.size,snapshot.filter,row_filter,include_columns,exclude_columns,rename_columns,transform_columns,snapshot.isolation,snapshot.scan,snapshot.incremental.datetime.as.string,snapshot.max.rows,snapshot.max.bytes,append.only.ingestion,append.delete.tombstones,max.records.per.batch,cdc.timeout,cdc.max.records,primary.keys,allow.nullable.index,table.migration
```

Create the connection from the Lakeflow Community Connector flow on the **Add Data** page, with the Databricks CLI, or with the Databricks SDK for Python. The Unity Catalog connection type must be `COMMUNITY`, and `sourceName` must be `informix`.

### Create a connection with the Databricks CLI

The example uses `jq` so the password comes from an environment variable instead of being written literally into shell history:

```bash
export INFORMIX_PASSWORD='<secret>'
# Password for informix_state_user, the Lakebase role holding connector state.
# Choose it once and supply the same value on every update.
export LAKEBASE_PASSWORD='<secret>'

databricks connections create --json "$(jq -n \
  --arg password "$INFORMIX_PASSWORD" \
  --arg lakebase_password "$LAKEBASE_PASSWORD" \
  '{
    name: "informix_sales",
    connection_type: "COMMUNITY",
    comment: "Informix CDC connection",
    options: {
      sourceName: "informix",
      hostname: "informix.example.internal",
      port: "9088",
      database: "sales",
      user: "cdc_service",
      password: $password,
      server: "informix_prod",
      encrypt: "true",
      "snapshot.staging.location": "/Volumes/main/informix_cdc/staging",
      "lakebase.password": $lakebase_password,
      externalOptionsAllowList: "qualified_source_table,decimal.variable.type,decimal.variable.column.type,snapshot.mode,snapshot.source,snapshot.boundary.lsn,snapshot.split.bytes,snapshot.gzip.records.per.batch,snapshot.unl.delimiter,snapshot.unl.escape,snapshot.page.size,keyless.snapshot.page.size,snapshot.filter,row_filter,include_columns,exclude_columns,rename_columns,transform_columns,snapshot.isolation,snapshot.scan,snapshot.incremental.datetime.as.string,snapshot.max.rows,snapshot.max.bytes,append.only.ingestion,append.delete.tombstones,max.records.per.batch,cdc.timeout,cdc.max.records,primary.keys,allow.nullable.index,table.migration"
    }
  }')"

unset INFORMIX_PASSWORD LAKEBASE_PASSWORD
```

Use `--profile <profile-name>` when the CLI should use a non-default Databricks profile. Confirm the result with:

```bash
databricks connections get informix_sales
```

### Update a connection with the Databricks CLI

Pass the complete desired `options` map when updating a connection; do not assume omitted options will be preserved. This TLS example again uses `jq` to keep the password out of the literal command:

```bash
export INFORMIX_PASSWORD='<secret>'
export LAKEBASE_PASSWORD='<secret>'
export DATABRICKS_PROFILE='<profile-name>'

databricks connections update informix_sales --json "$(jq -n \
  --arg password "$INFORMIX_PASSWORD" \
  --arg lakebase_password "$LAKEBASE_PASSWORD" \
  '{
    options: {
      sourceName: "informix",
      hostname: "informix.example.internal",
      port: "9089",
      server: "informix_prod",
      database: "sales",
      user: "cdc_service",
      password: $password,
      encrypt: "true",
      "ssl.ca.file": "/Volumes/catalog/schema/artifacts/informix-ca.pem",
      "snapshot.staging.location": "/Volumes/main/informix_cdc/staging",
      "lakebase.password": $lakebase_password,
      externalOptionsAllowList: "qualified_source_table,decimal.variable.type,decimal.variable.column.type,snapshot.mode,snapshot.source,snapshot.boundary.lsn,snapshot.split.bytes,snapshot.gzip.records.per.batch,snapshot.unl.delimiter,snapshot.unl.escape,snapshot.page.size,keyless.snapshot.page.size,snapshot.filter,row_filter,include_columns,exclude_columns,rename_columns,transform_columns,snapshot.isolation,snapshot.scan,snapshot.incremental.datetime.as.string,snapshot.max.rows,snapshot.max.bytes,append.only.ingestion,append.delete.tombstones,max.records.per.batch,cdc.timeout,cdc.max.records,primary.keys,allow.nullable.index,table.migration"
    }
  }')" \
  --profile "$DATABRICKS_PROFILE"

unset INFORMIX_PASSWORD LAKEBASE_PASSWORD DATABRICKS_PROFILE
```

The CA path must be readable by the serverless pipeline. Use the TLS listener's DNS hostname rather than its IP address when certificate hostname verification requires it.

### Create a connection with the Python API

Install or upgrade the Databricks SDK, configure its normal authentication environment, and call the Unity Catalog Connections API:

```python
import os
from types import SimpleNamespace

from databricks.sdk import WorkspaceClient


w = WorkspaceClient()  # Uses the standard Databricks SDK authentication chain.

# `connection_type` must be the string "COMMUNITY". The SDK's ConnectionType
# enum does not include it, so pass a small object whose `.value` is the string:
# `w.connections.create` serializes the argument as `connection_type.value`, and
# a bare string (no `.value`) or `ConnectionType("COMMUNITY")` (not an enum
# member) both fail.
connection = w.connections.create(
    name="informix_sales",
    connection_type=SimpleNamespace(value="COMMUNITY"),
    comment="Informix CDC connection",
    options={
        "sourceName": "informix",
        "hostname": "informix.example.internal",
        "port": "9088",
        "database": "sales",
        "user": "cdc_service",
        "password": os.environ["INFORMIX_PASSWORD"],
        "server": "informix_prod",
        "encrypt": "true",
        "snapshot.staging.location": "/Volumes/main/informix_cdc/staging",
        # Password for informix_state_user, the Lakebase role holding connector
        # state. Required; supply the same value on every update.
        "lakebase.password": os.environ["LAKEBASE_PASSWORD"],
        "externalOptionsAllowList": (
            "qualified_source_table,decimal.variable.type,decimal.variable.column.type,"
            "snapshot.mode,snapshot.source,snapshot.boundary.lsn,snapshot.split.bytes,snapshot.gzip.records.per.batch,snapshot.unl.delimiter,snapshot.unl.escape,snapshot.page.size,keyless.snapshot.page.size,snapshot.filter,row_filter,include_columns,exclude_columns,rename_columns,transform_columns,snapshot.isolation,snapshot.scan,snapshot.incremental.datetime.as.string,snapshot.max.rows,snapshot.max.bytes,"
            "append.only.ingestion,append.delete.tombstones,"
            "max.records.per.batch,cdc.timeout,cdc.max.records,primary.keys,allow.nullable.index,table.migration"
        ),
    },
)

print(connection.full_name or connection.name)
```

To update an existing connection, call `w.connections.update` with the complete
desired `options` map. As with the CLI, an update replaces the options wholesale;
do not assume omitted options are preserved, so include every option the
connection needs — including the required `lakebase.password`:

```python
import os

from databricks.sdk import WorkspaceClient


w = WorkspaceClient()  # Uses the standard Databricks SDK authentication chain.

connection = w.connections.update(
    name="informix_sales",
    options={
        "sourceName": "informix",
        "hostname": "informix.example.internal",
        "port": "9089",
        "database": "sales",
        "user": "cdc_service",
        "password": os.environ["INFORMIX_PASSWORD"],
        "server": "informix_prod",
        "encrypt": "true",
        "ssl.ca.file": "/Volumes/catalog/schema/artifacts/informix-ca.pem",
        "snapshot.staging.location": "/Volumes/main/informix_cdc/staging",
        # Password for informix_state_user, the Lakebase role holding connector
        # state. Required; supply the same value on every update.
        "lakebase.password": os.environ["LAKEBASE_PASSWORD"],
        "externalOptionsAllowList": (
            "qualified_source_table,decimal.variable.type,decimal.variable.column.type,"
            "snapshot.mode,snapshot.source,snapshot.boundary.lsn,snapshot.split.bytes,snapshot.gzip.records.per.batch,snapshot.unl.delimiter,snapshot.unl.escape,snapshot.page.size,keyless.snapshot.page.size,snapshot.filter,row_filter,include_columns,exclude_columns,rename_columns,transform_columns,snapshot.isolation,snapshot.scan,snapshot.incremental.datetime.as.string,snapshot.max.rows,snapshot.max.bytes,"
            "append.only.ingestion,append.delete.tombstones,"
            "max.records.per.batch,cdc.timeout,cdc.max.records,primary.keys,allow.nullable.index,table.migration"
        ),
    },
)

print(connection.full_name or connection.name)
```

The `databricks-sdk` `ConnectionType` enum does not include `COMMUNITY`, so the
typed enum cannot express it. The `SimpleNamespace(value="COMMUNITY")` shim above
supplies the `.value` the SDK serializes without depending on the enum. The
Databricks CLI (`databricks connections create`) takes the string directly and
needs no such workaround.

Do not hard-code production credentials in scripts, notebooks, pipeline JSON, or source control. Load them from your deployment system's secret store and pass them only while creating the connection. A minimal non-secret configuration shape is:

```json
{
  "hostname": "informix.example.internal",
  "port": "9088",
  "database": "sales",
  "server": "informix_prod",
  "encrypt": "true",
  "table.include.list": "sales.informix.orders,sales.informix.order_items"
}
```

Supply `user`, `password`, and the required `lakebase.password` separately through secret-backed connection properties.

### Authentication, redirects, and TLS

Normal Informix ASC username/password authentication and non-interactive PAM authentication are implemented. The normal ASC protocol carries the password directly. Verified TLS is therefore the default and strongly recommended. Setting `encrypt=false` explicitly opts into plaintext TCP; credentials, PAM exchanges, queries, and row data are then unencrypted and observable or modifiable by the network.

When enabled, TLS always verifies the hostname. It uses Python's system CA store by default, or a PEM CA bundle supplied with `ssl.ca.file`. Insecure/skip-verification mode is not supported. The CA file must be available to each serverless worker; do not rely on an ephemeral local path that is not distributed with the pipeline.

PAM never opens an interactive prompt. The built-in provider returns `password` for echo-off challenges and `authentication.pam.echo.response` for echo-on challenges; when the latter is absent it falls back to `password` for both. Informational PAM messages require no response. Multi-round conversations are supported up to `authentication.pam.max.rounds`, subject to the single overall login deadline and the 512-byte encoded-response limit. An unexpected message style, missing provider, excessive round count, oversized response, rejection, or timeout fails closed.

For a different non-interactive exchange, `authentication.provider.factory` names an installed, administrator-reviewed Python callable as `module:callable`. The callable receives the complete options mapping and returns the response provider. This imports and executes code in the pipeline, so never point it at unreviewed code. A custom factory supersedes the built-in echo-on/password behavior.

Keep `password` and `authentication.pam.echo.response` in secret-backed connection properties. Do not place either in pipeline JSON, source control, logs, provider error messages, or the redirect allowlist. For example, this is a secret-free PAM configuration shape:

```json
{
  "hostname": "informix.example.internal",
  "port": "9090",
  "server": "informix_prod_pam",
  "database": "sales",
  "user": "cdc_service",
  "authentication.mode": "pam",
  "authentication.pam.max.rounds": "8"
}
```

Redirects are an explicit opt-in because the destination is supplied by the server. With `redirect.enabled=true`, every target must exactly match a `host:numeric-port` entry in `redirect.allowlist`; wildcards, service names, and omitted ports are rejected. Every address returned for an allowed hostname is validated once and pinned for that connection attempt. The connector tries the validated addresses sequentially only after transport-level failures. If any address is private, loopback, link-local, multicast, or otherwise non-public, its exact `IP:numeric-port` must also be allow-listed. These checks prevent a permitted hostname from becoming an unrestricted network pivot.

Each redirect discards the old socket, parser, authentication, and statement state and starts login again. It remains inside `authentication.login.timeout`, cannot exceed `redirect.max`, and cannot revisit the same server/address/port identity. DNS is resolved and checked before connection. TLS is recreated with the original trust policy and hostname verification is performed against the redirected hostname; redirects cannot downgrade encryption or bypass certificate verification.

A secret-free redirect configuration shape is:

```json
{
  "hostname": "informix-router.example.internal",
  "port": "9088",
  "server": "g_informix",
  "database": "sales",
  "user": "cdc_service",
  "redirect.enabled": "true",
  "redirect.allowlist": "informix-a.example.internal:9091,10.20.30.40:9091",
  "redirect.max": "2",
  "authentication.login.timeout": "30"
}
```

GSS/Kerberos, private-server authentication, and automatic server-name or locale discovery remain unsupported. PAM has live integration coverage. Redirect parsing, multi-address validation and transport failover, reconnect state, limits, and loop detection have deterministic protocol-test coverage, but the current redirect fixture does not provide a TLS listener and therefore is not live redirect coverage. Serverless Lakeflow Connect execution over an Informix TLS listener has been validated separately.

The Informix test fixture (the separate `informix-cdc` repository) live-tests PAM against an Informix listener at `localhost:9090`. Its deterministic redirect responder on `localhost:9191` is plaintext and can be exercised only with the explicit `encrypt=false` opt-in; production redirect validation should use TLS or an independently trusted private network, with every destination explicitly allow-listed. Client-side `sqlhosts` failover is not redirect coverage. Fixture credentials are disposable test data and are intentionally not repeated here.

## Supported objects and naming

The connector dynamically discovers every base table in the configured database, Informix's system catalog tables included, then applies optional filters. Nothing is left out by name or owner: the only objects Informix's CDC API documents as impossible to capture are views, temporary and other non-logged tables, and tables in a database without logging. Views and other non-table objects are not exposed; a non-logged (`RAW`) table is listed, but Informix refuses to capture it.

Pipeline source names use `owner.table`, such as `informix.orders`. Filter patterns are case-sensitive shell-style patterns and can match:

- `database.owner.table`
- `owner.table`
- `database:owner.table`

Include filtering runs before exclusion filtering. Identifiers are limited to a letter or underscore followed by letters, digits, `_`, `$`, `+`, or `.`; a name with `+` or `.` is sent as a delimited (double-quoted) identifier.

### CDC type support

A table is captured via CDC when **every column it ingests has a supported CDC encoding**; columns of other types are left out (see below). A primary key is *not* required to read changes — it is required only to *merge* them into a keyed destination:

- **With a primary key** → keyed CDC with deletes (`cdc_with_deletes`): inserts, updates, and deletes are applied to the destination by key.
- **Without a primary key** → an append-only CDC stream (`ingestion_type="append"`, cursor `_informix_change_lsn`): changes are still read from the logical log, but with no key to identify a row they are appended rather than merged (no delete application; a delete appends a `d` tombstone row carrying the full before-image, see `append.delete.tombstones`). See [Keyless tables](#keyless-tables) for the ways to manage upserts and deletes on such a table.

The types without a CDC encoding are also the ones the snapshot reader can't materialize (see the type table below). The connector leaves a column of such a type out and ingests the rest of the table as if [`exclude_columns`](#column-selection) listed it: the snapshot and the change stream read only the other columns, and the destination table has no column for it. It logs a warning naming the table and the columns left out, once per table in each Spark process; the warning goes to the Python log of that process, not to the pipeline event log. Listing those columns in `exclude_columns` leaves them out without the warning; on a running table that needs no full refresh, and neither does taking the entry out again. A key column can't be left out, so a table whose key includes one fails, as it always did, with an error that it has columns the connector can't materialize. That holds whether the key is the catalog's, a unique index promoted to it, a nullable index promoted with `allow.nullable.index`, or a `primary.keys` list. The exception is `primary.keys: "*"`, which keys the table on the columns ingested, so rows that differ only in a left-out column share a key. A `primary.keys` list naming only other columns keys the table on those. Naming one in `include_columns` fails, and so does a table with no other columns.

| CDC status | Informix types |
|---|---|
| Live-validated end to end | `SMALLINT`, `INTEGER`/`INT`, `SERIAL`, `INT8`, `SERIAL8`, `BIGINT`, `BIGSERIAL`, `FLOAT`/`DOUBLE`, `REAL`/`SMALLFLOAT`, `DECIMAL`/`NUMERIC`, `MONEY`, `DATE`, supported `DATETIME` qualifiers, `INTERVAL`, `BOOLEAN`, `CHAR`, `NCHAR`, `VARCHAR`/`NVARCHAR`, `LVARCHAR` |
| Left out of the table, with a warning | `BYTE`, `TEXT`, `BLOB`, `CLOB`, complex and opaque types, and `DATETIME` or `INTERVAL` qualifiers the decoder doesn't support |
| Excluded from speculative decoding | Unknown catalog types, UDT and complex types such as `ROW`, `SET`, `LIST`, and `MULTISET` |

`INT8` and `SERIAL8` use Informix's complete ten-byte signed-magnitude CDC representation. `NCHAR` lands as `CHAR` does, without its blank padding; it differs only in collating by the database locale, which limits it in `row_filter` (see [Row filtering](#row-filtering)). `LVARCHAR` supports its variable-width ordinary SQLI snapshot envelope and native CDC representation. A `DATETIME` qualifier is CDC-capable when its start and end fields are supported by the native decoder. Values containing `YEAR` through at least `DAY` are exposed as timezone-free Spark timestamps. `HOUR`-based values are SQL TIME strings such as `13:03:36.93100`; other partial values remain qualifier-aware strings and never acquire the worker's current date.

`INTERVAL` lands as a string, because Delta tables can't store Spark's interval types. The string is Informix's own literal for the value with its padding trimmed: the first field unpadded, the others two digits each, the fraction at its declared width, and a leading `-` when negative. For example, `INTERVAL DAY(3) TO FRACTION(3)` gives `-12 13:14:15.016`, `YEAR TO MONTH` gives `1-02`, and `HOUR TO MINUTE` gives `10:30`. `FRACTION TO FRACTION(n)` has no field before the point, so `FRACTION TO FRACTION(3)` gives `.016`, `-.016`, and `.000`. Snapshots, file loads, and the change stream all produce the same text, which matches `TRIM(CAST(col AS VARCHAR(40)))` on the server. That was checked against a live Informix 14.10 on fifteen qualifiers covering every start field, leading precisions up to 9, and fractions of 1, 3, and 5 digits, with positive, negative, zero, and NULL values. The text doesn't sort by duration, so a snapshot keyed on an `INTERVAL` column copies the table in one consistent snapshot instead of in incremental chunks. `row_filter` can't filter on an `INTERVAL` column.

### Variable-scale decimals

Informix encodes an omitted scale in `DECIMAL(p)`/`NUMERIC(p)` as catalog scale byte `255`. This is **decimal floating point**, not scale zero: `p` is the number of *significant digits* (1–32) and the exponent floats, so the magnitude is not bounded by `p`. For example a `DECIMAL(5)` column can hold `114250` (the five significant digits `11425` scaled by `10^1`) or `0.00123`.

Because the exponent floats, no single fixed `DecimalType(precision, scale)` can represent the full range losslessly. The per-table option `decimal.variable.type` chooses the target Spark type:

| `decimal.variable.type` | Spark type | Notes |
| --- | --- | --- |
| `decimal(38,18)` (default) | `DecimalType(38,18)` | 20 integer digits, 18 fractional. Values whose integer part exceeds 20 digits raise a clear error. |
| `decimal(p,s)` | `DecimalType(p,s)` | Any `1<=p<=38`, `0<=s<=p`. Overflowing values raise an error. |
| `string` | `StringType` | Lossless canonical string for any magnitude and scale. |
| `double` | `DoubleType` | Native floating semantics; loses precision beyond ~15–17 significant digits. |
| `integer` | `LongType` | Truncated toward zero; values outside the signed 64-bit range raise an error. |

Use `decimal.variable.column.type` to override the global choice per column, e.g. `agt_no:decimal(9,0),bnk_acct_no:string`. Explicit fixed-scale `DECIMAL(p,s)` columns are unaffected and always map to `DecimalType(p,s)`.

Set `scalar.types.live.validation=true` and `scalar.types.test.table=owner.table` in an opt-in live test configuration to validate snapshot and CDC decoding against a populated, dedicated mutable table containing `INT8`, `SERIAL8`, `DATETIME`, `LVARCHAR`, and `BOOLEAN` columns. Snapshot validation opens separate `padVarchar=false` and `padVarchar=true` sessions, so VARCHARs beside LVARCHAR/BOOLEAN columns are exercised in both modes; include a VARCHAR column before and after them to catch a misaligned tuple. Provide `scalar.types.expected.snapshot` and `scalar.types.expected.cdc` as JSON objects containing exact non-null wire boundaries: a signed INT8 extreme, a positive generated SERIAL8 value, an LVARCHAR occupying its catalog maximum in the configured `CLIENT_LOCALE` encoding, a DATETIME preserving its declared fractional precision, and a Boolean value. INT8 exercises the shared signed-magnitude extreme without advancing the SERIAL8 generator to exhaustion. Provide corresponding null-sentinel cases in `scalar.types.expected.null.snapshot` and `scalar.types.expected.null.cdc`; each must include every required column and set every nullable scalar column to JSON `null`. Configure committed mutations with `scalar.types.mutation.sql` and `scalar.types.null.mutation.sql`, plus one idempotent `scalar.types.cleanup.sql` statement that removes both mutations. The test commits every statement explicitly in ANSI and non-ANSI databases and preserves all primary, rollback, cleanup, and close failures.

This regression passed against Informix 15.0.FC0DE in an ANSI-mode database over
the verified TLS SQLI listener, covering padded and unpadded snapshots, exact
boundary and null values, committed full-row CDC updates, and cleanup.

A reproducible fixture uses one non-scalar marker so CDC can emit unchanged
boundary/null scalar values through full-row logging:

```sql
CREATE TABLE scalar_types_live (
  id INTEGER NOT NULL PRIMARY KEY,
  int8_value INT8,
  serial8_value SERIAL8 NOT NULL,
  datetime_value DATETIME YEAR TO FRACTION(5),
  lvarchar_value LVARCHAR(16),
  boolean_value BOOLEAN,
  marker INTEGER NOT NULL
);

INSERT INTO scalar_types_live
  (id, int8_value, serial8_value, datetime_value, lvarchar_value, boolean_value, marker)
VALUES
  (1, 9223372036854775807, 0,
   DATETIME(2026-07-21 12:34:56.12345) YEAR TO FRACTION(5),
   'abcdefghijklmnop', 't', 0);
INSERT INTO scalar_types_live
  (id, int8_value, serial8_value, datetime_value, lvarchar_value, boolean_value, marker)
VALUES (2, NULL, 0, NULL, NULL, NULL, 0);
```

Add these test-only entries to `CONNECTOR_TEST_CONFIG_JSON` or the JSON file
referenced by `CONNECTOR_TEST_CONFIG_PATH`; expected objects are JSON-encoded
strings because connection options are strings:

```json
{
  "scalar.types.live.validation": "true",
  "scalar.types.test.table": "informix.scalar_types_live",
  "scalar.types.expected.snapshot": "{\"int8_value\":9223372036854775807,\"serial8_value\":1,\"datetime_value\":\"2026-07-21T12:34:56.12345\",\"lvarchar_value\":\"abcdefghijklmnop\",\"boolean_value\":true}",
  "scalar.types.expected.null.snapshot": "{\"int8_value\":null,\"serial8_value\":2,\"datetime_value\":null,\"lvarchar_value\":null,\"boolean_value\":null}",
  "scalar.types.mutation.sql": "UPDATE scalar_types_live SET marker=1 WHERE id=1",
  "scalar.types.null.mutation.sql": "UPDATE scalar_types_live SET marker=1 WHERE id=2",
  "scalar.types.cleanup.sql": "UPDATE scalar_types_live SET marker=0 WHERE id IN (1,2)",
  "scalar.types.expected.cdc": "{\"int8_value\":9223372036854775807,\"serial8_value\":1,\"datetime_value\":\"2026-07-21T12:34:56.12345\",\"lvarchar_value\":\"abcdefghijklmnop\",\"boolean_value\":true}",
  "scalar.types.expected.null.cdc": "{\"int8_value\":null,\"serial8_value\":2,\"datetime_value\":null,\"lvarchar_value\":null,\"boolean_value\":null}",
  "scalar.types.insert.smoke.sql": "INSERT INTO scalar_types_live (id,int8_value,serial8_value,datetime_value,lvarchar_value,boolean_value,marker) VALUES (9,NULL,42,NULL,NULL,NULL,0)",
  "scalar.types.insert.smoke.cleanup.sql": "DELETE FROM scalar_types_live WHERE id=9"
}
```

Informix's native capture-column API and ordinary SQLI snapshot protocol do not yet provide end-to-end materialization for the rejected types. A column of such a type is left out of the table with a warning naming it, as if `exclude_columns` listed it, and a key column of one fails the table at metadata discovery, naming the columns involved, rather than the connector advertising a snapshot fallback that later fails or silently returning placeholders. Unknown catalog type codes fail discovery. Decimal CDC requires valid precision and scale metadata within Spark's 38-digit decimal limit.

## Snapshot, CDC, and deletes

For a CDC-capable table, the connector defaults to an `incremental` snapshot: it records the prepared CDC boundary, publishes it so the delete channel begins immediately, and then copies existing rows in primary-key chunks interleaved with the live change stream (see [Snapshot modes](#snapshot-modes)). Each chunk is read in its own short repeatable-read transaction and stamped with the LSN captured just before that chunk, so no long-lived read view is held over the whole table.

Selecting `snapshot.mode=initial` uses the earlier blocking strategy instead: the SQLI bridge establishes one repeatable-read transaction, captures a single snapshot LSN, and reads the bounded initial snapshot in complete primary-key order before commit. Non-ANSI databases use explicit `BEGIN WORK`; ANSI databases use their implicit transaction after committing the catalog-mode probe. Snapshot rows use the transactional snapshot LSN, and both channels advance directly to that same boundary because the snapshot already represents all committed state visible there. The earlier prepared LSN ensures full-row logging and a valid capture window while the snapshot is established; it is not replayed after the completed snapshot.

### Snapshot isolation

The `snapshot.mode=initial` full-table snapshot runs in a single transaction, so its isolation level governs the whole scan. The per-table `snapshot.isolation` option selects it:

- **`committed_read_last_committed`** (default) — Informix reads the last-committed image of any row locked by a concurrent writer instead of taking and holding shared locks. The scan therefore **does not lock the table against writes** for its whole duration.
- **`repeatable_read`** — the scan holds shared locks on every row it reads until commit, freezing the table (a sequential scan effectively locks the whole table). This blocks concurrent `INSERT`/`UPDATE`/`DELETE` for the entire drain, which for a large keyless table can be minutes.

> **⚠️ Duplicate rows under `committed_read_last_committed`.** The gapless handoff to CDC works by capturing `snapshot_lsn` at the start of the scan and having the stream replay everything committed after it. `repeatable_read` freezes the table at that LSN, so each row is emitted exactly once. `committed_read_last_committed` does **not** freeze it: a row inserted *during* the multi-minute scan can be read into the snapshot **and** replayed by CDC (its commit LSN is greater than `snapshot_lsn`). A **keyed** table de-duplicates these by primary key at the sink, so this is harmless. A **keyless (append-only) table has no key to de-duplicate on and will emit duplicate rows** for anything inserted during the scan. For keyless tables that require exactly-once, set `snapshot.isolation=repeatable_read`, run the `initial` backfill during a quiet window, or use the default `cdc_only` mode (which takes no snapshot at all).

This option applies only to the monolithic `initial` snapshot. The default `incremental`/`auto_snapshot` strategy reads each chunk in its own short repeatable-read transaction regardless, so it never holds a whole-table lock.

To validate the ANSI transaction sequence against a live ANSI-mode database, supply the standard `CONNECTOR_TEST_CONFIG_JSON` or `CONNECTOR_TEST_CONFIG_PATH` configuration with `ansi.live.validation=true` and `ansi.test.table=owner.table`, then run `ansi_live_test.py`. The selected table must have a primary key and no more than 10,000 rows.

Only complete committed transactions are emitted. Inserts and update after-images go to the data channel; deletes go to an independently checkpointed delete channel. Delete output contains the primary-key fields and connector metadata. A primary-key update emits the new row and deletes the old key. Rollbacks are suppressed. Transactions are never split: `cdc.max.records` and `max.records.per.batch` are soft targets, and a transaction already observed is read through commit/rollback unless Informix returns TIMEOUT. CDC metadata and timeout control frames do not consume the `cdc.max.records` budget. Record and estimated retained-memory bounds limit each poll. Replay is transaction-atomic: another transaction's checkpoint never removes earlier records from a newly committed interleaved transaction. Continuous runs follow new commits without a mode-specific option.

The framework does not pass snapshot offsets to independently instantiated delete streams. The connector therefore coordinates automatically through immutable state records in Lakebase. Only the upsert reader may enable full-row logging and publish a boundary; its delete reader waits and consumes that boundary. Initialization, snapshots, trigger boundaries, schema nodes, and schema transitions are each elected by `INSERT ... ON CONFLICT DO NOTHING RETURNING`: exactly one writer gets a row back and every loser re-reads and validates the winner, which callers depend on because a record is shared truth for its key. A record cannot be partially visible, so there is no incomplete state to quarantine and no candidate to collect. Every committed record carries an immutable-format version and record type. Corrupt, mismatched, or inaccessible committed state fails closed.

Regenerate the deployable file with `bash src/databricks/labs/community_connector/sources/informix/generate_source.sh`. Informix-owned code wraps the generated reader base and installs the AvailableNow callback at class creation, so this output is identical to the repository's canonical merge command and needs no post-generation patch. The source-local tests use `*_test.py` names so the standard merger excludes them.

Delivery is at least once. A failure after rows are returned but before Lakeflow commits its checkpoint can replay them. `TRUNCATE` cannot be represented by keyed Lakeflow deletes and fails explicitly. Snapshot-only tables are fully reread and fail when they exceed `snapshot.max.rows`.

The connector adds `_informix_change_lsn`, `_informix_commit_lsn`, `_informix_tx_id`, `_informix_op`, and `_informix_commit_time` to rows. Native LSN fields are decoded across their complete unsigned 64-bit wire domain. The two LSN columns are fixed-width, zero-padded 20-digit decimal strings so Spark string ordering is identical to numeric LSN ordering. Native signed int32 transaction-ID bit patterns are normalized to `0..4294967295`, ensuring one stable identifier after the high bit is set. `_informix_change_lsn` is the incremental cursor; operations are `r` (snapshot), `c` (insert), `u` (update), and `d` (delete — a key-only row on a keyed table's delete channel; on an append-only table a tombstone carrying the full before-image, for a delete or for the old key of a key-changing update, see `append.delete.tombstones`). Targets created with an older connector that emitted unpadded LSN strings require a full refresh before using this version.

`_informix_commit_time` (`TimestampType`, UTC) is the **source** commit time — the Informix transaction commit time for CDC rows (`c`/`u`/`d`, from the CDC BEGIN/COMMIT record), and the snapshot boundary time for `r` rows (the source's `DBINFO('utc_current')` captured when the snapshot boundary is pinned; for a file-sourced `.unl` snapshot it comes from the extract's `_manifest.json` `boundary_time`, else `NULL`). It is **epoch-seconds granularity** and it is `≤` every subsequent CDC commit time, so the column is non-decreasing across the snapshot→CDC handoff. It is **informational** — keep `sequence_by` on `_informix_change_lsn`, which orders sub-second changes to one key that a second-granularity time cannot. It is an **additive** column: adding it to an existing target is a schema-evolution `ADD COLUMN` — the connector's schema fingerprint excludes it, so checkpoints resume with no full refresh — but rows ingested **before** the upgrade keep `NULL` (they are never re-read). To give the backlog a non-NULL value without re-snapshotting, coalesce at read time in a downstream view — `COALESCE(_informix_commit_time, TIMESTAMP '<cutover>')`, where `<cutover>` is the source time at which you upgraded (every backlog row's true commit is `≤` it, every new row `≥` it, so the column stays monotonic). A full refresh instead re-stamps every row as an `r` row with the new snapshot's boundary time. Avoid a sentinel like `1970-01-01`; `NULL` is the honest "unknown".

### Checkpoints and log retention

Trigger records use pipeline-scope-specific subtrees, so recovery never reads
another pipeline's trigger records.

On Databricks, the registration scope is
`<spark.pipelines.pipelineId>_@_<spark.pipelines.updateId>`. Both UUIDs are
captured on the driver before reader serialization. If either Spark property is
unavailable, the connector falls back to a random 32-character secret scope.

During a blocking (`initial`) snapshot, Lakeflow checkpoints offset version 10, the snapshot LSN, immutable staged-page index, last primary-key values, source-schema fingerprint, generation-specific schema node ID, and update scope. During an `incremental` snapshot the offset is already a streaming offset that additionally carries the incremental chunk cursor (last and maximum primary-key bounds and the current chunk LSN); the incremental block is dropped once every chunk within the captured key range has been emitted. A completed consistent snapshot publishes its fresh resume LSN for both independently instantiated channels. Streaming offsets checkpoint the `commit_lsn`, `change_lsn`, oldest required `begin_lsn`, fingerprint, schema node ID, current update scope, triggered-update generation, and trigger high-water LSN. This makes restart offsets self-contained: resumed readers coordinate new decisions under the current update scope rather than dereferencing the previous update. Global immutable schema nodes are shared and are not scoped to an update. Triggered readers share one immutable per-table high-water LSN under the current update scope even when their predecessor generations differ. Records are elected rather than assembled, so a publisher that dies mid-write commits nothing and there is no candidate state to sweep, quarantine, or reclaim.

Schema-node IDs are deterministic hashes of the physical Informix table identity
and schema fingerprint. Full refreshes with an unchanged table incarnation and
layout therefore reuse the existing global schema node; their new snapshot and
initial LSNs remain in update-scoped initialization and snapshot records.

Each triggered pipeline update publishes one immutable high-water boundary per
physical table under its current pipeline/update scope. Upsert and delete readers
use that boundary even when cancellation or retry left their predecessor
generations different, then independently checkpoint the shared generation.

A CDC poll ends when Informix's log reader goes idle for `cdc.timeout` seconds, which on a busy log can happen before it reaches the end. In a continuous pipeline an idle poll returns no rows and leaves the checkpoint unchanged. A triggered update reads until the log reader has passed the update's high-water boundary: a poll that goes idle short of it, with no transaction open, moves the checkpoint to where the log reader stopped, so the next read carries on from there instead of rescanning, and the update doesn't end early. Incomplete or open transactions never advance the checkpoint past their `BEGIN`. If the restart LSN predates the minimum retained logical log in `sysmaster:syslogs`, continuation fails and the table must be resnapshotted. Every CDC session validates its initial METADATA frame against a fresh catalog layout before decoding later records; another METADATA frame in that session fails immediately and requires a full refresh.

### Large transactions

The connector emits a transaction only once it has seen its `COMMIT`, so a poll holds an
open transaction's changes until then. An UPDATE counts twice, its before- and
after-image. Once one open transaction holds more than `cdc.spill.records` (50,000 by
default), its changes go to the staging Volume instead, in pages of up to 10,000 changes (fewer for wide rows) under a
`cdc-spill` stage beside the snapshot pages:

- **What stays in memory:** only the page being filled. A transaction of any size gets
  through without raising `cdc.max.transaction.records`. Several interleaved transactions
  that pass that bound together, none past `cdc.spill.records` alone, spill the largest.
- **How it's served:** the committed transaction is a microbatch of its own, never
  combined with others. Executors read its pages in parallel, one partition per page,
  and shape the rows there. The rows are the same as an in-memory transaction's,
  including filters, renames, transforms and the delete channel. The delete channel reads
  none of the pages of a transaction that only inserted.
- **Rollbacks:** a `ROLLBACK` deletes the pages and their Lakebase record. A rollback to a
  savepoint drops the changes it covers on the pages as well as in memory.
- **Retries and re-plans:** pages are named by the pipeline, the table's capture, the
  transaction and its first change, not by the update. A poll that's retried, the other
  channel, a batch planned again after a restart, or a later update all find the pages
  already written and keep them.
- **Clean-up:** each run of pages has a record in the Lakebase state database (`state_records`,
  type `cdc-spill-run`) holding the transaction's commit LSN once a poll has seen its
  `COMMIT`. Once Spark has committed a batch at or past that LSN, the upsert flow and, for a
  keyed table, the delete flow each mark the record. The flow that marks it last deletes the
  pages. A poll that reads the transaction again afterwards finds it consumed and writes
  nothing, and a poll that was still writing pages when the run was finished deletes them
  at the `COMMIT`.
  - **Flows that read it in memory:** a flow whose shard kept the transaction in memory
    (capturing fewer of its tables) finds the record when it lists its tables' runs from
    Lakebase, at its first read and every 5 minutes after.
  - **Transactions no poll saw commit:** an update stopped inside a spilled transaction
    leaves a record with no commit LSN. It stays until a later poll sees the `COMMIT` or
    `ROLLBACK`, or until the record expires, since a shared shard reading from below a
    flow's checkpoint can still hand the flow that transaction at its `COMMIT`. If the
    source has reinitialized its logical log, so the run's first change names a log file
    ahead of the current one, no reader can be handed it again: a flow reading the log
    directly finishes it at its next listing, sampling the current log after the listing.
    A flow served by a shared shard leaves it to the record's expiry, since the shard's
    position can predate the run.
  - **Fallback:** pages the marking misses are removed by the stale-stage sweep
    (`snapshot.staging.retention.days`). This covers a flow removed from the pipeline, a
    Lakebase error while marking, a page an update was stopped while writing, and a
    transaction an update was stopped inside. Once per `state.gc.interval.hours`, one
    reader staging under each location, whichever claims it in Lakebase first, also runs
    that sweep over every table's staging there, so the pages of a dropped table or a
    deleted pipeline go too.
  - **Record expiry:** records are dropped after the same retention, whichever pipeline
    wrote them, by the next reader of the table, which deletes the run's pages with the
    record once they are as old, or with the table's other state.
- **The cost:** the poll writes every page before the batch can be served.
- **Where memory still applies:** on the simple reader (`stream.partitioned` off), and
  during an incremental snapshot, the rows are shaped from the pages on the driver and
  held in memory there, as every batch is on those paths.

Set `cdc.spill.records` to `0` to keep every transaction in memory, bounded by
`cdc.max.transaction.records`.

### Schema evolution without full refresh

A normal pipeline restart adopts these Informix schema changes on a streaming table
without a full refresh:

- **Appended columns:** nullable, CDC-supported columns added after every existing one.
- **Added columns of an unsupported type:** a `TEXT` or `BYTE` column added to a
  streaming table is left out, with a warning, and the stream carries on; the
  destination never gets the column. Adding a `BLOB` or `CLOB` column needs a full
  refresh: Informix 14.10 rebuilds the table under a new table ID for it.
- **Longer strings:** a `CHAR`, `NCHAR`, `VARCHAR`, or `NVARCHAR` column made longer,
  with its type and nullability unchanged. It still arrives as a string, so the
  destination column doesn't change. Changing an `LVARCHAR` column's length needs a full
  refresh: Informix 14.10 rebuilds the table under a new table ID for it, which the
  connector can't tell from a dropped and re-created table.
- **Shorter strings:** the same types made shorter, the destination column again
  unchanged: it keeps its type and is never shrunk. Informix shortens in place,
  truncating existing values longer than the new length without logging a change for
  each row, so those rows keep their old, longer values in the destination until they
  next change or a full refresh. Changes logged before the `ALTER` but read after it
  arrive cut to the new length, as the source now holds them (checked live on all four
  types). Shortening a key column needs a full refresh instead, and so does shortening
  any column of a table keyed with `primary.keys: "*"`, where every column is in the key:
  the truncated keys would no longer match the rows already landed, so later updates
  and deletes would miss them.
- **`SMALLINT` to `INTEGER`:** both arrive as integers, so the destination column doesn't
  change.
- **Wider numeric types:** `SMALLINT` or `INTEGER` (including `SERIAL`) to `BIGINT` or
  `INT8`, `SMALLFLOAT` to `FLOAT`, a `DECIMAL`, `NUMERIC`, or `MONEY` column given more
  precision without losing integer digits (its scale may grow only as far as its
  precision grows, up to precision 38), and an integer to a fixed-scale `DECIMAL`,
  `NUMERIC`, or `MONEY` with at least 10 integer digits (`SMALLINT`, `INTEGER`) or 20
  (`BIGINT`, `INT8`), such as `INTEGER` to `DECIMAL(12,2)`. `SMALLINT` and `INTEGER` may
  also become `FLOAT`. Key columns may widen too. These change the
  destination column's type, so the pipeline must allow it: set
  `"pipelines.enableTypeWidening": "true"` in the pipeline's `configuration` (Databricks
  Runtime 15.4 or later). The destination then widens the column in place, keeping its
  rows. Without the setting, the update fails with `DELTA_MERGE_INCOMPATIBLE_DATATYPE`;
  add it and run the pipeline again, and it recovers with no full refresh. Narrowing a
  number or a `DATETIME` qualifier, `INT8` to `BIGINT` (the same width), variable-scale
  `DECIMAL(p)`, an integer to a `DECIMAL` with fewer integer digits than those minimums
  (Delta's, even where the values would fit), `BIGINT` or `INT8` to `FLOAT`, and an
  integer to `SMALLFLOAT` still need a full refresh; for a narrowing, Informix 14.10
  rebuilds the table under a new table ID as well. After a rebuild the change stream
  delivers every row again as an insert but not the changes logged before it, so a row
  deleted in between would stay in the destination; a full refresh is the only exact
  recovery. Until it runs, every update fails as it starts. Usually the error is the pipeline's own
  `CANNOT_UPDATE_TABLE_SCHEMA` ("Failed to merge the current and new schemas"), because
  the destination can't take the new type; where it can, the connector fails instead with
  "changed column … other than by widening it or shortening a string; run a full refresh"
  or, after a rebuild, "changed table identity or primary keys; run a full refresh".
- **Dropped columns:** any column that isn't part of the key, `NOT NULL` or not. Dropping
  any key column fails closed, whatever its nullability: a key set with `primary.keys` or
  taken from a nullable index may name a nullable column, and rows would otherwise key on
  NULL. The exception is a whole-row key, which shrinks with the drop (see below).
  For a dropped non-key column the connector stops reading it and no longer reports it,
  and the destination keeps the column. With SCD type 1, a row updated after the drop
  keeps the value it had; rows inserted after the drop hold NULL. With SCD type 2,
  versions written after the drop hold NULL, and earlier versions keep their values. NULL
  fits even where the source column was `NOT NULL`, because the pipeline creates every
  destination column nullable.

Anything else still needs a full refresh: renames, reorders, a column added before
existing ones, other type changes, nullability changes, non-nullable additions,
a column changed to an unsupported type, primary-key changes, and dropping a column of
any key but a whole-row one. Changing `include_columns`,
`exclude_columns`, `rename_columns`, `transform_columns`, or `row_filter` on a running table also needs one, except for an `exclude_columns` entry naming a column of an unsupported type.

All of these have been validated against a live Informix server: after the change,
Informix returns log records written before it in the current layout. Values logged
under the old layout arrive with the column at its new width or type (a `SMALLINT` as a
`BIGINT`, a `DECIMAL(5,2)` as a `DECIMAL(10,4)`, an `INTEGER` as a `DECIMAL(12,2)` or a
`FLOAT`, an `INT8` as a `DECIMAL(20,0)`) and a dropped column left out, so the
connector decodes old and new records alike. The integer-to-`DECIMAL` changes were
checked on `DECIMAL` targets; `MONEY` targets follow the same rule but weren't run live.

A table keyed with `primary.keys: "*"` is the one exception to an unchanged key: its
key is every column, so an appended column joins it. The same holds for
`"* except(c1, c2)"`, except that a column the list names stays out of the key and
needs none of what follows. The key may grow that way without
a full refresh when every added column is nullable and has no default, and no
incremental copy is still running. Rows that existed before the change hold NULL in
the new column at the source, and the target gives them NULL when it gains the column,
so their later updates and deletes still match by the longer key. The connector
reports the longer key, and the pipeline uses it from the restart. A column added with
a default fails the read with a full-refresh error: existing rows would carry the
default at the source but NULL in the target, so their changes would never match.

A dropped column leaves a whole-row key the same way: the key shrinks to the
remaining columns without a full refresh, as long as no incremental copy is still
running and no column was added in the same step. Informix returns changes logged
before the drop without the column, and the target keeps it as an ordinary column, so
changes match by the shorter key; a Databricks pipeline was checked to accept a key that
shrinks between updates, under SCD types 1 and 2. The shorter key takes effect when the
pipeline next starts, since a running update keeps merging on the key it started with: a
drop seen mid-update fails the read until the pipeline is stopped and started again, with
no full refresh. The DDL steps below stop the pipelines first anyway. To drop one column
and add another, run the pipeline once between the two changes.

In the target, the dropped column keeps its value in rows that don't change. A changed
row lands with NULL there, since a change to a whole-row key is a delete plus an insert;
an update that rewrites a row with the same values keeps the old value under SCD type 1
and opens a version holding NULL under SCD type 2. Rows that differed only in the dropped
column become one key, like exact duplicate rows, and a change to one copy at the source
reaches every target row under that key: under SCD type 1, deleting one copy removes all
of them; under SCD type 2, it closes the newest version and the others stay current.
Versions tied for newest all close, such as rows that one snapshot loaded.

Informix rejects `ALTER TABLE` while full-row logging is enabled. Stop every
pipeline using this connection, then quiesce source writes before disabling
logging and keep them quiesced until logging is re-enabled. Apply the additive
DDL, immediately re-enable logging, and then writes may resume even before the
pipeline restarts. Restart normally—do not request a full refresh. For example, to
append a column:

```sql
EXECUTE FUNCTION syscdcv1:cdc_set_fullrowlogging(
  'testdb:informix.members', 0
);
ALTER TABLE informix.members ADD new_nullable_column VARCHAR(64);
EXECUTE FUNCTION syscdcv1:cdc_set_fullrowlogging(
  'testdb:informix.members', 1
);
```

The other supported changes follow the same sequence with a different `ALTER TABLE`. A
`MODIFY` restates the whole column definition, so keep `NOT NULL` on a column that has
it; otherwise the column becomes nullable and the change needs a full refresh. On a
primary-key column, restate `PRIMARY KEY` as well: Informix drops the table's primary
key when its column is modified without it, and a lost key needs a full refresh.

```sql
ALTER TABLE informix.members MODIFY (surname VARCHAR(120) NOT NULL);
ALTER TABLE informix.members MODIFY (member_id BIGINT NOT NULL PRIMARY KEY);
ALTER TABLE informix.members DROP (legacy_code);
```

Shared state stores predecessor-linked schema generations, the Informix catalog
table ID for incarnation detection, and one observation LSN per additive step. Lagging pipelines advance one recorded schema
at a time instead of skipping intermediate layouts, and each step is checked on its own, so a
reader behind a whole-row key follows a drop and an add that ran in separate updates. An incompatible full
refresh creates a new root generation while retaining older descriptors for
other pipelines. Both upsert and delete readers register the expanded projection
and replay directly from their retained checkpoints. Informix emits `NULL` for
the appended columns on pre-DDL records and their logged values on post-DDL
records. Lakeflow retains its checkpoints and Delta adds the new column without
introducing a restart-time LSN boundary or data-loss window.

Backfilling existing rows only propagates when it produces logged row changes
that CDC can capture. Populating the column outside the change stream does not
reach the destination: an `ALTER TABLE ... ADD ... DEFAULT <value>` sets every
existing row as part of the DDL (not a logged row change), and any `UPDATE`
applied while full-row logging is disabled — including during the
disable-logging window of the DDL sequence above — is likewise not captured.
In both cases the destination keeps `NULL` for those rows even though the source
is fully populated, because the connector only ever received the schema change,
not the values. To backfill, re-enable full-row logging first, then issue an
`UPDATE` that touches the affected rows (for example
`UPDATE informix.members SET new_nullable_column = new_nullable_column`, which
CDC captures as full-row updates and applies), or run a Lakeflow full refresh of
that table to re-snapshot every row with the column already populated. A full
refresh also clears the transient upsert/delete channel skew that a burst of
primary-key updates can leave, where the destination briefly retains an old key
(extra row) before the new key's insert and the old key's delete both land. Run the connector once after upgrading from a version without
schema history and before applying DDL so the current checkpoint descriptor is
seeded in shared state.

The one-MiB limit applies to each immutable state record, not to aggregate
history. Committed schema generations are retained because automatically
deleting one could break a paused pipeline, so schema history grows with the
number of additive steps a connection has taken. If a required historical schema
node is removed, the affected pipeline fails closed and requires a full refresh.

## Keyless tables

A table without a primary key is still captured from the logical log; the
connector just has no column to merge a change on. By default such a table lands
as an append-only change log, one row per change, with `_informix_op` saying what
happened. To get merged current state instead, give the table a key, either a set
of columns that is unique per row or the whole row.

In a change log, `_informix_op = 'd'` marks a deleted row, and ordering by
`_informix_change_lsn` gives the order changes happened in. A merged target needs
no filter: it holds current state.

### Which tables count as keyless

A table is keyed when any of these supplies a key, highest precedence first:

1. the `primary.keys` table option;
2. a `UNIQUE` index with nullable columns, when the table sets `allow.nullable.index: "true"`;
3. the catalog primary key, or a `UNIQUE` index whose columns are all `NOT NULL`
   (`primary.key.from.unique.index`, on by default).

A table with none of these is keyless. A column of an unsupported type is left out of
the table, unless it is part of the key, which fails the table; `primary.keys: "*"` and
`"* except(...)"` instead key the table on the columns ingested.

### Choosing an approach

| Goal | Table configuration | The target holds | Watch out for |
|---|---|---|---|
| A change log (the default) | none | One row per change | Updates carry only new values, so current state can't be rebuilt |
| Current state, unique columns | `primary.keys: "col_a,col_b"`, or a `UNIQUE` index | Merged rows | The key must be unique per row |
| Current state, whole row | `primary.keys: "*"` and `snapshot.scan: cursor` | Merged rows | Duplicate rows collapse; a column added with a default needs a full refresh |
| Current state with soft deletes | a key, as above, and `scd_type: SCD_TYPE_2` | Every version; deleted ones closed, not removed | Old versions accumulate |
| A change log you can rebuild state from | `primary.keys: "*"`, `append.only.ingestion: "true"` and `scd_type: APPEND_ONLY` | One row per change; each update as `d` then `u` | Readers need the current-state query below |
| A small table re-read each run | `append.only.ingestion: "false"`, and `primary_keys` in the pipeline spec | The whole table, merged by those keys | Each run re-reads every row, capped by `snapshot.max.rows` |

### The default change log

| Source operation | Lands as |
|---|---|
| Existing row, copied when `snapshot.mode: initial` | `r` with the row |
| `INSERT` | `c` with the new row |
| `UPDATE` | `u` with the new values only |
| `DELETE` | `d` with the deleted row's values |
| `TRUNCATE` | Stops the flow; a full refresh recovers |

- Every row also carries `_informix_change_lsn`, `_informix_commit_lsn`,
  `_informix_tx_id` and `_informix_commit_time`.
- Set `append.delete.tombstones: "false"` to drop deletes instead of recording
  them, for example on an archive table whose retention purges you don't want in
  the log.
- An update records only its new values, so the log can't say which earlier row
  it replaced. For a table whose rows get updated, you can't rebuild current state
  from this log; use one of the keyed approaches instead.
- The flow starts at the current log position and copies no existing rows. Set
  `snapshot.mode: initial` on the table to copy them first. Any other mode is
  rejected for a change-log table, so if you set `snapshot.mode` at connection
  scope, set it per table here as well.

### Keyed on a set of columns

Name the columns with `primary.keys`, or rely on a `UNIQUE` index. The table then
behaves like any keyed table: the pipeline merges upserts by key and applies
deletes through a separate delete flow.

| Source operation | Effect on the target |
|---|---|
| `INSERT` | Row inserted |
| `UPDATE` | Row updated in place |
| `UPDATE` that changes the key | Old key removed, new key inserted |
| `DELETE` | Row removed |

- The key must be unique per row; a non-unique key silently merges distinct rows.
- Choose the key before the first ingest. Changing it later needs a full refresh.
  Adding a nullable column does not.
- A key column declared nullable may hold NULL, and updates and deletes of such
  rows still apply. A NULL key value can make a key-ordered snapshot skip rows or
  fail, so set `snapshot.scan: cursor` for those tables.
- The default snapshot copies the table in key-ordered chunks, which is cheap
  with an index on the key columns. Without one, set `snapshot.scan: cursor`.

### Keyed on the whole row

`primary.keys: "*"` makes every column, in table order, the key. It gets a
keyless table merged into current state, with inserts, updates and deletes all
applied, when no set of columns can be vouched unique. Without a key the table
lands as a change log in which an update records only its new values, so once
rows are updated, current state can't be rebuilt from it.

When rows are unique as a whole, the full row is an exact identity. Full-row
logging supplies the values of every deleted row and the before-image of every
update, so each change maps onto the target exactly:

| Source operation | Effect on the target |
|---|---|
| `INSERT` | Row inserted |
| `UPDATE` | Old row removed, new row inserted |
| `DELETE` | Row removed |

`primary.keys: "* except(c1, c2)"` keys on every column but the ones named. It suits a
table whose rows are unique as a whole bar a few columns that change or are too wide to
key on, such as an audit timestamp or a free-text note. An update that changes only an
excepted column keeps the row's key, so it updates the row in place instead of deleting
it and inserting a new one. What this section says about the whole-row key holds for
it too, counting only the columns it keys on: a column added later joins the key unless
the list names it, and a dropped column leaves it. `except` and the names are matched
ignoring case. Every name must be a column of the table, so a misspelt name fails the
table instead of letting the column it meant into the key; a column `exclude_columns`
or an unsupported type leaves out still counts as one. A column still to be added can't
be named ahead: to keep it out of the key, stop the pipeline, add the column, add it to
the list, then restart. When a named column is dropped at the source, the table fails
until its name is taken out of the list (with no names left, use `"*"`); the key stays
as it was, so that edit needs no full refresh. An edit that moves an ingested column
into or out of the key changes the key, so on a running table it needs a full refresh.

It fits tables where the row itself is the identity:

- junction tables linking two others, such as `user_roles(user_id, role_id)`
  declared without a primary key;
- lookup or reference tables that were never given a key;
- tag and membership tables, where a row is a fact that is either present or not.

Forced to append, it instead gives a change log that records both sides of every
update, so current state can be rebuilt from history; see
[A change log with a key](#a-change-log-with-a-key). Under `SCD_TYPE_2`, deleted
rows are kept with their validity closed; see [Soft deletes](#soft-deletes).

Use something else when:

- **the table has a natural key.** An explicit `primary.keys` list keeps a row's
  identity across updates, which a whole-row key can't, because every update
  becomes a different key. Under `SCD_TYPE_2` that loses the history of a single
  row.
- **the table holds exact duplicate rows.** They collapse to one, as described
  below.
- **rows are heavily updated or very wide.** Every update becomes a delete plus
  an insert, which is more merge work than an in-place update.

- Exact duplicate rows collapse to one row in the target, and deleting one copy
  at the source removes that row.
- A column appended to the table joins the key. If it's nullable and has no
  default, and the table is already streaming changes, no full refresh is needed.
  Rows from before the change hold NULL in the new column on both sides, so their
  later updates and deletes still match. A column added with a default, or added
  while an incremental copy is still running, needs a full refresh. See
  [Schema evolution without full refresh](#schema-evolution-without-full-refresh).
- A dropped column leaves the key, with no full refresh: the pipeline uses the shorter
  key from its next start. Rows that differed only in that
  column then behave like exact duplicates. A column dropped while an incremental copy
  is still running, or together with an added one, needs a full refresh.
- Paging a snapshot by every column sorts the table once per page, so set
  `snapshot.scan: cursor`.

#### Why not a row hash

Another way to key a keyless table is a synthetic column holding a hash of the
whole row. The connector keys on the columns themselves instead, because here a
hash costs more than it saves:

- **It can't make the snapshot cheaper.** The hash exists only in the
  connector's output, so Informix can't index it or order by it. The per-page
  sort a whole-row key causes is avoided with `snapshot.scan: cursor` instead.
- **It makes merges read more of the target.** A merge skips a target file only
  when that file's key values can't include any incoming key. Hash values are
  random, so every file spans nearly the whole range and almost nothing is
  skipped. Clustering the target on the hash helps, but each changed row still
  lands in its own file. Real columns keep some locality, for example recent IDs
  that tend to change together.
- **It can silently merge distinct rows.** Two different rows with the same hash
  become one. Making that negligible needs a hash of at least 128 bits.
- **It depends on the exact bytes of every value.** The target compares typed
  values, so representation differences it ignores, such as a decimal's trailing
  zeros, can still give two hashes of the same row. If a snapshot row and a later
  change ever render a value differently, the change no longer finds its row.
  With real columns that kind of mismatch can be inspected column by column; with
  a hash it can't.
- **It turns a column addition into a full refresh.** Adding a column changes
  every row's hash, so changes to existing rows no longer find them. With real
  columns, rows from before the change match by their NULL in the new column, so
  the key grows without a full refresh.
- **It costs CPU on every row.** The connector would hash each row in Python,
  including every change row.

A hash does give a compact, single-column key, which can speed up merges on very
wide rows. Its other advantage, a key that is never NULL, doesn't matter here,
because updates and deletes of rows with NULL key values apply normally. If merge
time on a wide table turns out to be dominated by the key, an explicit
`primary.keys` list of a few columns that are unique together is the better fix.

### Soft deletes

With `scd_type: SCD_TYPE_2` on a keyed table, a delete closes the row's current
version instead of removing it: the row stays, with `__END_AT` set. Current rows
are those where `__END_AT` is NULL. Under a whole-row key every update closes the
old row and opens a new one, so each version appears as a separate key rather
than as the history of one row.

### A change log with a key

`append.only.ingestion: "true"` keeps a keyed table on the change-log path. The
key then only detects key changes.

| Source operation | Lands as |
|---|---|
| `INSERT` | `c` with the new row |
| `UPDATE` that keeps the key | `u` with the new values |
| `UPDATE` that changes the key | `d` with the old row, then `u` with the new one |
| `DELETE` | `d` with the deleted row's values |

Under a whole-row key every update changes the key, so the log records both sides
of every change. Current state is then every distinct row whose latest event is
not a delete:

```sql
SELECT * FROM main.informix.orders_log
QUALIFY row_number() OVER (
  PARTITION BY col_a, col_b, col_c          -- every source column
  ORDER BY _informix_change_lsn DESC
) = 1 AND _informix_op <> 'd'
```

This query doesn't work on the default keyless log, where an update doesn't mark
the old row as removed.

Setting only `scd_type: APPEND_ONLY` on a keyed table is not the same. The target
becomes an append table, but the connector stays on the keyed path, so deletes
are silently dropped. Set `append.only.ingestion: "true"`.

As with the default change log, only `snapshot.mode: initial` and `cdc_only` are
allowed. An `initial` snapshot pages by key unless you set `snapshot.scan: cursor`.

### Snapshot-only ingestion

`append.only.ingestion: "false"` on a keyless table skips change capture. Each
pipeline update reads the whole table in one query, held in one executor task,
and the pipeline compares it with the previous copy. That comparison runs by the
`primary_keys` set in the pipeline spec, so set them. The read fails if the table
holds more than `snapshot.max.rows` rows; for this path an unset value means
100,000. It suits small reference tables only.

### Loading existing rows

| Approach | Snapshot modes | Default |
|---|---|---|
| Change log, with or without a key | `initial`, `cdc_only` | `cdc_only`, no existing rows |
| Keyed, on columns or the whole row | any | `incremental` |
| Snapshot-only | not applicable | the whole table, every run |

To load existing rows from Informix `UNLOAD` files instead of a live scan, set
`snapshot.source` and `snapshot.mode: initial`, and supply the extract's log
position in a `_manifest.json` or `snapshot.boundary.lsn`. See
[File-sourced initial snapshot](#file-sourced-initial-snapshot).

### Limits

- `TRUNCATE` stops the flow on every path; a full refresh recovers.
- Exact duplicate rows can't be told apart once the table is keyed; they collapse
  to one row.
- A NULL in a `NOT NULL` key column fails the read as a broken log record.
- Changing a key needs a full refresh. The exception is a whole-row key, with or
  without `except(...)`, growing by a nullable column added without a default, or
  shrinking by a dropped column, once the table is streaming.
- Changing the files under a running file snapshot fails the read with a
  full-refresh error.
- A column of an unsupported type is left out, with a warning. One in the key fails
  the table, except under `primary.keys: "*"` or `"* except(...)"`, which key on the
  columns ingested.

### Option reference

| Option | Default | Effect |
|---|---|---|
| `append.only.ingestion` | `auto` | `auto` appends keyless tables; `true` appends keyed ones too; `false` makes a keyless table snapshot-only |
| `append.delete.tombstones` | `true` | Records deletes on a change log as `d` rows |
| `primary.keys` | catalog key | An explicit key, `"*"` for the whole row, or `"* except(c1, c2)"` for the whole row but those columns |
| `primary.key.from.unique.index` | `true` | Promotes an all-`NOT NULL` `UNIQUE` index to the key |
| `allow.nullable.index` | `false` | Also promotes a `UNIQUE` index with nullable columns |
| `snapshot.mode` | `incremental`, or `cdc_only` for a change log | How existing rows are copied |
| `snapshot.scan` | `keyset` | `cursor` reads a keyed table's snapshot without sorting |
| `snapshot.max.rows` | `0` | Row cap; for snapshot-only tables `0` means 100,000 |
| `snapshot.source` | none | Loads existing rows from `UNLOAD` files |

Full definitions are in [Connection parameters](#connection-parameters).

## Table configuration

```json
{
  "pipeline_spec": {
    "connection_name": "informix_sales",
    "object": [
      {
        "table": {
          "source_table": "orders",
          "destination_table": "orders",
          "table_configuration": {
            "qualified_source_table": "informix.orders",
            "decimal.variable.type": "decimal(38,18)",
            "snapshot.mode": "initial",
            "snapshot.page.size": "2000",
            "max.records.per.batch": "2000",
            "sequence_by": "_informix_change_lsn"
          }
        }
      }
    ]
  }
}
```

Supported source-specific table options are `qualified_source_table`, `decimal.variable.type`, `decimal.variable.column.type`, `snapshot.mode`, `snapshot.source`, `snapshot.boundary.lsn`, `snapshot.split.bytes`, `snapshot.gzip.records.per.batch`, `snapshot.unl.delimiter`, `snapshot.unl.escape`, `snapshot.page.size`, `keyless.snapshot.page.size`, `snapshot.filter`, `row_filter`, `include_columns`, `exclude_columns`, `rename_columns`, `transform_columns`, `snapshot.isolation`, `snapshot.scan`, `snapshot.incremental.datetime.as.string`, `snapshot.max.rows`, `snapshot.max.bytes`, `append.only.ingestion`, `append.delete.tombstones`, `max.records.per.batch`, `cdc.timeout`, `cdc.max.records`, `primary.keys`, `allow.nullable.index`, and `table.migration`. `qualified_source_table` maps the pipeline's logical table name to an Informix `owner.table` name. Standard destination, SCD, key, sequence, and clustering options remain available.

### Column selection

`include_columns` lists the columns to ingest, and `exclude_columns` lists the ones to
leave out. Both take a comma-separated list or a JSON array, use the names of Lakeflow
Connect's managed-connector options, and can't be combined. A column left out is read
nowhere: not by the snapshot `SELECT`, not by the CDC capture, and not into the
destination.

```json
{
  "source_table": "orders",
  "table_configuration": {
    "qualified_source_table": "informix.orders",
    "include_columns": ["order_id", "status", "amount"]
  }
}
```

- **Columns added later:** with `include_columns` they stay out; with `exclude_columns`
  they come in like any appended column.
- **Keys and filters:** key columns must stay selected, and so must every column
  `row_filter` uses. A `primary.keys` override may name other selected columns in place
  of an excluded catalog key. `primary.keys: "*"` keys the table on the selected columns
  only, so leaving out a column that made rows unique can produce duplicate keys.
- **Names:** every name must be a column of the table, so a typo fails instead of letting
  in a column you meant to keep out. After dropping a listed column at the source, take
  it out of the list; that edit needs no full refresh.
- **Unsupported types:** the connector leaves BYTE, TEXT, BLOB, CLOB, collection, and
  other unsupported columns out on its own, with a warning. Listing them in
  `exclude_columns` leaves them out without the warning; `include_columns` can't name them.
- **Changing the selection:** on a running table this fails closed, because rows already
  landed were read under the old selection. Run a full refresh to apply the new one. The
  exception is an `exclude_columns` entry for a column of an unsupported type, which may
  be added or taken out freely: the connector leaves that column out either way.
- **File-sourced snapshots:** an extract still holds every column. The connector matches
  fields by catalog position and keeps the selected ones.

### Column renames

`rename_columns` lands columns under new names. Give it an object from source name to
destination name, or a string of comma-separated `source:destination` pairs:

```json
{
  "source_table": "orders",
  "table_configuration": {
    "qualified_source_table": "informix.orders",
    "rename_columns": {"cust_nm": "customer_name", "ord_dt": "ordered_at"}
  }
}
```

- **What changes:** the names in the reported schema, in every row (snapshots,
  file-sourced snapshots, changes, deletes, and tombstones), and in the primary key the
  connector reports. A renamed key column is the key under its new name.
- **What doesn't:** every other option still names source columns: `include_columns`,
  `exclude_columns`, `primary.keys`, `row_filter`, and `snapshot.filter`. Pipeline-level
  settings such as `sequence_by` see the destination names, because they apply to the
  landed table.
- **Names:** each source name must be a selected column. The renames apply together, so
  two columns can swap names. A destination name can't match another landed column or a
  connector metadata column such as `_informix_op`; the check ignores case, as Delta does.
  A destination name can't hold a space or any of `,;{}()=`.
- **Changing the renames:** on a running table this fails closed, because rows already
  landed under the old names. Run a full refresh to apply new ones. After dropping a
  renamed column at the source, take its entry out; that edit needs no full refresh.

### Value transforms

`transform_columns` replaces columns' values as rows leave the connector, so the raw
values never reach Spark, the destination, or its history. Give it an object from column
name to an expression over that column:

```json
{
  "source_table": "members",
  "table_configuration": {
    "qualified_source_table": "informix.members",
    "transform_columns": {
      "ssn": "MASK(ssn, 4)",
      "member_id": "HASH(member_id)",
      "email": "HASH(LOWER(TRIM(email)))",
      "notes": "NULLIFY(notes)",
      "salary": "ROUND(salary, -3)"
    }
  }
}
```

- **Functions:** every [row filter function](#row-filtering), plus three for transforms:

  | Function | Result |
  |---|---|
  | `MASK(s[, keep[, char]])` | replaces every character but the last `keep` (default 0) with `char` (default `*`); a value no longer than `keep` is masked whole |
  | `HASH(x)` | HMAC-SHA256 of the value's text as 64 hex characters, keyed by the connection's `transform.hash.key`. Numbers hash in one form whatever type carries them (`5`, `5.0`, and `5.00` all hash as `5`; `1.50` as `1.5`), so a hashed key keeps its digest when its column widens; dates and timestamps hash as ISO text, booleans as `true`/`false`, binary as hex |
  | `NULLIFY(x)` | NULL |

- **`HASH`:** set `transform.hash.key` on the connection to a secret of at least 16
  characters, and keep it out of the pipeline spec. Keyed hashing means a hashed SSN or
  email can't be reversed by hashing guesses without the key. The same value hashes the
  same from snapshots, files, and CDC, and across tables sharing the connection, so
  hashed keys still join. The connector records only an HMAC-derived id of the key;
  changing the key on a running table fails closed until a full refresh, since old and
  new hashes would otherwise mix.
- **Keys:** a key column takes only `HASH(column)`, which keeps keys one-to-one, so
  updates and deletes still find their rows. Any other change to a key could map two
  rows to one.
- **What a transform sees:** the value the connector emits, so `CHAR` values without
  their padding and dates and timestamps as ISO text. Transforms run in Python only, so
  they apply the functions above without the `CHAR` padding a filter uses.
- **Types:** a transform lands as its result's type: strings for string functions,
  `MASK`, and `HASH`; integers for `LENGTH`, `CHAR_LENGTH`, `YEAR`, `MONTH`, `DAY`, and
  `WEEKDAY`; and the column's own type otherwise. `ROUND` on a decimal adds one digit of
  precision, since rounding up can carry. A transformed column is nullable when its source
  column is, or when `NULLIFY` or `SUBSTR` (NULL past the end) can produce NULL; `HASH` on
  a `NOT NULL` key keeps it `NOT NULL`. `NVL` and `COALESCE` fall back to a value of the
  column's own type, so on an integer column, or over `LENGTH`, `CHAR_LENGTH`, `YEAR`,
  `MONTH`, `DAY`, or `WEEKDAY`, the fallback must be a whole number.
- **Order:** `row_filter`, the column selection, and the key options see source values;
  `rename_columns` applies after, so a renamed column's transform still uses its source
  name. Change images, deletes, and append-path tombstones are transformed like
  snapshot rows.
- **Changing the transforms:** on a running table this fails closed, because rows
  already landed hold the old values. Run a full refresh to apply new ones. After
  dropping a transformed column at the source, take its entry out; that edit needs no
  full refresh.

If raw values may land but must be hidden from most readers, Unity Catalog column masks
on the destination table do that without any connector option.

### Row filtering

`row_filter` keeps only the rows that match a predicate, written without `WHERE`:

```json
{
  "source_table": "orders",
  "table_configuration": {
    "qualified_source_table": "informix.orders",
    "row_filter": "status IN ('open', 'held') AND amount >= 100"
  }
}
```

Unlike `snapshot.filter`, which only filters snapshot queries, `row_filter` applies
wherever a row can arrive: snapshot queries (combined with `snapshot.filter` by `AND`),
file-sourced snapshots, and the change stream. For changes, the connector evaluates the
filter on each row's before- and after-image:

| Change | Result |
|---|---|
| Insert that matches | Inserted |
| Update, before and after both match | Updated |
| Update that moves a row into the filter | Upserted |
| Update that moves a row out of the filter | Deleted (a `d` tombstone on the append path) |
| Delete of a matching row | Deleted |
| Change whose rows never match | Dropped |

A keyed destination therefore holds exactly the matching rows. Lakeflow Connect's
managed connectors keep rows that stop matching; this connector deletes them.

The predicate is parsed by the connector, so it can be evaluated the same way in SQL and
on change images. That limits it to:

- **Operators:** `=`, `<>` (or `!=`), `<`, `<=`, `>`, `>=`, `[NOT] IN (...)`,
  `[NOT] BETWEEN ... AND ...`, `[NOT] LIKE '...' [ESCAPE '...']`, `IS [NOT] NULL`,
  `AND`, `OR`, `NOT`, and parentheses.
- **Values:** numbers, `'quoted strings'` (double a quote to include one), `TRUE` and
  `FALSE`, `DATE 'YYYY-MM-DD'`, and `TIMESTAMP 'YYYY-MM-DD HH:MM:SS[.ffffff]'`. A
  `TIMESTAMP` can't be more precise than the column's `DATETIME` qualifier.
- **Columns:** numeric (except `FLOAT` and `SMALLFLOAT`), `CHAR`, `NCHAR`, `VARCHAR`,
  `LVARCHAR`, `NVARCHAR`, `BOOLEAN`, `DATE`, and `DATETIME YEAR TO DAY` or finer. Each
  value must match its column's type.
- **Strings:** compare by code point with trailing spaces ignored, which is Informix's
  `CHAR` and `VARCHAR` order in ISO 8859-1 and UTF-8 databases. `NCHAR` and `NVARCHAR`
  collate by locale, so they only take `=`, `<>`, `IN`, and `LIKE`.
- **`LIKE`:** `%` matches any run of characters and `_` matches one. Matching is
  case-sensitive and ignores trailing blanks in both the value and the pattern, as
  Informix does on every string type. A backslash makes the next character literal
  (`'50\%'`), or `ESCAPE` names another escape character (`'50!%' ESCAPE '!'`). The
  connector always sends the escape character to Informix, so the server's
  `DEFAULTESCCHAR` setting doesn't change the result. A pattern can't end with its escape
  character.
- **Functions:** a function can stand in for the column on the left of any test, as in
  `UPPER(TRIM(status)) = 'OPEN'` or `YEAR(ordered_on) >= 2020`. Its first argument is a
  column or another function and the rest are literals. Each one below is evaluated by
  Informix in snapshot queries and by the connector on change images and files, and
  every Python twin was checked against Informix 14.10 on 2,352 cases (on an ISO 8859-1
  database) to give the same result. The twins count bytes and pad `CHAR` values in the
  connection's `DB_LOCALE` (default `en_US.819`), so set it when the database uses another
  code set, such as UTF-8:

  | Function | Takes | Notes |
  |---|---|---|
  | `UPPER(s)`, `LOWER(s)` | strings | ASCII letters only, as Informix maps them: `à` and `É` stay as they are |
  | `TRIM(s)`, `LTRIM(s)`, `RTRIM(s)` | strings | blanks only |
  | `LENGTH(s)` | strings | bytes in the database code set (`DB_LOCALE`), without trailing blanks |
  | `CHAR_LENGTH(s)` | strings | characters, counting a `CHAR` column's padding to its byte width |
  | `SUBSTR(s, start[, length])` | strings | `start` from 1; a start past the end gives NULL |
  | `REPLACE(s, from[, to])` | strings | `to` defaults to `''` |
  | `LPAD(s, n, pad)`, `RPAD(s, n, pad)` | strings | a longer value is cut to `n` |
  | `NVL(x, value)`, `COALESCE(x, value)` | any | `value` replaces NULL, padded like a `CHAR` column; in a transform it takes the column's own type |
  | `ABS(n)`, `ROUND(n[, digits])`, `TRUNC(n[, digits])` | numbers | `ROUND` rounds halves away from zero; a float is taken by the digits it shows, so `ROUND(1.15, 1)` is 1.2; `digits` from -32 to 32 |
  | `MOD(n, divisor)` | numbers | truncates both to integers first, so `MOD(2.5, 3)` is 2 |
  | `YEAR(d)`, `MONTH(d)`, `DAY(d)`, `WEEKDAY(d)` | `DATE`, `DATETIME` | `WEEKDAY` counts from 0 for Sunday |

  A `CHAR` value is blank-padded to its width before a function sees it, as on
  Informix. Functions that depend on the clock or the session (`TODAY`, `CURRENT`,
  `USER`) aren't offered: a row's membership would change without any change event to
  carry it, so CDC couldn't keep the target right. Filter on those downstream instead.
- **NULL:** follows SQL's three-valued logic; a row is kept only when the predicate is
  true. Functions give NULL for a NULL input, except `NVL` and `COALESCE`.

Changing the filter on a running table fails closed until a full refresh, since rows
already landed were selected under the old one. Formatting-only edits, such as spacing,
keyword case, or `!=` for `<>`, don't count as changes.

### Snapshot modes

`snapshot.mode` is a per-table option. It controls what happens before or while
the table enters CDC; it does not override Lakeflow's durable checkpoint. The
default is `incremental`. It may also be set once at connection scope as the
default for every table, and overridden per table.

For an append-only table without a primary key, an unset mode defaults to
`cdc_only`. Such a table supports `cdc_only` or `initial`: `initial` streams one
unordered forward-only cursor under repeatable read into durable bounded pages,
then continues CDC from the snapshot LSN. Other modes require key-based snapshot
progress and are rejected.

| Mode | Behavior |
|---|---|
| `incremental` | Default. Begin CDC immediately at the captured boundary and copy existing rows in primary-key chunks interleaved with the change stream, one chunk per microbatch. No long-lived repeatable-read transaction is held over the whole table; each chunk is read in its own short repeatable-read transaction and its `r` rows are stamped with the LSN captured just before that chunk. Correctness for keyed (`apply_changes`) targets follows from LSN sequencing — any concurrent or later change to a chunked key commits at a higher `_informix_change_lsn` and supersedes the snapshot row in Auto CDC's sequence-merge, so no in-memory deduplication window is required. Rows inserted beyond the key range captured at snapshot start are left to the change stream. Tables whose primary key includes one or more `DATETIME` columns (alone or combined with non-`DATETIME` key columns in a composite key) are chunked by a fixed-width string cast of each `DATETIME` key column when `snapshot.incremental.datetime.as.string` is true (the default). Any contiguous `DATETIME` qualifier is supported, including `HOUR`-anchored time-of-day ranges. Set the option false to force the blocking `initial` snapshot for such tables. See [Incremental snapshot and append-only targets](#incremental-snapshot-and-append-only-targets). |
| `initial` | If the table has no checkpoint, take a single transactionally consistent (blocking) snapshot under one repeatable-read transaction and continue from its captured Informix LSN. If a checkpoint exists, resume CDC without another snapshot. Use this when you require a single point-in-time snapshot LSN for the whole table rather than per-chunk boundaries. |
| `initial_only` | Take the initial snapshot, checkpoint its boundary, and emit no later CDC records. Both upsert and delete readers then remain exhausted. Snapshot continuation pages still finish normally after a restart. |
| `cdc_only` | Do not copy existing rows. Enable full-row logging, record the current schema and LSN, and stream only transactions after that boundary. It requires CDC-supported column types; keyless tables use append-only ingestion. |
| `auto_snapshot` | Behave like `incremental`, but automatically begin a new PK-chunked snapshot if the checkpoint's restart LSN has fallen out of the retained Informix logical logs. CDC begins immediately at the new deterministic boundary while existing rows are copied in chunks; the independently checkpointed delete reader adopts the same boundary. If the pipeline stops before the delete reader's move to that boundary commits, the next update replays it by landing on the boundary without reading, with a warning in the event log. An upsert batch replayed from a start the log no longer holds resnapshots at a later boundary instead, as a first batch does. Other checkpoint or schema errors still fail closed. |
| `recovery` | Rebuild missing immutable schema-history state from an existing stream checkpoint, then resume CDC without copying table data. It is accepted only when the current source schema fingerprint exactly matches the checkpoint and the checkpoint LSN is still retained. If either condition is false, run a full refresh. Do not use this mode to accommodate a real schema change. |

To move a table to a **new flow** — an SCD1→append-only switch or a destination
relocation — without re-snapshotting, keep its `snapshot.mode` and set the separate
`table.migration` option; see
[Migrating a table without a re-snapshot](#migrating-a-table-without-a-re-snapshot).

For example, to start CDC at the current source position without ingesting
existing rows:

```json
{
  "source_table": "members",
  "table_configuration": {
    "qualified_source_table": "informix.members",
    "snapshot.mode": "cdc_only"
  }
}
```

Changing `snapshot.mode` does not erase a checkpoint. Use a pipeline full
refresh when deliberately replacing existing destination contents or when
forcing a fresh snapshot of a table that already has a checkpoint.

#### Migrating a table without a re-snapshot

Two changes normally force a table to be re-snapshotted from scratch, because each
one gives the table a **new Lakeflow flow with an empty checkpoint**:

- **Changing `scd_type`** between a keyed merge (`SCD_TYPE_1`/`SCD_TYPE_2`) and
  `APPEND_ONLY` — the pipeline swaps a merge flow for an append flow.
- **Moving a table's destination** to a different catalog or schema — a new
  destination name is a new streaming table and flow.

The `table.migration` option lets the table keep its place in the change stream across
that switch instead of re-reading it. It is **orthogonal to `snapshot.mode`** — you
leave the table's real snapshot policy in place and just toggle `table.migration`.
Every migration run **records a checkpoint, emits no rows, and stops** — it never
streams. The first run parks the table's current CDC position in the connector's
Lakebase state (keyed by the **source** table, so it survives any destination or flow
change); the second seeds the new flow from that parked position and stops. Clearing
`table.migration` afterward (the **Restore** step) is what resumes streaming, now from
the recorded position. The boundary is exact — no change is dropped or duplicated at
the seam — and no snapshot is re-read.

The runbook differs slightly for the two cases. In both, "run the pipeline" means a
normal triggered update, and every edit is to the table's `table_configuration` in
your pipeline spec.

##### Case 1 — switch `scd_type` (e.g. SCD Type 1 → append-only)

1. **Capture.** On the existing (keyed) configuration, add `table.migration: true`
   and run the pipeline. The table parks its CDC position and stops. Make this the
   **last** run before the switch — a normal run in between moves the table past the
   parked position. (Re-running the capture step itself is safe.)

   ```json
   {
     "source_table": "orders",
     "table_configuration": {
       "qualified_source_table": "informix.orders",
       "table.migration": "true"
     }
   }
   ```

2. **Cutover.** Change `scd_type` to `APPEND_ONLY` and add
   `append.only.ingestion: true` (required so a **keyed** table is streamed as
   append rather than re-snapshotted), keeping `table.migration: true`. Run the
   pipeline. The append flow records the parked position as its checkpoint and stops —
   no re-snapshot, no rows yet. (Restoring in step 3 resumes streaming from there.)

   ```json
   {
     "source_table": "orders",
     "table_configuration": {
       "qualified_source_table": "informix.orders",
       "scd_type": "APPEND_ONLY",
       "append.only.ingestion": "true",
       "table.migration": "true"
     }
   }
   ```

3. **Restore.** Remove `table.migration` (or set it to `false`) and run normally from
   then on. This run resumes streaming from the recorded checkpoint.

Because the destination table is unchanged, its existing rows stay in place and the
append stream simply continues on top of them.

##### Case 2 — migrate the destination to a new catalog/schema

1. **Capture.** Same as Case 1, step 1: add `table.migration: true` on the current
   configuration and run the pipeline once to park the position.

2. **Backfill the new table.** `table.migration` resumes the *stream* position but does
   not copy existing rows, so a brand-new destination would otherwise contain only
   changes after the switch. Copy the current table into the new location first
   (for example `CREATE TABLE new_catalog.new_schema.orders DEEP CLONE
   old_catalog.old_schema.orders`, or a one-time backfill flow). Do this after the
   capture run so the copy matches the parked position.

3. **Cutover.** Point the table at the new catalog/schema and add
   `table.migration: true`, then run the pipeline. The flow for the new destination
   records the parked position as its checkpoint and stops — no re-snapshot, no rows
   yet.

4. **Restore.** Remove `table.migration` and run normally. This run resumes
   streaming, appending new changes onto the backfilled rows.

##### Notes and safeguards

- **Migrating a table that is still snapshotting.** You do not have to wait for a
  table to finish its initial load before capturing — either snapshot strategy can be
  migrated mid-flight, and neither triggers a *second* snapshot.
  - **Incremental** (the default: a primary-key-chunked copy interleaved with CDC) is
    already a stream-phase position, so capture parks it directly; after Restore the new
    flow **continues the copy from its cursor**, re-reading nothing and copying only the
    remaining rows.
  - **Blocking `initial`** (`snapshot.mode=initial`, a single bulk read) parks its
    mid-serve position too. Its staged pages are carried **by reference**: the cutover
    records the capturing flow's scope on the offset (`stage_scope`) so the new flow
    reads those already-staged pages **in place** — no copy — finishes the snapshot from
    the parked page, then streams under its own scope. Because the pages are referenced,
    the cutover must happen within `snapshot.staging.retention.days` (the age-based sweep
    reclaims abandoned staging); a longer gap reclaims the pages and forces a re-snapshot.
- **Keep the two runs close together.** The parked position must still be within
  Informix's retained logical logs at cutover; a long gap risks it aging out.
- **Fail-closed when there is nothing to migrate.** Migration never snapshots, so if a
  run finds an empty checkpoint with no parked token it stops with an explanatory error
  rather than silently starting a snapshot. This covers both a cutover whose capture was
  never run (or was already consumed) and a capture applied to a flow that has not yet
  reached a hand-off-able position (steady-state streaming, an in-flight incremental
  copy, or a mid-serve snapshot). Run the flow without `table.migration` until it
  is streaming (or mid initial snapshot), then set `table.migration=true` — for an
  `scd_type` switch, capture before you change `scd_type`.
- **Fail-closed on a schema change.** The parked position is tagged with the source
  schema at capture time. If the source table's schema changes between capture and
  cutover, the cutover stops with an explanatory error instead of resuming at a
  position that no longer aligns with the current columns. Re-run the capture step
  against the current schema, or start fresh (`cdc_only`/`initial`).
- **Deletes are carried across the seam.** For a relocation that keeps a keyed
  `scd_type` (a table with a delete channel), the delete reader's position is handed
  off on its own channel alongside the upsert position, so deletes are resumed at
  exactly the parked point — none are dropped or double-applied at the boundary. (An
  `scd_type` switch to append-only has no delete channel, so this does not apply.)
- **Relocation baseline.** For a destination move, `table.migration` resumes the read
  position but does not re-emit rows already written to the old destination, so the
  portion emitted before cutover — a mid-incremental prefix, or the snapshot pages a
  blocking `initial` serve had already delivered — must still be backfilled into the new
  table (Case 2, step 2). The remaining, not-yet-served blocking-snapshot pages are
  finished into the new destination automatically (by reference; see the note above).
  An `scd_type` switch reuses the same table and needs no backfill.
- **Alternatives to migration.** To start a table fresh instead of preserving its
  position, leave `table.migration` off and use `snapshot.mode=cdc_only` (stream new
  changes only, no history) or `snapshot.mode=initial` (a full one-time snapshot).

#### Incremental snapshot and append-only targets

The default `incremental` mode delegates per-key deduplication to the target
flow. For `SCD_TYPE_1` and `SCD_TYPE_2` targets (Lakeflow Auto CDC), rows are
merged by key and ordered by `sequence_by` (`_informix_change_lsn` by default),
so a snapshot `r` row is always superseded by any later change to the same key
and the materialized state is exact.

For `APPEND_ONLY` targets there is no key merge: every emitted row is retained.
Because each chunk is read in its own repeatable-read transaction, its `r` rows
are consistent as-of that chunk's LSN, and no row is ever lost or fabricated.
The only artifact is that a key changed just before its chunk boundary can
appear twice — once as the change event and once as an `r` row carrying the same
value at a nearby LSN. An append-only consumer that reconstructs state by
ordering on `_informix_change_lsn` (the documented contract) still resolves the
correct value. If you require an append changelog with no duplicated snapshot
rows, use `snapshot.mode=initial` for that table.

#### File-sourced initial snapshot

Set `snapshot.source=<Volume path>` (with `snapshot.mode=initial`) to serve a
table's initial snapshot from Informix **UNLOAD (`.unl`) files** you extracted to a
Unity Catalog Volume, instead of a live repeatable-read scan of the source. The
connector reads and shapes those files (`_informix_op="r"`), then transitions to the
CDC stream at the boundary — the same handoff a live snapshot makes, so the stream
resumes at the boundary and never re-emits snapshot rows. It reads splits in parallel
across executors via Files-API ranged GETs, splitting each file into ~`snapshot.split.bytes`
(default 50 MiB) pieces at record boundaries, so a large table fans out into byte-balanced
splits. Splitting by bytes needs no whole-file scan to plan — the connector seeks to each
target and reads only a small window to snap to the next record. The serve is **windowed
and resumable**: each microbatch advances `stream.partitioned.snapshot.pages.per.batch`
splits (default 8), so a large extract drains over several bounded microbatches and a
restart mid-snapshot picks up at the last committed split rather than restarting. Files
must be UNLOAD-delimited (`|` delimiter, backslash escaping, empty field = NULL), and every
file in the directory is treated as one snapshot at a single boundary.

**HPL DELIMITED files.** The extract need not come from `dbaccess` `UNLOAD` — Informix's
High-Performance Loader (`onpload`/`ipload`) **DELIMITED** output is the same
newline-terminated, escaped, delimited shape and ingests through the same path. It differs
from `UNLOAD` only in that its field delimiter and escape character are job-configured (and,
unlike `UNLOAD`, HPL does not honor `DBDELIMITER`), and it writes no trailing delimiter — the
parser already tolerates a missing trailing delimiter, and `||` is NULL for both. Set
`snapshot.unl.delimiter` and `snapshot.unl.escape` (each a single character; both default to
`UNLOAD`'s `|` and `\`) to match the HPL job when they differ from those defaults; set
`snapshot.unl.escape=""` to disable escape processing for an HPL job that writes no escapes.
The delimiter/escape apply to the serial and the partitioned (per-executor) reads alike, and
the record terminator is always a newline. HPL's **fixed-position (COBOL)** and
**Informix-internal binary** formats are **not** supported — they are not self-describing
(they need the ipload map's field widths/types) — so configure the HPL job to emit
newline-terminated DELIMITED output.

**Gzip.** A file is decompressed transparently when it is gzip-compressed — detected by its
`1f 8b` magic bytes, so `.unl.gz` (or even a mislabelled `.unl` that is actually gzip) works.
Because a gzip stream is not seekable, a compressed file is **one non-splittable split**: by
default it is streamed and decompressed whole on a single executor, and a restart re-reads it
from the start. Parallelism for compressed extracts therefore comes from producing **multiple
`.unl.gz` files** (e.g. `UNLOAD` to N files, gzip each), not from splitting within a file.
For mid-file resume, set `snapshot.gzip.records.per.batch`: each gzip file is then served on
the driver that many records per microbatch, and a restart resumes after the last committed
record instead of re-reading the file. `snapshot.split.bytes` has no effect on a gzip file.
Plain and gzip files may be mixed in one directory. Concatenated gzip members
(`cat a.gz b.gz`) are handled.

**Extract validation.** A file snapshot resumes by position in a split plan rebuilt from the
directory on every read, so the extract must not change until the snapshot finishes. When
the snapshot starts, the connector pins a manifest of the extract: each file's name, size,
modification time, and a fingerprint hashing its size with its first and last megabyte.
Every later read checks every file's name, size and modification time against it, and
re-checks the fingerprint of each file that read serves. Any file added, removed or changed
fails the read with a full-refresh error instead of silently skipping or repeating rows.
Modification times are compared within a few seconds, because a Volume reports an unsettled
time just after a write. The fingerprint samples rather than hashes whole files, so an edit
confined to the middle of a file that also keeps its size and modification time is not
detected. To recover, run a full refresh to ingest the current extract, or restore the
original files with their modification times.

**Boundary LSN.** For CDC to resume correctly the connector needs the log position the
extract corresponds to. It is resolved per table, **first hit wins**:

1. `snapshot.boundary.lsn=<X>` — the LSN you captured at extract time.
2. else a `_manifest.json` in the `snapshot.source` directory: `{"boundary_lsn": "<X>"}`
   (other keys are ignored, so the marker is extensible).
3. else the connector **self-pins** its own registration LSN (the fallback; correct
   only if the extract reflects the table at ingest time).

The manifest may also carry an optional `"boundary_time": "<epoch-seconds>"` — the source
UTC time the extract reflects. When present it becomes the `_informix_commit_time` of the
served `r` rows (a file-sourced snapshot has no live boundary to query); when absent those
rows carry `NULL`. Capture it in the **same transaction** as the boundary LSN (the recipe
below does) so it matches the extract's as-of point.

A supplied boundary is authoritative (the CDC stream and delete-channel bootstrap both
start at it) and is validated against the source's retained/current log range — a
boundary **below the minimum retained LSN fails closed** (the logical log recycled past
it, so there would be a gap), as does one above the current LSN. You are responsible for
the extract reflecting the table at the boundary (quiesce, or extract-then-ingest);
the connector does not verify alignment, and producing the `.unl` files (via `UNLOAD`
or HPL) is outside the connector's scope.

#### Reference recipe: extracting `.unl` files and their manifest

Producing the extract is your responsibility, not the connector's — but the
consistency requirement above (the `.unl` files and the `boundary_lsn` must describe
the **same** point in the log) is easy to get subtly wrong, so this is a reference
recipe that gets it right. It is not a shipped tool; adapt it to your environment.

The key idea is that the boundary LSN and the `UNLOAD` are read in **one
`REPEATABLE READ` transaction, LSN first**. Under that isolation the `UNLOAD` sees the
table as of the transaction's read view, and the LSN captured just before it is `≤`
that view — so the connector's CDC stream, which discards commits at or below the
boundary, re-applies every change made after the extract with neither gap nor loss.
The LSN encoding must match the connector's capture boundary:
`(uniqid << 32) + ((used - 1) << 12)`, the **start** of the current logical log page in
`sysmaster:syslogs` — never its end (`used << 12`), because `used` counts the page being
written, and a commit landing later in that page would otherwise fall at or below the
boundary and be discarded by the stream as already captured.

Run this **on a host with `dbaccess`**. Per table it writes, under `OUTDIR/<table>/`,
the `<table>.unl` extract and a `_manifest.json` holding `{"boundary_lsn": "<X>",
"boundary_time": "<epoch-seconds>"}`:

```bash
#!/usr/bin/env bash
# extract_unl.sh <database> <outdir> <table> [table ...]
set -euo pipefail

DB="${1:?usage: extract_unl.sh <database> <outdir> <table> [table ...]}"
OUTDIR="${2:?output directory}"
shift 2
TABLES=("$@")
[ "${#TABLES[@]}" -gt 0 ] || { echo "no tables given" >&2; exit 2; }

for tbl in "${TABLES[@]}"; do
  dir="$OUTDIR/$tbl"; mkdir -p "$dir"
  lsn_file="$dir/.lsn.unl"; unl_file="$dir/$tbl.unl"

  # One session, one transaction: capture the LSN + source UTC time, then UNLOAD.
  dbaccess - <<SQL
DATABASE $DB;
SET ISOLATION TO REPEATABLE READ;
BEGIN WORK;
UNLOAD TO '$lsn_file' DELIMITER '|'
  SELECT uniqid, used, DBINFO('utc_current') FROM sysmaster:syslogs WHERE is_current = 1;
UNLOAD TO '$unl_file' DELIMITER '|'
  SELECT * FROM $tbl;
COMMIT WORK;
SQL

  IFS='|' read -r uniqid used utc _ < "$lsn_file"       # ".lsn.unl" is "uniqid|used|utc|"
  # (uniqid<<32)+((used-1)<<12): the start of the current log page, matching the
  # connector's capture boundary (see the note above the script).
  boundary_lsn=$(( uniqid * 4294967296 + (used > 0 ? used - 1 : 0) * 4096 ))
  rm -f "$lsn_file"

  # Informix UNLOAD on Windows terminates records with CRLF; the connector splits
  # records on \n, so a trailing CR would ride along on each row's last field.
  # Normalize CRLF -> LF on Windows shells. No-op on Unix hosts (UNLOAD writes LF).
  case "$(uname -s 2>/dev/null)" in
    MINGW*|MSYS*|CYGWIN*|Windows_NT) perl -i -pe 's/\r\n/\n/g' "$unl_file" ;;
  esac

  # boundary_time becomes the served r rows' _informix_commit_time (source UTC seconds).
  printf '{"boundary_lsn": "%s", "boundary_time": "%s"}\n' "$boundary_lsn" "$utc" \
    > "$dir/_manifest.json"
  echo "extracted $tbl: $(wc -l < "$unl_file") rows, boundary_lsn=$boundary_lsn -> $dir"
done
```

The script is portable across every OS Informix runs on — it uses `perl` (present in
the base install on Unix hosts and bundled with Git Bash/MSYS2/Cygwin) rather than
GNU-specific `sed`, so it behaves the same on BSD userland too. Per platform:

- **Linux** (x86-64, POWER, IBM Z), **AIX**, **Solaris**, **HP-UX** — run as-is.
  `UNLOAD` writes bare-LF records, so the CRLF branch is a no-op; just ensure
  `dbaccess` is on `PATH` and the extract user can write `OUTDIR`.
- **Windows** (x86-64) — run it under **Git Bash, MSYS2, Cygwin, or WSL** (native
  `cmd.exe`/PowerShell cannot run the bash script). Informix `UNLOAD` on Windows
  terminates records with **CRLF**; the connector splits on `\n`, so the script
  normalizes CRLF → LF (equivalent to running `dos2unix` on each `.unl`). Under WSL
  the Informix binaries are Linux and write LF, so the branch stays a no-op.
- **macOS** — Developer Edition only (dev/test, not production). `UNLOAD` writes LF and
  the BSD `perl` handles the script unchanged.

`dbaccess` `UNLOAD` writes to the **local filesystem of the host running it**, not to a
UC Volume, so upload each table's directory to the Volume the pipeline's
`snapshot.source` points at, then run the pipeline:

```bash
./extract_unl.sh mydb /tmp/extract members orders

databricks fs cp -r /tmp/extract/members \
  dbfs:/Volumes/<catalog>/<schema>/informix_unl/members
```

Notes:

- The explicit `DELIMITER '|'` guards against a site-customized `DBDELIMITER`; the rest
  is `UNLOAD` default format (backslash escaping, empty field = NULL, trailing `|`),
  which is what the decoder assumes. `SELECT *` yields column-definition order, which
  the connector maps positionally.
- One plain `.unl` per table is the best default — the connector byte-splits it across
  executors with no whole-file scan. Only reach for `gzip` when transfer size matters,
  and then produce **multiple** `.unl.gz` files (`UNLOAD` ranges to N files, gzip each),
  because a gzip file is one non-splittable split. For one large `.unl.gz` that must resume
  mid-file, set `snapshot.gzip.records.per.batch` instead.
- If you set `snapshot.boundary.lsn` on the table it overrides the manifest, so the
  `_manifest.json` is only needed when you would rather not carry the LSN in the spec.

##### Unloading to multiple files

A single `UNLOAD` statement writes one file, and there is no "split into N" option — but
you get multiple files by issuing **several ranged `UNLOAD`s in the same transaction**.
Keeping them in one `REPEATABLE READ` transaction (with the LSN capture first) is what
makes every part, and the single `boundary_lsn`, describe the same snapshot point. This is
mainly worth doing for **gzip** extracts: a `.unl.gz` is one non-splittable split, so N
compressed files are the only way to parallelize them (a single plain `.unl` the connector
already byte-splits across executors on its own).

The script partitions on `MOD(<key>, N)`, so pass an integer split key — a numeric primary
key, or the `rowid` pseudo-column for a **non-fragmented** keyless table (a fragmented table
has no reliable `rowid`; partition on a real column instead):

```bash
#!/usr/bin/env bash
# extract_unl_multi.sh <database> <outdir> <files> <table> <split_key>
set -euo pipefail

DB="${1:?usage: extract_unl_multi.sh <database> <outdir> <files> <table> <split_key>}"
OUTDIR="${2:?output directory}"
FILES="${3:?number of files (N)}"
TBL="${4:?table}"
KEY="${5:?integer split-key expression, e.g. a numeric PK or rowid}"

dir="$OUTDIR/$TBL"; mkdir -p "$dir"
lsn_file="$dir/.lsn.unl"

# Build one transaction: capture the LSN + source UTC time, then one UNLOAD per MOD bucket.
sql="DATABASE $DB;
SET ISOLATION TO REPEATABLE READ;
BEGIN WORK;
UNLOAD TO '$lsn_file' DELIMITER '|'
  SELECT uniqid, used, DBINFO('utc_current') FROM sysmaster:syslogs WHERE is_current = 1;"
for ((k = 0; k < FILES; k++)); do
  sql="$sql
UNLOAD TO '$dir/$TBL.p$k.unl' DELIMITER '|'
  SELECT * FROM $TBL WHERE MOD($KEY, $FILES) = $k;"
done
sql="$sql
COMMIT WORK;"
printf '%s\n' "$sql" | dbaccess -

IFS='|' read -r uniqid used utc _ < "$lsn_file"
# (uniqid<<32)+((used-1)<<12): start of the current log page (the connector's capture boundary).
boundary_lsn=$(( uniqid * 4294967296 + (used > 0 ? used - 1 : 0) * 4096 ))
rm -f "$lsn_file"
printf '{"boundary_lsn": "%s", "boundary_time": "%s"}\n' "$boundary_lsn" "$utc" \
  > "$dir/_manifest.json"

# On Windows shells, normalize each part's CRLF -> LF (see the per-OS note above).
case "$(uname -s 2>/dev/null)" in
  MINGW*|MSYS*|CYGWIN*|Windows_NT)
    for f in "$dir/$TBL".p*.unl; do perl -i -pe 's/\r\n/\n/g' "$f"; done ;;
esac

# Optional: gzip each part for transfer. Multiple .unl.gz files are what give a
# compressed extract its executor parallelism (each is one non-splittable split).
# gzip "$dir/$TBL".p*.unl

echo "extracted $TBL into $FILES parts, boundary_lsn=$boundary_lsn -> $dir"
```

```bash
./extract_unl_multi.sh mydb /tmp/extract 4 orders order_id
gzip /tmp/extract/orders/orders.p*.unl        # optional, for gzip parallelism
```

The connector treats **every** file in the `snapshot.source` directory as one snapshot at
the single boundary, so `orders.p0.unl … orders.p3.unl` (plain or `.unl.gz`) plus one
`_manifest.json` is a valid, parallelizable extract. `MOD` coverage is even only if the key
is evenly distributed; `MOD(key, N) = k` for `k` in `0 … N-1` tiles the whole table with no
gap or overlap regardless. HPL DELIMITED output works the same way — set
`snapshot.unl.delimiter`/`snapshot.unl.escape` to match the job.

### SCD Type 2 sequencing and validity columns

Set `scd_type` to `SCD_TYPE_2` to retain row history. Lakeflow derives the types and values of `__START_AT` and `__END_AT` from `sequence_by`. The default `_informix_change_lsn` sequence is the safest ordering value, but it produces string validity columns containing zero-padded 20-digit decimal LSNs:

```json
{
  "scd_type": "SCD_TYPE_2",
  "sequence_by": "_informix_change_lsn"
}
```

To produce timestamp validity columns, sequence on a non-null source timestamp instead:

```json
{
  "qualified_source_table": "informix.members",
  "scd_type": "SCD_TYPE_2",
  "sequence_by": "updated_at"
}
```

This changes Lakeflow Auto CDC ordering and deduplication to `updated_at`; it does not merely change the display type. The connector continues using Informix LSNs for native CDC reads, recovery, and source checkpoints. Use a timestamp only when it is updated for every source change and has enough precision to order repeated changes to the same key. Otherwise retain `_informix_change_lsn`. Changing an existing SCD2 target between LSN and timestamp sequencing changes the validity-column schema and requires recreating or fully refreshing that target. A null `__END_AT` is expected for the currently active version.

### Lakebase-backed shared state

Connection capacity slots, backlog hints, the capacity limit, and every immutable
per-table state record (schema nodes, initialization, schemas, trigger scopes,
snapshot manifests, delete floors) live in a Lakebase Autoscaling Postgres endpoint. Snapshot
page *payloads* remain on the Volume named by `snapshot.staging.location`, because
they are large gzip blobs that suit object storage; nothing else uses a Volume.

Coordination needs one primitive: an atomic compare-and-swap. Postgres provides it
directly, so claiming a slot is a single `UPDATE ... FOR UPDATE SKIP LOCKED` and
electing a record is a single `INSERT ... ON CONFLICT DO NOTHING RETURNING`.

Provisioning is self-contained. The first reader that needs state creates the
project, branch, compute endpoint, and schema, keyed by a hash of `hostname`,
`port`, and `server`; every later reader in every later update finds them.

There are two separate identities, with different lifetimes and different rights:

| | Role | Credential | Used for |
| --- | --- | --- | --- |
| **State** | `informix_state_user` (fixed) | `lakebase.password` (**required**) | every ordinary read and write of state |
| **Admin** | `lakebase.admin_user` | `lakebase.admin_password`, or an OAuth credential when unset | creating the state role and resetting its password |

The state role is long-lived and needs no rights beyond its own tables, so nothing
in a running stream depends on a credential that can expire. The admin role needs
`CREATEROLE` and is used only at startup. Keeping them apart is the point: the
credential handed to every reader process is not one that can create roles.

`lakebase.password` is therefore required — without it there is no long-lived
credential for state access at all, and a missing value fails the update while it
is being set up rather than on the first microbatch that needs state. The role
name is deliberately not configurable: every pipeline sharing a Lakebase endpoint
must agree on which role owns the state tables, so naming it per connection could
only misconfigure that.

Startup tries the state login first and only falls back to the admin identity if
it fails. `lakebase.admin_user` defaults to the pipeline's own identity, which the
connector resolves for itself, and `lakebase.admin_password` is only needed where
an OAuth credential cannot be minted.

The configured password is the source of truth: a role whose password does not
match it is repaired to match, which also invalidates the previous password. The
role is never dropped — it owns the state tables, so dropping it would discard the
shared CDC state and force every table to resnapshot. (Postgres refuses the drop
outright for that reason once the tables exist.)

Provisioning needs a workspace credential, and only the pipeline's **driver** has
one. The reader itself runs in processes with no ambient identity at all — no auth
environment variables, no config file, no usable `dbutils` — so the connector
captures the credential when the pipeline module is loaded and carries it to where
provisioning happens. Nothing needs configuring for this; `lakebase.workspace.host`
and `lakebase.workspace.token` exist only as an override for running outside a
Databricks runtime.

Defaults, and the measurements behind them:

| Setting | Default | Rationale |
| --- | --- | --- |
| `lakebase.autoscale.min.cu` | `0.5` | smallest value the API accepts |
| `lakebase.autoscale.max.cu` | `2` | steady-state query cost is ~11 ms, so this is ample headroom |
| `lakebase.suspend.timeout.seconds` | `60` | resume from suspended costs ~3.3 s, and a streaming pipeline never idles that long |

Capacity and suspend settings apply **only when the connector creates the
project**. That is a constraint of the API rather than a choice: it accepts
`suspend_timeout_duration` solely through a project's
`default_endpoint_settings` and does not apply it retroactively to an endpoint
that already exists. Resizing a live endpoint is therefore an operator action
(`databricks postgres update-endpoint`), not something a reader does implicitly.

Requirements and caveats:

- A Postgres driver — `psycopg2` **or** `psycopg` (v3) — must be importable on the
  compute that runs the connector, plus permission to create Lakebase projects.
  `psycopg2` is preinstalled on classic Databricks runtimes, but **serverless
  pipeline compute may have neither**. When it does not, add a **prebuilt binary
  wheel** to the pipeline's environment dependencies: `psycopg2-binary` (matches the
  connector's first-choice import) or `psycopg[binary]`. Do **not** use plain
  `psycopg` — it is a source distribution that compiles against `libpq` and needs
  `pg_config` at install time, which pipeline clusters lack, so the install fails
  with `ENVIRONMENT_PIP_INSTALL_ERROR` and the connector then raises
  `LakebaseStateError: needs psycopg2 or psycopg installed on the runtime`.
- `snapshot.staging.location` is now required and has no default, because the
  shared-state location it used to fall back on no longer exists.
- `lakebase.password` is required. Choose a value once and supply the same one on
  every update; changing it resets the role's password rather than failing.
- **This is a breaking change for an existing deployment.** Durable schema nodes
  previously held on the Volume are not migrated, and `cdc.shared.state.location`
  is no longer accepted. Update the connection and run a full refresh.
- The endpoint bills for compute whenever it is awake, so a pipeline that never
  idles never scales to zero.

#### Sharing one project across Informix servers

By default each Informix server gets its own project. To keep the state of
connections to several servers in one project, set `lakebase.project.id` to the
same id on each of them. Nothing else changes: every state row carries a
namespace, so the servers' rows never mix.

- Connection slots, waiters, the capacity limit and backlog hints are namespaced by
  `hostname`, `port` and `server`. Each server keeps its own connection budget, so
  sharing a project doesn't pool capacity between servers.
- State records and CDC handoffs are namespaced by those three plus `database`, so
  two databases never share a record.

Every connection sharing the project must use the same:

- `lakebase.password`. They all log in as `informix_state_user`, and a connection
  whose password doesn't match resets the role to its own, which breaks the other
  connections' next logins.
- `lakebase.database`, the database that holds the state tables.
- Connector version, or compatible ones. The connections share one set of state
  tables, and a newer connector upgrades them in place.

Also:

- Connections to the same Informix server must use the same project, whether that's
  the derived one or the override. In different projects their slots are counted
  separately, so together they can open more than `max.concurrent.connections`.
- Existing connections can stay on their derived projects; only connections that
  set the override use the shared one. A pipeline moved to another project leaves
  its state behind, so it needs a full refresh.
- `lakebase.autoscale.*` and `lakebase.suspend.timeout.seconds` apply only for the
  connection that creates the project. Size the endpoint for every pipeline that
  uses it, and resize it with `databricks postgres update-endpoint`.
- Every pipeline's run-as identity needs access to the project, not only the one
  that created it. If a pipeline ever has to repair the state role, its admin
  identity also needs `CREATEROLE` there; otherwise set `lakebase.admin_user` and
  `lakebase.admin_password`.
- Use an id that doesn't start with `informix-state-`. With
  `state.gc.drop.unused.projects` on, a connection deletes unused projects with
  that prefix other than its own. A project named otherwise is never deleted, and
  connections that set `lakebase.project.id` never delete projects.

## Operational guidance

- Start with one small table and verify snapshot, insert, update, delete, restart, rollback, idle timeout, and retention-expiry behavior against the target Informix version before broader use.
- Disposable Informix 15 testing has validated normal-password and PAM authentication, queries, discovery, snapshots, and committed INSERT/UPDATE/DELETE transactions through `syscdcv1`. Redirect security behavior has deterministic protocol coverage but still requires a TLS-capable live redirect fixture. A serverless Lakeflow Connect pipeline has validated TLS, multi-table snapshots, checkpointed CDC flows, deletes, and SCD Type 2 materialization. Validate TLS trust, locale behavior, permissions, schemas, data-type boundaries, restart behavior, retention, and IDS/HDR-emitted redirects against the target environment.
- Authentication errors commonly indicate a wrong `server`/locale, unsupported authentication mode or redirect, an untrusted/mismatched TLS certificate, or insufficient `syscdcv1` privileges.
- Schema changes that alter captured column layout are not guaranteed to be safe during active capture. Restart and validate at a clean LSN boundary.
- Ensure source log retention covers downtime and the oldest checkpoint. Otherwise resnapshotting is required.
- A connection dropped mid-read (a `truncated SQLI stream` EOF from an idle NLB/PrivateLink reset or a server-side session reap) is absorbed in place rather than surfaced as a stream failure: the dead transport is reset and the identical read reissued under the slot already held, for both CDC polls and snapshot page/key-bound reads. Each read advances no offset and runs in its own repeatable-read transaction, so the retry is idempotent. A few bounded attempts with short backoff recover a transient blip; a genuinely-down source still fails once the attempts are exhausted.

## References

- IBM Informix Change Data Capture API documentation for Informix-side CDC concepts and prerequisites (the `syscdcv1` routines)
- Informix CDC installation script: `$INFORMIXDIR/etc/syscdcv1.sql`
