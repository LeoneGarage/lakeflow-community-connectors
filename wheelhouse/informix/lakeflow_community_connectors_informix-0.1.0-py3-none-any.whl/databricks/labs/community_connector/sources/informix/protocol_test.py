"""Source-local golden tests for bytecode-verified protocol layouts."""

import base64
import io
import ssl
import struct
import unittest
from datetime import date, datetime, timezone
from decimal import Decimal
from unittest.mock import Mock, patch

from databricks.labs.community_connector.sources.informix.cdc_protocol import (
    CdcFrameParser,
    CdcProtocolError,
    ColumnDescriptor,
    OpenTransactionRecords,
    apply_null_byte,
    cdc_routine,
    decode_frame,
    decode_interval,
    decode_value,
    interval_layout,
    metadata_column_names,
    validate_snapshot_arity,
)
from databricks.labs.community_connector.sources.informix.sqli import (
    SQ_EOT,
    datetime_order_preserving_cast,
    SQ_EXIT,
    ConnectionState,
    InformixDatetimeLiteral,
    InformixSqliClient,
    PasswordAuthenticationProvider,
    ResultColumn,
    ResultDescription,
    SqliDescriptorNotImplemented,
    SqliProtocolError,
    SqliRedirect,
    SqliSessionRejected,
    SqliTransportError,
    SqliUnsupportedAuthentication,
    TypedBind,
    _connector_sql,
    _DeadlineReader,
    _decode_result_value,
    _fixed_result_size,
    _statement_keyword,
    decode_asc_accept,
    encode_asc_char,
    encode_asc_environment,
    encode_bind,
    encode_char,
    encode_close_release,
    encode_cursor_open,
    encode_fetch,
    encode_fixed_open_fetch,
    encode_lodata_read,
    encode_normal_auth_prefix,
    encode_normal_auth_request,
    encode_pam_response,
    encode_prepare,
    encode_protocol_offer,
    encode_secondary_info,
    encode_session_packet,
    encode_simple_command,
    encode_variable_fetch,
    parse_redirect_detail,
    read_session_packet,
)


def _frame(kind, header=b"", payload=b""):
    header_size = 16 + len(header)
    return struct.pack(">IIII", header_size, len(payload), 0, kind) + header + payload


class FrameTests(unittest.TestCase):
    def test_cdc_routines_are_cross_database_qualified(self):
        self.assertEqual(cdc_routine("cdc_opensess"), "syscdcv1:informix.cdc_opensess")
        with self.assertRaises(CdcProtocolError):
            cdc_routine("cdc_opensess); DROP DATABASE testdb")

    def test_partial_and_multiple_frames(self):
        first = _frame(201, struct.pack(">q", 17))
        second = _frame(2, struct.pack(">qiq", 22, 4, 123))
        parser = CdcFrameParser(1024)
        self.assertEqual(parser.feed(first[:7]), [])
        frames = parser.feed(first[7:] + second)
        self.assertEqual(frames, [first, second])
        self.assertEqual(decode_frame(first, {})["lsn"], 17)

    def test_lsn_uses_full_unsigned_64_bit_wire_domain(self):
        lsn = (1 << 63) + 17
        record = decode_frame(_frame(201, struct.pack(">Q", lsn)), {})
        self.assertEqual(record["lsn"], lsn)

    def test_metadata_tolerates_ibm_header_extension(self):
        record = decode_frame(_frame(200, struct.pack(">i", 7) + bytes(16), b"integer id"), {})
        self.assertEqual(record["label"], 7)
        self.assertEqual(record["metadata"], b"integer id")

    def test_metadata_column_order_ignores_type_argument_commas(self):
        self.assertEqual(
            metadata_column_names(b"id serial, amount decimal(12,2), name varchar(60,0)\0"),
            ("id", "amount", "name"),
        )

    def test_metadata_uses_negotiated_client_encoding(self):
        self.assertEqual(
            metadata_column_names("café varchar(20)".encode("iso8859-1"), "iso8859-1"),
            ("café",),
        )

    def test_operation_primitive_row(self):
        header = struct.pack(">qii", 99, 7, 3)
        payload = struct.pack(">hi", 12, 34) + b"\x03abc" + b"\x00\x01"
        columns = {
            3: (
                ColumnDescriptor("s", "SMALLINT"),
                ColumnDescriptor("i", "INTEGER"),
                ColumnDescriptor("v", "VARCHAR"),
                ColumnDescriptor("b", "BOOLEAN"),
            )
        }
        record = decode_frame(_frame(40, header, payload), columns)
        self.assertEqual(record["row"], {"s": 12, "i": 34, "v": "abc", "b": True})

    def test_bounds_reject_oversize(self):
        parser = CdcFrameParser(32)
        with self.assertRaises(CdcProtocolError):
            parser.feed(struct.pack(">IIII", 16, 17, 0, 201))

    def test_truncate_preserves_wire_user_id_and_capture_interpretation(self):
        record = decode_frame(_frame(119, struct.pack(">qii", 9, 4, 7)), {})
        self.assertEqual(record["user_id"], 7)
        self.assertEqual(record["capture_label"], 7)
        self.assertNotIn("label", record)

    def test_null_sentinels_and_lvarchar_flags(self):
        self.assertEqual(
            decode_value(memoryview(struct.pack(">h", -32768)), ColumnDescriptor("s", "SMALLINT")),
            (None, 2),
        )
        self.assertEqual(
            decode_value(memoryview(b"\x00\x01\x01"), ColumnDescriptor("v", "LVARCHAR")),
            (None, 3),
        )
        self.assertEqual(
            decode_value(memoryview(b"\x01\x00"), ColumnDescriptor("v", "VARCHAR")),
            (None, 2),
        )
        self.assertEqual(
            decode_value(memoryview(b"\x01\x00"), ColumnDescriptor("b", "BOOLEAN")),
            (None, 2),
        )
        with self.assertRaisesRegex(CdcProtocolError, "boolean null flag"):
            decode_value(memoryview(b"\x02\x00"), ColumnDescriptor("b", "BOOLEAN"))
        self.assertEqual(
            decode_value(memoryview(b"\xff" * 8), ColumnDescriptor("f", "FLOAT")),
            (None, 8),
        )

    def test_informix_date_epoch_is_1899_12_31(self):
        self.assertEqual(
            decode_value(memoryview(struct.pack(">i", 0)), ColumnDescriptor("d", "DATE")),
            (datetime(1899, 12, 31).date(), 4),
        )

    def test_packed_decimal_positive_negative_and_null(self):
        column = ColumnDescriptor("d", "DECIMAL", precision=4, scale=2)
        self.assertEqual(decode_value(memoryview(b"\xc1\x0c\x22"), column), (Decimal("12.34"), 3))
        self.assertEqual(decode_value(memoryview(b"\x3e\x57\x42"), column), (Decimal("-12.34"), 3))
        self.assertEqual(
            decode_value(
                memoryview(b"\xc2\x02\x32\x00\x00\x00"),
                ColumnDescriptor("amount", "DECIMAL", precision=10, scale=2),
            ),
            (Decimal("250.00"), 6),
        )
        self.assertEqual(decode_value(memoryview(b"\0\0\0"), column), (None, 3))

    def test_ordinary_decimal_with_omitted_scale_accepts_null(self):
        column = ResultColumn("prefix", 0, 5, 0, 0x05FF)

        self.assertIsNone(_decode_result_value(b"\0" * 4, column, "utf-8"))

    def test_variable_scale_decimal_preserves_native_exponent(self):
        self.assertEqual(
            decode_value(
                memoryview(b"\xc1\x0c\x22\x00"),
                ColumnDescriptor("amount", "DECIMAL", precision=4, scale=0xFF),
            ),
            (Decimal("12.34"), 4),
        )

    def test_open_record_bound_excludes_committed_and_handles_interleaving(self):
        tracker = OpenTransactionRecords()
        tracker.begin(1)
        tracker.append(1, 10)
        tracker.begin(2)
        tracker.append(2, 11)
        tracker.append(2, 12)
        self.assertEqual(tracker.buffered, 3)
        tracker.finish(1)
        self.assertEqual(tracker.buffered, 2)
        tracker.discard(2, 12)
        self.assertEqual(tracker.buffered, 1)
        tracker.finish(2)
        self.assertEqual(tracker.buffered, 0)
        self.assertFalse(tracker)

    def test_open_record_bound_rejects_duplicate_begin(self):
        tracker = OpenTransactionRecords()
        tracker.begin(1)
        with self.assertRaisesRegex(CdcProtocolError, "duplicate CDC BEGIN"):
            tracker.begin(1)

    def test_snapshot_continuation_arity(self):
        validate_snapshot_arity([1, 2], ["a", "b"])
        with self.assertRaises(CdcProtocolError):
            validate_snapshot_arity([1], ["a", "b"])

    def test_int8_signed_magnitude_and_datetime_year_to_fraction5(self):
        int8 = ColumnDescriptor("i", "INT8")
        self.assertEqual(decode_value(memoryview(struct.pack(">hII", -1, 7, 0)), int8), (-7, 10))
        self.assertEqual(decode_value(memoryview(b"\0" * 10), int8), (None, 10))
        with self.assertRaises(CdcProtocolError):
            decode_value(memoryview(struct.pack(">hII", 2, 1, 0)), int8)
        snapshot_int8 = ResultColumn("i", 0, 17, 0, 10)
        snapshot_serial8 = ResultColumn("s", 0, 18, 0, 10)
        self.assertEqual(
            _decode_result_value(struct.pack(">hII", -1, 7, 0), snapshot_int8, "utf-8"),
            -7,
        )
        self.assertIsNone(_decode_result_value(b"\0" * 10, snapshot_serial8, "utf-8"))
        temporal = ColumnDescriptor("t", "DATETIME", length=0x000F)
        raw = bytes([0xC7, 20, 24, 1, 2, 3, 4, 5, 12, 34, 50])
        self.assertEqual(
            decode_value(memoryview(raw), temporal),
            (datetime(2024, 1, 2, 3, 4, 5, 123450), 11),
        )
        time_only = ColumnDescriptor("t", "DATETIME", length=0x060A)
        self.assertEqual(
            decode_value(memoryview(bytes([0xC3, 12, 34, 56])), time_only),
            ("12:34:56", 4),
        )
        time_fraction = ColumnDescriptor("t", "DATETIME", length=0x060F)
        self.assertEqual(
            decode_value(memoryview(bytes([0xC2, 33, 11, 31, 77, 30, 0])), time_fraction),
            ("00:33:11.31773", 7),
        )

    def test_datetime_sub_unit_fraction_has_negative_exponent(self):
        # A time whose whole fields AND first fraction group are all zero -- e.g.
        # 00:00:00.00042 in a HOUR TO FRACTION(5) column -- normalizes to a *negative*
        # base-100 exponent (the leading zero groups are stripped, like any DECIMAL).
        # The mantissa [04, 20, 0, 0, 0, 0] with exponent -1 (header 0x80 | (63)) must
        # reconstruct rather than being rejected as "exceeds its qualifier width".
        time_fraction = ColumnDescriptor("t", "DATETIME", length=0x060F)
        self.assertEqual(
            decode_value(memoryview(bytes([0xBF, 4, 20, 0, 0, 0, 0])), time_fraction),
            ("00:00:00.00042", 7),
        )
        # And 00:00:00.00001 -> exponent -2: the fraction "00001" pads to groups
        # [00, 00, 10], whose only significant group (10) sits in the last slot, so the
        # normalized mantissa is [10, ...] at exponent -2 (header 0x80 | 62).
        self.assertEqual(
            decode_value(memoryview(bytes([0xBE, 10, 0, 0, 0, 0, 0])), time_fraction),
            ("00:00:00.00001", 7),
        )

    def test_datetime_precision_beyond_qualifier_is_rejected(self):
        # A sub-unit value against a fraction-less qualifier (HOUR TO SECOND) would need
        # precision the qualifier cannot hold -- reject it clearly rather than silently
        # dropping the significant group.
        hour_to_second = ColumnDescriptor("t", "DATETIME", length=0x060A)
        with self.assertRaisesRegex(CdcProtocolError, "more precision than"):
            decode_value(memoryview(bytes([0xBF, 5, 0, 0])), hour_to_second)

    def test_datetime_exponent_above_qualifier_still_rejected(self):
        # More integer groups than the qualifier admits remains a true overflow.
        hour_to_second = ColumnDescriptor("t", "DATETIME", length=0x060A)
        with self.assertRaisesRegex(CdcProtocolError, "exceeds its qualifier width"):
            decode_value(memoryview(bytes([0xC4, 1, 2, 3])), hour_to_second)

    def test_year_one_datetime_is_utc_aware(self):
        # 0001-01-01 00:00:00.00000 sits adjacent to datetime.min; a naive value
        # overflows PySpark's internal astimezone() on TimestampType conversion, so the
        # decoder attaches UTC (a no-op for astimezone(UTC)) to let it pass through.
        temporal = ColumnDescriptor("t", "DATETIME", length=0x000F)
        raw = bytes([0xC7, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0])
        self.assertEqual(
            decode_value(memoryview(raw), temporal),
            (datetime(1, 1, 1, tzinfo=timezone.utc), 11),
        )
        # A normal year stays a naive wall-clock value (no session-timezone shift).
        normal = bytes([0xC7, 20, 24, 1, 2, 3, 4, 5, 12, 34, 50])
        decoded, _ = decode_value(memoryview(normal), temporal)
        self.assertIsNone(decoded.tzinfo)

    def test_datetime_partial_qualifiers(self):
        cases = (
            (0x060A, bytes([0xC3, 12, 34, 56]), "12:34:56"),
            (0x0408, bytes([0xC3, 12, 3, 4]), "DAY=12:HOUR=03:MINUTE=04"),
            (0x0002, bytes([0xC3, 20, 24, 1]), "YEAR=2024:MONTH=01"),
            (0x080F, bytes([0xC2, 34, 56, 12, 34, 50]), "MINUTE=34:SECOND=56:FRACTION(5)=12345"),
        )
        for qualifier, raw, expected in cases:
            with self.subTest(qualifier=qualifier):
                self.assertEqual(
                    decode_value(
                        memoryview(raw), ColumnDescriptor("t", "DATETIME", length=qualifier)
                    ),
                    (expected, len(raw)),
                )

    def test_datetime_partial_qualifiers_reject_out_of_range_fields(self):
        cases = (
            (0x060A, bytes([0xC3, 24, 0, 0])),
            (0x080A, bytes([0xC2, 60, 0])),
            (0x0A0A, bytes([0xC1, 60])),
            (0x0204, bytes([0xC2, 13, 1])),
            (0x0404, bytes([0xC1, 32])),
        )
        for qualifier, raw in cases:
            with self.subTest(qualifier=qualifier):
                with self.assertRaisesRegex(CdcProtocolError, "invalid DATETIME field"):
                    decode_value(
                        memoryview(raw),
                        ColumnDescriptor("t", "DATETIME", length=qualifier),
                    )

    def test_partial_month_day_uses_calendar_bounds(self):
        descriptor = ColumnDescriptor("t", "DATETIME", length=0x0204)
        with self.assertRaisesRegex(CdcProtocolError, "calendar fields"):
            decode_value(memoryview(bytes([0xC2, 2, 30])), descriptor)
        self.assertEqual(
            decode_value(memoryview(bytes([0xC2, 2, 29])), descriptor),
            ("MONTH=02:DAY=29", 3),
        )

    def test_ordinary_datetime_uses_extended_id_qualifier(self):
        # SQL result encoded_length is packed storage metadata, not the
        # start/end qualifier. The latter must survive from extended_id.
        column = ResultColumn("t", 0, 10, 0x060A, 0x0603)
        self.assertEqual(
            _decode_result_value(bytes([0xC3, 12, 34, 56]), column, "utf-8"),
            "12:34:56",
        )

    def test_live_ordinary_datetime_uses_encoded_length_qualifier_fallback(self):
        column = ResultColumn("updated_at", 0, 266, 0, 0x130F)
        raw = bytes([0xC7, 20, 26, 7, 19, 12, 34, 56, 12, 34, 50])
        self.assertEqual(
            _decode_result_value(raw, column, "utf-8"),
            datetime(2026, 7, 19, 12, 34, 56, 123450),
        )

    def test_native_boolean_and_bigint_result_ids(self):
        boolean = ResultColumn("enabled", 0, 45, 0, 1)
        bigint = ResultColumn("count", 0, 52, 0, 8)
        bigserial = ResultColumn("serial", 0, 53, 0, 8)
        self.assertTrue(_decode_result_value(b"\x01", boolean, "utf-8"))
        self.assertEqual(_decode_result_value(struct.pack(">q", 1 << 40), bigint, "utf-8"), 1 << 40)
        self.assertEqual(_decode_result_value(struct.pack(">q", 123), bigserial, "utf-8"), 123)

    def test_char_result_decodes_with_client_locale_codeset(self):
        # A CHAR value the server transmitted in the client's Latin-1 codeset must
        # decode with that codeset, not be forced through UTF-8.
        latin1 = "café".encode("iso8859-1")
        column = ResultColumn("owner", 0, 0, 0, len(latin1))
        self.assertEqual(_decode_result_value(latin1, column, "iso8859-1"), "café")

    def test_char_result_codeset_mismatch_raises_actionable_error(self):
        # A lone 0xE9 ('é' in Latin-1) is not valid UTF-8. Decoding it as UTF-8
        # must raise a diagnostic that points at CLIENT_LOCALE rather than a bare
        # UnicodeDecodeError, so a locale misconfiguration is recognizable.
        column = ResultColumn("owner", 0, 0, 0, 4)
        with self.assertRaisesRegex(SqliProtocolError, "CLIENT_LOCALE"):
            _decode_result_value(b"caf\xe9", column, "utf-8")

    def test_ordinary_boolean_null_and_marker_validation(self):
        one_byte = ResultColumn("enabled", 0, 45, 0, 1)
        two_byte = ResultColumn("enabled", 0, 45, 0, 2)
        self.assertIsNone(_decode_result_value(b"\xff", one_byte, "utf-8"))
        self.assertIsNone(_decode_result_value(b"\x00\xff", two_byte, "utf-8"))
        self.assertIs(_decode_result_value(b"t", one_byte, "utf-8", True), True)
        self.assertIs(_decode_result_value(b"f", one_byte, "utf-8", True), False)
        with self.assertRaisesRegex(SqliProtocolError, "invalid BOOLEAN"):
            _decode_result_value(b"\x02", one_byte, "utf-8")
        enveloped = ResultColumn("enabled", 0, 45, 0, 1)
        self.assertTrue(
            _decode_result_value(b"\x00" + struct.pack(">i", 1) + b"\x01", enveloped, "utf-8")
        )
        self.assertIsNone(_decode_result_value(b"\x01" + struct.pack(">i", 0), enveloped, "utf-8"))
        with self.assertRaises(SqliDescriptorNotImplemented):
            _decode_result_value(
                b"\x00" + struct.pack(">i", 1) + b"\x01",
                ResultColumn("collection", 0, 23, 0, 1),
                "utf-8",
            )

    def test_ordinary_char_strips_only_space_padding(self):
        column = ResultColumn("value", 0, 0, 0, 4)
        self.assertEqual(_decode_result_value(b"a\t  ", column, "utf-8"), "a\t")

    def test_snapshot_and_cdc_char_use_the_same_padding_normalization(self):
        column = ColumnDescriptor("value", "CHAR", length=4)
        self.assertEqual(decode_value(memoryview(b"a   "), column), ("a", 4))

    def test_nchar_decodes_as_char_on_both_paths(self):
        # NCHAR differs from CHAR only in collating by locale: it is fixed width and blank
        # padded in the database code set on the SQLI wire (type 15) and in CDC images.
        result = ResultColumn("value", 0, 15, 0, 5)
        self.assertEqual(_fixed_result_size(result), 5)
        self.assertEqual(_decode_result_value(b"ab   ", result, "utf-8"), "ab")
        column = ColumnDescriptor("value", "NCHAR", length=5)
        self.assertEqual(decode_value(memoryview(b"ab   "), column), ("ab", 5))

    def test_ordinary_varchar_null_sentinel(self):
        for type_code in (13, 16):
            with self.subTest(type_code=type_code):
                column = ResultColumn("value", 0, type_code, 0, 20)
                self.assertIsNone(_decode_result_value(b"\x01\x00", column, "utf-8"))

    def test_ordinary_lvarchar_value_null_and_validation(self):
        column = ResultColumn("value", 0, 43, 0, 100)
        self.assertEqual(
            _decode_result_value(b"\x00" + struct.pack(">i", 5) + b"hello", column, "utf-8"),
            "hello",
        )
        self.assertIsNone(_decode_result_value(b"\x01" + struct.pack(">i", 0), column, "utf-8"))
        with self.assertRaisesRegex(SqliProtocolError, "length"):
            _decode_result_value(b"\x00" + struct.pack(">i", 4) + b"short", column, "utf-8")


# (qualifier, packed bytes, Informix's text) read from a live Informix 14.10 table: the
# bytes from the SQLI snapshot and CDC decoders alike, the text from CAST(... AS
# VARCHAR) with its padding trimmed.
_LIVE_INTERVALS = (
    (0x0602, "c6010200", "1-02"),  # YEAR TO MONTH
    (0x0602, "39626200", "-1-02"),
    (0x0802, "c80c22380b", "123456-11"),  # YEAR(6) TO MONTH
    (0x0322, "c60117", "123"),  # MONTH(3) TO MONTH
    (0x0322, "3a5f00", "-5"),
    (0x084A, "c402000001", "2 00:00:01"),  # DAY TO SECOND
    (0x084A, "3b62616060", "-1 02:03:04"),
    (0x0C4D, "3b57565554622800", "-12 13:14:15.016"),  # DAY(3) TO FRACTION(3)
    (0x0C4D, "405a000000000000", "-0 00:00:00.001"),
    (0x0468, "c30a1e", "10:30"),  # HOUR TO MINUTE
    (0x0468, "3d6300", "-0:01"),
    (0x078A, "c401172d38", "12345:56"),  # MINUTE(5) TO SECOND
    (0x0BAF, "c30c22380c2232", "123456.12345"),  # SECOND(6) TO FRACTION(5)
    (0x0BAF, "415a0000000000", "-0.00001"),
    (0x144F, "c801172d4359173b3b63635a", "123456789 23:59:59.99999"),  # DAY(9) TO FRACTION(5)
    (0x144F, "3b6300000000000000000000", "-1 00:00:00.00000"),
    (0x0346, "c40506", "5 06"),  # DAY(1) TO HOUR
    (0x0346, "3b5a4d", "-9 23"),
    (0x086B, "c401172d3b5a", "123:45:59.9"),  # HOUR(3) TO FRACTION(1)
    (0x086B, "3f5a00000000", "-0:00:00.1"),
    (0x0100, "c607", "7"),  # YEAR(1) TO YEAR
    (0x0100, "395d", "-7"),
    (0x0602, "80000000", "0-00"),
    (0x01CB, "c032", ".5"),  # FRACTION TO FRACTION(1)
    (0x01CB, "3f32", "-.5"),
    (0x01CB, "8000", ".0"),
    (0x03CD, "c0013c", ".016"),  # FRACTION TO FRACTION(3)
    (0x03CD, "3f6228", "-.016"),
    (0x03CD, "c00100", ".010"),
    (0x03CD, "000000", None),
    (0x05CF, "c0011728", ".01234"),  # FRACTION TO FRACTION(5)
    (0x05CF, "3f624c3c", "-.01234"),
    (0x05CF, "c063635a", ".99999"),
    (0x05CF, "80000000", ".00000"),
    (0x0C4D, "8000000000000000", "0 00:00:00.000"),
    (0x0602, "00000000", None),
    (0x144F, "000000000000000000000000", None),
)


class IntervalTests(unittest.TestCase):
    """INTERVAL decodes to Informix's own literal text on the CDC and SQLI paths."""

    def test_live_intervals_decode_to_informix_text(self):
        for qualifier, packed, expected in _LIVE_INTERVALS:
            with self.subTest(qualifier=hex(qualifier), packed=packed):
                raw = bytes.fromhex(packed)
                self.assertEqual(decode_interval(memoryview(raw), qualifier), (expected, len(raw)))
                column = ColumnDescriptor("i", "INTERVAL", length=qualifier)
                decoded = decode_value(memoryview(raw + b"\xff"), column)
                self.assertEqual(decoded, (expected, len(raw)))
                result = ResultColumn("i", 0, 14, 0, qualifier)
                self.assertEqual(_fixed_result_size(result), len(raw))
                self.assertEqual(_decode_result_value(raw, result, "utf-8"), expected)

    def test_interval_layouts(self):
        self.assertEqual(interval_layout(0x0C4D), ((4, 6, 8, 10), 3, 3))
        self.assertEqual(interval_layout(0x0602), ((0, 2), 4, 0))
        self.assertEqual(interval_layout(0x0100), ((0,), 1, 0))
        self.assertEqual(interval_layout(0x01CB), ((), 0, 1))  # FRACTION TO FRACTION(1)
        self.assertEqual(interval_layout(0x05CF), ((), 0, 5))
        for qualifier in (0x0624, 0x03BD, 0x02CB, 0x01CA, 0x0202, 0x0C02, 0x0420, 0x0642):
            # MONTH TO DAY mixes classes; FRACTION never starts at code 11; FRACTION TO
            # FRACTION(1) with two digits, or ending at SECOND; too few digits for YEAR TO
            # MONTH; a ten-digit leading field; MONTH TO YEAR and DAY TO MONTH run backwards.
            with self.subTest(hex(qualifier)):
                self.assertIsNone(interval_layout(qualifier))
        with self.assertRaises(CdcProtocolError):
            decode_interval(memoryview(b"\x00\x00"), 0x0624)

    def test_corrupt_intervals_are_rejected(self):
        for qualifier, packed, message in (
            (0x0468, "c30a3c", "field 8 holds 60"),  # HOUR TO MINUTE, minute 60
            (0x0602, "c6010c00", "field 2 holds 12"),  # YEAR TO MONTH, month 12
            (0x0468, "c20a1e", "below its last field"),  # seconds in HOUR TO MINUTE
            (0x0346, "c50100", "exceeds 1 digits"),  # DAY(1) TO HOUR, 100 days
            (0x03CD, "c1013c", "above its fraction"),  # FRACTION TO FRACTION(3), 1.016
        ):
            with self.subTest(packed):
                raw = bytes.fromhex(packed)
                with self.assertRaisesRegex(CdcProtocolError, message):
                    decode_interval(memoryview(raw), qualifier)


class LoDataTests(unittest.TestCase):
    def test_verified_read_body(self):
        self.assertEqual(
            encode_lodata_read(9, 32000), struct.pack(">hhhih", 97, 0, 9, 32000, 32000)
        )


class SqliPacketTests(unittest.TestCase):
    def test_unbounded_execute_skips_decoded_byte_accounting(self):
        client = InformixSqliClient("host", 9088, "db", "user", "password")
        output = io.BytesIO()

        with (
            patch.object(client, "_require_open", return_value=(io.BytesIO(), output)),
            patch.object(client, "_read_query_group", return_value=(None, [], False)),
            patch(
                "databricks.labs.community_connector.sources.informix.sqli._retained_size",
                side_effect=AssertionError("must not account"),
            ),
        ):
            self.assertEqual(client.execute("SELECT 1 FROM systables"), [])

    def test_execute_routes_non_row_statements_to_command_path(self):
        client = InformixSqliClient("host", 9088, "db", "user", "password")
        with patch.object(client, "execute_command") as execute_command:
            self.assertEqual(client.execute("UPDATE app.orders SET state = ?", ("done",)), [])

        execute_command.assert_called_once_with("UPDATE app.orders SET state = 'done'")

    def test_execute_routes_commented_non_row_statements_to_command_path(self):
        client = InformixSqliClient("host", 9088, "db", "user", "password")
        with patch.object(client, "execute_command") as execute_command:
            client.execute("/* mutation */\n-- owned SQL\nUPDATE t SET value = ?", (1,))
        execute_command.assert_called_once_with(
            "/* mutation */\n-- owned SQL\nUPDATE t SET value = 1"
        )

    def test_connector_sql_ignores_question_marks_in_literals_and_comments(self):
        sql = "SELECT '?' AS literal /* ? */ FROM t -- ?\nWHERE id = ?"
        self.assertEqual(
            _connector_sql(sql, (7,)),
            "SELECT '?' AS literal /* ? */ FROM t -- ?\nWHERE id = 7",
        )
        self.assertEqual(_statement_keyword("/* note */ -- note\n UPDATE t SET x=1"), "UPDATE")

    def test_connector_sql_renders_date_and_datetime_pagination_values(self):
        self.assertEqual(
            _connector_sql(
                "SELECT * FROM t WHERE d > ? AND ts > ?",
                (date(2026, 7, 24), datetime(2026, 7, 24, 1, 2, 3, 123450)),
            ),
            "SELECT * FROM t WHERE d > MDY(7,24,2026) AND ts > "
            "DATETIME(2026-07-24 01:02:03.12345) YEAR TO FRACTION(5)",
        )
        with self.assertRaisesRegex(ValueError, "timezone-free"):
            _connector_sql("SELECT * FROM t WHERE ts > ?", (datetime.now(timezone.utc),))

        self.assertEqual(
            _connector_sql(
                "SELECT * FROM t WHERE t > ?",
                (InformixDatetimeLiteral("13:03:36.93100", 0x060F),),
            ),
            "SELECT * FROM t WHERE t > " "DATETIME(13:03:36.93100) HOUR TO FRACTION(5)",
        )

    def test_connector_sql_renders_bounded_finite_decimal_pagination_values(self):
        self.assertEqual(
            _connector_sql(
                "SELECT * FROM t WHERE amount > ?",
                (Decimal("123.4500"),),
            ),
            "SELECT * FROM t WHERE amount > 123.4500",
        )
        with self.assertRaisesRegex(ValueError, "must be finite"):
            _connector_sql("SELECT * FROM t WHERE amount > ?", (Decimal("NaN"),))

    def test_non_row_command_uses_sq_command_execute_release_path(self):
        client = InformixSqliClient("host", 9088, "db", "user", "password")
        output = io.BytesIO()
        transcript = (
            struct.pack(">hhhh", 99, 1, 2, 1)
            + struct.pack(">hhiii", 15, 0, 0, 0, 0)
            + struct.pack(">h", 12)
        )
        client._input = io.BytesIO(transcript)

        with patch.object(client, "_require_open", return_value=(client._input, output)):
            client.execute_command("BEGIN WORK")

        self.assertEqual(
            output.getvalue(),
            encode_simple_command("BEGIN WORK", "utf-8", long_sql_length=False),
        )
        self.assertEqual(client._input.tell(), len(transcript))

    def test_non_row_command_consumes_zero_column_description(self):
        client = InformixSqliClient("host", 9088, "db", "user", "password")
        output = io.BytesIO()
        transcript = (
            struct.pack(">hhhihhi", 8, 0, 7, 0, 0, 0, 0)
            + struct.pack(">hhiii", 15, 0, 0, 0, 0)
            + struct.pack(">h", 12)
        )
        client._input = io.BytesIO(transcript)

        with patch.object(client, "_require_open", return_value=(client._input, output)):
            client.execute_command("SET ISOLATION TO REPEATABLE READ")

        self.assertEqual(client._input.tell(), len(transcript))

    def test_execute_enforces_incremental_decoded_result_byte_bound(self):
        client = InformixSqliClient("host", 9088, "db", "user", "password")
        description = ResultDescription(2, 7, 4, (ResultColumn("value", 0, 2, 0, 4),))
        responses = (
            (description, [], False),
            (description, [{"value": 1}], True),
        )
        output = io.BytesIO()

        with (
            patch.object(client, "_require_open", return_value=(io.BytesIO(), output)),
            patch.object(client, "_read_query_group", side_effect=responses),
            patch.object(client, "_poison"),
            self.assertRaisesRegex(SqliProtocolError, "max_result_bytes=1"),
        ):
            client.execute("SELECT value FROM t", max_result_bytes=1)

    def test_login_deadline_reader_recomputes_remaining_time_per_read(self):
        connection = Mock()
        reader = _DeadlineReader(io.BytesIO(b"ab"), connection, deadline=10.0, maximum=30.0)

        with patch(
            "databricks.labs.community_connector.sources.informix.sqli.time.monotonic",
            side_effect=(2.0, 7.0),
        ):
            self.assertEqual(reader.read(1), b"a")
            self.assertEqual(reader.read(1), b"b")

        self.assertEqual(connection.settimeout.call_args_list[0].args, (8.0,))
        self.assertEqual(connection.settimeout.call_args_list[1].args, (3.0,))
        reader.finish()
        self.assertEqual(connection.settimeout.call_args.args, (30.0,))

    def test_close_sends_graceful_sqli_exit_for_open_database(self):
        client = InformixSqliClient("host", 9088, "db", "user", "password")
        output = Mock()
        client._input = Mock()
        client._output = output
        client.state = ConnectionState.DATABASE_OPEN

        client.close()

        output.write.assert_called_once_with(struct.pack(">hh", SQ_EXIT, SQ_EOT))
        output.flush.assert_called_once_with()
        self.assertEqual(client.state, ConnectionState.CLOSED)

    def test_close_preserves_poisoned_state(self):
        client = InformixSqliClient("host", 9088, "db", "user", "password")
        client.state = ConnectionState.POISONED

        client.close()

        self.assertEqual(client.state, ConnectionState.POISONED)

    def test_login_deadline_reader_fails_after_absolute_deadline(self):
        reader = _DeadlineReader(io.BytesIO(b"a"), Mock(), deadline=10.0, maximum=30.0)
        with (
            patch(
                "databricks.labs.community_connector.sources.informix.sqli.time.monotonic",
                return_value=10.0,
            ),
            self.assertRaisesRegex(SqliUnsupportedAuthentication, "deadline exceeded"),
        ):
            reader.read(1)

    def test_informix_locale_codec_aliases_are_strict(self):
        client = InformixSqliClient(
            "host", 9088, "db", "user", "password", client_locale="en_US.819"
        )
        self.assertEqual(client._encoding, "iso8859-1")
        client.client_locale = "en_US.57372"
        self.assertEqual(client._encoding, "utf-8")
        client.client_locale = "en_US.unknown"
        with self.assertRaises(SqliProtocolError):
            _ = client._encoding

    def test_bounded_internal_bind_envelope(self):
        encoded = encode_bind(
            (TypedBind(2, 7), TypedBind(52, -9), TypedBind(13, "abc"), TypedBind(0, None))
        )
        self.assertTrue(encoded.startswith(struct.pack(">hh", 5, 4)))
        self.assertIn(struct.pack(">i", 7), encoded)
        self.assertIn(struct.pack(">q", -9), encoded)
        self.assertTrue(encoded.endswith(struct.pack(">hhh", 0, -1, 0)))

    def test_pam_static_frames_and_bounds(self):
        self.assertEqual(encode_pam_response("1234"), struct.pack(">hh", 130, 4) + b"1234\0\x0c")
        with self.assertRaises(SqliUnsupportedAuthentication):
            encode_pam_response("x" * 513)

    def test_pam_multiround_information_and_accept(self):
        wire = (
            struct.pack(">hhh", 129, 4, 4)
            + b"info"
            + struct.pack(">h", 12)
            + struct.pack(">hhh", 129, 1, 9)
            + b"Password:\0"
            + struct.pack(">h", 12)
            + struct.pack(">hh", 127, 12)
        )
        client = InformixSqliClient(
            "host",
            9088,
            "db",
            "user",
            "secret",
            client_locale="en_US.utf8",
            authentication_mode="pam",
            authentication_provider=PasswordAuthenticationProvider("secret"),
        )
        client._input, client._output = io.BytesIO(wire), io.BytesIO()
        client._authenticate_pam(float("inf"))
        self.assertEqual(
            client._output.getvalue(),
            struct.pack(">hh", 128, 12) + encode_pam_response("secret"),
        )

    def test_pam_fail_closed_states(self):
        cases = (
            (struct.pack(">hhh", 129, 1, 513), SqliProtocolError),
            (struct.pack(">hhh", 129, 1, 1) + b"x\0" + struct.pack(">h", 99), SqliProtocolError),
            (struct.pack(">hh", 56, 12), SqliUnsupportedAuthentication),
        )
        for wire, error in cases:
            client = InformixSqliClient(
                "host",
                9088,
                "db",
                "user",
                "secret",
                client_locale="en_US.utf8",
                authentication_mode="pam",
                authentication_provider=PasswordAuthenticationProvider("secret"),
            )
            client._input, client._output = io.BytesIO(wire), io.BytesIO()
            with self.assertRaises(error):
                client._authenticate_pam(float("inf"))

    def test_pam_encoded_response_bound_and_round_limit(self):
        wire = struct.pack(">hhh", 129, 1, 1) + b"x\0" + struct.pack(">h", 12)
        client = InformixSqliClient(
            "host",
            9088,
            "db",
            "user",
            "x" * 513,
            client_locale="en_US.utf8",
            authentication_mode="pam",
            authentication_provider=PasswordAuthenticationProvider("x" * 513),
            pam_max_rounds=1,
        )
        client._input, client._output = io.BytesIO(wire), io.BytesIO()
        with self.assertRaises(SqliUnsupportedAuthentication):
            client._authenticate_pam(float("inf"))

    def test_redirect_allowlist(self):
        self.assertEqual(
            parse_redirect_detail("redirect:x:srv:db.example:9089", {("db.example", 9089)}),
            ("srv", "db.example", 9089),
        )
        with self.assertRaises(SqliUnsupportedAuthentication):
            parse_redirect_detail("redirect:x:srv:evil:9089", {("db.example", 9089)})
        for unsafe in ("label=srv|db.example|service", "label=srv|db.example|9089|extra"):
            with self.assertRaises(SqliUnsupportedAuthentication):
                parse_redirect_detail(unsafe, {("db.example", 9089)})

    def test_redirect_resolution_is_stable_and_private_requires_ip_allowlist(self):
        client = InformixSqliClient(
            "origin",
            9088,
            "db",
            "user",
            "secret",
            redirect_enabled=True,
            redirect_allowlist=frozenset({("target", 9088)}),
        )
        with patch(
            "socket.getaddrinfo",
            return_value=[
                (2, 1, 6, "", ("203.0.113.1", 9088)),
                (2, 1, 6, "", ("203.0.113.2", 9088)),
            ],
        ):
            with self.assertRaises(SqliUnsupportedAuthentication):
                client._validate_redirect_destination("target", 9088, True)
        with patch(
            "socket.getaddrinfo",
            return_value=[
                (2, 1, 6, "", ("127.0.0.1", 9088)),
            ],
        ):
            with self.assertRaises(SqliUnsupportedAuthentication):
                client._validate_redirect_destination("target", 9088, True)
        client.redirect_allowlist = frozenset({("target", 9088), ("127.0.0.1", 9088)})
        with patch(
            "socket.getaddrinfo",
            return_value=[
                (2, 1, 6, "", ("127.0.0.1", 9088)),
            ],
        ):
            client._validate_redirect_destination("target", 9088, True)

    def test_redirect_uses_one_validated_dns_result_for_connection(self):
        client = InformixSqliClient(
            "origin",
            9088,
            "db",
            "user",
            "secret",
            server_name="origin",
            redirect_enabled=True,
            redirect_allowlist=frozenset({("target", 9089)}),
        )
        with (
            patch.object(
                client,
                "_connect_once",
                side_effect=(SqliRedirect("redirect:x:srv:target:9089"), None),
            ) as connect_once,
            patch(
                "socket.getaddrinfo",
                return_value=[(2, 1, 6, "", ("8.8.8.8", 9089))],
            ) as resolve,
        ):
            client.connect()

        self.assertEqual(resolve.call_count, 1)
        self.assertEqual(connect_once.call_args_list[-1].args[-1], "8.8.8.8")

    def test_redirect_retries_each_validated_dns_address(self):
        client = InformixSqliClient(
            "origin",
            9088,
            "db",
            "user",
            "secret",
            server_name="origin",
            redirect_enabled=True,
            redirect_allowlist=frozenset({("target", 9089)}),
        )
        with (
            patch.object(
                client,
                "_connect_once",
                side_effect=(
                    SqliRedirect("redirect:x:srv:target:9089"),
                    SqliTransportError("first address closed during SQLI negotiation"),
                    None,
                ),
            ) as connect_once,
            patch(
                "socket.getaddrinfo",
                return_value=[
                    (2, 1, 6, "", ("8.8.8.8", 9089)),
                    (2, 1, 6, "", ("8.8.4.4", 9089)),
                ],
            ),
        ):
            client.connect()

        self.assertEqual(
            [call.args[-1] for call in connect_once.call_args_list],
            [None, "8.8.4.4", "8.8.8.8"],
        )

    def test_redirect_preserves_protocol_failure_when_all_addresses_fail(self):
        client = InformixSqliClient(
            "origin",
            9088,
            "db",
            "user",
            "secret",
            server_name="origin",
            redirect_enabled=True,
            redirect_allowlist=frozenset({("target", 9089)}),
        )
        protocol_error = SqliTransportError("truncated SQLI response")
        with (
            patch.object(
                client,
                "_connect_once",
                side_effect=(
                    SqliRedirect("redirect:x:srv:target:9089"),
                    protocol_error,
                    OSError("second address unavailable"),
                ),
            ),
            patch(
                "socket.getaddrinfo",
                return_value=[
                    (2, 1, 6, "", ("8.8.8.8", 9089)),
                    (2, 1, 6, "", ("8.8.4.4", 9089)),
                ],
            ),
        ):
            with self.assertRaisesRegex(SqliTransportError, "truncated SQLI response") as raised:
                client.connect()

        self.assertTrue(
            any(
                "second address unavailable" in note
                for note in getattr(raised.exception, "__notes__", ())
            )
        )

    def test_redirect_does_not_retry_permanent_protocol_failure(self):
        client = InformixSqliClient(
            "origin",
            9088,
            "db",
            "user",
            "secret",
            server_name="origin",
            redirect_enabled=True,
            redirect_allowlist=frozenset({("target", 9089)}),
        )
        with (
            patch.object(
                client,
                "_connect_once",
                side_effect=(
                    SqliRedirect("redirect:x:srv:target:9089"),
                    SqliProtocolError("Informix SQL error -951"),
                ),
            ) as connect_once,
            patch(
                "socket.getaddrinfo",
                return_value=[
                    (2, 1, 6, "", ("8.8.8.8", 9089)),
                    (2, 1, 6, "", ("8.8.4.4", 9089)),
                ],
            ),
        ):
            with self.assertRaisesRegex(SqliProtocolError, "-951"):
                client.connect()

        self.assertEqual(connect_once.call_count, 2)

    def test_redirect_shared_address_space_requires_exact_ip_allowlist(self):
        client = InformixSqliClient(
            "origin",
            9088,
            "db",
            "user",
            "secret",
            redirect_allowlist=frozenset({("target", 9088)}),
        )
        with self.assertRaises(SqliUnsupportedAuthentication):
            client._validate_redirect_destination("target", 9088, True, ("100.64.0.1",))
        client.redirect_allowlist = frozenset({("target", 9088), ("100.64.0.1", 9088)})
        client._validate_redirect_destination("target", 9088, True, ("100.64.0.1",))

    def test_tls_handshake_failure_closes_raw_socket(self):
        raw = Mock()
        context = Mock()
        context.wrap_socket.side_effect = OSError("TLS failed")
        client = InformixSqliClient(
            "host",
            9088,
            "db",
            "user",
            "secret",
            server_name="server",
            ssl_context=context,
        )
        with patch("socket.create_connection", return_value=raw):
            with self.assertRaisesRegex(OSError, "TLS failed"):
                client._connect_once("host", 9088, "server", float("inf"))
        raw.close.assert_called_once_with()

    def test_tls_socket_cleanup_does_not_mask_handshake_failure(self):
        raw = Mock()
        raw.close.side_effect = OSError("close failed")
        context = Mock()
        context.wrap_socket.side_effect = ValueError("handshake failed")
        client = InformixSqliClient(
            "host",
            9088,
            "db",
            "user",
            "secret",
            server_name="server",
            ssl_context=context,
        )
        with patch("socket.create_connection", return_value=raw):
            with self.assertRaisesRegex(ValueError, "handshake failed") as raised:
                client._connect_once("host", 9088, "server", float("inf"))
        self.assertTrue(
            any("close failed" in note for note in getattr(raised.exception, "__notes__", ()))
        )

    def test_makefile_failure_after_tls_wrap_closes_wrapped_socket(self):
        raw = Mock()
        wrapped = Mock()
        wrapped.makefile.side_effect = OSError("makefile failed")
        context = Mock()
        context.wrap_socket.return_value = wrapped
        client = InformixSqliClient(
            "host",
            9088,
            "db",
            "user",
            "secret",
            server_name="server",
            ssl_context=context,
        )
        with patch("socket.create_connection", return_value=raw):
            with self.assertRaisesRegex(OSError, "makefile failed"):
                client._connect_once("host", 9088, "server", float("inf"))
        # The wrapped socket owns the raw fd after a successful handshake, so it is
        # the one that must be closed; closing raw would leak the TLS session.
        wrapped.close.assert_called_once_with()
        raw.close.assert_not_called()

    def test_a_failed_ca_file_read_is_retried_before_the_socket_opens(self):
        # ssl.ca.file on a Volume is read through its FUSE mount, which refuses a read now
        # and then. The read is tried three times before the connection fails, and before
        # any socket is opened; a CA file whose contents don't load fails at once.
        module = "databricks.labs.community_connector.sources.informix.sqli"
        refused = PermissionError(1, "Operation not permitted")
        context = Mock()
        context.wrap_socket.side_effect = RuntimeError("stop after the TLS wrap")
        client = InformixSqliClient(
            "host", 9088, "db", "user", "secret", server_name="server", ca_file="/v/ca.pem"
        )

        def connect(created):
            with (
                patch(f"{module}._CA_FILE_RETRY_SECONDS", 0),
                patch("ssl.create_default_context", side_effect=created) as create_context,
                patch("socket.create_connection", return_value=Mock()) as open_socket,
            ):
                try:
                    client._connect_once("host", 9088, "server", float("inf"))
                except Exception as error:  # noqa: BLE001 - returned for the assertions
                    return error, create_context, open_socket
            raise AssertionError("connect unexpectedly succeeded")

        error, create_context, open_socket = connect([refused, refused, context])
        self.assertRegex(str(error), "stop after the TLS wrap")
        self.assertEqual(create_context.call_count, 3)
        create_context.assert_called_with(cafile="/v/ca.pem")
        open_socket.assert_called_once()
        error, create_context, open_socket = connect([refused] * 3)
        self.assertIs(error, refused)
        self.assertEqual(create_context.call_count, 3)
        open_socket.assert_not_called()
        bad = ssl.SSLError("no certificate or crl found")
        error, create_context, open_socket = connect([bad, context])
        self.assertIs(error, bad)
        self.assertEqual(create_context.call_count, 1)
        open_socket.assert_not_called()

    def test_plaintext_connection_does_not_create_or_wrap_tls_context(self):
        raw = Mock()
        raw.makefile.side_effect = RuntimeError("stop after socket selection")
        client = InformixSqliClient(
            "host",
            9088,
            "db",
            "user",
            "secret",
            server_name="server",
            tls=False,
        )
        with (
            patch("socket.create_connection", return_value=raw),
            patch("ssl.create_default_context") as create_context,
            self.assertRaisesRegex(RuntimeError, "stop after socket selection"),
        ):
            client._connect_once("host", 9088, "server", float("inf"))
        create_context.assert_not_called()

    def test_a_short_protocol_offer_reads_as_offering_nothing(self):
        # The offer reader accepts vectors from 5 bytes, so the session flags read from
        # bytes 7 and 8 must treat a shorter offer as not offering them, not index past it.
        module = "databricks.labs.community_connector.sources.informix.sqli"
        client = InformixSqliClient(
            "host", 9088, "db", "user", "secret", server_name="server", tls=False
        )
        with (
            patch("socket.create_connection", return_value=Mock()),
            patch(f"{module}.read_exact", side_effect=lambda _, n: b"\x00\x06\x00\x00\x00\x00"[:n]),
            patch(f"{module}.decode_asc_accept", return_value=Mock()),
            patch.object(InformixSqliClient, "_read_protocol_offer", return_value=b"\xff" * 5),
            patch(f"{module}.encode_secondary_info", side_effect=RuntimeError("offer read")),
            self.assertRaisesRegex(RuntimeError, "offer read"),
        ):
            client._connect_once("host", 9088, "server", float("inf"))
        self.assertEqual(
            (client.remove_64k_limit, client.large_tuple_size, client.long_row_id),
            (False, False, False),
        )

    def test_session_header_round_trip(self):
        packet = encode_session_packet(1, b"request")
        self.assertEqual(read_session_packet(io.BytesIO(packet)), (1, 60, b"request"))
        flagged = bytearray(encode_session_packet(2, b"accepted"))
        flagged[4:6] = b"\x10\x00"
        self.assertEqual(read_session_packet(io.BytesIO(flagged)), (2, 60, b"accepted"))
        flagged[4:6] = b"\x20\x00"
        with self.assertRaises(SqliProtocolError):
            read_session_packet(io.BytesIO(flagged))

    def test_char_padding(self):
        self.assertEqual(encode_char(b"abc"), b"\x00\x03abc\x00")
        self.assertEqual(encode_char(b"abcd"), b"\x00\x04abcd")

    def test_asc_strings_are_nul_terminated_without_even_padding(self):
        self.assertEqual(encode_asc_char("ab"), b"\x00\x03ab\0")
        self.assertEqual(encode_asc_char("abc"), b"\x00\x04abc\0")

    def test_normal_auth_prefix_golden_fields(self):
        prefix = encode_normal_auth_prefix("alice", "secret", "srv", "db")
        self.assertTrue(prefix.startswith(struct.pack(">hhi", 100, 101, 61)))
        self.assertIn(encode_asc_char("alice"), prefix)
        self.assertIn(encode_asc_char("secret"), prefix)
        self.assertIn(struct.pack(">i", 316), prefix)
        self.assertTrue(prefix.endswith(struct.pack(">hhhhh", 0, 0, 0, 0, 0)))
        self.assertNotIn(b"db\0", prefix)

    def test_live_mandatory_environment_is_deterministic(self):
        values = {
            "CLIENT_LOCALE": "en_US.819",
            "CLNT_PAM_CAPABLE": "1",
            "DBPATH": ".",
            "DB_LOCALE": "en_US.819",
            "DELIMIDENT": "1",
            "IFX_UPDDESC": "1",
            "NODEFDAC": "no",
        }
        encoded = encode_asc_environment(values, "iso8859-1")
        self.assertTrue(encoded.startswith(struct.pack(">hh", 106, 7)))
        offsets = [encoded.index(key.encode() + b"\0") for key in sorted(values)]
        self.assertEqual(offsets, sorted(offsets))

    def test_complete_auth_request_and_accept_decode(self):
        request = encode_normal_auth_request(
            "alice", "secret", "srv", "db", {"CLIENT_LOCALE": "en_US.utf8"}
        )
        sl_type, protocol, payload = read_session_packet(io.BytesIO(request))
        self.assertEqual((sl_type, protocol), (1, 60))
        self.assertTrue(payload.endswith(struct.pack(">h", 127)))
        body = (
            struct.pack(">hh", 100, 101)
            + b"\0" * 4
            + struct.pack(">h", 0)
            + struct.pack(">h", 108)
            + b"\0" * 12
            + struct.pack(">h", 3)
            + b"316"
            + struct.pack(">hhiii", 0, 0, 1, 2, 3)
            + b"\0" * 2
            + struct.pack(">hh", 0, 0)
            + b"\0" * 24
            + struct.pack(">h", 127)
        )
        accepted = decode_asc_accept(encode_session_packet(2, body))
        self.assertEqual(
            (accepted.version, accepted.cap_1, accepted.cap_2, accepted.cap_3), ("316", 1, 2, 3)
        )

    def test_rejected_session_points_at_the_server_log(self):
        with self.assertRaisesRegex(SqliSessionRejected, "server log"):
            decode_asc_accept(encode_session_packet(3, b""))

    def test_live_initresp_metadata_tail_is_bounded_by_asceot(self):
        fixed = (
            struct.pack(">hh", 100, 101)
            + b"\0" * 4
            + struct.pack(">h", 0)
            + struct.pack(">h", 108)
            + b"\0" * 12
            + struct.pack(">h", 3)
            + b"316"
            + struct.pack(">hhiii", 0, 0, 316, 0, 0)
            + b"\0" * 2
            + struct.pack(">hh", 0, 0)
            + b"\0" * 24
            + struct.pack(">h", 102)
            + b"\0" * 12
            + b"sanitized-server-metadata"
            + struct.pack(">h", 127)
        )
        packet = bytearray(encode_session_packet(2, fixed))
        packet[4:6] = b"\x10\x00"
        self.assertEqual(decode_asc_accept(bytes(packet)).version, "316")

    def test_simple_command_group(self):
        command = encode_simple_command("SELECT 1")
        self.assertTrue(command.startswith(struct.pack(">hh", 1, 0)))
        self.assertTrue(command.endswith(struct.pack(">hhhh", 22, 7, 11, 12)))

    def test_protocol_and_secondary_environment_groups(self):
        self.assertEqual(
            encode_protocol_offer(),
            struct.pack(">hh", 126, 9)
            + bytes.fromhex("ff fc 7f fc 3c 8c aa 97 06")
            + b"\0\x00\x0c",
        )
        info = encode_secondary_info({"CLIENT_LOCALE": "en_US.utf8"})
        self.assertTrue(info.startswith(struct.pack(">hh", 81, 6)))
        self.assertTrue(info.endswith(struct.pack(">hhh", 0, 0, 12)))

    def test_forward_cursor_messages(self):
        self.assertEqual(encode_cursor_open(7, "c")[:6], struct.pack(">hhh", 4, 7, 3))
        self.assertEqual(encode_fetch(7), struct.pack(">hhhihh", 4, 7, 9, 32767, 0, 12))
        self.assertEqual(encode_close_release(7), struct.pack(">hhhh", 4, 7, 10, 12))
        self.assertEqual(encode_close_release(7, True), struct.pack(">hhhh", 4, 7, 11, 12))

    def test_variable_fetch_sends_ret_type_before_nfetch(self):
        description = ResultDescription(2, 7, 20, (ResultColumn("v", 0, 13, 0, 20),))
        self.assertEqual(
            encode_variable_fetch(description, 4096),
            struct.pack(">hhhhhhihihh", 4, 7, 100, 1, 1, 13, 20, 9, 4096, 0, 12),
        )

    def test_variable_fetch_resolves_builtin_extended_types(self):
        description = ResultDescription(
            2,
            7,
            17,
            (
                ResultColumn("text", 0, 40, 1, 16, "informix", "lvarchar"),
                ResultColumn("enabled", 16, 41, 5, 1, "informix", "boolean"),
            ),
        )
        expected = bytearray(struct.pack(">hhhhh", 4, 7, 100, 1, 2))
        expected.extend(struct.pack(">h", 43))
        expected.extend(encode_char(""))
        expected.extend(encode_char(""))
        expected.extend(struct.pack(">i", 16))
        expected.extend(struct.pack(">h", 45))
        expected.extend(encode_char("informix"))
        expected.extend(encode_char("boolean"))
        expected.extend(struct.pack(">i", 1))
        expected.extend(struct.pack(">hihh", 9, 4096, 0, 12))

        self.assertEqual(encode_variable_fetch(description, 4096), bytes(expected))

    def test_variable_fetch_rejects_user_defined_builtin_name(self):
        description = ResultDescription(
            2,
            7,
            16,
            (ResultColumn("value", 0, 40, 9, 16, "application", "lvarchar"),),
        )

        with self.assertRaisesRegex(SqliDescriptorNotImplemented, "result type 40"):
            encode_variable_fetch(description)

    def test_mixed_lvarchar_and_boolean_tuple_decodes_variable_envelopes(self):
        payload = (
            b"\x00" + struct.pack(">i", 5) + b"hello" + b"\x00" + struct.pack(">i", 1) + b"\x01"
        )
        transcript = struct.pack(">hi", 0, len(payload)) + payload
        if len(payload) & 1:
            transcript += b"\x00"
        client = InformixSqliClient("host", 9088, "db", "user", "password")
        client._input = io.BytesIO(transcript)
        description = ResultDescription(
            2,
            7,
            len(payload),
            (
                ResultColumn("text", 0, 43, 0, 100),
                ResultColumn("enabled", 10, 45, 0, 1),
            ),
        )

        self.assertEqual(client._read_tuple(description), {"text": "hello", "enabled": True})

    def test_padded_varchar_beside_an_lvarchar_is_length_prefixed(self):
        # A live server sends a tuple holding an LVARCHAR or BOOLEAN in the variable
        # layout, VARCHARs length-prefixed, even under padVarchar; reading the VARCHAR
        # as padded ran every later column out of the payload.
        payload = (
            b"\x02ab"
            + b"\x00"
            + struct.pack(">i", 5)
            + b"hello"
            + b"\x00"
            + struct.pack(">i", 1)
            + b"\x01"
            + b"\x01z"
        )
        transcript = struct.pack(">hi", 0, len(payload)) + payload
        if len(payload) & 1:
            transcript += b"\x00"
        client = InformixSqliClient("host", 9088, "db", "user", "password", pad_varchar=True)
        client._input = io.BytesIO(transcript)
        description = ResultDescription(
            2,
            7,
            len(payload),
            (
                ResultColumn("label", 0, 13, 0, 10),
                ResultColumn("text", 10, 43, 0, 100),
                ResultColumn("enabled", 110, 45, 0, 1),
                ResultColumn("note", 111, 13, 0, 10),
            ),
        )

        self.assertEqual(
            client._read_tuple(description),
            {"label": "ab", "text": "hello", "enabled": True, "note": "z"},
        )

    def test_fetch_and_decode_agree_on_the_tuple_layout(self):
        # execute asks for the variable fetch exactly when _read_tuple expects it.
        varchar = ResultColumn("label", 0, 13, 0, 10)
        lvarchar = ResultColumn("text", 10, 40, 0, 100)
        integer = ResultColumn("id", 0, 2, 0, 4)
        # A BOOLEAN typed 45 reads as a variable envelope, as the opaque 41 one does.
        boolean = ResultColumn("enabled", 4, 45, 0, 1)
        for pad_varchar, columns, variable in (
            (True, (varchar, lvarchar), True),
            (True, (integer, boolean), True),
            (True, (varchar, integer), False),
            (False, (varchar, integer), True),
            (False, (integer,), False),
        ):
            with self.subTest(pad_varchar=pad_varchar, columns=[c.name for c in columns]):
                client = InformixSqliClient(
                    "host", 9088, "db", "user", "password", pad_varchar=pad_varchar
                )
                description = ResultDescription(2, 7, 0, columns)
                self.assertIs(client._variable_tuples(description), variable)

    def test_variable_tuple_positions_do_not_bound_runtime_envelopes(self):
        payload = (
            b"\x00" + struct.pack(">i", 5) + b"hello" + b"\x00" + struct.pack(">i", 1) + b"\x01"
        )
        transcript = struct.pack(">hi", 0, len(payload)) + payload
        if len(payload) & 1:
            transcript += b"\x00"
        client = InformixSqliClient("host", 9088, "db", "user", "password")
        client._input = io.BytesIO(transcript)
        description = ResultDescription(
            2,
            7,
            len(payload),
            (
                ResultColumn("text", 0, 43, 0, 100),
                ResultColumn("enabled", 9, 45, 0, 1),
            ),
        )

        self.assertEqual(client._read_tuple(description), {"text": "hello", "enabled": True})

    def test_live_feature62_prepare_and_fixed_open_fetch_goldens(self):
        prepare = encode_prepare("x" * 38, parameter_count=0, long_sql_length=True)
        self.assertEqual(len(prepare), 52)
        self.assertEqual(prepare[:8], struct.pack(">hhi", 2, 0, 38))
        combined = encode_fixed_open_fetch(7, "cursor_name_123456", buffer_size=4096)
        self.assertEqual(len(combined), 42)
        self.assertTrue(combined.endswith(struct.pack(">hhhhihh", 6, 4, 7, 9, 4096, 0, 12)))

    def test_cost_xact_done_close_dispatch(self):
        transcript = (
            struct.pack(">hii", 55, 10, 20)
            + struct.pack(">hhhh", 99, 1, 2, 1)
            + struct.pack(">hhiii", 15, 0, 3, 4, 5)
            + struct.pack(">hh", 10, 12)
        )
        client = InformixSqliClient("host", 9088, "db", "user", "password")
        client._input = io.BytesIO(transcript)
        client._read_status_group()
        self.assertEqual(client._input.tell(), len(transcript))

    def test_query_close_marks_cursor_exhausted(self):
        client = InformixSqliClient("host", 9088, "db", "user", "password")
        client._input = io.BytesIO(struct.pack(">hh", 10, 12))
        _, rows, exhausted = client._read_query_group(None)
        self.assertEqual(rows, [])
        self.assertTrue(exhausted)

    def test_query_exit_terminates_response_group(self):
        client = InformixSqliClient("host", 9088, "db", "user", "password")
        client._input = io.BytesIO(struct.pack(">h", 56))

        description, rows, exhausted = client._read_query_group(None)

        self.assertIsNone(description)
        self.assertEqual(rows, [])
        self.assertFalse(exhausted)

    def test_status_exit_terminates_completed_response_group(self):
        done = struct.pack(">hhiii", 15, 0, 0, 0, 0)
        client = InformixSqliClient("host", 9088, "db", "user", "password")
        client._input = io.BytesIO(done + struct.pack(">h", 56))

        client._read_status_group(require_done=True)

        self.assertEqual(client._input.tell(), len(done) + 2)

    def test_insertdone_consumes_serial_metadata(self):
        description = ResultDescription(6, 7, 0, ())
        for bigint_supported, body in (
            (False, b"s" * 10),
            (True, b"s" * 10 + b"b" * 8),
        ):
            client = InformixSqliClient("host", 9088, "db", "user", "password")
            client.bigint_supported = bigint_supported
            transcript = struct.pack(">h", 94) + body + struct.pack(">h", 12)
            client._input = io.BytesIO(transcript)

            client._read_query_group(description)

            self.assertEqual(client._input.tell(), len(transcript))

    def test_insertdone_outside_insert_fails_closed(self):
        client = InformixSqliClient("host", 9088, "db", "user", "password")
        client._input = io.BytesIO(struct.pack(">h", 94) + b"s" * 10)

        with self.assertRaisesRegex(SqliProtocolError, "outside an INSERT"):
            client._read_query_group(ResultDescription(2, 7, 0, ()))

    def test_status_group_consumes_insertdone_serial_metadata(self):
        for bigint_supported, body in (
            (False, b"s" * 10),
            (True, b"s" * 10 + b"b" * 8),
        ):
            with self.subTest(bigint_supported=bigint_supported):
                done = struct.pack(">hhiii", 15, 0, 1, 0, 0)
                transcript = struct.pack(">hh", 8, 94) + body + done + struct.pack(">h", 12)
                client = InformixSqliClient("host", 9088, "db", "user", "password")
                client.bigint_supported = bigint_supported
                client._input = io.BytesIO(transcript)
                with patch.object(
                    client,
                    "_read_description",
                    return_value=ResultDescription(6, 7, 0, ()),
                ):
                    client._read_status_group(require_done=True)

                self.assertEqual(client._input.tell(), len(transcript))

    def test_status_group_rejects_insertdone_for_non_insert(self):
        client = InformixSqliClient("host", 9088, "db", "user", "password")
        client._input = io.BytesIO(struct.pack(">hh", 8, 94) + b"s" * 10)
        with (
            patch.object(
                client,
                "_read_description",
                return_value=ResultDescription(4, 7, 0, ()),
            ),
            self.assertRaisesRegex(SqliProtocolError, "outside an INSERT"),
        ):
            client._read_status_group()

    def test_zero_row_done_marks_fetch_exhausted(self):
        done = struct.pack(">hhiii", 15, 0, 0, 0, 0) + struct.pack(">h", 12)
        client = InformixSqliClient("host", 9088, "db", "user", "password")
        client._input = io.BytesIO(done)
        description = ResultDescription(2, 7, 0, ())
        _, rows, exhausted = client._read_query_group(description)
        self.assertEqual(rows, [])
        self.assertTrue(exhausted)

    def test_done_without_tuple_marks_fetch_exhausted_even_with_cumulative_count(self):
        done = struct.pack(">hhiii", 15, 0, 1, 0, 0) + struct.pack(">h", 12)
        client = InformixSqliClient("host", 9088, "db", "user", "password")
        client._input = io.BytesIO(done)
        description = ResultDescription(2, 7, 0, ())
        _, rows, exhausted = client._read_query_group(description)
        self.assertEqual(rows, [])
        self.assertTrue(exhausted)

    def test_lodata_dispatch_group(self):
        client = InformixSqliClient("host", 9088, "db", "user", "password")
        client.state = ConnectionState.DATABASE_OPEN
        client._input = io.BytesIO(
            struct.pack(">hhih", 97, 0, 3, 3) + b"abc\0" + struct.pack(">h", 12)
        )
        client._output = io.BytesIO()
        self.assertEqual(client.read_lodata(4, 10), b"abc")
        self.assertEqual(
            client._output.getvalue(), encode_lodata_read(4, 10) + struct.pack(">h", 12)
        )

    def test_lodata_dispatch_rejects_unknown_direction_and_negative_size(self):
        for operation, size in ((2, 0), (3, 0), (2, -1), (0, -1)):
            client = InformixSqliClient("host", 9088, "db", "user", "password")
            client.state = ConnectionState.DATABASE_OPEN
            client._input = io.BytesIO(struct.pack(">hhi", 97, operation, size))
            client._output = io.BytesIO()
            with self.assertRaises(SqliProtocolError):
                client.read_lodata(4, 10)

    def test_lodata_decodes_informix_error_body(self):
        client = InformixSqliClient("host", 9088, "db", "user", "password")
        client.state = ConnectionState.DATABASE_OPEN
        client._input = io.BytesIO(
            struct.pack(">hhhh", 13, -23197, -255, 7) + encode_char("TLS login failed")
        )
        client._output = io.BytesIO()

        with self.assertRaisesRegex(
            SqliProtocolError, r"-23197/-255 at 7 during LODATA: TLS login failed"
        ):
            client.read_lodata(4, 10)

    def test_describe_and_tuple_query_group(self):
        def descriptor(position, type_code, length):
            return (
                struct.pack(">iih", 0, position, type_code)
                + struct.pack(">i", 0)
                + encode_char("")
                + encode_char("")
                + struct.pack(">hhiii", 0, 0, type_code, length, 0)[:-4]
            )

        names = b"a\0b\0"
        describe = (
            struct.pack(">h", 8)
            + struct.pack(">hhihhi", 1, 7, 1, 8, 2, len(names))
            + descriptor(0, 2, 4)
            + descriptor(4, 13, 4)
            + names
        )
        payload = struct.pack(">i", 42) + b"\x03abc"
        transcript = (
            describe
            + struct.pack(">hh", 12, 12)
            + struct.pack(">hhi", 14, 0, len(payload))
            + payload
            + struct.pack(">hhhh", 13, 100, 0, 0)
            + encode_char("")
            + struct.pack(">hhh", 12, 12, 12)
        )
        client = InformixSqliClient("host", 9088, "db", "user", "password")
        client.state = ConnectionState.DATABASE_OPEN
        client._input, client._output = io.BytesIO(transcript), io.BytesIO()
        self.assertEqual(client.execute("SELECT ?", ("x'y",)), [{"a": 42, "b": "abc"}])
        self.assertIn(b"SELECT 'x''y'", client._output.getvalue())

    def test_full_synthetic_connect_state_machine(self):
        asc_body = (
            struct.pack(">hh", 100, 101)
            + b"\0" * 4
            + struct.pack(">h", 0)
            + struct.pack(">h", 108)
            + b"\0" * 12
            + struct.pack(">h", 3)
            + b"316"
            + struct.pack(">hhiii", 0, 0, 1, 2, 3)
            + b"\0" * 2
            + struct.pack(">hh", 0, 0)
            + b"\0" * 24
            + struct.pack(">h", 127)
        )
        transcript = (
            encode_session_packet(2, asc_body)
            + struct.pack(">hh", 126, 9)
            + bytes.fromhex("ff fc 7f fc 3c 8c aa 97 06")
            + b"\0"
            + struct.pack(">hhh", 12, 12, 15)
            + struct.pack(">hqqi", 0, 0, 0, 0)
            + struct.pack(">h", 12)
        )

        class FakeSocket:
            def __init__(self):
                self.input, self.output = io.BytesIO(transcript), io.BytesIO()

            def settimeout(self, _value):
                pass

            def setsockopt(self, *_args):
                pass

            def makefile(self, mode, buffering=0):
                return self.input if "r" in mode else self.output

            def close(self):
                pass

        class FakeContext:
            def __init__(self):
                self.calls = 0

            def wrap_socket(self, raw, server_hostname=None):
                self.calls += 1
                return raw

        for tls in (True, False):
            with self.subTest(tls=tls):
                fake = FakeSocket()
                context = FakeContext()
                client = InformixSqliClient(
                    "host",
                    9088,
                    "db",
                    "user",
                    "password",
                    server_name="srv",
                    db_locale="en_US.utf8",
                    client_locale="en_US.utf8",
                    tls=tls,
                    ssl_context=context,
                )
                with patch("socket.create_connection", return_value=fake):
                    self.assertIs(client.connect(), client)
                self.assertEqual(client.state, ConnectionState.DATABASE_OPEN)
                self.assertTrue(client.remove_64k_limit)
                self.assertTrue(client.large_tuple_size)
                self.assertTrue(client.long_row_id)
                self.assertEqual(fake.output.getvalue()[2], 1)
                self.assertEqual(context.calls, 1 if tls else 0)


class DatetimeChunkCastTests(unittest.TestCase):
    def test_contiguous_qualifiers_produce_fixed_width_casts(self):
        # (packed qualifier, expected CHAR width) for the column's own range.
        # Widths are the canonical zero-padded text length: YEAR..SECOND ->
        # 4/7/10/13/16/19, HOUR-anchored TIME -> 2/5/8, plus 1+digits per
        # FRACTION. Casting in the column's own qualifier keeps the string
        # fixed-width, so byte order is a stable total order for keyset paging.
        cases = [
            (0x0000, 4),  # YEAR
            (0x0004, 10),  # YEAR TO DAY
            (0x000A, 19),  # YEAR TO SECOND
            (0x000F, 25),  # YEAR TO FRACTION(5)
            (0x0608, 5),  # HOUR TO MINUTE
            (0x060A, 8),  # HOUR TO SECOND
            (0x060F, 14),  # HOUR TO FRACTION(5)  (tw221's lu_time)
            (0x0204, 5),  # MONTH TO DAY
        ]
        for qualifier, width in cases:
            with self.subTest(qualifier=qualifier):
                expr = datetime_order_preserving_cast("ts", qualifier)
                self.assertIsNotNone(expr)
                # No EXTEND: cast the column in its own declared range.
                self.assertNotIn("EXTEND", expr)
                self.assertEqual(expr, f"CAST(ts AS CHAR({width}))")

    def test_malformed_qualifiers_have_no_cast(self):
        # Non-field start nibble, or end before start: reject so the caller
        # falls back instead of chunking on an ill-defined order.
        for qualifier in (0x0105, 0x0400, 0x0700):
            with self.subTest(qualifier=qualifier):
                self.assertIsNone(datetime_order_preserving_cast("ts", qualifier))


class StaleCaptureLabelFrameTests(unittest.TestCase):
    """Real frames captured from Informix 14.10 for tw316_ovhc via syscdcv1.

    Both frames are INSERT (kind 40) and both carry capture label 1, whose
    registered layout is ``source_rowid INTEGER, payload VARCHAR(160)``. The
    difference is the logical log they came from: the source replayed records
    from a reused log file under this session's label, so the label alone is not
    proof that a payload matches the layout.
    """

    # logical log 12: a genuine tw316_ovhc row.
    GOOD = base64.b64decode(
        "AAAAKAAAACEAAABCAAAAKAAAAAwEpMG4AAAAtgAAAAEAAAAAAAAAHQAAAAEcU3ludGhldGlj"
        "IE9WSEMgaGVhbHRoIGZ1bmQgMQ=="
    )
    # logical log 7: a syscolumns row (tabname/tabid/colno/coltype/collength),
    # nothing to do with tw316_ovhc, but tagged with the same capture label.
    STALE = base64.b64decode(
        "AAAAKAAAAHMAAABCAAAAKAAAAAcKnjegAAAAHwAAAAEAAAAAAAAAbwd0YWJuYW1lAAAAAQAB"
        "AA0AgIAAAACAAAAAAAAAAAAAAAAAAGxhc3MuYwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
        "AAAAAAAAAAAAAAAAnQUAAAAAAABpHn7UAAAAAP//AAAAAAAAAAAAAAAAAAAAAAA="
    )

    def labels(self):
        return {
            1: (
                ColumnDescriptor(
                    name="source_rowid",
                    type_name="INTEGER",
                    length=4,
                    precision=None,
                    scale=None,
                    encoding="utf-8",
                ),
                ColumnDescriptor(
                    name="payload",
                    type_name="VARCHAR",
                    length=160,
                    precision=None,
                    scale=None,
                    encoding="utf-8",
                ),
            )
        }

    def test_a_genuine_captured_row_still_decodes(self):
        record = decode_frame(self.GOOD, self.labels())

        self.assertEqual(record["op"], "INSERT")
        self.assertEqual(record["label"], 1)
        self.assertEqual(
            record["row"], {"source_rowid": 1, "payload": "Synthetic OVHC health fund 1"}
        )

    def test_a_stale_labelled_frame_reports_the_column_and_offset(self):
        """The bare UnicodeDecodeError this used to raise named neither.

        decode_row caught only CdcProtocolError, so the codec error from the text
        branch escaped unwrapped and production saw
        "'utf-8' codec can't decode byte 0x80 in position 12" with no indication
        of which column or payload offset failed.
        """

        with self.assertRaises(CdcProtocolError) as caught:
            decode_frame(self.STALE, self.labels())

        message = str(caught.exception)
        self.assertIn("payload", message)
        self.assertIn("offset", message)
        # The underlying codec failure is preserved as the cause.
        self.assertIsInstance(caught.exception.__cause__, UnicodeDecodeError)

    def test_the_stale_frame_carries_the_same_label_as_the_genuine_one(self):
        """Pins the premise: the label cannot distinguish these two frames."""

        good_lsn, _, good_label = struct.unpack_from(">Qii", self.GOOD, 16)
        stale_lsn, _, stale_label = struct.unpack_from(">Qii", self.STALE, 16)

        self.assertEqual(good_label, stale_label)
        self.assertEqual(good_lsn >> 32, 12)
        self.assertEqual(stale_lsn >> 32, 7)


class NullByteSanitizationTests(unittest.TestCase):
    """A decoded string with an embedded NUL is sanitized per the string.null.byte mode,
    in both decode paths (CDC decode_value and the snapshot/query _decode_result_value)."""

    def test_apply_null_byte_modes(self):
        self.assertEqual(apply_null_byte("a\x00b", "keep"), "a\x00b")  # pass through
        self.assertIsNone(apply_null_byte("a\x00b", "null"))  # whole value -> NULL
        self.assertEqual(apply_null_byte("a\x00b", "empty"), "ab")  # strip the NUL
        self.assertEqual(apply_null_byte("\x00", "empty"), "")  # NUL-only -> ""
        self.assertIsNone(apply_null_byte("\x00", "null"))

    def test_apply_null_byte_leaves_clean_and_non_string_values(self):
        self.assertEqual(apply_null_byte("abc", "null"), "abc")  # no NUL -> unchanged
        self.assertEqual(apply_null_byte(123, "null"), 123)  # non-string -> unchanged
        self.assertIsNone(apply_null_byte(None, "null"))

    def test_cdc_decode_value_applies_the_mode_to_char(self):
        char = ColumnDescriptor("c", "CHAR", length=3)
        self.assertEqual(decode_value(memoryview(b"ab\x00"), char, null_byte="keep"), ("ab\x00", 3))
        self.assertEqual(decode_value(memoryview(b"ab\x00"), char, null_byte="null"), (None, 3))
        self.assertEqual(decode_value(memoryview(b"ab\x00"), char, null_byte="empty"), ("ab", 3))
        # Default is keep, so existing callers/tests are unaffected.
        self.assertEqual(decode_value(memoryview(b"ab\x00"), char), ("ab\x00", 3))

    def test_cdc_decode_value_applies_the_mode_to_varchar(self):
        varchar = ColumnDescriptor("v", "VARCHAR")
        raw = memoryview(bytes([3]) + b"a\x00b")
        self.assertEqual(decode_value(raw, varchar, null_byte="null"), (None, 4))
        self.assertEqual(decode_value(raw, varchar, null_byte="empty"), ("ab", 4))

    def test_snapshot_decode_applies_the_mode_to_char(self):
        # type_code 0 = CHAR; encoded_length is the fixed width.
        column = ResultColumn("c", 0, 0, 0, 3)
        self.assertIsNone(_decode_result_value(b"ab\x00", column, "utf-8", False, "null"))
        self.assertEqual(_decode_result_value(b"ab\x00", column, "utf-8", False, "empty"), "ab")
        self.assertEqual(_decode_result_value(b"ab\x00", column, "utf-8", False, "keep"), "ab\x00")
        # Default keeps the byte (backward compatible for any caller not passing the mode).
        self.assertEqual(_decode_result_value(b"ab\x00", column, "utf-8"), "ab\x00")


if __name__ == "__main__":
    unittest.main()
