"""Pure-Python, serverless-capable Informix snapshot and CDC connector.

The SQLI, CDC framing, codec, transaction, and Lakeflow paths are covered by
source-local regression tests. Informix 15 and serverless Lakeflow pipelines
have validated authentication, queries, discovery, snapshots, and CDC.
"""

from __future__ import annotations

import base64
import concurrent.futures
import contextlib
import dataclasses
import errno
import fnmatch
import gzip
import hashlib
import hmac
import importlib
import itertools
import json
import logging
import math
import operator
import os
import queue
import random
import re
import secrets
import stat
import sys
import tempfile
import threading
import time
import types
import zipfile
import zlib
from collections import deque
from dataclasses import dataclass, field, replace
from datetime import date, datetime, timezone
from decimal import ROUND_DOWN, ROUND_HALF_UP, Decimal, InvalidOperation, localcontext
from typing import Any, Callable, Iterable, Iterator, Protocol, Sequence

from pyspark.sql.types import (
    BinaryType,
    BooleanType,
    DateType,
    DecimalType,
    DoubleType,
    FloatType,
    IntegerType,
    LongType,
    StringType,
    StructField,
    StructType,
    TimestampType,
)

from databricks.labs.community_connector.interface import LakeflowConnect
from databricks.labs.community_connector.interface.supports_partition import (
    SupportsPartitionedStream,
)
from databricks.labs.community_connector.sources.informix.cdc_protocol import (
    CdcFrameParser,
    CdcProtocolError,
    ColumnDescriptor,
    OpenTransactionRecords,
    apply_null_byte,
    cdc_routine,
    datetime_from_text,
    decode_frame,
    frame_log_file,
    interval_layout,
    metadata_column_names,
    validate_snapshot_arity,
)
from databricks.labs.community_connector.sources.informix.lakebase_state import (
    _DEFAULT_STAGING_TOKEN_LIFETIME_SECONDS,
    _STAGING_TOKEN_MIN_LIFETIME_SECONDS,
    LakebaseState,
    StagingCredentialProvider,
    StagingTokenUnavailable,
    WorkspaceFilesApi,
    WorkspaceHttpError,
    _workspace_credentials,
    acquire_slot,
    capture_workspace_credentials,
    collect_stale_table_state,
    connection_lost_error_types,
    delete_cdc_handoff,
    delete_obsolete_scoped_state_records,
    delete_spill_run,
    dequeue_waiter,
    enqueue_waiter,
    get_cdc_handoff,
    heartbeat_slot,
    heartbeat_waiter,
    list_spill_runs,
    merge_spill_run,
    pool_progress_token,
    publish_backlog_hint,
    publish_connection_limit,
    publish_maximum_lsn_state_record,
    publish_minimum_lsn_state_record,
    publish_state_record,
    put_cdc_handoff,
    read_backlog_hints,
    read_state_record,
    release_slot,
    seed_slots,
    touch_table_activity,
)
from databricks.labs.community_connector.sources.informix.sqli import (
    InformixDatetimeLiteral,
    InformixSqliClient,
    PasswordAuthenticationProvider,
    SqliProtocolError,
    SqliTransportError,
    add_informix_exception_note,
    datetime_order_preserving_cast,
    informix_locale_encoding,
)


class _Messages:
    # Docstring: The connector's message templates, read from informix_messages.json on first
    # use; ``_m(index, *values)`` formats one.
    #
    # Kept out of the pickled source: Spark ships this class's code to every worker by value,
    # and the templates are about 32 KB of text. Pickling holds only the file's path, which
    # every serverless worker can read, and each worker reads the file itself. The comment
    # above each ``_m`` call shows its template; lakeflow_test keeps the two in step. A file
    # that cannot be read never masks the error a message describes.
    #
    # Code imported from a zip archive (zipimport) has its path inside the archive, where
    # open() fails; the file is then read from the archive. After a failed read the numbered
    # message is used for a minute before the file is tried again. Every call passes its
    # values here, logging calls included, so the numbered message keeps them.

    def __init__(self) -> None:
        # Source run without a __file__ (the merged file pasted into a notebook cell, or
        # exec'd) looks in the working directory instead of failing to register.
        source = globals().get("__file__") or "_"
        self.path = os.path.join(os.path.dirname(os.path.abspath(source)), "informix_messages.json")
        self.templates: list[str] | None = None
        self.retry_at = 0.0

    def __getstate__(self) -> dict[str, str]:
        return {"path": self.path}

    def __setstate__(self, state: dict[str, str]) -> None:
        self.path, self.templates, self.retry_at = state["path"], None, 0.0

    def __call__(self, index: int, *values: Any) -> str:
        if self.templates is None and time.monotonic() >= self.retry_at:
            try:
                archive, member = self.path, []
                while not os.path.isfile(archive):
                    archive, name = os.path.split(archive)
                    if not name:
                        raise FileNotFoundError(self.path)
                    member.insert(0, name)
                if member:
                    with zipfile.ZipFile(archive) as bundle:
                        text = bundle.read("/".join(member))
                else:
                    with open(archive, "rb") as handle:
                        text = handle.read()
                self.templates = json.loads(text)
            except Exception:  # pylint: disable=broad-except
                self.retry_at = time.monotonic() + 60
        if self.templates is not None:
            try:
                return self.templates[index].format(*values)
            except Exception:  # pylint: disable=broad-except
                pass  # a file from another version: no such template, or other fields
        return f"Informix message {index} {values!r}"


_m = _Messages()

CURSOR = "_informix_change_lsn"
COMMIT_LSN = "_informix_commit_lsn"
TX_ID = "_informix_tx_id"
OP = "_informix_op"
# Source commit time (TimestampType, UTC): the Informix transaction commit time for
# CDC rows (c/u/d), the snapshot boundary time for snapshot rows (r), and NULL when the
# source did not supply one (e.g. a file-source extract without a manifest boundary_time).
# Appended last and excluded from the schema fingerprint, so adding it to an existing
# target is an additive column: pre-existing rows keep NULL, new rows are populated.
COMMIT_TIME = "_informix_commit_time"
_INTERNAL_COLUMNS = (CURSOR, COMMIT_LSN, TX_ID, OP, COMMIT_TIME)
_LSN_DECIMAL_WIDTH = 20
_OFFSET_VERSION = 10
# Informix undelimited identifiers: the first character is a "letter" or
# underscore and later characters add digits and "$", where the "letter" class
# is defined by the database locale -- under the default en_US.819 (Latin-1) that
# includes accented letters such as e-acute or n-tilde. Match Unicode letters so a
# legitimately accented owner/table/column name is not rejected. ``+`` and ``.``
# are also permitted in later positions -- both occur in real Informix owner names
# (e.g. a "firstname.lastname" login owner) -- while the class still excludes the
# injection-unsafe characters (quotes, spaces, ``;`` ...) so a validated identifier
# cannot break out of its SQL context. Characters beyond the bare-safe set are sent
# as delimited identifiers (see _sql_identifier / _join_identity).
_IDENTIFIER = re.compile(r"^[^\W\d][\w$+.]*$", re.UNICODE)
# Identifiers safe to interpolate *bare* (undelimited): a locale letter or
# underscore followed by letters/digits/underscore/"$". Anything the validator
# admits beyond this (e.g. "+" or ".") is not a valid undelimited identifier and
# must be sent delimited -- wrapped in double quotes, which the server honors
# because the connection sets DELIMIDENT.
_BARE_IDENTIFIER = re.compile(r"^[^\W\d][\w$]*$", re.UNICODE)


def _sql_identifier(identifier: str) -> str:
    # Docstring: Render a (already validated) identifier for interpolation into SQL.
    #
    # Bare when it is a valid undelimited identifier; otherwise delimited with
    # double quotes, doubling any embedded quote. The identifier must already have
    # passed ``_IDENTIFIER`` validation, so the delimited branch only ever escapes
    # admitted characters such as "+" and ".".

    if _BARE_IDENTIFIER.fullmatch(identifier):
        return identifier
    return '"' + identifier.replace('"', '""') + '"'


def _join_identity(*components: str) -> str:
    # Docstring: Join identity components with ``.``, delimiting any component that is not a
    # valid undelimited identifier so the result round-trips through
    # ``_split_identity`` even when a component itself contains ``.``.

    return ".".join(_sql_identifier(component) for component in components)


def _split_identity(identity: str) -> list[str]:
    # Docstring: Split a ``.``-joined identity into its components -- the inverse of
    # ``_join_identity``.
    #
    # A double-quoted component is taken whole (so it may contain ``.``) with its
    # doubled quotes unescaped; bare components split on ``.`` as before.

    parts: list[str] = []
    index, length = 0, len(identity)
    while True:
        if index < length and identity[index] == '"':
            cursor, buffer = index + 1, []
            while cursor < length:
                if identity[cursor] == '"':
                    if cursor + 1 < length and identity[cursor + 1] == '"':
                        buffer.append('"')
                        cursor += 2
                        continue
                    break
                buffer.append(identity[cursor])
                cursor += 1
            else:
                # 0: Unterminated quoted identifier in {!r}
                raise InformixError(_m(0, identity))
            parts.append("".join(buffer))
            index = cursor + 1
        else:
            dot = identity.find(".", index)
            end = length if dot == -1 else dot
            parts.append(identity[index:end])
            index = end
        if index >= length:
            return parts
        if identity[index] != ".":
            raise InformixError(f"Malformed identity {identity!r}")
        index += 1


_DATA_OPS = {"INSERT", "BEFORE_UPDATE", "AFTER_UPDATE", "DELETE", "TRUNCATE"}
_DEFAULT_SNAPSHOT_PAGE_SIZE = 20000
# A keyless initial snapshot drains positionally (no seek cursor) and stages whole
# pages to the Volume, so a larger default page means fewer manifest entries and
# round trips for the same rows. Kept separate from the keyed paging size so it can
# be tuned without affecting keyset chunks.
_DEFAULT_KEYLESS_SNAPSHOT_PAGE_SIZE = 50000
_DEFAULT_SNAPSHOT_READ_TIMEOUT_SECONDS = 300
# CDC session setup/teardown (cdc_opensess/startcapture/activatesess/endcapture/
# closesess) runs on the transport's default socket timeout unless raised here.
# syscdcv1 teardown can stall under many concurrent CDC sessions, so give these
# control-plane calls more room than the 30s default without adopting the much
# larger snapshot read budget.
_DEFAULT_CDC_READ_TIMEOUT_SECONDS = 60
# How long a bridge leaves DBINFO('utc_current') alone after the source answered it with an
# error, before asking again; until then snapshot rows carry a NULL commit time.
_UTC_TIME_REPROBE_SECONDS = 600.0
_DEFAULT_MAX_RECORDS_PER_BATCH = 10000
# Informix's own per-session ceiling, passed straight to cdc_opensess. Each poll
# pays a connection slot plus a full CDC session open/activate/close, so a small
# window amortises that fixed cost over very little log progress. Request the
# largest window the source accepts and let the soft-boundary loop finish any
# transaction still open past it.
_DEFAULT_CDC_MAX_RECORDS = 256
# An open transaction holding more change records than cdc.spill.records in one poll has
# them written to the staging Volume as pages of up to _CDC_SPILL_PAGE_RECORDS, under a
# "cdc-spill" stage beside the snapshot pages, rather than kept in memory. Its batch is
# served from those pages by executors. 0 keeps every transaction in memory, bounded by
# cdc.max.transaction.records.
_CDC_SPILL_RECORDS_OPTION = "cdc.spill.records"
_DEFAULT_CDC_SPILL_RECORDS = 50_000
_CDC_SPILL_PAGE_RECORDS = 10_000
_CDC_SPILL_SCHEMA = "cdc-spill"
# A run's Lakebase record names the channels that have committed past its transaction;
# the channel that completes the table's set deletes the pages.
_CDC_SPILL_RECORD_TYPE = "cdc-spill-run"
# How often a reader lists its tables' runs from Lakebase again: a channel that read a
# transaction in memory (its shard spilled nothing) finishes the other shard's run so.
_CDC_SPILL_LIST_SECONDS = 300
# The changes a delete channel shapes rows from; a run of none of them has nothing for it.
_SPILL_DELETE_OPS = frozenset({"DELETE", "BEFORE_UPDATE", "AFTER_UPDATE", "TRUNCATE"})
_SNAPSHOT_MODES = frozenset(
    {
        "incremental",
        "initial",
        "initial_only",
        "cdc_only",
        "auto_snapshot",
        "recovery",
    }
)
# Per-table migration switch. When ``table.migration=true`` the table runs a two-run
# checkpoint handoff (see _read_handoff / _read_append_only) *instead of* its normal read:
# it never streams -- every read records a checkpoint, emits no rows, and stops. While
# still on the old flow it parks its stream (or mid-serve snapshot) offset in Lakebase and
# stops; on the new flow (fresh checkpoint after an SCD1->append switch or a destination
# move) it seeds from that parked offset and stops instead of re-snapshotting. Clearing
# table.migration (the "Restore" step) resumes normal reads from the recorded offset. It
# is orthogonal to snapshot.mode, which the table keeps unchanged throughout.
_TABLE_MIGRATION_OPTION = "table.migration"
# Handoff-token channels. Only the upsert channel's offset is parked: append ingestion
# has no separate delete channel. A DELETE after the boundary reaches the upsert channel,
# where it lands as a full-before-image ``d`` tombstone row by default (see
# ``append.delete.tombstones``) or is dropped when tombstones are switched off. The
# old key of a key-changing UPDATE on a keyed append table is handled the same way.
_HANDOFF_CHANNEL_UPSERT = 0
_HANDOFF_CHANNEL_DELETE = 1
_DEFAULT_SNAPSHOT_MODE = "incremental"
_UNSUPPORTED_SNAPSHOT_MODES = frozenset({"configuration_based", "custom"})
# Opt-in append-only ingestion, for a table Informix can capture but this connector
# cannot merge -- in practice one without a primary key.
#
# Deliberately a connector option rather than something inferred from a missing key.
# Append output is a *change log*, not current state: an UPDATE at the source appends
# its after-image as a second row (``_informix_op='u'``) and a DELETE appends a
# tombstone row carrying the full before-image (``_informix_op='d'``, see
# ``append.delete.tombstones`` below). On a keyless table that tombstone is a
# change-log record, not an applied delete -- there is no key to pair it with -- so a
# consumer that wants current state filters on ``_informix_op``. Nothing in the schema
# distinguishes an append-only log from a mutable table that merely lacks a key, so
# inferring append from a missing key would silently turn the latter's merge into a log.
#
# It cannot be read from ``scd_type`` either, even though the pipeline layer already
# maps ``scd_type=APPEND_ONLY`` onto an append flow: ``get_table_configuration``
# strips scd_type/primary_keys/sequence_by before the connector sees any options, so
# the value is structurally unavailable here. To append a *keyed* table, set both --
# this option (``true``) so the connector streams incrementally, and
# ``scd_type: APPEND_ONLY`` so the destination appends instead of a keyed merge.
#
# Accepts ``true`` / ``false`` / ``auto``. ``auto`` (also the default when the option
# is unset) appends only keyless tables and leaves keyed tables on their normal
# CDC/snapshot path -- equivalent, for a keyless table, to ``true`` + a keyless
# append destination. ``true`` forces append for every capturable table; ``false``
# forces the normal CDC/snapshot path even for a keyless table.
_APPEND_INGESTION_OPTION = "append.only.ingestion"
# Delete tombstones on the append path, on by default. Every CDC session enables
# full-row logging before capture, so a DELETE record always carries its full
# before-image; the append path emits it as a ``d`` row with the usual cursor /
# commit LSN / tx id / commit time columns, keeping the change log lossless (an UPDATE
# already lands as a ``u`` row). On a keyed table forced to append, a key-changing
# UPDATE removes the old key as well, so it also lands its before-image as a ``d`` row,
# ahead of the new key's ``u`` row and sequenced at the before-image's own log position.
# It costs nothing on a genuinely insert-only table,
# which never deletes. Set ``false`` (per table or connection-wide; the table option
# wins) only for an archive-style table where retention purges would otherwise append
# one tombstone per purged row. It has no effect on a table that is not on the append
# path: the keyed upsert channel still skips DELETEs, because the pipeline applies
# deletes only through the separate delete flow and would merge a ``d`` row on the
# upsert view as an upsert.
_APPEND_DELETE_TOMBSTONES_OPTION = "append.delete.tombstones"
# Sharded daemon-reader CDC (see _shared_cdc_mode). ``cdc.shared.session=host``, the
# default, shares each shard between the flow processes on one host through a leader
# process (see the host-shared shards block after _shared_cdc_shard); ``process`` shares
# the shards only within one process.
#
# The tables are partitioned into K shards (``cdc.shared.reader.threads``,
# default a quarter of ``max.concurrent.connections``, at least 1). A bounded
# pool of K driver-resident daemon threads -- one per shard -- each holds a single
# shared CDC session multiplexing just its shard's subset of tables, reads the log
# once, and fans the assembled transactions out to per-table in-memory buffers. The
# daemon also supplies the schema and log position each streaming poll needs, so in
# steady state a consumer's poll reads entirely from memory and touches Informix for
# nothing. Sharding is by stable hash of the native identity, so a table maps to the
# same shard on every driver and across restarts without coordination.
#
# Concurrent CDC sessions drop from ~N to K (bounding the syscdcv1 teardown that stalls
# under many concurrent sessions), reads are guaranteed parallel across the K daemon
# threads, and the driver thread count is bounded by K. Both the upsert and delete
# channels are sharded independently (the shard is keyed by channel).
# Partitioned stream reader. When enabled (default), the connector advertises the
# SupportsPartitionedStream contract so Spark uses the partitioned DataSourceStreamReader.
# Its one win is the staged-snapshot page-serve phase: instead of serving one page per
# microbatch on the driver, a microbatch spans up to `stream.partitioned.snapshot.pages.
# per.batch` pages, each read+decoded on a separate Spark executor; the first microbatch,
# which drains the snapshot to the stage, serves its page 0 the same way. Every other phase
# (the live CDC/incremental stream, transitions, deletes) degrades to driver-computed rows
# embedded in the descriptor -- byte-for-byte the current output, just wrapped, and split
# across partitions of bounded size when large. Both readers persist the connector's bare
# offset dict, so flipping this option and restarting resumes an existing checkpoint in place
# (no full refresh); serverless SDP was verified to resume across the reader-class swap.
_PARTITIONED_STREAM_OPTION = "stream.partitioned"
_PARTITIONED_SNAPSHOT_PAGES_PER_BATCH_OPTION = "stream.partitioned.snapshot.pages.per.batch"
_DEFAULT_PARTITIONED_SNAPSHOT_PAGES_PER_BATCH = 8
# An embedded partition reaches the executor as one JSON document that the framework parses
# whole, at about seven times its text in Python objects, under serverless's 1 GB Python
# memory limit. A larger embedded microbatch is split across partitions of at most this
# much row text each.
_MAX_EMBEDDED_PARTITION_BYTES = 16 << 20
# The framework tags a delete-channel reader's options with this key (see
# sparkpds/lakeflow_datasource.py). The partitioned reader reads it to route the embedded
# path to read_table_deletes rather than read_table; the delete channel never page-serves.
_IS_DELETE_FLOW_OPTION = "isDeleteFlow"
_SHARED_CDC_SESSION_OPTION = "cdc.shared.session"
_SHARED_CDC_THREADS_OPTION = "cdc.shared.reader.threads"
_SHARED_CDC_BUFFER_OPTION = "cdc.shared.buffer.max.records"
# Safety ceiling on buffered-but-unconsumed transactions per table in a shard. When a
# shard's slowest buffer reaches it, that shard's daemon defers new reads (throttle to
# the slowest reader) until the backlog drains, bounding driver memory.
_DEFAULT_SHARED_CDC_BUFFER = 200000
# How long a shard retains a subscriber after its last poll before dropping it from the
# capture set and floor computation, so a stopped flow cannot pin the shard forever.
_SHARED_CDC_SUBSCRIBER_TTL_SECONDS = 300.0
# Idle back-off between reads once a shard has drained its log, so a caught-up daemon
# does not busy-spin (and releases its connection slot for consumer bootstrap).
_SHARED_CDC_IDLE_POLL_SECONDS = 1.0
# A bounded read whose shard view does not yet show it done waits for the shard's next read,
# holding no connection slot, rather than opening a session of its own: for two of the
# shard's reads (each waits out cdc.timeout about twice) and a margin, re-taking the view
# at this interval, before it reads directly.
_SHARED_VIEW_WAIT_TIMEOUTS = 4
_SHARED_VIEW_WAIT_MARGIN_SECONDS = 5.0
_SHARED_VIEW_WAIT_POLL_SECONDS = 0.5
# Tables per batched catalog query (table_versions, get_tables), well inside the SQLI
# limit of 1024 bind values a statement.
_CATALOG_BATCH = 500
# Pieces of the catalog queries, each spelled once and assembled where a query runs: a
# table's columns, its primary key's index, and its UNIQUE indexes, each with an optional
# select-list tail in place of the braces, and an index's 16 key parts.
_INDEX_PARTS = ",".join(f"i.part{number}" for number in range(1, 17))
_CATALOG_COLUMNS_SQL = (
    "SELECT c.colname, c.coltype, c.collength, c.colno, t.tabid, c.extended_id, "
    "x.name AS extended_name, x.owner AS extended_owner{} FROM systables t "
    "JOIN syscolumns c ON t.tabid = c.tabid "
    "LEFT JOIN sysxtdtypes x ON x.extended_id = c.extended_id WHERE t.tabtype = 'T'"
)
_PRIMARY_KEY_SQL = (
    "SELECT " + _INDEX_PARTS + "{} FROM systables t JOIN sysconstraints x ON t.tabid=x.tabid "
    "JOIN sysindexes i ON x.idxname=i.idxname AND x.tabid=i.tabid "
    "WHERE t.tabtype='T' AND x.constrtype='P'"
)
_UNIQUE_INDEX_SQL = (
    "SELECT i.idxname," + _INDEX_PARTS + "{} FROM systables t JOIN sysindexes i "
    "ON t.tabid=i.tabid WHERE t.tabtype='T' AND i.idxtype='U'"
)
# Snapshot-drain fairness. An ``initial``-mode snapshot drains the whole table through
# one REPEATABLE READ transaction, holding one connection slot for the entire scan; with
# many tables this can consume every slot and starve the streaming/CDC readers waiting
# for one. So the drain moves off the microbatch thread onto ``snapshot.reader.threads``
# (K) driver-resident daemon workers: the consumer waits (holding no slot) for a worker to
# stage the table and publish its manifest, then serves the staged pages exactly as a
# resumed snapshot does. At most K drains run at once in a process, and each claims its
# slot above its own floor (see _snapshot_daemon_connection_reservation), so the lowest
# slots stay with consumer reads.
_SNAPSHOT_READER_THREADS_OPTION = "snapshot.reader.threads"
_DEFAULT_SNAPSHOT_READER_THREADS = 1
# Isolation level for the monolithic ``snapshot.mode=initial`` full-table snapshot. A
# table option: the isolation trade-off is per table, not per connection. Maps a small
# validated token to a fixed SQL clause (so the value can never be SQL-injected). The
# default is COMMITTED READ LAST COMMITTED -- it reads the last-committed image of a
# locked row instead of taking held shared locks, so the scan does not lock the table
# against writers; the cost is that rows inserted DURING the scan can be captured by both
# the snapshot and the CDC stream, which a key-less table cannot de-duplicate (see the
# README warning). REPEATABLE READ restores the exactly-once, table-locking behaviour.
_SNAPSHOT_ISOLATION_OPTION = "snapshot.isolation"
_DEFAULT_SNAPSHOT_ISOLATION = "committed_read_last_committed"
# How a keyed table's one-pass consistent snapshot reads the source. ``keyset`` (default)
# pages in key order: each page is its own query, ordered by the key and bounded below by
# the previous page's last key. With an index on the key columns that is a cheap index
# walk; without one, every page can scan and sort the table, so the cost grows with pages
# times table size -- the usual case for a primary.keys override, the wildcard especially.
# ``cursor`` reads the table through one forward-only cursor with no ORDER BY, exactly as a
# keyless table is read, while the key still drives the destination merge and the delete
# channel. Skipping key comparisons also sidesteps keyset paging's trouble with NULL keys.
#
# Rows committed during a non-locking scan can reach both the snapshot and the CDC stream;
# for a keyed table that is harmless, because the sink merges by key and CDC replays every
# change after the snapshot LSN. snapshot.isolation=repeatable_read still gives an
# exactly-once scan that locks the table.
#
# With snapshot.mode=incremental or auto_snapshot there are no key ranges to chunk by, so
# a fresh snapshot falls back to the one-pass consistent snapshot, the same fallback a
# DATETIME key that cannot be chunked takes. A chunked copy already in flight finishes as
# it started. A keyless table always reads through the cursor, whatever this says.
_SNAPSHOT_SCAN_OPTION = "snapshot.scan"
_SNAPSHOT_SCAN_KEYSET = "keyset"
_SNAPSHOT_SCAN_CURSOR = "cursor"
_SNAPSHOT_SCANS = frozenset({_SNAPSHOT_SCAN_KEYSET, _SNAPSHOT_SCAN_CURSOR})

# Where snapshot page payloads are written. ``fuse`` uses the UC Volume FUSE mount
# (today's behaviour). ``rest`` writes them through the Files REST API, which never
# touches the mount and so avoids the ENOTCONN disconnects that recur under sustained
# write frequency, but needs a mintable personal access token (see
# StagingCredentialProvider). ``auto`` (the default) uses REST when a token can be
# minted and falls back to FUSE when the workspace forbids token creation.
_SNAPSHOT_STAGING_TRANSPORT_OPTION = "snapshot.staging.transport"
_SNAPSHOT_STAGING_TRANSPORTS = frozenset({"auto", "rest", "fuse"})
_DEFAULT_SNAPSHOT_STAGING_TRANSPORT = "auto"
# Per-table option: a UC Volume directory of Informix UNLOAD (`.unl`) extract files.
# When set, the table's ``snapshot.mode=initial`` phase reads its history from those
# files instead of a live ``consistent_snapshot()`` scan, then transitions to the CDC
# stream at the connector-pinned boundary exactly as a live snapshot does. The extract
# is the operator's responsibility to align with the boundary (quiesce/extract-then-run);
# the connector pins the boundary itself and does no operator-supplied LSN or fingerprint.
_SNAPSHOT_SOURCE_OPTION = "snapshot.source"
# Per-table operator-supplied CDC boundary for a `.unl` snapshot source: the LSN the
# extract was taken at (captured by the extract step). Resolution order per table:
# this option, then a `_manifest.json` (``{"boundary_lsn": "<X>"}``) in snapshot.source,
# then self-pin (the connector's own registration LSN). A supplied LSN is authoritative
# (initial_lsn == snapshot_lsn == X) so the CDC stream resumes at exactly that position.
_SNAPSHOT_BOUNDARY_LSN_OPTION = "snapshot.boundary.lsn"
_SNAPSHOT_MANIFEST_NAME = "_manifest.json"
# A large `.unl` fans out across executors in byte-bounded pieces: each split targets
# this many bytes and ends at the next record boundary (splits never cross a file).
# Byte splitting -- unlike a row cap -- needs no whole-file scan to plan: the planner
# seeks to each target and reads only a small window to snap to the next newline.
_UNL_SPLIT_TARGET_BYTES = 50 << 20
# Per-table (connection-fallback) override of the split target byte size.
_UNL_SPLIT_BYTES_OPTION = "snapshot.split.bytes"
# Resumable gzip extracts. A `.unl.gz` file cannot be split by byte range -- compressed
# data cannot be decoded from the middle -- so by default it is one split, read whole on an
# executor in one microbatch, and a failure re-reads the whole file. With
# ``snapshot.gzip.records.per.batch`` = N > 0, each gzip file is instead served on the
# driver N records per microbatch, and the offset records how many of the file's records
# are done (``snapshot.record_index``). The driver keeps the file's decompressor open
# between microbatches, so normal progress is still one pass over the file; after a
# restart it reopens the file and skips the recorded records once -- re-decompressing that
# prefix, but never re-ingesting it. Each microbatch's rows pass through the driver and its
# partition descriptor, and a gzip file is no longer read in parallel with other splits, so
# this suits large gzip files rather than many small ones. Plain files are unaffected.
# Clearing the option while a file is part-served finishes that file in one microbatch
# rather than re-reading its served prefix. Applies to the partitioned reader; the serial
# reader serves the whole extract in one microbatch either way.
_UNL_GZIP_RECORDS_OPTION = "snapshot.gzip.records.per.batch"
# Extract identity. A file snapshot resumes by position -- split index, and record index
# inside a gzip file served in record windows -- into a split plan rebuilt from the
# directory on every read, so a file replaced, added or removed after the snapshot started
# would make a resume silently skip or repeat rows. When the boundary is pinned, the
# connector also pins a manifest of the extract: every file's name, size and modification
# time, and a fingerprint hashing the size with the first and last
# _UNL_FINGERPRINT_SAMPLE_BYTES of the file. Every later read compares the directory with
# it -- names and sizes exactly, modification times within _UNL_MTIME_TOLERANCE_SECONDS,
# because a Volume reports an unsettled mtime for a few seconds after a write -- and
# re-checks the fingerprint of each file that read will serve, failing closed with a
# full-refresh error on any difference. Fingerprints are cached per (path, size, exact
# mtime) within a driver process, so a gzip file served over many microbatches is sampled
# once per run. The fingerprint samples rather than hashes whole files, so an edit confined
# to the middle of a file that also keeps its size and modification time escapes it.
_UNL_FINGERPRINT_SAMPLE_BYTES = 1 << 20
_UNL_MTIME_TOLERANCE_SECONDS = 5.0
# Fixed buffer for the streaming range reads and the boundary-snap scan: constant
# memory regardless of `.unl` size (never load a whole file).
_UNL_SCAN_CHUNK_BYTES = 4 << 20
# A `.unl` extract need not be dbaccess UNLOAD: Informix's High-Performance Loader
# (onpload/ipload) DELIMITED output is the same newline-terminated, escaped, delimited
# shape, but with a job-configured field delimiter and escape character -- and, unlike
# UNLOAD, HPL does not honor DBDELIMITER, so an HPL job commonly uses a non-`|`
# delimiter. These per-table (connection-fallback) options let the file serve parse an
# HPL DELIMITED extract whose delimiter/escape differ from UNLOAD's `|`/backslash
# defaults; the defaults leave a plain UNLOAD extract parsed exactly as before. Both are
# a single character (an empty escape disables escape processing for an HPL job that
# writes none). The record terminator stays a physical newline; HPL's fixed-position,
# COBOL, and Informix-internal binary formats are not supported (they are not
# self-describing) -- configure the HPL job to emit newline-terminated DELIMITED output.
_UNL_DELIMITER_OPTION = "snapshot.unl.delimiter"
_UNL_ESCAPE_OPTION = "snapshot.unl.escape"
_UNL_DEFAULT_DELIMITER = "|"
_UNL_DEFAULT_ESCAPE = "\\"
# Informix integer/float type names, for mapping UNLOAD text back to Python values.
_UNLOAD_INT_TYPES = frozenset(
    {"INTEGER", "INT", "SMALLINT", "BIGINT", "INT8", "SERIAL", "SERIAL8", "BIGSERIAL"}
)
_UNLOAD_FLOAT_TYPES = frozenset({"FLOAT", "SMALLFLOAT", "REAL", "DOUBLE", "DOUBLE PRECISION"})
_SNAPSHOT_STAGING_TOKEN_LIFETIME_OPTION = "snapshot.staging.token.lifetime.seconds"
# One secret scope holds every pipeline's current staging token, keyed per pipeline id.
_SNAPSHOT_STAGING_SECRET_SCOPE = "informix-snapshot-staging"
# Walks a completed snapshot stage's removal may take when background page deletes keep
# cutting it short (see _cleanup_completed_snapshot_stage); each walk removes more.
_SNAPSHOT_STAGE_CLEANUP_ATTEMPTS = 5
# Overlap a keyless positional drain's next page fetch with the previous page's
# shape+upload, through one bounded background uploader. Only engaged for a keyless
# drain writing over the REST transport -- pipelining FUSE writes would raise the
# mount's write frequency, the very thing the REST transport exists to avoid.
_SNAPSHOT_STAGING_PIPELINE_OPTION = "snapshot.staging.pipeline"
_SNAPSHOT_ISOLATION_SQL = {
    "committed_read_last_committed": "COMMITTED READ LAST COMMITTED",
    "repeatable_read": "REPEATABLE READ",
}
# Idle back-off for a snapshot-drain worker with no queued jobs, so it does not busy-spin.
# Also the granularity at which the consumer's liveness watchdog re-checks for progress.
_SNAPSHOT_DRAIN_IDLE_SECONDS = 1.0
# Extra grace the consumer's drain watchdog waits beyond the worker's slot-wait window, so
# a wedged pool surfaces the worker's precise ConnectionCapacityUnavailable (recorded when
# the worker gives up) rather than the consumer's generic "appears stalled" racing it out.
# Comfortably larger than one acquisition sweep so the worker always records first.
_SNAPSHOT_DRAIN_STALL_GRACE_SECONDS = 30.0
# What an append-only table does about rows that predate the flow.
#
# ``stream`` (default): begin at the server's current log position and capture only
# what arrives after. No history, but no size ceiling and no failure mode.
#
# ``snapshot``: read the table once through one forward-only cursor under REPEATABLE
# READ, stage bounded pages, then continue CDC from the snapshot LSN. No ordering or
# positional pagination is required because the transaction and cursor remain open.
_UUID_TEXT = r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"
_PIPELINE_SCOPE = re.compile(rf"(?:[0-9a-f]{{32}}|{_UUID_TEXT}_@_{_UUID_TEXT})")
_DEFAULT_STATE_GC_RETENTION_DAYS = 30
_DEFAULT_STATE_GC_INTERVAL_HOURS = 24.0
_DEFAULT_STATE_GC_PROJECT_RETENTION_DAYS = 90
_IMMUTABLE_STATE_VERSION = 1
_SNAPSHOT_STAGE_VERSION = 1
_SHARED_STATE_WAIT_SECONDS = 300
_MAX_SNAPSHOT_STAGE_PAGE_BYTES = 256 << 20
_DEFAULT_SNAPSHOT_STAGE_RETENTION_DAYS = 4
# Background threads that delete consumed staged pages off the microbatch serve
# path. A small pool drains the one-page-per-microbatch steady state easily and
# clears any post-restart backlog quickly without hammering the Volume.
_SNAPSHOT_CLEANUP_THREADS = 4
# How often a resumed snapshot re-reads the live Informix schema to detect drift.
# Serving immutable staged pages needs no live schema, so a per-microbatch
# get_table query (plus the connection/slot it opens) dominated serve time.
# Checking periodically instead keeps the drift guard -- a mid-snapshot schema
# change is caught within this window and aborts the copy -- while most pages skip
# Informix entirely. The window trades detection latency for throughput; the pages
# served in between are immutable as-of snapshot_lsn, so serving a few extra before
# an abort is harmless. A shared CDC shard's daemon checks its tables' definitions as
# often, for the same reason (see _ShardCatalog).
_SNAPSHOT_SCHEMA_REFRESH_INTERVAL_SECONDS = 60
# Bootstrap deferrals a delete reader records before its advisory offset stops
# changing (see _schema_node_fallback_offset). The upsert reader publishes this
# update's channel-start before taking its snapshot -- it enables full-row logging,
# captures one LSN, and publishes -- and a resumed upsert reader republishes its
# resume position on its first stream read, so a handful of microbatch intervals
# covers the window in which the delete reader would otherwise find nothing. The
# counter is persisted in offsets under its historical name.
_SCHEMA_NODE_FALLBACK_RETRIES = 5
_DEFAULT_MAX_CONCURRENT_CONNECTIONS = 16
# Slots the background daemons (sharded CDC readers, the snapshot drain pool) may not
# claim, guaranteeing them to consumer bootstrap/snapshot/incremental reads. Unlike a
# consumer read, a daemon never releases per microbatch (a busy CDC shard re-reads in a
# tight loop, a drain holds its slot for the whole scan), so without this the daemons --
# whose default thread count equals the pool size, across two channels -- can pin every
# slot and starve a fresh bootstrap read. Configured default 0, interpreted as
# floor(max.concurrent.connections / 3) (>= 1 whenever the pool has 2+ slots).
_DAEMON_RESERVATION_OPTION = "daemon.connection.reservation"
_DEFAULT_DAEMON_CONNECTION_RESERVATION = 0
# Private marker set on a daemon reader's options so its lazy slot acquisition applies the
# daemon reservation floor. Set by the CDC reader factory only.
_DAEMON_SLOT_MARKER_OPTION = "_informix.daemon.slot"
# Private marker for the snapshot-drain daemon reader. Unlike the CDC daemon (deferrable,
# floored highest), a drain is bootstrap work that must make progress to unblock its
# append-only consumer, so it is floored *below* the CDC daemon -- into a band the CDC
# daemon cannot claim -- rather than sharing the CDC floor and being starved by it.
_SNAPSHOT_DAEMON_SLOT_MARKER_OPTION = "_informix.snapshot.daemon.slot"
# Private, published per read by a yielding continuous reader: how long this
# attempt may spend acquiring a slot before the reader gives up and returns empty.
_CONNECTION_ATTEMPT_BUDGET_OPTION = "_informix.connection.attempt.budget.seconds"
# Remaining connection-acquisition budget shared by every internal read in one
# readBetweenOffsets() call. Without this, each advisory bootstrap retry starts a
# fresh connection.wait.timeout.seconds window and multiplies the configured cap.
_REPLAY_CONNECTION_WAIT_BUDGET_OPTION = "_informix.replay.connection.wait.budget.seconds"
# Carries the reader's backlog rank to the bridge for the duration of one read, so
# acquisition can prioritise by sweep cadence. Separate from the budget option
# because a *blocking* reader has no budget at all yet still needs a rank.
_CONNECTION_ATTEMPT_RANK_OPTION = "_informix.connection.attempt.backlog.rank"
_DEFAULT_CONNECTION_WAIT_TIMEOUT_SECONDS = 10 * 60
# One-shot jittered delay a reader sleeps before its *first* connection, so a pipeline that
# starts dozens of flows at once does not open all their Informix CDC sessions in the same
# instant -- the syscdcv1 subsystem can stall under many concurrent session open/teardowns
# (see validate_initial_lsn). Each reader sleeps random.uniform(0, this) once, before it
# acquires a slot (so it holds nothing while waiting), spreading the startup wave over the
# window. 0 (default) disables it; steady-state reads are never delayed (the flag is set
# after the first connect).
_CONNECTION_STARTUP_JITTER_OPTION = "connection.startup.jitter.seconds"
_CONNECTION_SLOT_LEASE_SECONDS = 120
_CONNECTION_SLOT_HEARTBEAT_SECONDS = 30
# How long a lease-loss handler waits for the in-flight operation before closing
# the transport anyway. Bounded because the alternative risks pairing with a
# releaser that is joining the heartbeat thread; the loss is already published, so
# the operation's result is discarded regardless of who wins.
_POISON_OPERATION_LOCK_SECONDS = 30.0
# How long a release waits for the heartbeat thread to exit. Short because it
# normally returns immediately, and a renewal that lands late is rejected by the
# epoch guard rather than doing harm.
_CONNECTION_SLOT_JOIN_SECONDS = 3.0
# Sweep cadence when slots live in Postgres. The Volume intervals (0.2-0.5s
# triggered, 1-5s continuous) were sized for ~2ms directory metadata calls; a
# Postgres round trip is ~11ms measured, and 60 flows sweeping at 0.2s would
# offer ~300 queries/s against an endpoint whose floor is 0.5 CU. These are wide
# enough to keep steady-state load modest while still noticing a freed slot
# inside the 1-5s a production slot is typically held.
_LAKEBASE_SWEEP_MIN_SECONDS = 0.5
_LAKEBASE_SWEEP_MAX_SECONDS = 2.0
# Fair slot queue: a waiter enqueues a ticket so acquisition is first-come per slot
# rather than a raw race, which prevents an unlucky reader being lapped indefinitely
# under contention. The queue interleaves requester classes so a high-volume class (many
# consumer bootstrap/fallback tickets) cannot crowd out a low-volume one (the few
# CDC-daemon tickets) by ticket count alone -- each class is served once per rotation.
# The class is derived from the private slot markers already on a reader's options (see
# _connection_waiter_class).
# Requester classes for the round-robin policy's rotation. The value is only a
# within-round tiebreak -- every class is still served once per round -- so the ordering
# among them does not starve any class. Consumer work is class 0 so that, all else equal,
# the reads that must finish to make progress are not deprioritised.
_SLOT_CLASS_CONSUMER = 0
_SLOT_CLASS_SNAPSHOT_DAEMON = 1
_SLOT_CLASS_CDC_DAEMON = 2
# The rotation modulus for the round-robin policy. Class 3 was the drain on a consumer's
# own thread, now gone; the modulus still counts it so that connectors of either version
# sharing one endpoint rotate alike, and the rotation only ranks classes with waiters.
_SLOT_CLASS_COUNT = 4
# A ticket stays authoritative for this long without a heartbeat. A waiter heartbeats
# every sweep (<= _LAKEBASE_SWEEP_MAX_SECONDS), so this is many sweeps of slack for a
# briefly-stalled live waiter, yet far below the slot lease so a crashed waiter's ticket
# stops blocking the queue quickly.
_LAKEBASE_WAITER_TTL_SECONDS = 15.0
# The backlog hint describes the *endpoint's* log position, not one table's, so
# all publishers share a single row. The hints table is keyed per table because
# state records reuse it; this constant is the endpoint-wide key.
_LAKEBASE_ENDPOINT_HINT_KEY = "__endpoint__"
# A waiter holds no slot and has no bridge, so it cannot borrow a bridge's
# Postgres connection. These caches give the waiter path one state handle and one
# connection per endpoint per process, keyed by endpoint identity.
_LAKEBASE_WAITER_STATE: dict[str, Any] = {}
_LAKEBASE_WAITER_CONNECTION: dict[str, Any] = {}
# Created on demand rather than at import, and held in a dict rather than a bare
# module global. Two constraints meet here. Spark cloudpickles the reader class to
# its workers, and a lock alive at serialization time makes that fail outright
# ("cannot pickle '_thread.lock' object"), so the lock cannot exist at import.
# And the merged single-file deployment nests this whole module inside a function,
# which turns module globals into that function's locals -- a rebinding helper
# declaring ``global`` would then address a name nothing ever assigns and raise
# ``NameError``. Mutating a dict needs no rebinding, so it survives both forms.
_LAKEBASE_WAITER_LOCK: dict[str, threading.Lock] = {}


def _lakebase_waiter_lock() -> threading.Lock:
    lock = _LAKEBASE_WAITER_LOCK.get("lock")
    if lock is None:
        # setdefault resolves the race: concurrent callers may each build a lock,
        # but every one of them returns whichever landed first.
        lock = _LAKEBASE_WAITER_LOCK.setdefault("lock", threading.Lock())
    return lock


_CONNECTION_LIMIT_CONFIG_VERSION = 1
# How old a backlog hint may be before a waiter ignores it. Lakebase stamps each hint
# with its own clock when it is published and measures the age on that same clock when
# it is read, so clock skew between workers does not change it.
_CONNECTION_HINT_MAX_AGE_SECONDS = 45.0
# Ranks are bounded so the value is cheap to compare and safe to persist in an
# offset. Eight log-scaled levels span the whole plausible backlog range.
_CONNECTION_BACKLOG_RANK_LEVELS = 8
# Consecutive reads that filled their row budget, above which a flow is treated as
# maximally behind. A read that truncates has *proved* work remains, which is the
# one backlog fact a reader establishes without asking the server anything -- the
# published hint is a global log position and so measures staleness rather than
# this table's lag. Four sustains the signal across a brief burst without letting
# one busy read dominate: a genuinely backlogged flow truncates every read, while
# a flow that truncated once and then drained falls straight back to zero.
_CONNECTION_BACKLOG_TRUNCATION_LEVELS = 4
_SHARED_STATE_ACCESS_MAX_RETRIES = 200
# Consecutive dropped-mount yields a continuous flow tolerates before failing.
#
# Deliberately far smaller than _SHARED_STATE_ACCESS_MAX_RETRIES even though both
# guard the same Volume, because the two retry at completely different cadences.
# An exhausted _open_state_entry_with_retry raises SharedStateAccessUnavailable
# and is retried from _shared_state_retry_offset, which sleeps 0.05-1.5s itself,
# so 200 of those is a couple of minutes. A dropped mount instead yields an empty
# batch and waits for the framework to call the reader again, so its cadence is
# the microbatch interval -- roughly 30s in production -- and reusing 200 there
# means ~100 minutes of a green, RUNNING pipeline replicating nothing.
#
# Sized for the real failure it was observed against: production mount drops
# recovered within seconds, so ten consecutive microbatches (~5 minutes) is well
# clear of a genuine remount while still surfacing an outage inside the window an
# operator would plausibly notice. A mount that is still gone after five minutes
# is an infrastructure fault, and failing the flow reports it where a silent
# retry cannot.
_DROPPED_MOUNT_MAX_RETRIES = 10
# Option carrying the LSN a replayed read must stop at.
#
# readBetweenOffsets(start, end) has to reproduce a range Spark already committed,
# but read_table's signature has no end parameter and thirty connectors implement
# it, so widening the interface to pass one is out of proportion to the fix. The
# framework builds table_options from the reader's own options dict, and the
# connector owns both the reader subclass and this option namespace -- so the
# bound travels the one channel already available. Private by the leading
# underscore convention: set per read by the replay path, never by a user.
_REPLAY_STOP_LSN_OPTION = "_informix.replay.stop.lsn"
# Option carrying the snapshot-chunk cursor a replayed read must stop at.
#
# The LSN bound above covers only half of what a microbatch emits during the
# incremental copy: the same read also returns a snapshot chunk, and a chunk is
# bounded by its keyset cursor, which no LSN constrains. Spark discards the
# offset a replay returns and commits ``end`` regardless, so a replay whose
# chunk covers less of the key range than ``end`` claims leaves the shortfall to
# be skipped by the next read -- silent row loss with the gap on a chunk
# boundary. ``end`` already carries the missing bound as
# incremental.last_pk, so it travels the same options channel as the LSN.
#
# Encoded as JSON because the value is the staged form of a key tuple (a list),
# not a scalar. Two distinguishable states matter: a cursor to stop at, and
# JSON ``null`` meaning "the copy finished inside this range" -- which must
# drain to max_pk rather than stop early. Absent means an ordinary read.
_REPLAY_STOP_PK_OPTION = "_informix.replay.stop.pk"
# Set by a replayed read on the offset it reached when the range cannot be reproduced and
# was re-established instead (a start the log no longer retains, under auto_snapshot):
# _replay_between_offsets then holds it to an initial range's terms. Never persisted.
_REPLAY_REESTABLISHED = "_informix.replay.reestablished"
# Distinguish JSON null (replay the copy-completing range through max_pk) from
# an absent option (ordinary one-page incremental read).
_REPLAY_DRAIN_TO_MAX_PK = object()
# Row budget for a bounded replay: the LSN bound is what limits the read, so the
# budget must not truncate it first. Large rather than None to keep the existing
# integer comparisons intact.
_REPLAY_UNBOUNDED_ROWS = 1 << 62
# Chunk fetches one replayed range may take before the read gives up.
#
# A replay pages until it reaches the committed cursor rather than stopping at
# snapshot.page.size, because rows inserted into the range since the original
# read can push it past one page. That loop runs while holding a connection
# slot, so it cannot be unbounded -- an unbounded wait while holding a slot is
# the deadlock shape avoided elsewhere in this module. In the ordinary case the
# range is exactly the one page the original read produced, so the loop runs
# once; this cap exists for the pathological case, and is a hard error rather
# than a silent truncation because truncation is the bug being fixed.
_REPLAY_MAX_CHUNK_FETCHES = 64
# In-process retries for a transient shared-state failure before the read gives up.
#
# Yielding an empty batch and waiting to be called again is the cheaper response
# for a normal read -- it frees the worker -- but it is unavailable during a
# replay, where the caller has already promised these rows and reads the empty
# batch as proof the range held none. Retrying in place serves both: a remount
# settles in seconds, so most outages clear inside the loop and never reach either
# decision. Mirrors _open_state_entry_with_retry, which already does exactly this
# for ENOTCONN on open(2).
#
# Sized to stay well inside one microbatch: five jittered sleeps of 0.25-4s is
# under 8s worst case. The read holds its connection slot throughout, which is
# acceptable only because the wait is on a filesystem rather than on another
# reader -- waiting on a sibling while holding a slot is the deadlock fixed in
# 65dac41, and this must not become that.
# Offset keys that carry scheduling bookkeeping rather than a stream position.
# Every other key comes from _offset() and answers "where is this reader"; these
# are layered on afterwards by the retry helpers and _with_backlog_streak. Their
# presence is what marks an offset as a yield rather than a completed read.
_OFFSET_ADVISORY_FIELDS = frozenset(
    {
        "shared_state_retry_count",
        "dropped_mount_retry_count",
        "trigger_boundary_retry_count",
        "schema_transition_retry_count",
        "schema_node_fallback_retry_count",
        "capacity_retry_count",
        "capacity_pressure",
        "backlog_rank",
        "backlog_streak",
    }
)
_TRANSIENT_VOLUME_IN_PROCESS_ATTEMPTS = 6
_TRANSIENT_VOLUME_IN_PROCESS_MAX_SECONDS = 8.0
# Continuous-mode capacity backpressure. Every flow in a continuous pipeline runs
# permanently, so N flows are N standing consumers of a fixed slot count and most
# are waiting at any instant. Blocking for the whole connection.wait.timeout.seconds
# pins one worker process per waiter and then fails the streaming query, so a
# continuous reader instead spends a short bounded budget trying to claim a slot
# and returns an empty batch when it cannot.
#
# The budget grows with the reader's consecutive-miss count, so a reader that has
# gone longest without a slot presses hardest. Without that, every reader would
# give up after the same interval and the unlucky ones would keep losing.
#
# The ceiling is bounded because each pass of the acquisition loop tries every
# candidate slot, so one pass costs one mkdir per slot and the budget sets how
# much Volume metadata a single starved read may spend before giving up. Measured
# at 16 slots, a 60s budget is roughly 22 passes and 368 mkdir calls for a read
# that may still return nothing. Endpoint listing was already engineered off this
# hot path because metadata cost dominated here, so the ceiling exists to stop a
# large budget reintroducing that load through a different door -- worst of all
# when the endpoint is most contended, since that is when misses accumulate.
_CAPACITY_RETRY_MAX_RETRIES = 500
# A CDC poll that drops its connection mid-read is retried in place: the dead
# transport is reset and the same read reissued under the slot already held.
# This is transient (network blip / NLB idle reset on a PrivateLink path), so a
# few bounded attempts with short backoff recover it without surfacing a stream
# failure. Applies identically to triggered (AvailableNow) and continuous flows
# because the retry never returns an empty-below-high-water batch.
_CDC_RECONNECT_MAX_RETRIES = 4
_CDC_RECONNECT_BASE_SECONDS = 0.5
_CDC_RECONNECT_MAX_SECONDS = 8.0
# Initial-LSN validation (cdc_opensess/startcapture/activatesess) can have its socket read
# time out under a startup storm -- many flows opening CDC sessions against syscdcv1 at
# once. That is transient contention, not a real validation failure, so a few bounded
# attempts with short backoff -- reconnecting a fresh transport between them -- ride it
# out; exhausting them re-raises so a genuinely-unreachable source still fails. Timeout-
# only: a server error (a nonzero cdc_* return, a negative session id) is a real failure
# and is never retried.
_VALIDATE_LSN_RETRY_MAX_RETRIES = 4
_VALIDATE_LSN_RETRY_BASE_SECONDS = 0.5
_VALIDATE_LSN_RETRY_MAX_SECONDS = 8.0
# The incremental-snapshot page and key-bound reads drop their connection the same
# way (a "truncated SQLI stream" EOF from an idle NLB/PrivateLink reset or a
# server-side session reap), and recover the same way: each read advances no offset
# and opens its own repeatable-read transaction, so the dead transport can be reset
# and the identical read reissued in place. Mirrors the CDC budget above.
_SNAPSHOT_RECONNECT_MAX_RETRIES = 4
_SNAPSHOT_RECONNECT_BASE_SECONDS = 0.5
_SNAPSHOT_RECONNECT_MAX_SECONDS = 8.0
# The Lakebase (Postgres) state connection drops the same way but on the other
# transport: a connection left idle across a long wait for capacity is reaped by
# the server, and because psycopg leaves ``.closed`` False until the next query,
# the cached handle is handed back dead and the next ``execute`` raises
# ``OperationalError`` ("SSL SYSCALL error: EOF detected"). State operations are
# idempotent (monotonic-min upsert, DO-NOTHING election, bare SELECT, idempotent
# DELETE) and commit only after the round-trip succeeds, so a dead connection can
# be dropped and the identical operation reissued on a fresh one. Mirrors the two
# SQLI budgets above.
_LAKEBASE_RECONNECT_MAX_RETRIES = 4
_LAKEBASE_RECONNECT_BASE_SECONDS = 0.5
_LAKEBASE_RECONNECT_MAX_SECONDS = 8.0
# Ceiling on the jittered pause a starved continuous reader takes before yielding,
# and on the budget it spends acquiring a slot.
#
# Held at 5.0 with a 0.1 floor. These were widened to 0.5-8.0 to cut how often
# starved readers touched the shared Volume, because UC Volume FUSE disconnects
# with ENOTCONN under sustained write frequency (Databricks ES-1604921 /
# ES-1614902: the prefetch mechanism is not memory-constraint aware, and
# "increasing the frequency of writes to UC Volume paths triggers the issue
# earlier") -- observed nine times in thirteen hours. Slots are Postgres rows now.
# A measured 247-266 req/s at 120 concurrent connections held latency flat with no
# errors, so the ~11-17 sweeps/s those waiters generate is not a load the endpoint
# notices, and there is no daemon left to protect.
#
# What the wider values did cost was latency: with light contention a freed slot
# could sit idle up to 8s before a waiter re-swept for it. The narrower range
# returns that responsiveness. The floor stays well below the ceiling because the
# jitter's other job is decorrelating equally-aged readers so they do not converge
# on one give-up instant and re-storm together, which needs a wide range.
_DEFAULT_CAPACITY_RETRY_MAX_DELAY_SECONDS = 5.0
# Floor on that same jittered pause, so the sleep cannot draw arbitrarily close to
# zero and let a reader re-sweep almost immediately.
_CAPACITY_RETRY_MIN_DELAY_SECONDS = 0.1
_CAPACITY_ATTEMPT_BASE_SECONDS = 1.0
_CAPACITY_ATTEMPT_PER_MISS_SECONDS = 0.5
# Per backlog rank level, added to the budget so a further-behind flow waits
# longer per attempt. Kept at the per-miss weight so eight rank levels can add at
# most 3.5s -- enough to bias which reader wins a contended slot, far too little
# to let a stale flow hold a worker for the full wait timeout.
_CAPACITY_ATTEMPT_PER_RANK_SECONDS = 0.5
_CAPACITY_ATTEMPT_MAX_SECONDS = 60.0
# Fraction of the sweep gap a maximally-ranked waiter keeps. A *blocking* waiter
# (a triggered flow, or a latency-tolerant snapshot/incremental copy) never gives
# up, so the per-attempt budget above cannot prioritise it -- for those readers
# the only lever is how often they re-sweep, because that decides who reaches a
# freed slot first. Measured in production: every ranked offset belonged to a
# steady-state CDC flow and every backlog streak to a blocking bulk-copy flow, so
# the two never met and ranking changed nothing for the readers with the most
# outstanding work. Scaling the gap rather than adding passes keeps the metadata
# rate bounded: at the floor a top-ranked waiter sweeps ~2x as often as an
# unranked one, not tens of times.
_SLOT_SWEEP_RANK_FLOOR = 0.5
_SHARED_STATE_OPEN_ATTEMPTS = 8
# Ceiling on the jittered backoff between reopen attempts after the Volume's FUSE
# mount drops (ENOTCONN). A remount settles in seconds, so the eight attempts span
# roughly half a minute in total -- long enough to ride out a blip, short enough
# that a genuine outage still surfaces as a failed flow rather than a silent hang.
_SHARED_STATE_MOUNT_RETRY_MAX_SECONDS = 8.0
# Bound on cached per-table registration lookups shared across reader instances
# in one process. Entries are single resolved tables (keyed by source identity +
# exposed name), so this can be generous -- a pipeline registers one entry per
# configured table.
_MAX_REGISTRATION_TABLE_CACHES = 512
# Predecessor hops a same-position channel start may follow back to its first schema.
_MAX_SCHEMA_DESCENT = 256
_INFORMIX_REGISTRATION_CONTEXT: dict[str, Any] = {"scope": None}


class _StateValidationCoordinator:
    # Docstring: Process-local exact leases whose synchronization state is never serialized.

    def __init__(self) -> None:
        self.condition = threading.Condition()
        self.table_caches: dict[tuple[str, ...], "Table"] = {}
        # (table identity, left-out column names) pairs already warned about, so a table
        # resolved on every read warns once per process rather than on each microbatch.
        self.unsupported_column_warnings: set[tuple[str, tuple[str, ...]]] = set()

    def __getstate__(self) -> dict[str, object]:
        # Spark workers must establish their own process-local validation state.
        return {}

    def __setstate__(self, state: dict[str, object]) -> None:
        del state
        self.__init__()


_STATE_VALIDATION_COORDINATOR = _StateValidationCoordinator()


def _sleep_with_backoff(deadline: float, delay: float) -> float:
    # Docstring: Sleep with jitter without crossing the caller's absolute deadline.

    remaining = deadline - time.monotonic()
    if remaining > 0:
        time.sleep(min(delay * random.uniform(0.8, 1.2), remaining))
    return min(delay * 1.5, 2.0)


# The framework stream readers the Informix wrapper below instruments: the simple
# reader (readBetweenOffsets replay) and the partitioned proxy, which is the default
# for CDC-capable tables and replays through get_partitions(start, end) instead.
_WRAPPED_STREAM_READER_NAMES = frozenset(
    {"LakeflowStreamReader", "LakeflowPartitionedStreamReader"}
)


def _snapshot_position(offset: Any) -> tuple | None:
    # Docstring: Where a snapshot-phase offset points: (snapshot LSN, page, record); else None.

    if not isinstance(offset, dict) or offset.get("phase") != "snapshot":
        return None
    position = offset.get("snapshot") or {}
    return (
        str(offset.get("snapshot_lsn")),
        int(position.get("page_index", 0)),
        int(position.get("record_index", 0)),
    )


def _replay_between_offsets(start, end, read, options, connector_options):
    # Docstring: Replay ``[start, end)`` by reading to ``end`` and stopping there.
    #
    # Shared by the simple reader's ``readBetweenOffsets`` and the partitioned reader's
    # ``get_partitions`` recompute, so both replay paths honour one contract: the read
    # is bounded at ``end.commit_lsn`` (and, mid-incremental-copy, at
    # ``end.incremental.last_pk``), and an under-read fails closed rather than letting
    # Spark commit an ``end`` the rows do not reach.
    #
    # The unbounded alternative (``read(start)`` with the reached offset discarded) is
    # not reproducible: it ends at whichever transaction boundary the row budget falls
    # on, so the same start LSN over the same log can end in different places --
    # measured directly, budget 10 ended at LSN 107 and budget 2 at 104 on identical
    # data. Spark commits its own ``end`` regardless, so a fresh read that stops earlier
    # than the original silently drops everything in between; that is how six tables
    # lost 151 rows.
    #
    # ``read(start)`` performs one read and returns ``(records, reached_offset)``; the
    # bounds are injected into ``options`` (the dict that read consults, restored on
    # exit) because read_table has no ``end`` parameter and thirty connectors
    # implement it. ``connector_options`` supplies the connection-wait default.

    positional_keys = {
        "commit_lsn",
        "change_lsn",
        "begin_lsn",
        "tx_id",
        "incremental",
    }
    # Spark may persist bootstrap coordination progress as a range of its own.
    # Such a range advances no Informix position and contains no records to
    # replay. Treat it as empty, while continuing to fail closed if either side
    # identifies a positional CDC range.
    advisory_only_end = isinstance(end, dict) and bool(end) and set(end) <= _OFFSET_ADVISORY_FIELDS
    if advisory_only_end and not positional_keys.intersection(start or {}):
        return iter(())

    stop = (end or {}).get("commit_lsn")
    if stop is None:
        # 1: Informix cannot replay an offset range whose end has no commit_lsn
        raise InformixError(_m(1))
    end_position = _snapshot_position(end)
    if end_position is not None and _snapshot_position(start) == end_position:
        # A snapshot range that served nothing (a retry yield at one page): reading would
        # serve that page, which the batch did not hold.
        return iter(())
    # The first incremental range starts at {} and still emits a chunk. Bound it
    # whenever either side identifies an in-progress copy; a start-side block with
    # no end-side block is the final range and is represented by JSON null below. A
    # copy that finished in its first batch leaves neither side a block, so an initial
    # range ending in the stream phase drains to max_pk too (only a copy reads it).
    initial_range = not positional_keys.intersection(start or {})
    replaying_chunk = (
        isinstance((start or {}).get("incremental"), dict)
        or isinstance((end or {}).get("incremental"), dict)
        or (initial_range and (end or {}).get("phase") == "stream")
    )
    # ``null`` is meaningful: the copy finished inside this range, so the replay
    # must drain to max_pk instead of stopping at a cursor.
    stop_pk = json.dumps(((end or {}).get("incremental") or {}).get("last_pk"))
    previous = options.get(_REPLAY_STOP_LSN_OPTION)
    previous_pk = options.get(_REPLAY_STOP_PK_OPTION)
    previous_wait_budget = options.get(_REPLAY_CONNECTION_WAIT_BUDGET_OPTION)
    options[_REPLAY_STOP_LSN_OPTION] = str(stop)
    if replaying_chunk:
        options[_REPLAY_STOP_PK_OPTION] = stop_pk
    try:
        replay_start = start
        reestablished = False
        if end_position is not None and _snapshot_position(start) is None:
            # A staged snapshot's first batch (an initial one, or auto_snapshot's replacing an
            # expired checkpoint): serve it from the snapshot Spark logged, from page 0,
            # rather than drain another one (a later update would), so the batch and the
            # pages after it come from one snapshot.
            position = {k: v for k, v in end["snapshot"].items() if k != "record_index"}
            replay_start = {**end, "snapshot": {**position, "page_index": 0, "last_pk": []}}
        record_parts = []
        configured_wait = float(
            options.get(
                "connection.wait.timeout.seconds",
                connector_options.get(
                    "connection.wait.timeout.seconds",
                    str(_DEFAULT_CONNECTION_WAIT_TIMEOUT_SECONDS),
                ),
            )
        )
        replay_wait_deadline = time.monotonic() + configured_wait
        step_wait = 0.1
        # Spark cannot checkpoint an advisory yield while replaying: it has already
        # fixed this range's end. Advance bootstrap coordination counters inside
        # this call until the reader obtains a real source position. This is
        # especially important for the delete flow's deferred schema node fallback
        # after a restart.
        while True:
            remaining_wait = replay_wait_deadline - time.monotonic()
            if remaining_wait <= 0:
                # 2: Informix replay did not produce a positional end LSN before its connection wait
                # deadline
                raise InformixError(_m(2))
            options[_REPLAY_CONNECTION_WAIT_BUDGET_OPTION] = repr(remaining_wait)
            try:
                records, reached = read(replay_start)
                if isinstance(reached, dict):
                    # Marked on the read that re-established the range; later polls of it
                    # read on from there.
                    reestablished = bool(reached.pop(_REPLAY_REESTABLISHED, False)) or reestablished
            except SchemaTransitionUnavailable:
                # The range needs a schema step the upsert reader records on its own read
                # (a column changed while the pipeline was stopped). A replay cannot yield
                # for it, so it waits in place, the read having given its slot back.
                if replay_wait_deadline - time.monotonic() <= 0:
                    raise
                step_wait = _sleep_with_backoff(replay_wait_deadline, step_wait)
                continue
            record_parts.append(records)
            if isinstance(reached, dict) and reached.get("commit_lsn") is not None:
                position = _snapshot_position(reached)
                if (
                    position is not None
                    and position != _snapshot_position(replay_start)
                    and (
                        end_position is None
                        or (position[0] == end_position[0] and position[1:] < end_position[1:])
                    )
                ):
                    # The simple reader serves a staged snapshot a page per read, and a batch
                    # the partitioned reader logged can span several: read on to its end.
                    replay_start = reached
                    continue
                if (
                    isinstance(replay_start, dict)
                    and (
                        # An initial range starts from no position (a copy's first batch).
                        replay_start.get("commit_lsn") is None
                        or int(replay_start["commit_lsn"]) < int(reached["commit_lsn"])
                    )
                    and int(reached["commit_lsn"]) < int(stop)
                ):
                    # One poll can go idle short of the committed end; the original
                    # read then advanced across the quiet log in several batches.
                    # Keep reading from where this one stopped, as it did. A chunked
                    # range too, whose CDC a direct poll may cap short of what the shared
                    # reader delivered: its chunk reached the committed cursor in the
                    # first poll, so the next ones read none.
                    replay_start = reached
                    continue
                break
            advisory_yield = (
                initial_range
                and isinstance(reached, dict)
                and bool(reached)
                and set(reached) <= _OFFSET_ADVISORY_FIELDS
            )
            if not advisory_yield:
                # 3: Informix replay did not produce a positional end LSN
                raise InformixError(_m(3))
            if reached == replay_start:
                # At the maximum schema fallback count, an unchanged advisory
                # offset means the owning upsert flow has not published its
                # current channel start yet. The read has released its connection
                # slot, so wait briefly and try again without extending the shared
                # deadline.
                remaining_wait = replay_wait_deadline - time.monotonic()
                if remaining_wait <= 0:
                    # 2: Informix replay did not produce a positional end LSN before its connection
                    # wait deadline
                    raise InformixError(_m(2))
                time.sleep(min(random.uniform(0.05, 0.2), remaining_wait))
            replay_start = reached
        # A replay with one read that returned rows hands back those rows as they came, so a
        # spilled transaction (_SpilledRows) still reaches get_partitions as pages after reads
        # that went idle. An idle read returns an empty list iterator, which reports its
        # size; a part that reports none (a generator) may hold rows, so it is kept.
        filled = [part for part in record_parts if operator.length_hint(part, -1) != 0]
        records = (
            filled[0] if len(filled) == 1 else itertools.chain.from_iterable(filled or record_parts)
        )
        try:
            reached_lsn = int(reached["commit_lsn"])
            stop_lsn = int(stop)
        except (KeyError, TypeError, ValueError) as error:
            # 4: Informix replay returned an invalid end LSN
            raise InformixError(_m(4)) from error
        # The first full-refresh range normally starts at {}, but the framework
        # may add retry bookkeeping before replaying it (for example
        # ``schema_node_fallback_retry_count``). Such metadata does not turn the
        # range into a checkpointed CDC range. Re-executing an initial range
        # legitimately establishes a newer snapshot/CDC boundary than the one
        # latestOffset planned before cancellation; its snapshot rows represent
        # that newer state and replaying them is safe. A checkpointed range,
        # however, must land on its exact transaction boundary. In both cases an
        # under-read is always destructive.
        # A range the read re-established is held to the same terms as an initial one.
        initial_terms = initial_range or reestablished
        wrong_lsn = reached_lsn < stop_lsn or (not initial_terms and reached_lsn != stop_lsn)
        if wrong_lsn:
            # 5: Informix replay did not reach its committed end LSN {}; reached {}
            raise InformixError(_m(5, stop_lsn, reached_lsn))
        # Every page of a snapshot shares its LSN, so the page is checked on its own, and a
        # replay still in a snapshot the logged end has left falls short of it too.
        if _snapshot_position(reached) != end_position:
            # 428: Informix replay did not reach its committed snapshot position {}; reached {}
            raise InformixError(_m(428, end_position, _snapshot_position(reached)))
        # An end that names a transaction is reached only by consuming that transaction.
        # The read lands on its bound without one only for an end the original read
        # reached by going idle, so landing there for this end means the replay never
        # saw the transaction.
        expected_tx = (end or {}).get("tx_id")
        if (
            not initial_terms
            and not replaying_chunk
            and expected_tx is not None
            and str(reached.get("tx_id")) != str(expected_tx)
        ):
            # 6: Informix replay did not reach its committed end transaction {} at LSN {}; reached
            # {}
            raise InformixError(_m(6, expected_tx, stop_lsn, reached.get("tx_id")))
        expected_incremental = (end or {}).get("incremental")
        reached_incremental = reached.get("incremental")
        if isinstance(expected_incremental, dict):
            expected_pk = expected_incremental.get("last_pk")
            # A copy the replay seeded again -- an initial range's, or a re-established one --
            # is another snapshot's, read in full up to the logged cursor: its own last key
            # need not be that cursor, its max_pk having been sampled again.
            if not initial_terms and (
                not isinstance(reached_incremental, dict)
                or reached_incremental.get("last_pk") != expected_pk
            ):
                # 7: Informix replay did not reach its committed incremental snapshot cursor {!r}
                raise InformixError(_m(7, expected_pk))
        elif (replaying_chunk or reestablished) and isinstance(reached_incremental, dict):
            # 8: Informix replay did not finish the incremental snapshot range that Spark has
            # committed
            raise InformixError(_m(8))
        return records
    finally:
        # Scoped strictly to this replay: a normal read that inherited the bound
        # would stop short forever.
        if previous is None:
            options.pop(_REPLAY_STOP_LSN_OPTION, None)
        else:
            options[_REPLAY_STOP_LSN_OPTION] = previous
        if previous_pk is None:
            options.pop(_REPLAY_STOP_PK_OPTION, None)
        else:
            options[_REPLAY_STOP_PK_OPTION] = previous_pk
        if previous_wait_budget is None:
            options.pop(_REPLAY_CONNECTION_WAIT_BUDGET_OPTION, None)
        else:
            options[_REPLAY_CONNECTION_WAIT_BUDGET_OPTION] = previous_wait_budget


def _informix_available_now_base(base: type, spark_session: Any | None = None) -> type:
    # Docstring: Wrap the generated reader base without changing the shared adapter source.

    original_base = getattr(base, "_informix_original_base", base)
    pipeline_id: str | None = None
    update_id: str | None = None
    if spark_session is not None:
        try:
            pipeline_id = spark_session.conf.get("spark.pipelines.pipelineId", None)
            update_id = spark_session.conf.get("spark.pipelines.updateId", None)
        except (AttributeError, TypeError):
            pass
    if not pipeline_id or not update_id:
        registration_scope = secrets.token_hex(16)
    else:
        registration_scope = f"{pipeline_id}_@_{update_id}".lower()
        if _PIPELINE_SCOPE.fullmatch(registration_scope) is None:
            # 9: Spark pipeline and update IDs must be canonical UUID strings
            raise ValueError(_m(9))
    # Schema discovery constructs connector instances before stream readers
    # exist. Publish this registration's immutable scope early so those
    # instances can share the registration-scoped catalog snapshot.
    _INFORMIX_REGISTRATION_CONTEXT["scope"] = registration_scope

    class InformixAvailableNowBase(original_base):
        _informix_available_now_wrapper = True
        _informix_original_base = original_base

        def __init_subclass__(cls, **kwargs):
            super().__init_subclass__(**kwargs)
            # Both framework stream readers are instrumented. Matching only the
            # simple reader left the partitioned proxy -- the default for
            # CDC-capable tables -- without the registration-scope setter and the
            # AvailableNow preparation hook.
            if cls.__name__ not in _WRAPPED_STREAM_READER_NAMES:
                return

            original_init = cls.__init__

            def initialize(reader, *args, **kwargs) -> None:
                original_init(reader, *args, **kwargs)
                setter = getattr(reader.lakeflow_connect, "set_registration_scope", None)
                if setter is not None:
                    setter(registration_scope)
                options = getattr(reader, "options", {})
                table = options.get("tableName", "<unknown>")
                role = "delete" if options.get("isDeleteFlow") == "true" else "upsert"
                # 10: Informix CDC reader initialized: scope={} table={} role={}
                logging.getLogger(__name__).info(
                    _m(10, registration_scope, table, role),
                )

            def prepare_for_trigger(reader) -> None:
                prepare = getattr(
                    reader.lakeflow_connect, "prepare_for_trigger_available_now", None
                )
                if prepare is not None:
                    prepare()

            def read_between_offsets(reader, start, end):
                # Docstring: Replay ``[start, end)`` bounded at ``end`` (see
                # _replay_between_offsets).
                #
                # The shared implementation is ``return self.read(start)[0]``: an
                # unbounded read whose returned offset is discarded. Spark commits its
                # own ``end`` regardless, so if the fresh read stops earlier than the
                # original did, everything in between is dropped silently. The bound
                # travels through the reader's options, which the framework copies into
                # table_options on every read.

                return _replay_between_offsets(
                    start,
                    end,
                    reader.read,
                    reader.options,
                    getattr(reader.lakeflow_connect, "options", {}),
                )

            cls.prepareForTriggerAvailableNow = prepare_for_trigger
            if cls.__name__ == "LakeflowStreamReader":
                # Only the simple reader replays through readBetweenOffsets; the
                # partitioned proxy replays through get_partitions(start, end), which
                # bounds its recompute with the same _replay_between_offsets contract.
                cls.readBetweenOffsets = read_between_offsets
            cls.__init__ = initialize

    return InformixAvailableNowBase


# In the deployable merged module the shared trigger base has already been
# defined and the shared reader is defined after this connector. Shadow its base
# with an Informix-owned wrapper that installs the callback at class creation.
# In normal package imports that global is absent, so this block is inert.
try:
    # This name is local to register_lakeflow_source() after merging; globals()
    # cannot see it. In a normal package import it is intentionally undefined.
    _generated_trigger_base = SupportsTriggerAvailableNow  # type: ignore[name-defined] # noqa: F821
except NameError:
    _generated_trigger_base = None
else:
    # Avoid assigning this name in register_lakeflow_source(): doing so would
    # make the imported PySpark base an uninitialized local throughout that
    # function. Replace the generated module global instead.
    globals()["SupportsTriggerAvailableNow"] = _informix_available_now_base(
        _generated_trigger_base, locals().get("spark")
    )
    # This block runs while the pipeline module executes on the driver, which is
    # the only place an ambient workspace identity is resolvable. Every process a
    # reader later runs in has none, so Lakebase provisioning would have no way to
    # reach the control plane unless the credential is captured here and carried
    # along. Doing it in the merged-deployment branch is deliberate: a plain
    # package import is not a driver and has nothing to capture.
    capture_workspace_credentials()


class InformixError(RuntimeError):
    # Docstring: Base error raised by this connector.
    pass


class ConnectionCapacityUnavailable(InformixError):
    # Docstring: No connector-managed Informix connection slot is currently available.
    pass


class SharedStateAccessUnavailable(InformixError):
    # Docstring: A transient permissions failure prevented access to shared state.
    pass


class TriggerBoundaryUnavailable(InformixError):
    # Docstring: The owning upsert reader has not published this update's boundary yet.
    pass


class SchemaTransitionUnavailable(InformixError):
    # Docstring: The owning upsert reader has not published this schema transition yet.
    pass


class LogRetentionError(InformixError):
    # Docstring: The requested restart LSN is no longer retained by Informix.
    pass


def _stale_capture_label_error(frame: bytes, error: Exception, start_lsn: int) -> InformixError:
    # Docstring: Explain an undecodable CDC frame in terms the operator can act on.
    #
    # Informix can emit log records that predate this capture's registration while
    # still tagging them with the session's capture label. ``decode_frame`` trusts
    # the label to select column descriptors, so such a record is decoded with the
    # wrong layout and fails -- observed in production as a bare
    # ``UnicodeDecodeError`` on a byte belonging to a foreign row's binary field,
    # with nothing to tie it to the log position that caused it.
    #
    # Fail closed rather than skipping the frame. A frame that cannot be decoded
    # under its declared layout cannot be classified: it may be a foreign record
    # (safe to drop) or a real change this reader must not lose, and nothing in the
    # frame distinguishes the two. Silently skipping would risk dropping
    # replicated changes, and continuing would risk ingesting a foreign row as if
    # it were data. Naming the log file lets the operator confirm the checkpoint
    # sits in reused log territory, which is the actual remedy.

    log_file = frame_log_file(frame)
    location = f"logical log {log_file}" if log_file is not None else "an unidentified logical log"
    # 11: Unable to decode an Informix CDC record from {} under the layout registered for this
    # capture: {}. The source replayed a log record that does not match this table's captured
    # columns, which happens when the restart position ({}, logical log {}) lies in a log file whose
    # space Informix has since reused for other tables. The record cannot be classified, so it is
    # neither skipped nor ingested. Run a full refresh to re-establish a restart position in the
    # live log.
    return InformixError(_m(11, location, error, start_lsn, start_lsn >> 32))


class UnsupportedChangeError(InformixError):
    # Docstring: A source operation cannot be represented by the Lakeflow interface.
    pass


class InformixBridge(Protocol):
    # Docstring: Injectable boundary around pure-Python SQLI metadata, snapshots, and CDC.

    def list_tables(self) -> list[dict[str, Any]]: ...

    def get_table(self, identity: str) -> dict[str, Any]: ...

    def key_index_directions(self, identity: str, columns: Sequence[str]) -> list[bool] | None: ...

    def column_defaults(self, identity: str, columns: Sequence[str]) -> list[str]: ...

    def current_lsn(self) -> int: ...

    def minimum_lsn(self) -> int: ...

    def current_utc_time(self) -> int | None: ...

    def prepare_initial_capture(self, identities: Sequence[str]) -> int: ...

    def validate_initial_lsn(self, capture: dict[str, Any], start_lsn: int) -> None: ...

    def snapshot_page(
        self,
        identity: str,
        columns: Sequence[str],
        primary_keys: Sequence[str],
        after: Sequence[Any] | None,
        limit: int,
        max_bytes: int | None = None,
        skip: int = 0,
        snapshot_filter: str | None = None,
        key_descending: Sequence[bool] | None = None,
    ) -> list[dict[str, Any]]: ...

    def consistent_snapshot(
        self,
        identity: str,
        columns: Sequence[str],
        primary_keys: Sequence[str],
        page_size: int,
        max_rows: int,
        max_bytes: int,
        datetime_primary_key: bool = False,
        page_consumer: Callable[[int, int, list[dict[str, Any]]], None] | None = None,
        snapshot_filter: str | None = None,
    ) -> tuple[int, list[dict[str, Any]]]: ...

    def snapshot_chunk(
        self,
        identity: str,
        columns: Sequence[str],
        primary_keys: Sequence[str],
        after: Sequence[Any] | None,
        limit: int,
        max_bytes: int | None = None,
        chunk_exprs: dict[str, str] | None = None,
        snapshot_filter: str | None = None,
        key_descending: Sequence[bool] | None = None,
    ) -> tuple[int, list[dict[str, Any]]]: ...

    def max_primary_key(
        self,
        identity: str,
        primary_keys: Sequence[str],
        chunk_exprs: dict[str, str] | None = None,
        snapshot_filter: str | None = None,
        key_descending: Sequence[bool] | None = None,
    ) -> list[Any] | None: ...

    def read_changes(
        self,
        tables: Sequence[dict[str, Any]],
        start_lsn: int,
        timeout_seconds: int,
        max_records: int,
    ) -> list[dict[str, Any]]: ...

    def release_connection(self) -> None:
        # Docstring: Close a finite poll's source connection and release its capacity lease.
        ...


def _serialized_sqli_operation(method: Callable[..., Any]) -> Callable[..., Any]:
    # Docstring: Keep lease-loss shutdown from closing a transport during an operation.

    def serialized(self: "PurePythonInformixBridge", *args: Any, **kwargs: Any) -> Any:
        lock = getattr(self, "_operation_lock", None)
        if lock is None:  # injected bridges constructed without __init__
            return method(self, *args, **kwargs)
        with lock:
            lease_lost = getattr(self, "_connection_lease_lost", None)
            if lease_lost is not None and lease_lost.is_set():
                # 12: Informix connection-capacity lease was lost before the SQLI operation
                raise ConnectionCapacityUnavailable(_m(12))
            try:
                result = method(self, *args, **kwargs)
            except BaseException as error:
                if lease_lost is not None and lease_lost.is_set():
                    # 13: Informix connection-capacity lease was lost during the SQLI operation
                    raise ConnectionCapacityUnavailable(_m(13)) from error
                raise
            if lease_lost is not None and lease_lost.is_set():
                # 13: Informix connection-capacity lease was lost during the SQLI operation
                raise ConnectionCapacityUnavailable(_m(13))
            return result

    return serialized


def _resolve_daemon_reservation(options: dict[str, str], slot_count: int) -> int:
    # Docstring: Effective CDC-daemon slot reservation (the ``0`` = auto case resolved).
    #
    # Resolution only -- range validation stays in ``_daemon_connection_reservation`` and
    # the constructor. Extracted so ``_resolve_snapshot_reader_threads`` can key its default
    # off the same value without duplicating the auto formula.

    reservation = int(
        options.get(_DAEMON_RESERVATION_OPTION, str(_DEFAULT_DAEMON_CONNECTION_RESERVATION))
    )
    if reservation == 0:
        return min(max(1, slot_count // 3), slot_count - 1)
    return reservation


def _resolve_snapshot_reader_threads(options: dict[str, str]) -> int:
    # Docstring: Number of snapshot-drain workers the pool spawns for these options.
    #
    # Shared by the connector (worker count) and the bridge (reservation band) so the two
    # never drift. An explicit ``snapshot.reader.threads`` wins; otherwise the count is one
    # below the CDC-daemon reservation. Keeping it strictly below the reservation guarantees
    # the snapshot-drain floor (``daemon.connection.reservation - threads``) never collapses
    # to 0, so a low slot always stays reachable by consumer bootstrap reads even while the
    # drains hold their slots for whole scans -- otherwise the drains grab the lowest slots
    # and, holding them for the entire (uncapped) backfill, starve consumer/CDC reads on a
    # small pool. Keyless drains serialize through this pool, so a flat single worker made
    # every keyless table's initial scan queue behind the last, stalling the later tables on
    # multi-table pipelines; one-below-reservation parallelizes them once the pool is large
    # enough to spare a drain band and still keep a consumer floor.

    explicit = options.get(_SNAPSHOT_READER_THREADS_OPTION)
    if explicit is not None:
        return max(1, int(explicit))
    slot_count = int(
        options.get("max.concurrent.connections", str(_DEFAULT_MAX_CONCURRENT_CONNECTIONS))
    )
    return max(1, _resolve_daemon_reservation(options, slot_count) - 1)


class PurePythonInformixBridge:
    # Docstring: Pure-Python SQLI/CDC bridge validated against disposable Informix 15.
    #
    # Tests can inject ``transport.factory=module:callable`` without changing
    # Lakeflow or CDC decoding code.

    def __init__(self, options: dict[str, str]) -> None:
        self.options = options
        authentication = options.get("authentication.mode", "password").lower()
        if authentication not in {"password", "pam"}:
            # 14: Authentication mode {!r} is unsupported; use password or pam.
            raise InformixError(_m(14, authentication))
        self.config = _bridge_config(options)
        # Resolved once and applied in both decode paths: the CDC decode via decode_frame
        # (see read_changes) and the snapshot/query decode inside the SQLI client.
        self._null_byte = _null_byte_mode(options)
        factory_path = options.get("transport.factory")
        if factory_path:
            self.transport = _load_factory(factory_path)(options)
        else:
            provider_path = options.get("authentication.provider.factory")
            provider = (
                _load_factory(provider_path)(options)
                if provider_path
                else PasswordAuthenticationProvider(
                    self.config["password"], options.get("authentication.pam.echo.response")
                )
            )
            self.transport = InformixSqliClient(
                self.config["hostname"],
                self.config["port"],
                self.config["database"],
                self.config["user"],
                self.config["password"],
                server_name=self.config["server"],
                db_locale=self.config["db_locale"],
                client_locale=self.config["client_locale"],
                tls=self.config["tls"],
                ca_file=self.config["ca_file"],
                pad_varchar=self.config["pad_varchar"],
                null_byte=self._null_byte,
                authentication_mode=authentication,
                authentication_provider=provider,
                pam_max_rounds=int(options.get("authentication.pam.max.rounds", "16")),
                login_timeout=float(options.get("authentication.login.timeout", "30")),
                redirect_enabled=_option_bool(options, "redirect.enabled", False),
                redirect_allowlist=_redirect_allowlist(options.get("redirect.allowlist", "")),
                redirect_max=int(options.get("redirect.max", "3")),
            )
        self._connected = False
        self._connect_lock = threading.Lock()
        self._operation_lock = threading.RLock()
        self._connection_lease_lost = threading.Event()
        self._connection_slot: str | None = None
        self._connection_slot_heartbeat_stop: threading.Event | None = None
        self._connection_slot_heartbeat: threading.Thread | None = None
        # Optional callback the snapshot-drain reader installs so a worker blocked in
        # ``_acquire_connection_slot`` can report "still alive, pool is turning over" up to
        # the waiting consumer's liveness watchdog. None (the default) for every other read.
        self._slot_wait_liveness: Callable[[], None] | None = None
        # Startup jitter is one-shot: set once the first connection has applied its delay so
        # steady-state polls and reconnects are never delayed.
        self._startup_jitter_applied = False

    def _apply_startup_jitter(self) -> None:
        # Docstring: Sleep a one-time jittered delay before this reader's first connection.
        #
        # Spreads a pipeline's startup connection/CDC-session opens over a window so dozens of
        # flows do not hit syscdcv1 simultaneously. One-shot per reader instance: the flag is
        # set before sleeping, so a failed connect that retries does not re-delay, and every
        # connection after the first is immediate.

        if getattr(self, "_startup_jitter_applied", True):
            return
        self._startup_jitter_applied = True
        try:
            jitter = float(self.options.get(_CONNECTION_STARTUP_JITTER_OPTION, "0") or 0)
        except (TypeError, ValueError):
            jitter = 0.0
        if jitter > 0:
            time.sleep(random.uniform(0, jitter))

    def _ensure_connected(self) -> None:
        # Tests and injected bridges built with ``object.__new__`` already
        # supply a ready transport and intentionally bypass ``__init__``.
        if getattr(self, "_connected", True):
            return
        with self._connect_lock:
            if self._connected:
                return
            # Before acquiring a slot -- a jittering reader holds nothing while it waits.
            self._apply_startup_jitter()
            bypass_capacity = self.options.get("_informix.bypass.connection.capacity") == "true"
            # A reconnect after reset_transport still holds its slot and heartbeat; claiming
            # another would strand the first, renewed until the process exits.
            if not bypass_capacity and getattr(self, "_lakebase_slot", None) is None:
                budget = self.options.get(_CONNECTION_ATTEMPT_BUDGET_OPTION)
                budget = float(budget) if budget else None
                try:
                    self._acquire_connection_slot(budget)
                except connection_lost_error_types():
                    # Lakebase reaped the state connection while this bridge sat idle
                    # between reads, which psycopg reports only once a query fails:
                    # reopen it and claim again. A live connection's error is real.
                    connection = getattr(self, "_lakebase_conn", None)
                    if connection is not None and not connection.closed:
                        raise
                    self._lakebase_conn = None
                    self._acquire_connection_slot(budget)
            try:
                self._connect_transport()
                self._connected = True
            except Exception:
                self._release_connection_slot()
                raise

    def _connect_transport(self) -> None:
        connect = getattr(self.transport, "connect", None)
        if connect:
            connect()

    @staticmethod
    def _connection_identity_from(source: dict[str, Any]) -> str:
        # Docstring: Identify the Informix endpoint whose capacity is being shared.
        #
        # Deliberately excludes the database name: capacity is a property of the
        # server process, so every database on one server draws from one pool.
        #
        # Takes the mapping so a holder (which has a parsed ``config``) and a waiter
        # (which has only ``options``) derive the *same* identity. They must: the
        # holder publishes the backlog hint and the waiter reads it, so a divergence
        # here would leave every hint silently unreadable rather than failing
        # loudly.

        return "\0".join(
            (
                str(source.get("hostname", "")).strip().rstrip(".").casefold(),
                str(int(source.get("port", 9088) or 9088)),
                str(source.get("server", "")).strip().casefold(),
            )
        )

    def _connection_identity(self) -> str:
        return self._connection_identity_from(getattr(self, "config", None) or self.options)

    def _lakebase(self) -> Any:
        # Docstring: Return this process's Lakebase state handle, provisioning on first use.

        existing = getattr(self, "_lakebase_state", None)
        if existing is not None:
            return existing
        state = LakebaseState(self.options, self._connection_identity())
        state.provision()
        self._lakebase_state = state
        return state

    def _lakebase_connection(self) -> Any:
        # Docstring: Return a per-bridge Postgres connection, reconnecting if it has died.
        #
        # One connection per bridge rather than a pool: a bridge serves a single
        # table's reads sequentially, and the endpoint permits 450 connections
        # (measured), which is ample for a pipeline's flows.

        connection = getattr(self, "_lakebase_conn", None)
        if connection is not None:
            try:
                if not connection.closed:
                    return connection
            except Exception:
                pass
        connection = self._lakebase().connect()
        self._lakebase_conn = connection
        return connection

    def _lakebase_namespace(self) -> str:
        # Docstring: Namespace every row by the Informix endpoint sharing the capacity.

        return hashlib.sha256(self._connection_identity().encode()).hexdigest()[:24]

    def _connection_hints_enabled(self) -> bool:
        return self.options.get("connection.backlog.hint.enabled", "true") != "false"

    def _publish_connection_backlog_hint(self) -> None:
        # Docstring: Record the endpoint's current log position for waiters to read.
        #
        # Called by a reader that still holds a slot, which is the only participant
        # able to ask the server anything. One monotonic upsert: ``GREATEST`` makes
        # concurrent publications converge, so every holder may publish and the
        # value can never regress -- no per-quantum election is needed.
        #
        # Advisory. Every failure is swallowed, because a missing hint only degrades
        # waiters to the unprioritised behaviour they had before hints existed and
        # must never fail a read that otherwise succeeded.

        if not self._connection_hints_enabled():
            return
        try:
            publish_backlog_hint(
                self._lakebase_connection(),
                self._lakebase_namespace(),
                _LAKEBASE_ENDPOINT_HINT_KEY,
                self.current_lsn(),
            )
        except Exception:
            # 15: Informix backlog hint publication failed
            logging.getLogger(__name__).debug(_m(15), exc_info=True)

    @classmethod
    def _read_connection_backlog_hint_at(cls, options: dict[str, str]) -> int | None:
        # Docstring: Return the published endpoint log position from Postgres, or None.
        #
        # Called by a *waiter*, which holds no slot and has no bridge, so it cannot
        # reuse a bridge's connection. The handle is cached per process and keyed by
        # endpoint identity; a waiter reads once per sweep, so one shared connection
        # per process is enough.
        #
        # Advisory, so every failure yields None and the caller falls back to
        # unprioritised waiting rather than failing.

        identity = cls._connection_identity_from(options)
        namespace = hashlib.sha256(identity.encode()).hexdigest()[:24]
        try:
            with _lakebase_waiter_lock():
                state = _LAKEBASE_WAITER_STATE.get(namespace)
                if state is None:
                    state = LakebaseState(options, identity)
                    state.provision()
                    _LAKEBASE_WAITER_STATE[namespace] = state
                connection = _LAKEBASE_WAITER_CONNECTION.get(namespace)
                if connection is None or getattr(connection, "closed", False):
                    connection = state.connect()
                    _LAKEBASE_WAITER_CONNECTION[namespace] = connection
                hints = read_backlog_hints(
                    connection, namespace, max_age_seconds=_CONNECTION_HINT_MAX_AGE_SECONDS
                )
            return hints.get(_LAKEBASE_ENDPOINT_HINT_KEY)
        except Exception:
            with _lakebase_waiter_lock():
                # Drop a connection that may be broken so the next read reopens.
                broken = _LAKEBASE_WAITER_CONNECTION.pop(namespace, None)
            if broken is not None:
                with contextlib.suppress(Exception):
                    broken.close()
            # 16: Informix Lakebase backlog hint read failed
            logging.getLogger(__name__).debug(_m(16), exc_info=True)
            return None

    def _daemon_connection_reservation(self, slot_count: int) -> int:
        reservation = int(
            self.options.get(
                _DAEMON_RESERVATION_OPTION,
                str(_DEFAULT_DAEMON_CONNECTION_RESERVATION),
            )
        )
        if not 0 <= reservation < slot_count:
            # At slot_count a daemon could never claim a slot at all, stranding the
            # sharded CDC session and the snapshot drain permanently.
            # 17: Option '{}' must be >= 0 and < max.concurrent.connections ({})
            raise ValueError(_m(17, _DAEMON_RESERVATION_OPTION, slot_count))
        # A 0 (unset) reservation reserves a third of the pool by default (rounded up to
        # at least 1 whenever the pool has 2+ slots, 0 only for a single-slot pool), so a
        # fresh consumer bootstrap read always has slots the daemons cannot pin. Set a
        # positive value to give the daemons more of the pool (down to reserving a single
        # slot); a single-slot pool reserves nothing because it cannot spare one. Resolved
        # through the shared helper so the snapshot-reader-thread default tracks the same value.
        return _resolve_daemon_reservation(self.options, slot_count)

    def _snapshot_daemon_connection_reservation(self, slot_count: int) -> int:
        # Docstring: Floor for the snapshot-drain daemon: one band below the CDC daemon.
        #
        # The CDC daemon is deferrable and floored at ``daemon.connection.reservation``;
        # a drain is bootstrap work that must make progress, so it sits ``snapshot.reader
        # .threads`` slots lower, giving it that many slots the CDC daemon cannot claim.
        # The band below it (``daemon.connection.reservation - snapshot.reader.threads``
        # slots) stays reachable only by consumer bootstrap reads at floor 0. When the
        # pool cannot spare a private drain band the floor collapses to 0, where the drain
        # still reaches the CDC-free low slots (consumer reads release per microbatch, so
        # those slots churn) -- it simply loses its dedicated headroom.

        daemon_reservation = self._daemon_connection_reservation(slot_count)
        # Reserve a band exactly as wide as the number of drain workers the pool will
        # actually spawn -- resolved through the same module helper the connector's
        # _snapshot_reader_thread_count uses, so a pool-relative default
        # (max.concurrent.connections // 3) and an explicit override both stay in lockstep
        # with the reservation. A flat constant here would under-reserve once the default
        # scales with the pool.
        threads = _resolve_snapshot_reader_threads(self.options)
        return max(0, daemon_reservation - threads)

    def _connection_sweep_rank_scale(self) -> float:
        # Docstring: Shrink the gap between acquisition sweeps for a further-behind reader.
        #
        # The connector publishes the rank alongside the attempt budget, so this
        # needs no offset access of its own. Returns 1.0 when no rank is present,
        # which leaves the cadence byte-identical to the pre-rank behaviour.
        #
        # Linear between 1.0 (unranked) and ``_SLOT_SWEEP_RANK_FLOOR`` (top rank).
        # Bounded deliberately: a freed slot goes to whoever sweeps next, so halving
        # the gap is enough to bias that race, while an unbounded shrink would
        # reintroduce exactly the metadata storm the wide interval exists to prevent.

        raw = self.options.get(_CONNECTION_ATTEMPT_RANK_OPTION)
        if not raw:
            return 1.0
        try:
            rank = int(raw)
        except (TypeError, ValueError):
            return 1.0
        top = _CONNECTION_BACKLOG_RANK_LEVELS - 1
        if rank <= 0 or top <= 0:
            return 1.0
        fraction = min(1.0, rank / top)
        return 1.0 - (1.0 - _SLOT_SWEEP_RANK_FLOOR) * fraction

    def _connection_waiter_class(self) -> int:
        # Docstring: The requester class this reader enqueues under for the round-robin policy.
        #
        # Derived from the private slot markers already on the reader's options, checked
        # daemon-first so a daemon reader is never misclassified as a plain consumer. The
        # class only interleaves the queue; it does not change which slots a reader may
        # claim (that is the reservation ``floor``).

        if self.options.get(_SNAPSHOT_DAEMON_SLOT_MARKER_OPTION) == "true":
            return _SLOT_CLASS_SNAPSHOT_DAEMON
        if self.options.get(_DAEMON_SLOT_MARKER_OPTION) == "true":
            return _SLOT_CLASS_CDC_DAEMON
        return _SLOT_CLASS_CONSUMER

    def _acquire_connection_slot(self, budget_seconds: float | None = None) -> None:
        # Docstring: Claim a capacity slot from Postgres.
        #
        # Structurally the same wait loop as the Volume path -- the same timeout,
        # the same rank-scaled cadence, the same reservation floor -- but each pass
        # is a single atomic statement instead of a per-slot ``mkdir`` sweep, so
        # there is no fence to check afterwards and no partial claim to unwind.

        namespace = self._lakebase_namespace()
        slot_count = int(
            self.options.get(
                "max.concurrent.connections",
                str(_DEFAULT_MAX_CONCURRENT_CONNECTIONS),
            )
        )
        floor = 0
        # The sharded CDC daemon draws from the same pool but, unlike a consumer read,
        # never releases per microbatch: a busy CDC shard re-reads in a tight loop. With
        # ``cdc.shared.reader.threads`` threads on each of two channels, it can pin every
        # slot and starve a fresh consumer bootstrap read (which then times out and fails
        # the query). Floor it above the daemon reservation so those low slots stay
        # reachable by consumer reads.
        is_cdc_daemon = self.options.get(_DAEMON_SLOT_MARKER_OPTION) == "true"
        if is_cdc_daemon:
            floor = max(floor, self._daemon_connection_reservation(slot_count))
        # The snapshot-drain daemon also holds its slot for the whole scan, but it is
        # bootstrap work that must finish to unblock its consumer -- so it floors *below*
        # the CDC daemon into a band the CDC daemon cannot claim, rather than sharing the
        # CDC floor and being starved by a saturated CDC daemon.
        is_snapshot_daemon = self.options.get(_SNAPSHOT_DAEMON_SLOT_MARKER_OPTION) == "true"
        if is_snapshot_daemon:
            floor = max(floor, self._snapshot_daemon_connection_reservation(slot_count))
        connection_wait_timeout = float(
            self.options.get(
                "connection.wait.timeout.seconds",
                str(_DEFAULT_CONNECTION_WAIT_TIMEOUT_SECONDS),
            )
        )
        if budget_seconds is not None:
            connection_wait_timeout = min(connection_wait_timeout, budget_seconds)
        sweep_scale = self._connection_sweep_rank_scale()
        sweep_min = _LAKEBASE_SWEEP_MIN_SECONDS * sweep_scale
        sweep_max = _LAKEBASE_SWEEP_MAX_SECONDS * sweep_scale
        connection = self._lakebase_connection()
        # Capacity is the row count, so the rows must exist before the first
        # claim. Seeding is idempotent and only ever adds rows, and both writes change
        # nothing until the limit does, so a bridge makes them once per limit rather
        # than on every claim. Both commit before the claim, so a claim that gives up
        # leaves them in place.
        seeded = (namespace, slot_count)
        if getattr(self, "_seeded_connection_limit", None) != seeded:
            seed_slots(connection, namespace, slot_count)
            publish_connection_limit(
                connection, namespace, slot_count, _CONNECTION_LIMIT_CONFIG_VERSION
            )
            self._seeded_connection_limit = seeded
        owner = secrets.token_hex(16)
        scope = self.options.get("_informix.pipeline.scope") or None
        deadline = time.monotonic() + connection_wait_timeout
        # Slot-wait liveness (the two daemon roles). A daemon is not a consumer microbatch: it must
        # not fail merely because the pool is *full* -- only when it is *wedged*. So its deadline is
        # a liveness watchdog keyed on pool turnover: as long as slots keep being claimed (the token
        # advances -- other work is completing and recycling capacity), reset the deadline; give up
        # only after a whole window with zero turnover. The snapshot drain additionally pings its
        # waiting consumer each turnover. The CDC shard daemon uses the same watchdog so it holds
        # its queue ticket long enough for the round-robin rotation to reach it -- a round is paid
        # in turnover, not wall-clock -- rather than failing fast on a short budget and re-queuing
        # at the back; on a genuine wedge it gives up and its consumers degrade to direct reads.
        # Other callers keep the plain deadline (a consumer that cannot get a slot should fail its
        # microbatch and retry, not wait out a backfill).
        liveness = is_snapshot_daemon or is_cdc_daemon
        progress_token = pool_progress_token(connection, namespace) if liveness else None
        # Fair queue: enqueue a ticket so acquisition waits its turn instead of a raw race,
        # then heartbeat it each sweep and drop it the moment we win or give up. The ticket
        # carries this reader's requester class so the round-robin policy can interleave
        # classes.
        ticket_id = enqueue_waiter(
            connection,
            namespace,
            owner,
            floor=floor,
            ceiling=slot_count,
            waiter_class=self._connection_waiter_class(),
        )
        try:
            while True:
                # Renew our place and reap any crashed/timed-out waiters so a dead ticket
                # cannot block us; a lost state connection here is transient, so let it
                # surface and be retried by the normal reconnect path. If our own ticket
                # was reaped (a stall longer than the waiter TTL between two sweeps), take
                # a fresh one: acquisition grants only to a live ticket, so sweeping on with
                # a dead one could never win. The new ticket joins the back of its class's
                # rotation, which is the fair outcome for a waiter that went dark.
                if not heartbeat_waiter(
                    connection, namespace, ticket_id, waiter_ttl=_LAKEBASE_WAITER_TTL_SECONDS
                ):
                    # 18: Informix connection-slot waiter ticket {} was reaped; re-enqueuing
                    logging.getLogger(__name__).warning(
                        _m(18, ticket_id),
                    )
                    ticket_id = enqueue_waiter(
                        connection,
                        namespace,
                        owner,
                        floor=floor,
                        ceiling=slot_count,
                        waiter_class=self._connection_waiter_class(),
                    )
                slot = acquire_slot(
                    connection,
                    namespace,
                    owner,
                    slot_count=slot_count,
                    floor=floor,
                    scope=scope,
                    lease_seconds=_CONNECTION_SLOT_LEASE_SECONDS,
                    ticket_id=ticket_id,
                    waiter_ttl=_LAKEBASE_WAITER_TTL_SECONDS,
                    waiter_class=self._connection_waiter_class(),
                    num_classes=_SLOT_CLASS_COUNT,
                )
                if slot is not None:
                    self._connection_slot = f"slot-{slot.slot_id:04d}"
                    self._lakebase_slot = slot
                    stop = threading.Event()
                    heartbeat = threading.Thread(
                        target=self._heartbeat_connection_slot,
                        args=(slot, stop, self._poison_connection_slot_lease),
                        daemon=True,
                        name="informix-lakebase-slot-heartbeat",
                    )
                    self._connection_slot_heartbeat_stop = stop
                    self._connection_slot_heartbeat = heartbeat
                    heartbeat.start()
                    return
                if liveness:
                    # Poll the turnover token: if any slot was claimed since the last sweep
                    # the pool is doing work and will free capacity, so extend the window and
                    # tell the consumer's watchdog the drain is still live. If it is frozen,
                    # fall through to the deadline check -- the pool is genuinely wedged.
                    token = pool_progress_token(connection, namespace)
                    if token != progress_token:
                        progress_token = token
                        deadline = time.monotonic() + connection_wait_timeout
                        if self._slot_wait_liveness is not None:
                            self._slot_wait_liveness()
                if time.monotonic() >= deadline:
                    if liveness:
                        # 19: Timed out waiting for an Informix connection-capacity slot: the pool
                        # made no progress (no slot was claimed or released) for {:g}s, so capacity
                        # is wedged rather than merely busy. Raise max.concurrent.connections, or
                        # reduce concurrent daemon/consumer load.
                        raise ConnectionCapacityUnavailable(_m(19, connection_wait_timeout))
                    # 20: Timed out waiting for an Informix connection-capacity slot after {:g}
                    # seconds
                    raise ConnectionCapacityUnavailable(_m(20, connection_wait_timeout))
                time.sleep(random.uniform(sweep_min, sweep_max))
        finally:
            # Drop our ticket whether we won, timed out, or errored -- a lingering ticket
            # would wrongly hold back younger waiters until it aged out. Best-effort: a
            # dequeue failure must never mask a successful acquire or the real timeout.
            try:
                dequeue_waiter(connection, namespace, ticket_id)
            except Exception:  # noqa: BLE001 - ticket ages out via the reaper anyway
                # 21: snapshot slot waiter dequeue failed
                logging.getLogger(__name__).debug(_m(21), exc_info=True)

    def _heartbeat_connection_slot(
        self,
        slot: Any,
        stop: threading.Event,
        on_lease_lost: Callable[[], None] | None = None,
    ) -> None:
        # Docstring: Renew a Postgres lease until released, poisoning it if renewal fails.
        #
        # Uses its own connection: the bridge's connection is busy serving reads,
        # and psycopg connections are not safe to share across threads.

        def report_lease_lost() -> None:
            # Mirrors the Volume heartbeat: a lease whose owner is already
            # releasing must not be poisoned, or the releaser (which sets ``stop``
            # then joins this thread) and the poisoner (which wants the owner's
            # operation lock) would wait on each other.
            if stop.is_set() or on_lease_lost is None:
                return
            on_lease_lost()

        connection: Any = None
        first_failure: float | None = None
        try:
            while not stop.wait(_CONNECTION_SLOT_HEARTBEAT_SECONDS):
                try:
                    if connection is None or connection.closed:
                        connection = self._lakebase().connect()
                    if not heartbeat_slot(connection, slot):
                        # The guard rejected us: the lease was reclaimed and now
                        # belongs to someone else. Nothing to retry.
                        report_lease_lost()
                        return
                    first_failure = None
                except Exception:
                    now = time.monotonic()
                    if first_failure is None:
                        first_failure = now
                    try:
                        if connection is not None:
                            connection.close()
                    except Exception:
                        pass
                    connection = None
                    # A transient error must not drop a healthy lease, but one
                    # that outlasts the lease means another reader may already
                    # have reclaimed the slot, so the transport has to go.
                    if now - first_failure >= _CONNECTION_SLOT_LEASE_SECONDS:
                        # 22: Informix Lakebase slot renewal failed for {:.0f}s; treating the lease
                        # as lost: {}
                        logging.getLogger(__name__).warning(
                            _m(22, now - first_failure, slot),
                            exc_info=True,
                        )
                        report_lease_lost()
                        return
                    # 23: Informix Lakebase slot renewal failed; will retry
                    logging.getLogger(__name__).debug(_m(23), exc_info=True)
        finally:
            if connection is not None:
                try:
                    connection.close()
                except Exception:
                    pass

    def _release_connection_slot(self) -> None:
        # Docstring: Free a Postgres lease, tolerating a lease already reclaimed.

        slot = getattr(self, "_lakebase_slot", None)
        # Stop the heartbeat before releasing, and clear the handles first so a
        # re-entrant release cannot signal the same thread twice. Without this the
        # thread outlives the lease it was renewing: the slot is freed, another
        # reader claims it and bumps the epoch, and the stale heartbeat's next
        # renewal is rejected -- which it correctly reports as a lost lease,
        # poisoning a transport whose owner had already finished with it.
        stop = getattr(self, "_connection_slot_heartbeat_stop", None)
        heartbeat = getattr(self, "_connection_slot_heartbeat", None)
        self._connection_slot_heartbeat_stop = None
        self._connection_slot_heartbeat = None
        if stop is not None:
            stop.set()
        if heartbeat is not None and heartbeat is not threading.current_thread():
            # Returns as soon as the thread exits, so an ordinary release pays
            # nothing. The bound matters only if a renewal is mid-flight, and the
            # epoch guard makes a late renewal harmless anyway.
            heartbeat.join(timeout=_CONNECTION_SLOT_JOIN_SECONDS)
        if slot is None:
            return
        self._lakebase_slot = None
        # release_connection publishes a backlog hint only while a slot is held.
        self._connection_slot = None
        try:
            try:
                release_slot(self._lakebase_connection(), slot)
            except Exception:  # pylint: disable=broad-except
                # Reaped while the read ran (the lease heartbeat has its own connection), or
                # left in a failed transaction by the advisory backlog-hint write: release
                # over a fresh one.
                stale, self._lakebase_conn = getattr(self, "_lakebase_conn", None), None
                with contextlib.suppress(Exception):
                    stale.close()
                release_slot(self._lakebase_connection(), slot)
        except Exception:
            # Releasing is best effort: the lease expires on its own, so a failed
            # release costs one slot for one lease period rather than a stranded
            # slot as it did on the Volume.
            # 24: Informix could not release Lakebase connection slot {}; its lease will expire
            # instead
            logging.getLogger(__name__).warning(
                _m(24, slot),
                exc_info=True,
            )

    def _poison_connection_slot_lease(self) -> None:
        # Docstring: Abandon a lease that can no longer be renewed, closing the transport.
        #
        # Called from the heartbeat when renewal is rejected or fails persistently.
        # The reader has provably lost its capacity slot, so continuing to use the
        # SQLI connection would exceed the configured concurrency: another reader
        # already owns the slot. Nothing here is Volume-specific -- it is about the
        # Informix transport and the operation in flight on it.

        lease_lost = getattr(self, "_connection_lease_lost", None)
        if lease_lost is not None:
            # Publish loss before waiting. The active operation can finish its
            # bounded socket work, but its wrapper must discard the result.
            lease_lost.set()
        operation_lock = getattr(self, "_operation_lock", None)
        context: Any = contextlib.nullcontext()
        if operation_lock is not None:
            # Bound the wait for the active operation. The lease is already
            # published as lost, so the operation's wrapper will discard its result
            # regardless; what remains is closing the transport and freeing the
            # slot. Waiting without a bound risks pairing with a releaser that is
            # joining this thread. The guard in the heartbeat covers the ordinary
            # release, and this covers the residue: a reader whose operation
            # outlives the lease still gets its transport closed and slot freed
            # here rather than leaving the lease poisoned indefinitely.
            if operation_lock.acquire(timeout=_POISON_OPERATION_LOCK_SECONDS):
                context = contextlib.ExitStack()
                context.callback(operation_lock.release)
            else:
                # 25: Informix connection-slot lease loss could not take the operation lock within
                # {:.0f}s; closing the transport while an operation is still in flight: {}
                logging.getLogger(__name__).warning(
                    _m(25, _POISON_OPERATION_LOCK_SECONDS, getattr(self, "_connection_slot", None)),
                )
        with context:
            with self._connect_lock:
                # 26: Informix connection-slot lease renewal failed persistently; closing SQLI
                # transport after the active operation exits
                logging.getLogger(__name__).error(_m(26))
                self._connected = False
                try:
                    close = getattr(self.transport, "close", None)
                    if close is not None:
                        close()
                except Exception:
                    # 27: Failed to close SQLI transport after connection-slot lease loss
                    logging.getLogger(__name__).warning(
                        _m(27),
                        exc_info=True,
                    )
                finally:
                    self._release_connection_slot()
                    if lease_lost is not None:
                        lease_lost.clear()

    @classmethod
    def _remove_connection_slot_tree(cls, path: str) -> None:
        parent, name = os.path.split(path)
        parts = os.path.normpath(path).split(os.sep)
        if len(parts) >= 5 and parts[1] == "Volumes":
            root = os.path.join(os.sep, *parts[1:5])
            descriptor = _open_state_directory(root, parent)
        else:
            flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0) | getattr(os, "O_NOFOLLOW", 0)
            descriptor = os.open(parent or ".", flags)
        try:
            info = os.stat(name, dir_fd=descriptor, follow_symlinks=False)
            if not stat.S_ISDIR(info.st_mode):
                os.unlink(name, dir_fd=descriptor)
                return
            _remove_candidate_tree_at(descriptor, name)
            os.rmdir(name, dir_fd=descriptor)
        finally:
            os.close(descriptor)

    def release_connection(self) -> None:
        # Docstring: Release a finite worker poll's SQLI session without discarding metadata.

        operation_lock = getattr(self, "_operation_lock", None)
        context = operation_lock if operation_lock is not None else contextlib.nullcontext()
        with context:
            with self._connect_lock:
                if not self._connected:
                    self._release_connection_slot()
                    return
                # Publish the backlog hint here: this is the last point at which
                # the connection is still live *and* the slot is still held, which
                # is exactly the position a waiter cannot reach. Advisory, so it
                # must never turn a completed read into a failed one.
                slot = getattr(self, "_connection_slot", None)
                if slot is not None:
                    self._publish_connection_backlog_hint()
                try:
                    close = getattr(self.transport, "close", None)
                    if close:
                        close()
                finally:
                    self._connected = False
                    self._release_connection_slot()

    def reset_transport(self) -> None:
        # Docstring: Drop a dead SQLI transport but keep the connection slot held.
        #
        # Used to recover from a mid-read connection drop: close the (already
        # broken) transport and mark the bridge disconnected so the next
        # ``_ensure_connected`` reconnects, *without* releasing and re-acquiring
        # the connection slot. Releasing the slot here would reintroduce capacity
        # contention on what is a transient network blip, and the caller is
        # retrying the same read in place under the slot it already owns.

        operation_lock = getattr(self, "_operation_lock", None)
        context = operation_lock if operation_lock is not None else contextlib.nullcontext()
        with context:
            with self._connect_lock:
                if not self._connected:
                    return
                try:
                    close = getattr(self.transport, "close", None)
                    if close:
                        close()
                except Exception:
                    # 28: Failed to close SQLI transport during reset; reconnecting anyway
                    logging.getLogger(__name__).warning(
                        _m(28),
                        exc_info=True,
                    )
                finally:
                    self._connected = False

    def _metadata_max_bytes(self) -> int | None:
        # Docstring: ``metadata.max.bytes`` as a catalog query's result bound; ``0`` is unbounded.

        return int(self.options.get("metadata.max.bytes", str(64 << 20))) or None

    @_serialized_sqli_operation
    def list_tables(self) -> list[dict[str, Any]]:
        self._ensure_connected()
        maximum = self._metadata_max_bytes()
        # Every base table, the system catalog's included. Informix's CDC API refuses only
        # views, temporary and non-logged tables and unlogged databases, so nothing else is
        # left out by name or owner; tabtype 'T' already leaves views and synonyms out.
        columns = self.transport.execute(
            _CATALOG_COLUMNS_SQL.format(", t.owner, t.tabname")
            + " ORDER BY t.owner, t.tabname, c.colno",
            max_result_bytes=maximum,
        )
        keys = self.transport.execute(
            _PRIMARY_KEY_SQL.format(",t.owner,t.tabname") + " ORDER BY t.owner,t.tabname",
            max_result_bytes=maximum,
        )
        columns_by_table: dict[tuple[str, str], list[Any]] = {}
        for row in columns:
            identity = (
                str(_field(row, "owner", 8)),
                str(_field(row, "tabname", 9)),
            )
            columns_by_table.setdefault(identity, []).append(row)
        keys_by_table = {
            (str(_field(row, "owner", 16)), str(_field(row, "tabname", 17))): [row] for row in keys
        }
        # A table without a primary key is keyed by a UNIQUE index here too, as
        # _describe_table keys it: the connector caches these tables, so a later read of
        # one must see the key a direct lookup would.
        unique_by_table: dict[tuple[str, str], list[Any]] = {}
        if _option_bool(self.options, _PROMOTE_UNIQUE_INDEX_OPTION, True) and any(
            table not in keys_by_table for table in columns_by_table
        ):
            for row in self.transport.execute(
                _UNIQUE_INDEX_SQL.format(",t.owner,t.tabname") + " ORDER BY t.owner,t.tabname",
                max_result_bytes=maximum,
            ):
                table = (str(_field(row, "owner", 17)), str(_field(row, "tabname", 18)))
                if table not in keys_by_table:
                    unique_by_table.setdefault(table, []).append(row)
        result = []
        retained_bytes = (
            _deep_size(result)
            + _deep_size(columns)
            + _deep_size(keys)
            + _deep_size(unique_by_table)
            if maximum
            else 0
        )
        for (owner, name), table_columns in columns_by_table.items():
            table = self._table_from_catalog_rows(
                owner,
                name,
                table_columns,
                keys_by_table.get((owner, name), []),
                unique_by_table.get((owner, name), []),
            )
            if maximum:
                retained_bytes += _deep_size(table)
            if maximum and retained_bytes > maximum:
                # 29: Informix metadata discovery exceeded metadata.max.bytes={}
                raise InformixError(_m(29, maximum))
            result.append(table)
        return result

    @_serialized_sqli_operation
    def get_table(self, identity: str) -> dict[str, Any]:
        self._ensure_connected()
        parts = _split_identity(identity)
        if len(parts) != 3:
            # 30: Invalid logical table identity {!r}
            raise InformixError(_m(30, identity))
        return self._describe_table(parts[1], parts[2])

    @_serialized_sqli_operation
    def table_versions(self, tabids: Sequence[int]) -> dict[int, tuple[str, str, int]]:
        # Docstring: ``systables.version`` of the tables with these IDs, as table ID ->
        # (owner, name, version), in one catalog query per _CATALOG_BATCH IDs.
        #
        # Informix bumps the version on every change to a table's definition -- a column
        # added, changed, dropped, or renamed, an index or constraint created or dropped, a
        # default changed, the table renamed -- and on UPDATE STATISTICS. An ID missing from
        # the result no longer names a table.

        self._ensure_connected()
        maximum = self._metadata_max_bytes()
        wanted = sorted({int(tabid) for tabid in tabids})
        versions: dict[int, tuple[str, str, int]] = {}
        for start in range(0, len(wanted), _CATALOG_BATCH):
            batch = wanted[start : start + _CATALOG_BATCH]
            rows = self.transport.execute(
                "SELECT tabid, owner, tabname, version FROM systables "
                f"WHERE tabtype = 'T' AND tabid IN ({', '.join('?' * len(batch))})",
                tuple(batch),
                max_result_bytes=maximum,
            )
            for row in rows:
                versions[int(_field(row, "tabid", 0))] = (
                    str(_field(row, "owner", 1)).strip(),
                    str(_field(row, "tabname", 2)).strip(),
                    int(_field(row, "version", 3)),
                )
        return versions

    @_serialized_sqli_operation
    def get_tables(self, identities: Sequence[str]) -> dict[str, dict[str, Any]]:
        # Docstring: Describe several tables as get_table does, as identity -> table, in
        # two or three catalog queries per _CATALOG_BATCH tables rather than per table; an
        # identity missing from the result names no table. See _describe_tables.

        self._ensure_connected()
        wanted: dict[tuple[str, str], str] = {}
        for identity in identities:
            parts = _split_identity(identity)
            if len(parts) != 3:
                # 30: Invalid logical table identity {!r}
                raise InformixError(_m(30, identity))
            wanted[(parts[1], parts[2])] = identity
        described = self._describe_tables(wanted)
        return {wanted[table]: raw for table, raw in described.items()}

    def _describe_tables(
        self, tables: Iterable[tuple[str, str]]
    ) -> dict[tuple[str, str], dict[str, Any]]:
        # Docstring: _describe_table for several (owner, name) tables at once, as
        # (owner, name) -> table; a table missing from the result doesn't exist.
        #
        # The queries select by table name and keep the owners asked for, so a same-named
        # table of another owner is read and dropped. The UNIQUE-index query runs only for
        # the tables without a primary key, as in _describe_table.

        maximum = self._metadata_max_bytes()
        wanted = set(tables)
        names = sorted({name for _, name in wanted})
        columns: dict[tuple[str, str], list[Any]] = {}
        keys: dict[tuple[str, str], list[Any]] = {}
        unique_indexes: dict[tuple[str, str], list[Any]] = {}

        def rows_by_table(sql: str, batch: list[str], owner_at: int, into: dict) -> None:
            for row in self.transport.execute(
                sql + f" AND t.tabname IN ({', '.join('?' * len(batch))})",
                tuple(batch),
                max_result_bytes=maximum,
            ):
                table = (
                    str(_field(row, "owner", owner_at)).strip(),
                    str(_field(row, "tabname", owner_at + 1)).strip(),
                )
                if table in wanted:
                    into.setdefault(table, []).append(row)

        for start in range(0, len(names), _CATALOG_BATCH):
            batch = names[start : start + _CATALOG_BATCH]
            rows_by_table(
                _CATALOG_COLUMNS_SQL.format(", t.owner, t.tabname"),
                batch,
                8,
                columns,
            )
            rows_by_table(
                _PRIMARY_KEY_SQL.format(",t.owner,t.tabname"),
                batch,
                16,
                keys,
            )
        keyless = sorted({table[1] for table in wanted if table in columns and table not in keys})
        if keyless and _option_bool(self.options, _PROMOTE_UNIQUE_INDEX_OPTION, True):
            for start in range(0, len(keyless), _CATALOG_BATCH):
                rows_by_table(
                    _UNIQUE_INDEX_SQL.format(",t.owner,t.tabname"),
                    keyless[start : start + _CATALOG_BATCH],
                    17,
                    unique_indexes,
                )
        described: dict[tuple[str, str], dict[str, Any]] = {}
        for table in wanted:
            if table not in columns:
                continue
            ordered = sorted(columns[table], key=lambda row: int(_field(row, "colno", 3)))
            described[table] = self._table_from_catalog_rows(
                table[0], table[1], ordered, keys.get(table, [])[:1], unique_indexes.get(table, [])
            )
        return described

    @staticmethod
    def _capture_table(capture: dict[str, Any]) -> tuple[str, str, str]:
        # Docstring: A capture's native identity as (database, owner, name).

        native = str(capture["identity"])
        try:
            database, qualified = native.split(":", 1)
            owner, name = _split_identity(qualified)
        except ValueError as error:
            # 31: Invalid native table identity {!r}
            raise InformixError(_m(31, native)) from error
        return database, owner, name

    def _assert_capture_layout(
        self,
        capture: dict[str, Any],
        encoding: str,
        catalog: dict[tuple[str, str], dict[str, Any]],
    ) -> None:
        # Docstring: Fail before decoding rows when catalog metadata changed mid-session.
        #
        # ``catalog`` is the read's captured tables as _describe_tables read them, once,
        # when the first CDC metadata record arrived (see read_changes).

        native = str(capture["identity"])
        database, owner, name = self._capture_table(capture)
        described = catalog.get((owner, name))
        if described is None:
            # 32: Informix schema changed for {!r} during CDC; run a full refresh before decoding
            # additional records
            raise InformixError(_m(32, native))
        refreshed = _capture_descriptor(Table.parse(described, database), encoding)

        def layout(value: dict[str, Any]) -> dict[str, tuple[Any, ...]]:
            return {
                str(column["name"]): (
                    str(column["type_name"]),
                    int(column.get("length") or 0),
                    column.get("precision"),
                    column.get("scale"),
                    str(column.get("encoding") or "utf-8"),
                )
                for column in value["descriptors"]
            }

        # Every captured column must still exist with the layout it is decoded by. Matched
        # by name, not position: a column selection captures a subset of the catalog, and
        # the CDC metadata record already fixes the order rows arrive in.
        refreshed_layout = layout(refreshed)
        capture_layout = layout(capture)
        captured_unchanged = all(
            refreshed_layout.get(column) == capture_layout[column] for column in capture["columns"]
        )
        if not captured_unchanged:
            # 32: Informix schema changed for {!r} during CDC; run a full refresh before decoding
            # additional records
            raise InformixError(_m(32, native))

    def _describe_table(self, owner: str, name: str) -> dict[str, Any]:
        columns = self.transport.execute(
            _CATALOG_COLUMNS_SQL.format("") + " AND t.owner = ? AND t.tabname = ? ORDER BY c.colno",
            (owner, name),
            max_result_bytes=self._metadata_max_bytes(),
        )
        keys = self.transport.execute(
            _PRIMARY_KEY_SQL.format("") + " AND t.owner=? AND t.tabname=?",
            (owner, name),
            max_result_bytes=self._metadata_max_bytes(),
        )
        unique_indexes: list[Any] = []
        # No primary key: fall back to a UNIQUE index (see _select_unique_index_key). Only
        # queried when the table is physically key-less and the feature is enabled, so a
        # normal keyed table pays nothing extra. The index name is fetched so the selection
        # can break ties on it deterministically.
        if not keys and _option_bool(self.options, _PROMOTE_UNIQUE_INDEX_OPTION, True):
            unique_indexes = self.transport.execute(
                _UNIQUE_INDEX_SQL.format("") + " AND t.owner=? AND t.tabname=?",
                (owner, name),
                max_result_bytes=self._metadata_max_bytes(),
            )
        return self._table_from_catalog_rows(owner, name, columns, keys, unique_indexes)

    def _table_from_catalog_rows(
        self,
        owner: str,
        name: str,
        columns: list[Any],
        keys: list[Any],
        unique_indexes: list[Any] | None = None,
    ) -> dict[str, Any]:
        parsed_columns = [_catalog_column(row) for row in columns]
        for column in parsed_columns:
            if column["type_name"] in {"INT8", "SERIAL8"}:
                column["cdc_supported"] = True
            if column["type_name"] == "DATETIME":
                start, end = (column["length"] >> 8) & 0xF, column["length"] & 0xF
                column["cdc_supported"] = (
                    start in {0, 2, 4, 6, 8, 10}
                    and end in {0, 2, 4, 6, 8, 10, 11, 12, 13, 14, 15}
                    and end >= start
                )
        by_number = {
            int(_field(row, "colno", 3)): str(_field(row, "colname", 0)) for row in columns
        }
        primary_keys = []
        # Per-column index direction, parallel to primary_keys: True == the column
        # is stored DESC in the key index (a negative catalog part number). Kept so
        # a mixed-direction key can be paged in the index's own order instead of
        # forcing an all-ascending sort. Normalized to [] when every column is ASC
        # so the common case carries no extra state and behaves exactly as before.
        key_descending: list[bool] = []
        # A UNIQUE index with nullable column(s) that could stand in as the key only if the
        # per-table allow.nullable.index option is set. Reported as a catalog fact (columns
        # + directions); the connector promotes it, since that option is table-level.
        nullable_index_key: list[tuple[str, bool]] = []
        if keys:
            for position in range(16):
                column_number = int(_field(keys[0], f"part{position + 1}", position))
                if column_number != 0:
                    primary_keys.append(by_number[abs(column_number)])
                    key_descending.append(column_number < 0)
        elif unique_indexes:
            # No primary-key constraint: stand a UNIQUE index in for it (deterministically
            # chosen -- see _select_unique_index_key). The resulting key is catalog-derived,
            # so a schema refresh re-derives it; an explicit primary.keys option still
            # overrides it downstream in _apply_primary_key_override.
            nullable_by_name = {
                column["name"]: bool(column["nullable"]) for column in parsed_columns
            }
            index_parts = [
                (
                    str(_field(index, "idxname", 0)),
                    [
                        int(_field(index, f"part{position + 1}", position + 1))
                        for position in range(16)
                    ],
                )
                for index in unique_indexes
            ]
            selected = _select_unique_index_key(index_parts, by_number, nullable_by_name)
            primary_keys = [name for name, _ in selected]
            key_descending = [is_desc for _, is_desc in selected]
            if not primary_keys:
                # No all-NOT-NULL unique index qualified. Offer the nullable-relaxed
                # candidate for the connector to promote when allow.nullable.index is set.
                nullable_index_key = _select_unique_index_key(
                    index_parts, by_number, nullable_by_name, allow_nullable=True
                )
        try:
            tabid = int(_field(columns[0], "tabid", 4))
        except (IndexError, KeyError, TypeError, ValueError) as error:
            # 33: Informix catalog metadata for {}.{} is missing tabid
            raise InformixError(_m(33, owner, name)) from error
        if tabid <= 0:
            # 34: Informix catalog metadata for {}.{} has invalid tabid {}
            raise InformixError(_m(34, owner, name, tabid))
        return {
            "database": self.config["database"],
            "owner": owner,
            "name": name,
            "columns": parsed_columns,
            "primary_keys": primary_keys,
            # Only carry directions for a genuinely mixed/descending key; an
            # all-ascending key stays [] so nothing downstream changes for it.
            "key_descending": key_descending if any(key_descending) else [],
            # The nullable-relaxed unique-index candidate as [[name, descending], ...],
            # promotable only when the table sets allow.nullable.index.
            "nullable_index_key": [[name, is_desc] for name, is_desc in nullable_index_key],
            "incarnation": str(tabid),
        }

    @_serialized_sqli_operation
    def column_defaults(self, identity, columns):
        # Docstring: Return which of ``columns`` have a non-NULL default in the catalog.
        #
        # ``sysdefaults`` holds one row per column with an explicit default; type ``N`` is
        # ``DEFAULT NULL``, which leaves existing rows NULL like no default at all, so it is
        # not reported.

        self._ensure_connected()
        database, owner, name = _split_identity(identity)
        for identifier in (database, owner, name, *columns):
            if not _IDENTIFIER.fullmatch(identifier):
                # 35: Unsafe column-default identifier {!r}
                raise InformixError(_m(35, identifier))
        rows = self.transport.execute(
            "SELECT c.colname, d.type FROM systables t "
            "JOIN syscolumns c ON t.tabid = c.tabid "
            "JOIN sysdefaults d ON d.tabid = c.tabid AND d.colno = c.colno "
            "WHERE t.tabtype = 'T' AND t.owner = ? AND t.tabname = ?",
            (owner, name),
            max_result_bytes=self._metadata_max_bytes(),
        )
        wanted = set(columns)
        return sorted(
            {
                str(_field(row, "colname", 0)).strip()
                for row in rows
                if str(_field(row, "colname", 0)).strip() in wanted
                and str(_field(row, "type", 1)).strip().upper() != "N"
            }
        )

    @_serialized_sqli_operation
    def key_index_directions(self, identity, columns):
        # Docstring: Return the per-column DESC flags of an index whose key columns exactly
        # match ``columns`` in order, or ``None`` if no index matches.
        #
        # A ``primary.keys`` override names columns, not an index, so on its own it
        # pages all-ascending -- which sorts when the real key index is
        # mixed-direction. This finds any index (unique, duplicate, or the PK's)
        # whose ordered key columns equal the override and reports its directions,
        # so the override can page in that index's own order. A negative catalog
        # part number is a descending column. ``None`` leaves paging ascending.

        self._ensure_connected()
        database, owner, name = _split_identity(identity)
        for identifier in (database, owner, name, *columns):
            if not _IDENTIFIER.fullmatch(identifier):
                # 36: Unsafe key-index identifier {!r}
                raise InformixError(_m(36, identifier))
        max_bytes = self._metadata_max_bytes()
        column_rows = self.transport.execute(
            "SELECT c.colname, c.colno FROM systables t JOIN syscolumns c ON t.tabid = c.tabid "
            "WHERE t.tabtype = 'T' AND t.owner = ? AND t.tabname = ?",
            (owner, name),
            max_result_bytes=max_bytes,
        )
        by_number = {
            int(_field(row, "colno", 1)): str(_field(row, "colname", 0)) for row in column_rows
        }
        index_rows = self.transport.execute(
            f"SELECT {_INDEX_PARTS} FROM systables t JOIN sysindexes i ON t.tabid = i.tabid "
            "WHERE t.tabtype = 'T' AND t.owner = ? AND t.tabname = ?",
            (owner, name),
            max_result_bytes=max_bytes,
        )
        target = list(columns)
        for row in index_rows:
            names: list[str] = []
            directions: list[bool] = []
            for position in range(16):
                part = int(_field(row, f"part{position + 1}", position + 1))
                if part == 0:
                    break  # key columns are contiguous; the rest is padding
                column_name = by_number.get(abs(part))
                if column_name is None:
                    names = []  # references a column we cannot name; skip this index
                    break
                names.append(column_name)
                directions.append(part < 0)
            if names == target:
                return directions
        return None

    @_serialized_sqli_operation
    def current_lsn(self) -> int:
        self._ensure_connected()
        uniqid, used = self._current_log_position()
        return _log_lsn(uniqid, used)

    @_serialized_sqli_operation
    def boundary_lsn(self) -> int:
        # Docstring: A capture boundary that is never ahead of the log's true write position.
        #
        # ``syslogs.used`` is a page count, so :meth:`current_lsn` names the end of the
        # page currently being written -- up to one page ahead of the last record on
        # disk. A transaction committing in the rest of that page *after* the sample
        # would carry an LSN at or below such a boundary and be discarded by ``_recover``
        # as already captured, while the snapshot read that follows the sample may or
        # may not have seen it: a stale or missing row with nothing left to correct it.
        # Anchoring the boundary at the *start* of the current page keeps it at or below
        # every commit that follows the sample. The cost is at most one page of log
        # re-delivered, which keyed targets dedup by key and LSN. Positions used as a
        # stop bound (the AvailableNow high-water mark, log-file comparisons) keep
        # :meth:`current_lsn`, where overshooting is harmless.

        self._ensure_connected()
        uniqid, used = self._current_log_position()
        return _log_lsn(uniqid, used, page_start=True)

    def _current_log_position(self) -> tuple[int, int]:
        row = self.transport.execute(
            "SELECT uniqid, used FROM sysmaster:syslogs WHERE is_current = 1"
        )[0]
        return int(_field(row, "uniqid", 0)), int(_field(row, "used", 1))

    @_serialized_sqli_operation
    def minimum_lsn(self) -> int:
        self._ensure_connected()
        row = self.transport.execute("SELECT MIN(uniqid) AS uniqid FROM sysmaster:syslogs")[0]
        return int(_field(row, "uniqid", 0)) << 32

    @_serialized_sqli_operation
    def current_utc_time(self) -> int | None:
        # Docstring: Source-server current time as UTC epoch seconds, matching the CDC commit-time
        # units, for stamping snapshot rows' ``_informix_commit_time``.
        #
        # Best-effort: a source that does not support ``DBINFO('utc_current')`` yields NULL
        # commit-time on snapshot rows rather than failing the read.

        if time.monotonic() < getattr(self, "_utc_time_retry_at", 0.0):
            return None
        self._ensure_connected()
        try:
            row = self.transport.execute(
                "SELECT DBINFO('utc_current') AS utc FROM sysmaster:sysdual"
            )[0]
            return int(_field(row, "utc", 0))
        except Exception as error:
            # The failed statement poisoned the SQLI client: drop the transport, keeping
            # the slot, so the next statement reconnects rather than failing on it. A
            # source that answered with an error isn't asked again for a while: the
            # error may mean it can't run the probe, or only a lock timeout.
            self.reset_transport()
            if not isinstance(error, (SqliTransportError, OSError)):
                self._utc_time_retry_at = time.monotonic() + _UTC_TIME_REPROBE_SECONDS
            return None

    @_serialized_sqli_operation
    def prepare_initial_capture(self, identities: Sequence[str]) -> int:
        # Docstring: Enable full-row logging for every table, then capture one shared boundary.
        #
        # The boundary is :meth:`boundary_lsn` -- never ahead of the true log position --
        # because the snapshot that follows is sequenced against it.

        self._ensure_connected()

        if not identities:
            # 37: Initial CDC preparation requires at least one table
            raise InformixError(_m(37))
        enabled = []
        try:
            for identity in identities:
                _expect_zero(
                    self.transport.execute(
                        f"EXECUTE FUNCTION {cdc_routine('cdc_set_fullrowlogging')}(?, 1)",
                        (identity,),
                    ),
                    f"cdc_set_fullrowlogging({identity})",
                )
                enabled.append(identity)
        except Exception as error:
            # 38: Initial CDC preparation was partially applied; full-row logging remains enabled
            # for {!r}. Correct the failure and rerun preparation.
            raise InformixError(_m(38, enabled)) from error
        return self.boundary_lsn()

    @_serialized_sqli_operation
    def validate_initial_lsn(self, capture: dict[str, Any], start_lsn: int) -> None:
        # Docstring: Validate CDC registration/activation without reading LODATA records.
        #
        # Retries on a socket-read *timeout*, which under a startup storm (many flows
        # opening CDC sessions against syscdcv1 at once) is transient contention rather
        # than a real validation failure. Each attempt reconnects a fresh transport;
        # bounded attempts with short backoff ride out the storm, and exhausting them
        # re-raises so a genuinely-unreachable source still fails honestly. A non-timeout
        # failure (a nonzero cdc_* return, a negative session id) is a real error and is
        # never retried. Idempotent: each attempt opens its own CDC session, and the
        # server reclaims an abandoned one on its own.

        attempt = 0
        while True:
            try:
                self._validate_initial_lsn_once(capture, start_lsn)
                return
            except Exception as error:  # pylint: disable=broad-except
                if not _is_timeout_error(error) or attempt >= _VALIDATE_LSN_RETRY_MAX_RETRIES:
                    raise
                delay = min(
                    _VALIDATE_LSN_RETRY_BASE_SECONDS * (2**attempt),
                    _VALIDATE_LSN_RETRY_MAX_SECONDS,
                )
                # 39: Informix CDC initial-LSN validation timed out ({}); resetting the transport
                # and retrying (attempt {}/{}) after {:.1f}s. Raise cdc.read.timeout.seconds or
                # reduce concurrent CDC sessions if this recurs.
                logging.getLogger(__name__).warning(
                    _m(39, error, attempt + 1, _VALIDATE_LSN_RETRY_MAX_RETRIES, delay),
                    exc_info=True,
                )
                self.reset_transport()
                time.sleep(delay)
                attempt += 1

    def _validate_initial_lsn_once(self, capture: dict[str, Any], start_lsn: int) -> None:
        # Docstring: One attempt of :meth:`validate_initial_lsn` (which owns the retry policy).

        self._ensure_connected()

        # The CDC control-plane calls below (open/start/activate/end/close) run on
        # the transport's default socket timeout unless raised here. syscdcv1
        # teardown can stall under many concurrent CDC sessions, so give them the
        # configured cdc.read.timeout.seconds budget instead of the ~30s default.
        set_socket_timeout = getattr(self.transport, "set_socket_timeout", None)
        previous_socket_timeout = getattr(self.transport, "socket_timeout", None)
        cdc_timeout = float(
            self.options.get("cdc.read.timeout.seconds", str(_DEFAULT_CDC_READ_TIMEOUT_SECONDS))
        )
        if set_socket_timeout is not None:
            set_socket_timeout(max(float(previous_socket_timeout or 30), cdc_timeout))

        server_row = self.transport.execute(
            "SELECT env_value FROM sysmaster:sysenv WHERE env_name='INFORMIXSERVER'"
        )[0]
        server = str(_field(server_row, "env_value", 0))
        session_row = self.transport.execute(
            f"EXECUTE FUNCTION {cdc_routine('cdc_opensess')}(?, 0, 1, 1, 1, 1)",
            (server,),
        )[0]
        session = int(_field(session_row, "session_id", 0))
        if session < 0:
            # 40: cdc_opensess failed with Informix error {}
            raise InformixError(_m(40, session))
        native = capture["identity"]
        started = False
        primary_error: BaseException | None = None
        try:
            _expect_zero(
                self.transport.execute(
                    f"EXECUTE FUNCTION {cdc_routine('cdc_startcapture')}(?, 0, ?, ?, ?)",
                    (session, native, ",".join(capture["columns"]), 1),
                ),
                "cdc_startcapture",
            )
            started = True
            _expect_zero(
                self.transport.execute(
                    f"EXECUTE FUNCTION {cdc_routine('cdc_activatesess')}(?, ?)",
                    (session, start_lsn),
                ),
                "cdc_activatesess",
            )
        except BaseException as error:
            primary_error = error
            raise
        finally:
            if primary_error is None or not _is_timeout_error(primary_error):
                self._teardown_validation_session(
                    started,
                    session,
                    native,
                    primary_error,
                    set_socket_timeout,
                    previous_socket_timeout,
                )
            else:
                # The socket is mid-read on a timed-out CDC session. Skip teardown --
                # issuing it on a dead socket would only time out again, tripling this
                # attempt's cost. validate_initial_lsn resets the transport and retries;
                # the server reclaims the abandoned session on its own. The timeout is
                # still put back: the client keeps it for every later connection.
                if set_socket_timeout is not None and previous_socket_timeout is not None:
                    set_socket_timeout(float(previous_socket_timeout))

    def _teardown_validation_session(
        self,
        started: bool,
        session: int,
        native: str,
        primary_error: BaseException | None,
        set_socket_timeout,
        previous_socket_timeout,
    ) -> None:
        # Docstring: Best-effort teardown for :meth:`_validate_initial_lsn_once`.
        #
        # The purpose of the validation -- proving the CDC boundary registers and
        # activates -- is already met once activation succeeds (``primary_error`` is
        # None). cdc_endcapture/cdc_closesess are best-effort: the server reclaims an
        # abandoned CDC session on its own, and the validation returns no value derived
        # from them. A teardown that merely *times out* under heavy syscdcv1 load must not
        # fail an otherwise-successful validation -- doing so was observed wedging a flow
        # (e.g. tw101) purely on a slow teardown. Poison the transport so the next use
        # reconnects rather than resuming a half-torn-down session, and treat it as
        # non-fatal. A non-timeout cleanup failure, or any failure alongside a real primary
        # error, is still surfaced.

        cleanup_errors = []
        cleanup_timed_out = False
        if started:
            try:
                _expect_zero(
                    self.transport.execute(
                        f"EXECUTE FUNCTION {cdc_routine('cdc_endcapture')}(?, 0, ?)",
                        (session, native),
                    ),
                    "cdc_endcapture",
                )
            except Exception as error:
                cleanup_errors.append(error)
                cleanup_timed_out = cleanup_timed_out or _is_timeout_error(error)
        try:
            _expect_zero(
                self.transport.execute(
                    f"EXECUTE FUNCTION {cdc_routine('cdc_closesess')}(?)", (session,)
                ),
                "cdc_closesess",
            )
        except Exception as error:
            cleanup_errors.append(error)
            cleanup_timed_out = cleanup_timed_out or _is_timeout_error(error)
        if set_socket_timeout is not None and previous_socket_timeout is not None:
            try:
                set_socket_timeout(float(previous_socket_timeout))
            except Exception as error:
                cleanup_errors.append(error)
        if cleanup_errors and primary_error is None:
            if cleanup_timed_out and all(_is_timeout_error(e) for e in cleanup_errors):
                # The socket is mid-read on a half-torn-down CDC session; drop the
                # transport so the next operation reconnects instead of resuming it,
                # keeping the connection slot (this is not a capacity problem).
                reset_transport = getattr(self, "reset_transport", None)
                if callable(reset_transport):
                    reset_transport()
                # 41: Informix CDC validation succeeded but session teardown timed out; treating as
                # non-fatal and reconnecting. Raise cdc.read.timeout.seconds or reduce concurrent
                # CDC sessions if this recurs.
                logging.getLogger(__name__).warning(
                    _m(41),
                    exc_info=cleanup_errors[0],
                )
                return
            # 42: Initial CDC validation cleanup failed
            raise InformixError(_m(42)) from cleanup_errors[0]
        if cleanup_errors and primary_error is not None:
            for error in cleanup_errors:
                add_informix_exception_note(
                    primary_error,
                    f"Initial Informix CDC validation cleanup also failed: {error}",
                )

    @_serialized_sqli_operation
    def snapshot_page(
        self,
        identity,
        columns,
        primary_keys,
        after,
        limit,
        max_bytes=None,
        skip=0,
        chunk_exprs=None,
        snapshot_filter=None,
        key_descending=None,
    ):
        self._ensure_connected()
        database, owner, name = _split_identity(identity)
        for identifier in (database, owner, name, *columns, *primary_keys):
            if not _IDENTIFIER.fullmatch(identifier):
                # 43: Unsafe snapshot identifier {!r}
                raise InformixError(_m(43, identifier))
        if int(skip) < 0:
            # 44: Snapshot SKIP offset cannot be negative
            raise InformixError(_m(44))
        # chunk_exprs maps a primary-key column to an order-preserving SQL text
        # expression used for keyset comparison and ordering (see
        # datetime_order_preserving_cast). The rendered value is projected under
        # a "__chunk_<key>" alias so the caller can track the cursor as a string.
        chunk_exprs = dict(chunk_exprs or {})
        for key in chunk_exprs:
            if key not in primary_keys:
                # 45: Chunk expression names unknown key {!r}
                raise InformixError(_m(45, key))
        # Page in the key index's own column directions when the key is mixed
        # (some column DESC): then ORDER BY matches the index and a forward scan
        # serves it without a sort. A chunked (DATETIME) key keeps the default
        # ascending order -- its order-preserving cast has no direction-aware index
        # to match -- and an all-ascending key is unaffected.
        descending = list(key_descending or [])
        direction_aware = any(descending) and not chunk_exprs

        def is_descending(index: int) -> bool:
            return direction_aware and index < len(descending) and descending[index]

        def order_term(key: str) -> str:
            # Names are validated, but one with "+" or "." must be sent delimited.
            return chunk_exprs.get(key) or _sql_identifier(key)

        def order_clause(index: int, key: str) -> str:
            return f"{order_term(key)} DESC" if is_descending(index) else order_term(key)

        alias_names = [f"__chunk_{key}" for key in primary_keys if key in chunk_exprs]
        projection = [_sql_identifier(column) for column in columns] + [
            f"{chunk_exprs[key]} AS {_sql_identifier(f'__chunk_{key}')}"
            for key in primary_keys
            if key in chunk_exprs
        ]
        window = f"SKIP {int(skip)} " if skip else ""
        # {+FIRST_ROWS(n)} asks the optimizer to stream the page in key order from
        # the index rather than sort the table: the keyset predicate below is the
        # OR-form `(k1 > ?) OR (k1 = ? AND k2 > ?)`, which optimizers often fail to
        # recognize as an index range start, and a composite `ORDER BY k1, k2` then
        # tips into a full scan + top-sort on a large table -- observed timing out
        # per page even under the extended snapshot budget. It is a `{+ }` comment,
        # so a server with external directives disabled ignores it rather than
        # erroring; UPDATE STATISTICS on the source is the complementary fix that
        # steers the cost model to the same index-ordered plan on its own.
        sql = (
            f"SELECT {{+FIRST_ROWS({int(limit)})}} {window}FIRST {int(limit)} "
            f"{','.join(projection)} "
            f"FROM {database}:{_sql_identifier(owner)}.{_sql_identifier(name)}"
        )
        parameters: list[Any] = []
        predicates = [f"({snapshot_filter})"] if snapshot_filter else []
        if after is not None:
            validate_snapshot_arity(after, primary_keys)
            bound_after = list(after)
            if any(isinstance(value, str) for value in after):
                datetimes = self._datetime_qualifiers(owner, name)
                for index, key in enumerate(primary_keys):
                    # DATETIME keys chunked by expression compare as strings, so
                    # they must not be rewritten into a native DATETIME literal.
                    if (
                        key not in chunk_exprs
                        and key in datetimes
                        and isinstance(bound_after[index], str)
                    ):
                        bound_after[index] = InformixDatetimeLiteral(
                            bound_after[index], datetimes[key]
                        )
            # Guarded leading-column seek bound. The OR-form keyset below is
            # frequently not recognized by the optimizer as an index range start,
            # so the scan begins at the index head and re-reads then discards the
            # whole already-copied prefix every page -- cost grows with the cursor
            # and a large table eventually times a page out (tw305). This redundant
            # bound gives the optimizer a concrete value to seek to, and unlike the
            # {+FIRST_ROWS} directive it is honored where external directives are
            # disabled. It is added as a separate conjunct and does not touch the
            # ORDER BY or the OR-form, so the index-direction (ASC/DESC) ordered
            # iteration is unchanged; it only reuses is_descending(0) to pick the
            # matching comparator (>= for ASC, <= for DESC).
            #
            # It is result-preserving only under guards, so it is omitted otherwise
            # rather than risk silently dropping rows:
            #   * leading key must be a plain indexed column, not an order-preserving
            #     cast (chunk_exprs): no index serves the cast, and its ordering can
            #     diverge from the column's, so the bound would neither seek nor stay
            #     provably redundant;
            #   * the leading cursor value must be non-NULL: `k1 >= NULL` is UNKNOWN
            #     for every row and would return an empty page (a nullable leading
            #     column under allow.nullable.index can resume from NULL). Rows whose
            #     leading value IS NULL are already excluded by the OR-form itself
            #     (NULL > ? / NULL < ? are UNKNOWN), so the bound removes exactly the
            #     same rows the OR-form does -- it never drops a row the OR-form keeps.
            if primary_keys and primary_keys[0] not in chunk_exprs and bound_after[0] is not None:
                seek_comparison = "<=" if is_descending(0) else ">="
                predicates.append(f"{order_term(primary_keys[0])} {seek_comparison} ?")
                parameters.append(bound_after[0])
            clauses = []
            for index, key in enumerate(primary_keys):
                prefix = " AND ".join(
                    f"{order_term(previous)} = ?" for previous in primary_keys[:index]
                )
                # "Next in scan order" is a larger value for an ASC column and a
                # smaller one for a DESC column, so the keyset comparison flips to
                # match the index direction.
                comparison = "<" if is_descending(index) else ">"
                clauses.append(
                    f"({prefix + ' AND ' if prefix else ''}{order_term(key)} {comparison} ?)"
                )
                parameters.extend(bound_after[: index + 1])
            predicates.append("(" + " OR ".join(clauses) + ")")
        if predicates:
            sql += " WHERE " + " AND ".join(predicates)
        if primary_keys:
            sql += " ORDER BY " + ",".join(
                order_clause(index, key) for index, key in enumerate(primary_keys)
            )
        rows = self.transport.execute(
            sql,
            tuple(parameters),
            max_result_bytes=(
                (max_bytes or None)
                if max_bytes is not None
                else (int(self.options.get("snapshot.max.bytes", "0")) or None)
            ),
        )
        return [
            dict(row)
            if isinstance(row, dict)
            else dict(zip(list(columns) + alias_names, row, strict=True))
            for row in rows
        ]

    def _datetime_qualifiers(self, owner: str, name: str) -> dict[str, int]:
        # Docstring: The table's DATETIME columns and their qualifiers, described once per bridge.
        #
        # A keyset page needs them to bind a string cursor value as a DATETIME literal.
        # Describing the table on every page of a CHAR-keyed table cost catalog queries
        # inside each page's transaction. The connector pages with key metadata it read
        # when the snapshot began, so caching these adds no staleness of its own.

        cache = getattr(self, "_datetime_qualifier_cache", None)
        if cache is None:
            cache = self._datetime_qualifier_cache = {}
        if (owner, name) not in cache:
            table = self._describe_table(owner, name)
            cache[(owner, name)] = {
                str(column["name"]): int(column["length"])
                for column in table["columns"]
                if column["type_name"] == "DATETIME"
            }
        return cache[(owner, name)]

    @contextlib.contextmanager
    def _repeatable_read_transaction(self, isolation: str = "REPEATABLE READ"):
        # Docstring: Run a snapshot transaction at ``isolation`` with the snapshot socket timeout.
        #
        # Yields ``execute_command``. Commits on success and rolls back on any
        # error, preserving the primary error if rollback also fails. Isolates
        # the ANSI/non-ANSI transaction handling shared by the blocking
        # consistent snapshot and per-chunk incremental snapshot reads.
        #
        # ``isolation`` is the SQL clause after ``SET ISOLATION TO`` and must be one
        # of the fixed clauses in ``_SNAPSHOT_ISOLATION_SQL`` -- it is interpolated
        # into a statement, so it is guarded here against anything else even though
        # the connector already maps it from a validated token.

        if isolation not in _SNAPSHOT_ISOLATION_SQL.values():
            # 46: Unsupported snapshot isolation {!r}
            raise InformixError(_m(46, isolation))
        execute_command = getattr(self.transport, "execute_command", self.transport.execute)
        # A database's mode never changes, so a non-ANSI one is probed once. An ANSI one
        # is probed every time: the probe opens the implicit transaction the COMMIT
        # WORK below ends.
        is_ansi = getattr(self, "_is_ansi_database", None)
        if is_ansi is not False:
            ansi_rows = self.transport.execute(
                "SELECT is_ansi FROM sysmaster:sysdatabases WHERE name = ?",
                (self.config["database"],),
            )
            if len(ansi_rows) != 1:
                # 47: Could not determine transaction mode for database {!r}
                raise InformixError(_m(47, self.config["database"]))
            is_ansi = self._is_ansi_database = bool(int(_field(ansi_rows[0], "is_ansi", 0)))
        if is_ansi:
            # The catalog SELECT starts an implicit transaction in an ANSI
            # database. End it before establishing the snapshot isolation.
            execute_command("COMMIT WORK")
        execute_command(f"SET ISOLATION TO {isolation}")
        if not is_ansi:
            execute_command("BEGIN WORK")
        set_socket_timeout = getattr(self.transport, "set_socket_timeout", None)
        previous_socket_timeout = getattr(self.transport, "socket_timeout", None)
        if set_socket_timeout is not None:
            set_socket_timeout(
                max(
                    float(previous_socket_timeout or 30),
                    float(
                        self.options.get(
                            "snapshot.read.timeout.seconds",
                            str(_DEFAULT_SNAPSHOT_READ_TIMEOUT_SECONDS),
                        )
                    ),
                )
            )
        try:
            yield execute_command
            execute_command("COMMIT WORK")
        except BaseException as primary_error:
            try:
                execute_command("ROLLBACK WORK")
            except Exception as cleanup_error:
                add_informix_exception_note(
                    primary_error,
                    f"Informix snapshot rollback also failed: {cleanup_error}",
                )
            raise
        finally:
            if set_socket_timeout is not None and previous_socket_timeout is not None:
                try:
                    set_socket_timeout(float(previous_socket_timeout))
                except Exception:
                    # 48: Failed to restore Informix snapshot socket timeout
                    logging.getLogger(__name__).warning(
                        _m(48),
                        exc_info=True,
                    )

    @_serialized_sqli_operation
    def snapshot_chunk(
        self,
        identity,
        columns,
        primary_keys,
        after,
        limit,
        max_bytes=None,
        chunk_exprs=None,
        snapshot_filter=None,
        key_descending=None,
    ):
        # Docstring: Read one PK-ordered chunk in its own repeatable-read transaction.
        #
        # Returns ``(chunk_lsn, rows)`` where ``chunk_lsn`` is the source LSN
        # captured immediately before the chunk SELECT. The chunk is read at
        # REPEATABLE READ so its values are consistent as-of ``chunk_lsn``; the
        # transaction spans a single page, so no long-lived read view is held.
        # ``chunk_exprs`` optionally maps primary-key columns to order-preserving
        # SQL text expressions for keyset comparison (e.g. DATETIME-as-string).
        # ``key_descending`` optionally carries the per-column key index direction
        # so a mixed-direction key pages in the index's own order.

        self._ensure_connected()
        with self._repeatable_read_transaction():
            # boundary_lsn, not current_lsn: the stamp must not exceed the true log
            # position, or a change committing right after the sample (but before
            # this SELECT) sequences below a row that predates it.
            chunk_lsn = self.boundary_lsn()
            rows = self.snapshot_page(
                identity,
                columns,
                primary_keys,
                after,
                limit,
                max_bytes,
                chunk_exprs=chunk_exprs,
                snapshot_filter=snapshot_filter,
                key_descending=key_descending,
            )
            return chunk_lsn, rows

    @_serialized_sqli_operation
    def max_primary_key(
        self, identity, primary_keys, chunk_exprs=None, snapshot_filter=None, key_descending=None
    ):
        # Docstring: Return the largest primary-key tuple, or ``None`` for an empty table.
        #
        # "Largest" is the last tuple in the key's paging order. For a plain-column
        # key that order follows the index's per-column direction (see
        # ``key_descending``); for an all-ascending key it is ordinary descending.
        #
        # When ``chunk_exprs`` maps a key to an order-preserving SQL expression,
        # that key is ordered and returned as its rendered string form so the
        # upper bound matches the values chunk pages compare against.
        #
        # A plain-column key resolves the maximum tuple one column at a time (see
        # ``_max_key_stepwise``) so every read is index-servable regardless of the
        # key index's per-column direction. A chunked (DATETIME) key keeps the
        # single composite read: its equality prefix would have to match an
        # order-preserving cast expression that no index serves, so a stepwise scan
        # would not avoid a sort there.

        self._ensure_connected()
        database, owner, name = _split_identity(identity)
        for identifier in (database, owner, name, *primary_keys):
            if not _IDENTIFIER.fullmatch(identifier):
                # 49: Unsafe max-key identifier {!r}
                raise InformixError(_m(49, identifier))
        chunk_exprs = dict(chunk_exprs or {})
        table_ref = f"{database}:{_sql_identifier(owner)}.{_sql_identifier(name)}"
        if primary_keys and not chunk_exprs:
            return self._max_key_stepwise(
                table_ref, list(primary_keys), snapshot_filter, list(key_descending or [])
            )
        select_terms = [
            f"{chunk_exprs[key]} AS {_sql_identifier(f'__chunk_{key}')}"
            if key in chunk_exprs
            else _sql_identifier(key)
            for key in primary_keys
        ]
        result_names = [f"__chunk_{key}" if key in chunk_exprs else key for key in primary_keys]
        order = ",".join(
            f"{chunk_exprs.get(key) or _sql_identifier(key)} DESC" for key in primary_keys
        )
        # {+FIRST_ROWS(1)} steers the optimizer to minimize time-to-first-row so a
        # DESC ordering is served by an index read (row 1 returns immediately)
        # rather than a full scan + top-sort. It is a `{+ }` comment, so a server
        # with external directives disabled ignores it rather than erroring. It
        # cannot help when a key column is chunked to an order-preserving
        # expression (no index serves that ordering); that path stays sort-bound.
        sql = f"SELECT {{+FIRST_ROWS(1)}} FIRST 1 {','.join(select_terms)} FROM {table_ref}"
        if snapshot_filter:
            sql += f" WHERE ({snapshot_filter})"
        sql += f" ORDER BY {order}"
        rows = self._execute_with_snapshot_read_timeout(sql, ())
        if not rows:
            return None
        row = rows[0]
        if isinstance(row, dict):
            return [row[name] for name in result_names]
        return list(row)

    def _max_key_stepwise(
        self,
        table_ref: str,
        primary_keys: list[str],
        snapshot_filter: str | None,
        descending: list[bool],
    ) -> list[Any] | None:
        # Docstring: Resolve the maximum key tuple one column at a time.
        #
        # Each step reads ``FIRST 1`` of one key column under an equality filter
        # that pins the already-resolved higher-order columns, ordered to return
        # that column's *last* value in the key's paging order: for an ASC column
        # that is its max (``ORDER BY col DESC``), for a DESC column its min
        # (``ORDER BY col ASC``) -- so the tuple is the last row a forward index
        # scan in the key's own order would reach. A single-column order within an
        # equality prefix is served by a directional sub-range scan of the key
        # index -- no whole-table sort -- and it holds for any mix of ASC/DESC
        # column directions, where a composite ``ORDER BY`` matches neither scan
        # direction and forces a sort. Prior columns are pinned with ``?``
        # parameters, exactly as the snapshot keyset does, so no key value is
        # rendered back into SQL text.
        #
        # All steps run inside one REPEATABLE READ view so the columns resolve
        # against a single point in time -- identical to what the equivalent
        # one-statement composite read would return -- and that view also carries
        # the snapshot read-timeout budget instead of the bare transport default.

        with self._repeatable_read_transaction():
            resolved: list[Any] = []
            for index, key in enumerate(primary_keys):
                predicates = [f"({snapshot_filter})"] if snapshot_filter else []
                params: list[Any] = []
                for previous in range(index):
                    predicates.append(f"{_sql_identifier(primary_keys[previous])} = ?")
                    params.append(resolved[previous])
                where = f" WHERE {' AND '.join(predicates)}" if predicates else ""
                # The last value in paging order is the min of a DESC column, the
                # max of an ASC one; fetch it by ordering opposite the index.
                fetch_order = "ASC" if index < len(descending) and descending[index] else "DESC"
                term = _sql_identifier(key)
                sql = (
                    f"SELECT {{+FIRST_ROWS(1)}} FIRST 1 {term} "
                    f"FROM {table_ref}{where} ORDER BY {term} {fetch_order}"
                )
                rows = self.transport.execute(sql, tuple(params))
                if not rows:
                    # No row at the first column means the table (or filtered set)
                    # is empty. A later column cannot come up empty under the
                    # frozen read view once a higher column resolved, so an empty
                    # result at any step is the empty-table answer.
                    return None
                row = rows[0]
                resolved.append(row[key] if isinstance(row, dict) else row[0])
            return resolved

    def _execute_with_snapshot_read_timeout(self, sql: str, params: tuple) -> list:
        # Docstring: Run one read with the snapshot read-timeout budget, then restore it.
        #
        # The incremental-snapshot key bound can run a full scan + top-sort on a
        # large table, so it must not be constrained by the bare ~30s transport
        # default or a slow seed times out and crash-loops the stream on restart.

        set_socket_timeout = getattr(self.transport, "set_socket_timeout", None)
        previous_socket_timeout = getattr(self.transport, "socket_timeout", None)
        if set_socket_timeout is not None:
            set_socket_timeout(
                max(
                    float(previous_socket_timeout or 30),
                    float(
                        self.options.get(
                            "snapshot.read.timeout.seconds",
                            str(_DEFAULT_SNAPSHOT_READ_TIMEOUT_SECONDS),
                        )
                    ),
                )
            )
        try:
            return self.transport.execute(sql, params)
        finally:
            if set_socket_timeout is not None and previous_socket_timeout is not None:
                try:
                    set_socket_timeout(float(previous_socket_timeout))
                except Exception:
                    # 50: Failed to restore Informix max-key socket timeout
                    logging.getLogger(__name__).warning(
                        _m(50),
                        exc_info=True,
                    )

    @_serialized_sqli_operation
    def consistent_snapshot(
        self,
        identity,
        columns,
        primary_keys,
        page_size,
        max_rows,
        max_bytes,
        datetime_primary_key=False,
        page_consumer=None,
        snapshot_filter=None,
        isolation="REPEATABLE READ",
    ):
        # Docstring: Read one bounded point-in-time snapshot at ``isolation``.
        #
        # ``isolation`` defaults to REPEATABLE READ, which freezes the scanned rows
        # so the snapshot is exactly the committed state as-of ``snapshot_lsn``. A
        # non-locking level (e.g. COMMITTED READ LAST COMMITTED) avoids locking the
        # table but no longer freezes it, so rows committed during the scan may be
        # captured here and replayed by CDC -- harmless for a keyed table (the sink
        # de-duplicates), a duplicate-row risk for a key-less one.

        self._ensure_connected()

        # Informix SQLI does not expose parameter binding, so keyset pagination
        # must render continuation values as SQL literals. Some valid partial
        # DATETIME values are rejected when parsed back by Informix (-1263), and a
        # float key has no exact literal. Within this snapshot transaction,
        # positional pagination is stable and avoids converting such keys back into SQL.
        positional_pagination = bool(datetime_primary_key)

        self._ensure_connected()
        with self._repeatable_read_transaction(isolation):
            # boundary_lsn, not current_lsn: see snapshot_chunk.
            snapshot_lsn = self.boundary_lsn()
            rows: list[dict[str, Any]] = []
            retained_bytes = _deep_size(rows) if max_bytes else 0
            total_rows = 0
            page_index = 0

            if not primary_keys:
                database, owner, name = _split_identity(identity)
                for identifier in (database, owner, name, *columns):
                    if not _IDENTIFIER.fullmatch(identifier):
                        # 43: Unsafe snapshot identifier {!r}
                        raise InformixError(_m(43, identifier))
                execute_pages = getattr(self.transport, "execute_pages", None)
                if not callable(execute_pages):
                    # 51: Configured Informix SQLI transport does not implement execute_pages()
                    raise InformixError(_m(51))

                def consume(page: list[dict[str, Any]]) -> None:
                    nonlocal retained_bytes, total_rows, page_index
                    if max_rows and total_rows + len(page) > max_rows:
                        # 52: Initial snapshot exceeds snapshot.max.rows={}
                        raise InformixError(_m(52, max_rows))
                    if max_bytes:
                        retained_bytes += _deep_size(page)
                        if retained_bytes > max_bytes:
                            # 53: Initial snapshot exceeds snapshot.max.bytes={}
                            raise InformixError(_m(53, max_bytes))
                    if page_consumer is None:
                        rows.extend(page)
                    else:
                        page_consumer(snapshot_lsn, page_index, page)
                    total_rows += len(page)
                    page_index += 1

                execute_pages(
                    f"SELECT {','.join(_sql_identifier(column) for column in columns)} "
                    f"FROM {database}:{_sql_identifier(owner)}.{_sql_identifier(name)}"
                    + (f" WHERE ({snapshot_filter})" if snapshot_filter else ""),
                    (),
                    page_size,
                    consume,
                )
                return snapshot_lsn, rows

            after = None
            skip = 0
            while True:
                remaining_rows = max_rows - total_rows if max_rows else page_size
                page_capacity = min(page_size, remaining_rows)
                remaining_bytes = max_bytes - retained_bytes if max_bytes else None
                if remaining_bytes is not None and remaining_bytes <= 0:
                    # 53: Initial snapshot exceeds snapshot.max.bytes={}
                    raise InformixError(_m(53, max_bytes))
                page = self.snapshot_page(
                    identity,
                    columns,
                    primary_keys,
                    after,
                    page_capacity + 1,
                    remaining_bytes,
                    skip=skip if positional_pagination else 0,
                    snapshot_filter=snapshot_filter,
                )
                has_more = len(page) > page_capacity
                if has_more and max_rows and remaining_rows == 0:
                    # 52: Initial snapshot exceeds snapshot.max.rows={}
                    raise InformixError(_m(52, max_rows))
                accepted = page[:page_capacity]
                if max_bytes:
                    retained_bytes += _deep_size(accepted)
                if max_bytes and retained_bytes > max_bytes:
                    # 53: Initial snapshot exceeds snapshot.max.bytes={}
                    raise InformixError(_m(53, max_bytes))
                if page_consumer is None:
                    rows.extend(accepted)
                else:
                    page_consumer(snapshot_lsn, page_index, accepted)
                total_rows += len(accepted)
                if not has_more:
                    break
                if positional_pagination:
                    skip += len(accepted)
                else:
                    after = [accepted[-1][key] for key in primary_keys]
                page_index += 1
            return snapshot_lsn, rows

    @_serialized_sqli_operation
    def read_changes(self, tables, start_lsn, timeout_seconds, max_records):
        self._ensure_connected()
        set_socket_timeout = getattr(self.transport, "set_socket_timeout", None)
        previous_socket_timeout = getattr(self.transport, "socket_timeout", None)
        server_row = self.transport.execute(
            "SELECT env_value FROM sysmaster:sysenv WHERE env_name='INFORMIXSERVER'"
        )[0]
        server = str(_field(server_row, "env_value", 0))
        session_row = self.transport.execute(
            f"EXECUTE FUNCTION {cdc_routine('cdc_opensess')}(?, 0, ?, ?, 1, 1)",
            (server, timeout_seconds, max_records),
        )[0]
        session = int(_field(session_row, "session_id", 0))
        if session < 0:
            # 40: cdc_opensess failed with Informix error {}
            raise InformixError(_m(40, session))
        labels: dict[int, tuple[ColumnDescriptor, ...]] = {}
        captures = []
        try:
            if set_socket_timeout is not None:
                set_socket_timeout(max(float(previous_socket_timeout or 30), timeout_seconds + 5.0))
            for label, capture in enumerate(tables, 1):
                native = capture["identity"]
                columns = tuple(capture["columns"])
                _expect_zero(
                    self.transport.execute(
                        f"EXECUTE FUNCTION {cdc_routine('cdc_set_fullrowlogging')}(?, 1)",
                        (native,),
                    ),
                    "cdc_set_fullrowlogging",
                )
                _expect_zero(
                    self.transport.execute(
                        f"EXECUTE FUNCTION {cdc_routine('cdc_startcapture')}(?, 0, ?, ?, ?)",
                        (session, native, ",".join(columns), label),
                    ),
                    "cdc_startcapture",
                )
                captures.append(native)
                labels[label] = tuple(_column_descriptor(c) for c in capture["descriptors"])
            _expect_zero(
                self.transport.execute(
                    f"EXECUTE FUNCTION {cdc_routine('cdc_activatesess')}(?, ?)",
                    (session, start_lsn),
                ),
                "cdc_activatesess",
            )
            parser = CdcFrameParser(int(self.options.get("cdc.max.frame.bytes", str(16 << 20))))
            # Set by the connector for one poll (_read_changes_with_reconnect), else None.
            spill = getattr(self, "cdc_spill", None)
            records = []
            budget_records = 0
            open_transactions = OpenTransactionRecords()
            max_transaction_records = int(self.options.get("cdc.max.transaction.records", "100000"))
            max_poll_records = int(self.options.get("cdc.max.poll.records", "200000"))
            max_poll_bytes = int(self.options.get("cdc.max.poll.bytes", "0"))
            requested = int(self.options.get("cdc.read.bytes", "32000"))
            empty_reads = 0
            timed_out = False
            retained_bytes = 0
            # What each open transaction's changes add to retained_bytes, which they leave
            # when it spills.
            held_bytes: dict[int, int] = {}
            truncated = False
            completed_transactions = 0
            metadata_labels: set[int] = set()
            # Every captured table's catalog entry, read in one batch when the first
            # metadata record arrives. Full-row logging is on for each of them by then, so
            # Informix rejects an ALTER TABLE, and the batch sees what each table's own
            # metadata record describes, as reading each table at its record did.
            capture_catalog: dict[tuple[str, str], dict[str, Any]] | None = None

            def _spill_open(tx_id: int) -> None:
                # Its changes, and any DISCARD among them, go to the spill in order; its
                # BEGIN stays here for the transaction buffer, with a SPILLING record per
                # table so that it still shows which tables it holds open. Informix reuses
                # transaction IDs, so only what follows its latest BEGIN is its own: an
                # earlier transaction with this ID stays as it was.
                nonlocal retained_bytes
                begin = max(
                    (
                        index
                        for index, r in enumerate(records)
                        if r.get("tx_id") == tx_id and r["op"] == "BEGIN"
                    ),
                    default=-1,
                )
                later = records[begin + 1 :]
                records[begin + 1 :] = [r for r in later if r.get("tx_id") != tx_id]
                own = [r for r in later if r.get("tx_id") == tx_id]
                begin_lsn = int((records[begin] if begin >= 0 else own[0])["lsn"])
                for table in spill.start(tx_id, begin_lsn, own):
                    records.append(
                        {"op": "SPILLING", "tx_id": tx_id, "lsn": begin_lsn, "table": table}
                    )
                open_transactions.release(tx_id)
                retained_bytes -= held_bytes.pop(tx_id, 0)

            def _stop_at_poll_bound(bound: str) -> None:
                # The poll bounds cap what one poll may retain, not how much the
                # stream may contain. An interleaved long-running transaction
                # keeps this loop reading far past cdc.max.records, so under a
                # bulk load the bound is reached routinely rather than
                # exceptionally. End the poll and return the transactions that
                # already completed: they advance the checkpoint, and the next
                # poll resumes from the oldest still-open BEGIN.
                if not completed_transactions:
                    # Nothing completed, so there is no progress to checkpoint.
                    # Returning empty would leave the flow retrying the same
                    # bound forever, so surface the stall instead.
                    # 54: A CDC poll exceeded {} before any transaction completed
                    raise InformixError(_m(54, bound))
                # 55: Informix CDC poll reached {} after {} completed transactions; ending the poll
                # early and resuming from the oldest open transaction
                logging.getLogger(__name__).warning(
                    _m(55, bound, completed_transactions),
                )

            # cdc.max.records is a soft boundary: once crossed, finish every
            # transaction already observed so a transaction larger than the
            # native boundary can make progress. An idle open transaction is
            # still bounded by Informix's TIMEOUT control frame.
            while (
                (budget_records < max_records or open_transactions)
                and empty_reads < 1
                and not timed_out
                and not truncated
            ):
                chunk = self.transport.read_lodata(session, requested)
                if not chunk:
                    empty_reads += 1
                    continue
                empty_reads = 0
                for frame in parser.feed(chunk):
                    try:
                        record = decode_frame(
                            frame, labels, null_byte=getattr(self, "_null_byte", "keep")
                        )
                    except CdcProtocolError as error:
                        raise _stale_capture_label_error(frame, error, start_lsn) from error
                    if max_poll_bytes and not (
                        # A spilled transaction's changes are not retained.
                        spill is not None
                        and record["op"] in _DATA_OPS
                        and spill.holds(int(record.get("tx_id") or 0))
                    ):
                        size = len(frame) + _deep_size(record)
                        retained_bytes += size
                        if record["op"] in _DATA_OPS:
                            held = int(record.get("tx_id") or 0)
                            held_bytes[held] = held_bytes.get(held, 0) + size
                    if max_poll_bytes and retained_bytes > max_poll_bytes:
                        _stop_at_poll_bound(f"cdc.max.poll.bytes={max_poll_bytes}")
                        truncated = True
                        break
                    if record["op"] == "TIMEOUT":
                        # Informix represents an idle CDC timeout as a real,
                        # non-empty protocol frame. Treat it as the terminal
                        # condition for this finite poll instead of waiting for
                        # max_records timeout frames.
                        timed_out = True
                    label = record.get("label", record.get("capture_label"))
                    if record["op"] == "METADATA" and label in labels:
                        if label in metadata_labels:
                            # 56: Informix emitted a second CDC metadata layout for capture label
                            # {}; run a full refresh before continuing
                            raise InformixError(_m(56, label))
                        descriptors = {column.name: column for column in labels[label]}
                        encoding = next(iter(descriptors.values())).encoding
                        names = metadata_column_names(record["metadata"], encoding)
                        if set(names) != set(descriptors):
                            # 57: CDC metadata for capture label {} does not match the requested
                            # columns
                            raise InformixError(_m(57, label))
                        if capture_catalog is None:
                            capture_catalog = self._describe_tables(
                                {self._capture_table(capture)[1:] for capture in tables}
                            )
                        self._assert_capture_layout(tables[label - 1], encoding, capture_catalog)
                        labels[label] = tuple(descriptors[name] for name in names)
                        metadata_labels.add(label)
                    if label and 1 <= label <= len(tables):
                        record["table"] = tables[label - 1]["logical_identity"]
                    if len(records) >= max_poll_records:
                        _stop_at_poll_bound(f"cdc.max.poll.records={max_poll_records}")
                        truncated = True
                        break
                    # A transaction that outgrew cdc.spill.records keeps its changes on
                    # the staging Volume (see _CdcSpill), not in this poll's records.
                    tx_id = int(record.get("tx_id") or 0)
                    spilling = spill is not None and spill.holds(tx_id)
                    if spilling and record["op"] in _DATA_OPS:
                        if spill.add(record):
                            records.append(
                                {
                                    "op": "SPILLING",
                                    "tx_id": tx_id,
                                    "lsn": int(record["lsn"]),
                                    "table": record.get("table"),
                                }
                            )
                    else:
                        records.append(record)
                    if record["op"] not in {"METADATA", "TIMEOUT"}:
                        budget_records += 1
                    if record["op"] == "COMMIT":
                        completed_transactions += 1
                    if record["op"] == "BEGIN":
                        open_transactions.begin(tx_id)
                        held_bytes.pop(tx_id, None)
                    elif record["op"] in _DATA_OPS and not spilling:
                        open_transactions.append(tx_id, int(record["lsn"]))
                        if spill is not None and open_transactions.held(tx_id) > spill.threshold:
                            _spill_open(tx_id)
                    elif record["op"] == "DISCARD":
                        open_transactions.discard(tx_id, int(record["lsn"]))
                        if spilling:
                            spill.discard(tx_id, int(record["lsn"]))
                    elif record["op"] in {"COMMIT", "ROLLBACK"}:
                        open_transactions.finish(tx_id)
                        held_bytes.pop(tx_id, None)
                        if spilling and record["op"] == "ROLLBACK":
                            spill.drop(tx_id)
                        elif spilling:
                            # Ahead of the COMMIT, so the transaction carries its pages.
                            records[-1:-1] = spill.finish(tx_id, int(record["lsn"]))
                    while (
                        spill is not None
                        and open_transactions.buffered > max_transaction_records
                        and open_transactions.held(open_transactions.largest())
                    ):
                        # Interleaved transactions, none past cdc.spill.records alone, hold
                        # more than the bound between them: spill the largest.
                        _spill_open(open_transactions.largest())
                    if open_transactions.buffered > max_transaction_records:
                        # 58: An open CDC transaction exceeded cdc.max.transaction.records={}
                        raise InformixError(_m(58, max_transaction_records))
                    if timed_out:
                        # Ignore anything following the terminal timeout in this
                        # session. The checkpoint remains at the last complete
                        # transaction, so a later poll safely replays it.
                        break
            # A poll that reached cdc.max.records with every transaction complete stops on
            # purpose, so its last cdc.read.bytes read can end inside the next record. Like a
            # truncated poll, it leaves that partial frame for the next poll, which
            # replays from the last complete transaction.
            stopped_at_budget = budget_records >= max_records and not open_transactions
            if parser.buffered_bytes and not (timed_out or truncated or stopped_at_budget):
                # 59: CDC read ended with an incomplete native frame
                raise InformixError(_m(59))
            return records
        finally:
            cleanup_errors = []
            lease_lost = getattr(self, "_connection_lease_lost", None)
            if lease_lost is None or not lease_lost.is_set():
                for native in captures:
                    try:
                        _expect_zero(
                            self.transport.execute(
                                f"EXECUTE FUNCTION {cdc_routine('cdc_endcapture')}(?, 0, ?)",
                                (session, native),
                            ),
                            "cdc_endcapture",
                        )
                    except Exception as error:  # preserve an active CDC failure
                        cleanup_errors.append(error)
                try:
                    _expect_zero(
                        self.transport.execute(
                            f"EXECUTE FUNCTION {cdc_routine('cdc_closesess')}(?)", (session,)
                        ),
                        "cdc_closesess",
                    )
                except Exception as error:  # preserve an active CDC failure
                    cleanup_errors.append(error)
            # Put the timeout back after a lost lease too: the client keeps it for every
            # later connection, so a skipped restore made it the new default.
            if set_socket_timeout is not None and previous_socket_timeout is not None:
                try:
                    set_socket_timeout(float(previous_socket_timeout))
                except Exception as error:
                    cleanup_errors.append(error)
            active_error = sys.exc_info()[1]
            if cleanup_errors:
                if active_error is None:
                    # 60: Informix CDC session cleanup failed
                    raise InformixError(_m(60)) from cleanup_errors[0]
                for error in cleanup_errors:
                    add_informix_exception_note(
                        active_error, f"Informix CDC cleanup also failed: {error}"
                    )


_bridge_factory: Callable[[dict[str, str]], InformixBridge] = PurePythonInformixBridge


def set_bridge_factory(factory: Callable[[dict[str, str]], InformixBridge]) -> None:
    # Docstring: Set the process-wide bridge factory (primarily for deterministic tests).

    global _bridge_factory
    _bridge_factory = factory


def _bridge_config(options: dict[str, str]) -> dict[str, Any]:
    required = ("hostname", "database", "user", "password", "server")
    missing = [name for name in required if not options.get(name)]
    if missing:
        # 61: Missing required Informix option(s): {}
        raise ValueError(_m(61, (", ".join(missing))))
    return {
        "hostname": options["hostname"],
        "port": int(options.get("port", "9088")),
        "database": options["database"],
        "user": options["user"],
        "password": options["password"],
        "server": options.get("server"),
        "db_locale": (
            # Spark hands option keys to the Python Data Source lowercased (its
            # JVM CaseInsensitiveStringMap stores them that way), so a user's
            # ``DB_LOCALE`` arrives as ``db_locale``. Check the lowercased form
            # first; keep the original-case and dotted spellings as fallbacks.
            options.get("db_locale")
            or options.get("DB_LOCALE")
            or options.get("db.locale")
            or "en_US.819"
        ),
        "client_locale": (
            options.get("client_locale")
            or options.get("CLIENT_LOCALE")
            or options.get("client.locale")
            or "en_US.utf8"
        ),
        "tls": _option_bool(options, "encrypt", True),
        "ca_file": options.get("ssl.ca.file"),
        "pad_varchar": _option_bool(options, "padVarchar", False),
        "cdc_timeout": int(options.get("cdc.timeout", "5")),
        "cdc_max_records": int(options.get("cdc.max.records", str(_DEFAULT_CDC_MAX_RECORDS))),
        "stop_logging_on_close": False,
    }


def _option_bool(options: dict[str, str], name: str, default: bool) -> bool:
    value = options.get(name)
    if value is None:
        return default
    normalized = value.strip().lower()
    if normalized in {"1", "true", "yes"}:
        return True
    if normalized in {"0", "false", "no"}:
        return False
    # 62: Option '{}' must be one of: 1, true, yes, 0, false, no
    raise ValueError(_m(62, name))


def _snapshot_scan_value(raw: object) -> str:
    # Docstring: Normalise and validate a ``snapshot.scan`` value; see ``_SNAPSHOT_SCAN_OPTION``.
    #
    # Shared by construction (connection scope), registration (table scope) and the
    # snapshot read itself, so a malformed value fails before any read.

    value = str(raw).strip().lower()
    if value not in _SNAPSHOT_SCANS:
        # 63: Option '{}' must be one of: {}, {}
        raise ValueError(
            _m(63, _SNAPSHOT_SCAN_OPTION, _SNAPSHOT_SCAN_KEYSET, _SNAPSHOT_SCAN_CURSOR)
        )
    return value


def _validate_nonneg_float_option(options: dict[str, str], name: str) -> None:
    # Docstring: Raise if ``name`` is present and not a number >= 0. Absent means the default.

    if name not in options:
        return
    try:
        if float(options[name]) < 0:
            raise ValueError
    except (TypeError, ValueError) as error:
        # 64: Option '{}' must be a number >= 0
        raise ValueError(_m(64, name)) from error


# How a decoded string containing an embedded NUL (\x00) is sanitized. A NUL is genuine
# content -- the decoders already trim real (space) padding -- but many downstream
# consumers cannot store it, so the default converts such a value to NULL (honest and
# detectable) rather than silently stripping it. "empty" strips the NUL characters;
# "keep" passes them through unchanged.
_NULL_BYTE_OPTION = "string.null.byte"
_NULL_BYTE_MODES = {"null", "empty", "keep"}
_DEFAULT_NULL_BYTE_MODE = "null"


def _null_byte_mode(options: dict[str, str]) -> str:
    # Docstring: Resolve the ``string.null.byte`` option to ``null`` (default), ``empty``, or
    # ``keep``.

    raw = options.get(_NULL_BYTE_OPTION)
    if raw is None:
        return _DEFAULT_NULL_BYTE_MODE
    mode = raw.strip().lower()
    if mode == "empty_string":
        mode = "empty"
    if not mode:
        return _DEFAULT_NULL_BYTE_MODE
    if mode not in _NULL_BYTE_MODES:
        # 65: Option '{}' must be one of: null, empty, keep
        raise ValueError(_m(65, _NULL_BYTE_OPTION))
    return mode


def _append_only_value(raw: str) -> str:
    # Docstring: Normalize the tri-state ``append.only.ingestion`` option.
    #
    # ``true``/``false`` force append (or not) for every capturable table; ``auto``
    # (also the default when the option is unset) applies append only to keyless
    # tables and leaves keyed tables on their normal CDC/snapshot path.

    normalized = (raw or "").strip().lower()
    if normalized in {"1", "true", "yes"}:
        return "true"
    if normalized in {"0", "false", "no"}:
        return "false"
    if normalized == "auto":
        return "auto"
    # 66: Option '{}' must be one of: true, false, auto (or 1/yes, 0/no)
    raise ValueError(_m(66, _APPEND_INGESTION_OPTION))


_PRIMARY_KEYS_OPTION = "primary.keys"
# ``primary.keys: "*"`` keys a table on every column, in catalog column order, so the whole
# row is its identity. Meant for a keyless table whose rows are unique as a whole, such as
# a junction or lookup table. It is shorthand for listing every column, except that the key
# follows the schema: an added column joins the key. For a table already streaming changes,
# the schema-transition check accepts exactly that growth -- the old key followed by the
# appended nullable columns -- so no full refresh is needed. Rows written before the ALTER
# hold NULL in the new column at the source, and the target gives them NULL when it gains
# the column, so their updates and deletes still match by the longer key. The check fails
# closed instead when an added column has a default (existing rows would carry it at the
# source but NULL in the target) or while an incremental copy is still in progress (its
# stored chunk position is laid out by the old key).
#
# A dropped column leaves the key the same way: the check accepts the old key
# minus exactly the dropped columns. Informix returns records logged before the ALTER
# without the column, and the target keeps it as an ordinary column, so changes match by
# the shorter key (probe-verified: AUTO CDC accepts a key that shrinks between updates).
# Only the first read of a new update may shrink it -- a running update still merges on
# the key it started with -- and never in the same step as a growth. Rows that differed
# only in the dropped column become one key, like exact duplicates.
#
# Nullable columns join the key like any other. On the keyed CDC path a delete carries a
# NULL key value through, and the pipeline's AUTO CDC delete flow matches it (see
# _shape_delete), so updates and deletes of a row holding NULL apply normally -- under a
# wildcard every update changes the key and deletes the old row. What a NULL can still
# break is keyset snapshot paging, which compares key values in SQL and in Python;
# snapshot.scan=cursor avoids it, and the per-page sort an all-column key usually costs.
# On the append path with snapshot.mode=cdc_only, its default, nothing pages by key, so a
# NULL there is harmless.
_PRIMARY_KEYS_WILDCARD = "*"
# ``"* except(c1, c2)"`` keys the table on every column but the ones named, which suits a
# table whose rows are unique as a whole bar a few columns that change or are too wide to
# key on (an audit timestamp, a free-text note). It follows the schema like the bare
# wildcard: a column added later joins the key unless it is named, and one dropped leaves
# it. Every name must be a column of the table, so a misspelt one fails instead of
# keeping its column in the key (see _ensure_excepted_columns_exist). EXCEPT and the
# names are matched case-insensitively (see _wildcard_key).
_PRIMARY_KEYS_WILDCARD_EXCEPT = re.compile(r"\*\s*except\s*\((?P<names>.*)\)", re.I | re.S)
# When a table has no primary-key constraint, promote a UNIQUE index to stand in as the
# primary key, so a physically key-less table becomes keyed (resumable keyset snapshots and
# CDC dedup) instead of falling back to the one-shot key-less drain. Default on. An explicit
# ``primary.keys`` option still wins over the discovered index. Set false to keep the old
# behaviour (only a real primary key makes a table keyed).
_PROMOTE_UNIQUE_INDEX_OPTION = "primary.key.from.unique.index"
# Per-table opt-in: when a table has no primary key and no all-NOT-NULL unique index, allow a
# UNIQUE index that includes nullable column(s) to stand in as the key. The operator asserts
# those columns are effectively unique for every row. A row that does hold NULL in one of
# them is still updated and deleted correctly: as for a ``primary.keys`` override, a delete
# carries the NULL through and the pipeline's delete flow matches it (see _shape_delete).
# What a NULL can still break is keyset snapshot paging, which compares key values and can
# skip the row or fail; snapshot.scan=cursor avoids that. Default false (stay key-less).
_ALLOW_NULLABLE_INDEX_OPTION = "allow.nullable.index"


class _DescendingKey:
    # Docstring: Order one key-column value descending inside a tuple comparison.
    #
    # Index-native paging over a mixed-direction key compares tuples in the
    # index's order, not Python's all-ascending default. Wrapping the values of
    # the DESC columns flips just those positions; ASC columns stay bare. A
    # wrapper is only ever compared against another wrapper at the same tuple
    # position (same column, same type), so comparing the underlying values is
    # well-defined.

    __slots__ = ("value",)

    def __init__(self, value: Any) -> None:
        self.value = value

    def __eq__(self, other: object) -> bool:
        return isinstance(other, _DescendingKey) and self.value == other.value

    def __ne__(self, other: object) -> bool:
        return not self.__eq__(other)

    def __lt__(self, other: "_DescendingKey") -> bool:
        return other.value < self.value

    def __le__(self, other: "_DescendingKey") -> bool:
        return other.value <= self.value

    def __gt__(self, other: "_DescendingKey") -> bool:
        return other.value > self.value

    def __ge__(self, other: "_DescendingKey") -> bool:
        return other.value >= self.value

    def __hash__(self) -> int:
        return hash(self.value)


def _order_key(values: Sequence[Any], descending: Sequence[bool]) -> tuple:
    # Docstring: Map a key tuple to a comparison key honoring per-column direction.
    #
    # Empty or all-ascending ``descending`` returns the tuple unchanged, so the
    # common (all-ascending lexicographic) case keeps Python's native order and is
    # unaffected. Otherwise DESC columns are wrapped so tuple comparison reproduces
    # the index's own scan order.

    if not descending or not any(descending):
        return tuple(values)
    return tuple(
        _DescendingKey(value) if is_desc else value for value, is_desc in zip(values, descending)
    )


def _select_unique_index_key(
    indexes: list[tuple[str, list[int]]],
    column_by_number: dict[int, str],
    nullable_by_name: dict[str, bool],
    allow_nullable: bool = False,
) -> list[tuple[str, bool]]:
    # Docstring: Choose a UNIQUE index to stand in for an absent primary key.
    #
    # ``indexes`` is ``(idxname, [part1..part16])`` per unique index; the parts are
    # ``syscolumns`` column numbers in key order, terminated by a ``0`` (a negative number
    # is a descending column -- still part of the key, so its magnitude names the column).
    #
    # By default only indexes whose every column is NOT NULL are eligible: a primary key must
    # be non-null for keyset pagination (``WHERE key > ?``) and CDC dedup to be sound, exactly
    # as a real primary key is, and a NULL key value would silently drop or mis-order rows.
    # ``allow_nullable`` relaxes that -- the operator asserts the columns are effectively
    # unique and non-null -- so an index with a nullable column can stand in. An index
    # referencing a column not present in the projection is skipped either way.
    #
    # Among the eligible indexes, choose the one with the fewest columns; break ties by index
    # name in ascending lexical order (deterministic and independent of catalog row order).
    # Returns the ordered key as ``(column, descending)`` pairs -- ``descending`` records the
    # per-column index direction so paging can match the index's own order -- or ``[]`` when
    # no unique index qualifies (the table stays key-less).

    candidates: list[tuple[int, str, list[tuple[str, bool]]]] = []
    for idxname, parts in indexes:
        columns: list[tuple[str, bool]] = []
        eligible = True
        for part in parts:
            number = int(part)
            if number == 0:
                break  # key columns are contiguous; the rest of the parts are padding
            name = column_by_number.get(abs(number))
            if name is None:
                eligible = False  # references a column we cannot name -> unusable
                break
            if not allow_nullable and nullable_by_name.get(name, True):
                eligible = False  # nullable column -> not a safe primary key unless allowed
                break
            columns.append((name, number < 0))  # negative part number == descending column
        if eligible and columns:
            candidates.append((len(columns), str(idxname), columns))
    if not candidates:
        return []
    return min(candidates, key=lambda candidate: (candidate[0], candidate[1]))[2]


def _parse_key_columns(raw: str, option: str = _PRIMARY_KEYS_OPTION) -> list[str]:
    # Docstring: Parse a column-list option -- a comma-separated list or a JSON array.

    text = (raw or "").strip()
    if not text:
        return []
    if text.startswith("["):
        try:
            values = json.loads(text)
        except json.JSONDecodeError as error:
            # 67: Option '{}' is not a valid JSON array: {!r}
            raise ValueError(_m(67, option, text)) from error
        items = [str(value).strip() for value in values]
    else:
        items = [item.strip() for item in text.split(",")]
    return [item for item in items if item]


def _key_override(
    table_options: dict[str, str],
) -> tuple[list[str], tuple[str, ...]] | None:
    # Docstring: The ``primary.keys`` option, parsed and checked, as (keys, excepted): the
    # column names, or ``["*"]`` for the wildcard with the names its ``except(...)`` leaves
    # out (none for a bare ``*``); None when unset.
    #
    # Parsed once per table resolve and shared by _requested_key and the override itself,
    # so a malformed value fails before any column is left out. The except form is matched
    # before the comma split, since its own list holds commas; a JSON array may hold it as
    # its one element.

    raw = table_options.get(_PRIMARY_KEYS_OPTION)
    if raw is None:
        return None
    text = str(raw).strip()
    if text.startswith("["):
        items = _parse_key_columns(text)
        text = items[0] if len(items) == 1 else text
    match = _PRIMARY_KEYS_WILDCARD_EXCEPT.fullmatch(text)
    if match:
        excepted = _parse_key_columns(match.group("names"))
        if not excepted:
            # 68: Option '{}' names no columns in '{} except(...)'
            raise ValueError(_m(68, _PRIMARY_KEYS_OPTION, _PRIMARY_KEYS_WILDCARD))
        if len(excepted) != len({name.casefold() for name in excepted}):
            # 69: Option '{}' excepts a column twice
            raise ValueError(_m(69, _PRIMARY_KEYS_OPTION))
        return [_PRIMARY_KEYS_WILDCARD], tuple(excepted)
    keys = _parse_key_columns(raw)
    if not keys:
        # 70: Option '{}' is set but lists no columns
        raise ValueError(_m(70, _PRIMARY_KEYS_OPTION))
    if _PRIMARY_KEYS_WILDCARD in keys and keys != [_PRIMARY_KEYS_WILDCARD]:
        # 71: Option '{}' must be '{}' alone to key on every column, '{} except(c1, c2)' to key on
        # every column but those, or a list of column names
        raise ValueError(
            _m(71, _PRIMARY_KEYS_OPTION, _PRIMARY_KEYS_WILDCARD, _PRIMARY_KEYS_WILDCARD)
        )
    if len(keys) != len(set(keys)):
        # 72: Option '{}' lists a duplicate column
        raise ValueError(_m(72, _PRIMARY_KEYS_OPTION))
    return keys, ()


def _snapshot_filter(options: dict[str, str]) -> str | None:
    # Docstring: Return a validated connector-owned snapshot WHERE predicate.

    value = options.get("snapshot.filter")
    if value is None:
        return None
    predicate = value.strip()
    if not predicate:
        return None
    if len(predicate) > 8192:
        # 73: Option 'snapshot.filter' cannot exceed 8192 characters
        raise ValueError(_m(73))
    if any(ord(character) < 32 for character in predicate):
        # 74: Option 'snapshot.filter' cannot contain control characters
        raise ValueError(_m(74))
    if ";" in predicate or "--" in predicate or "/*" in predicate or "*/" in predicate:
        # 75: Option 'snapshot.filter' must be one SQL predicate without comments or semicolons
        raise ValueError(_m(75))
    # Outside its quoted literals, a predicate must not open an Informix {...} comment,
    # leave a quote open, or hold a ? the connector would bind its own keyset values to.
    bare = re.sub(r"'(?:[^']|'')*'|\"(?:[^\"]|\"\")*\"", "", predicate)
    if any(character in bare for character in "{}?'\""):
        # 76: Option 'snapshot.filter' cannot hold a {{...}} comment, a ? placeholder, or an
        # unclosed quote outside its quoted literals
        raise ValueError(_m(76))
    return predicate


def _snapshot_predicate(snapshot_filter: str | None, table: Table) -> str | None:
    # Docstring: The WHERE predicate a snapshot read applies: snapshot.filter and row_filter.

    row_filter = _row_filter_sql(table)
    if snapshot_filter and row_filter:
        return f"({snapshot_filter}) AND ({row_filter})"
    return snapshot_filter or row_filter


_INCLUDE_COLUMNS_OPTION = "include_columns"
_EXCLUDE_COLUMNS_OPTION = "exclude_columns"


def _column_selection(options: dict[str, str]) -> tuple[str, tuple[str, ...]] | None:
    # Docstring: The table's include_columns / exclude_columns choice as (mode, sorted names).
    #
    # Named as in Lakeflow Connect's managed connectors. Either takes a comma-separated
    # list or a JSON array, as primary.keys does; setting both is ambiguous, so rejected.
    # include_columns keeps a column added to the source later out, exclude_columns lets
    # it in.

    include = options.get(_INCLUDE_COLUMNS_OPTION)
    exclude = options.get(_EXCLUDE_COLUMNS_OPTION)
    if include is None and exclude is None:
        return None
    if include is not None and exclude is not None:
        raise ValueError(
            f"Set '{_INCLUDE_COLUMNS_OPTION}' or '{_EXCLUDE_COLUMNS_OPTION}', not both"
        )
    mode, option, raw = (
        ("include", _INCLUDE_COLUMNS_OPTION, include)
        if include is not None
        else ("exclude", _EXCLUDE_COLUMNS_OPTION, exclude)
    )
    names = _parse_key_columns(raw, option)
    if not names:
        # 70: Option '{}' is set but lists no columns
        raise ValueError(_m(70, option))
    if len(names) != len(set(names)):
        # 72: Option '{}' lists a duplicate column
        raise ValueError(_m(72, option))
    return mode, tuple(sorted(names))


def _apply_column_selection(table: Table, selection: tuple[str, tuple[str, ...]] | None) -> Table:
    # Docstring: Narrow ``table`` to the selected columns; see ``Table.column_selection``.
    #
    # Every listed name must be a column of the table, so a typo fails instead of quietly
    # ingesting a column exclude_columns was meant to keep out. After a listed column is
    # dropped at the source, take it out of the list; the schema transition accepts that
    # edit. A nullable-index key candidate that loses a column is no candidate any more.

    if selection is None:
        return table
    mode, names = selection
    option = _INCLUDE_COLUMNS_OPTION if mode == "include" else _EXCLUDE_COLUMNS_OPTION
    catalog = table.catalog_columns or table.columns
    known = {column.name for column in catalog}
    missing = [name for name in names if name not in known]
    if missing:
        # 77: Option '{}' names column(s) that '{}' does not have: {}
        raise InformixError(_m(77, option, table.exposed_name, (", ".join(missing))))
    chosen = set(names)
    columns = tuple(column for column in catalog if (column.name in chosen) == (mode == "include"))
    if not columns:
        # 78: Option '{}' leaves '{}' with no columns
        raise ValueError(_m(78, option, table.exposed_name))
    keep_index = set(table.nullable_index_key) <= {column.name for column in columns}
    return replace(
        table,
        columns=columns,
        catalog_columns=catalog,
        column_selection=selection,
        nullable_index_key=table.nullable_index_key if keep_index else (),
        nullable_index_descending=table.nullable_index_descending if keep_index else (),
    )


def _unsupported_column_list(columns: Iterable[Column]) -> str:
    # Docstring: ``name (TYPE)`` for each column, noting a DATETIME or INTERVAL qualifier.

    return ", ".join(
        f"{column.name} ({column.type_name}"
        + (" with an unsupported qualifier" if column.type_name in {"DATETIME", "INTERVAL"} else "")
        + ")"
        for column in columns
    )


def _leave_out_unsupported_columns(table: Table, key: tuple[str, ...] | None) -> Table:
    # Docstring: Leave the columns of a type the connector can't read out of ``table``.
    #
    # BYTE, TEXT, BLOB, CLOB, collection, ROW and opaque columns, and DATETIME or INTERVAL
    # columns whose qualifier the decoder doesn't handle, can be neither snapshotted nor
    # captured. Rather than rejecting the table, the connector reads the rest of it, as if
    # exclude_columns listed them, and warns once per process naming what it left out.
    # Runs after the column selection, so a column it already excludes draws no warning,
    # and include_columns naming one fails: that asks for a column the connector can't land.
    #
    # ``key`` is the key the table will merge and delete by (see _requested_key), or None
    # for a primary.keys "*" wildcard, which keys on whatever is ingested. A key column
    # can't be left out, so then the table is returned as it is and fails as it always
    # did, once _ensure_materializable finds the column.

    unsupported = _snapshot_unsupported_columns(table)
    if not unsupported:
        return table
    if key is not None and {column.name for column in unsupported} & set(key):
        return table
    if table.column_selection is not None and table.column_selection[0] == "include":
        # 79: Option '{}' names column(s) of '{}' whose type the connector can't read: {}
        raise InformixError(
            _m(
                79,
                _INCLUDE_COLUMNS_OPTION,
                table.exposed_name,
                _unsupported_column_list(unsupported),
            )
        )
    names = {column.name for column in unsupported}
    columns = tuple(column for column in table.columns if column.name not in names)
    if not columns:
        # 80: Table '{}' has no column the connector can read: {}
        raise InformixError(_m(80, table.exposed_name, _unsupported_column_list(unsupported)))
    warning = (table.identity, tuple(sorted(names)))
    coordinator = _STATE_VALIDATION_COORDINATOR
    with coordinator.condition:
        first = warning not in coordinator.unsupported_column_warnings
        coordinator.unsupported_column_warnings.add(warning)
    if first:
        # 81: Informix table '{}' has column(s) of a type the connector can't read: {}. They are
        # left out; the rest of the table is ingested without them.
        logging.getLogger(__name__).warning(
            _m(81, table.exposed_name, _unsupported_column_list(unsupported)),
        )
    keep_index = not set(table.nullable_index_key) & names
    return replace(
        table,
        columns=columns,
        catalog_columns=table.catalog_columns or table.columns,
        unsupported_columns=unsupported,
        nullable_index_key=table.nullable_index_key if keep_index else (),
        nullable_index_descending=table.nullable_index_descending if keep_index else (),
    )


def _ensure_selected_keys(table: Table) -> None:
    # Docstring: Fail when the column selection leaves out a key column.
    #
    # The pipeline merges and deletes by the key, so it must be ingested. Checked after the
    # key options, so a primary.keys override naming other columns can stand in for an
    # excluded catalog key.

    if table.column_selection is None:
        return
    selected = {column.name for column in table.columns}
    missing = [key for key in table.primary_keys if key not in selected]
    if missing:
        # 82: Key column(s) {} of '{}' must be selected; add them to '{}' or remove them from '{}'
        raise InformixError(
            _m(
                82,
                (", ".join(missing)),
                table.exposed_name,
                _INCLUDE_COLUMNS_OPTION,
                _EXCLUDE_COLUMNS_OPTION,
            )
        )


_RENAME_COLUMNS_OPTION = "rename_columns"
# rename_columns lands chosen columns under new names: a JSON object such as
# {"cust_nm": "customer_name"}, or "cust_nm:customer_name, ..." pairs. Every other
# option still names source columns. The renames apply together, so two columns may
# swap names, and a destination name may not clash (ignoring case, as Delta does) with
# another reported column or a connector metadata column.
_RENAME_FORBIDDEN = re.compile(r"[ ,;{}()\n\t=]")


def _column_renames(options: dict[str, str]) -> tuple[tuple[str, str], ...] | None:
    # Docstring: The table's rename_columns as sorted (source, destination) pairs, or None.

    raw = options.get(_RENAME_COLUMNS_OPTION)
    if raw is None or not str(raw).strip():
        return None
    text = str(raw).strip()
    option = _RENAME_COLUMNS_OPTION
    if text.startswith("{"):
        try:
            pairs = json.loads(text, object_pairs_hook=list)
        except ValueError as error:
            # 83: Option '{}' is not a valid JSON object
            raise ValueError(_m(83, option)) from error
        if not all(isinstance(value, str) for pair in pairs for value in pair):
            # 84: Option '{}' must map column names to column names
            raise ValueError(_m(84, option))
    else:
        pairs = []
        for item in text.split(","):
            source, separator, target = item.partition(":")
            if not separator:
                # 85: Option '{}' takes a JSON object or 'source:destination' pairs
                raise ValueError(_m(85, option))
            pairs.append((source, target))
    pairs = [(source.strip(), target.strip()) for source, target in pairs]
    sources = [source for source, _ in pairs]
    if len(sources) != len(set(sources)):
        # 86: Option '{}' renames a column twice
        raise ValueError(_m(86, option))
    for source, target in pairs:
        if not source or not target:
            # 87: Option '{}' has an empty column name
            raise ValueError(_m(87, option))
        if _RENAME_FORBIDDEN.search(target):
            # 88: Option '{}' destination name {!r} contains a space or one of ,;{{}}()= that Delta
            # column names can't hold
            raise ValueError(_m(88, option, target))
    return tuple(sorted((source, target) for source, target in pairs if source != target)) or None


def _apply_column_renames(table: Table, renames: tuple[tuple[str, str], ...] | None) -> Table:
    # Docstring: Validate ``renames`` against ``table``'s selected columns and record them.

    if renames is None:
        return table if table.column_renames is None else replace(table, column_renames=None)
    selected = {column.name for column in table.columns}
    missing = [source for source, _ in renames if source not in selected]
    if missing:
        # 89: Option '{}' renames column(s) that '{}' does not have or does not select: {}
        raise InformixError(
            _m(89, _RENAME_COLUMNS_OPTION, table.exposed_name, (", ".join(missing)))
        )
    mapping = dict(renames)
    names = [mapping.get(column.name, column.name) for column in table.columns]
    names += [CURSOR, COMMIT_LSN, TX_ID, OP, COMMIT_TIME]
    folded = [name.casefold() for name in names]
    clashes = sorted({name for name, fold in zip(names, folded) if folded.count(fold) > 1})
    if clashes:
        # 90: Option '{}' gives '{}' more than one column named {}
        raise InformixError(
            _m(90, _RENAME_COLUMNS_OPTION, table.exposed_name, (", ".join(clashes)))
        )
    return table if table.column_renames == renames else replace(table, column_renames=renames)


_TRANSFORM_COLUMNS_OPTION = "transform_columns"
# transform_columns replaces chosen columns' values as rows leave the connector: an
# object from column name to an expression over that column, e.g. {"ssn": "MASK(ssn, 4)",
# "email": "HASH(LOWER(email))"}. Expressions use row_filter's grammar and functions plus
# MASK, HASH, and NULLIFY, and run in Python only, on the values the connector emits
# (CHAR without its padding, dates and timestamps as ISO text), so raw values never
# reach Spark. A key column takes only HASH(column), which keeps keys one-to-one so
# deletes still match. row_filter, the column selection, and the key options keep
# seeing source values; renames apply after.
_TRANSFORM_CACHE: dict[str, tuple] = {}
# Functions whose result is an integer whatever their input; the others keep the type of
# what they apply to (strings stay strings, ABS/ROUND/TRUNC/MOD/NVL keep a number's type).
_INTEGER_RESULT_FUNCTIONS = frozenset({"YEAR", "MONTH", "DAY", "WEEKDAY", "LENGTH", "CHAR_LENGTH"})


def _column_transforms(options: dict[str, str]) -> tuple[tuple[str, str, Any], ...] | None:
    # Docstring: The table's transform_columns as sorted (column, canonical text, operand).

    raw = options.get(_TRANSFORM_COLUMNS_OPTION)
    if raw is None or not str(raw).strip():
        return None
    text = str(raw).strip()
    cached = _TRANSFORM_CACHE.get(text)
    if cached is not None:
        return cached
    option = _TRANSFORM_COLUMNS_OPTION
    try:
        pairs = json.loads(text, object_pairs_hook=list)
    except ValueError as error:
        # 83: Option '{}' is not a valid JSON object
        raise ValueError(_m(83, option)) from error
    if not isinstance(pairs, list) or not all(
        isinstance(pair, tuple) and all(isinstance(value, str) for value in pair) for pair in pairs
    ):
        # 91: Option '{}' must map column names to expressions
        raise ValueError(_m(91, option))
    columns = [column for column, _ in pairs]
    if len(columns) != len(set(columns)):
        # 92: Option '{}' transforms a column twice
        raise ValueError(_m(92, option))
    parsed = []
    for column, expression in pairs:
        operand = _RowFilterParser(expression, option, "transform").parse_expression()
        if isinstance(operand, str):
            # 93: Option '{}' for {} applies no function
            raise ValueError(_m(93, option, column))
        parsed.append((column, _expression_text(operand), operand))
    result = tuple(sorted(parsed, key=lambda item: item[0])) or None
    if len(_TRANSFORM_CACHE) >= 64:
        _TRANSFORM_CACHE.clear()
    _TRANSFORM_CACHE[text] = result
    return result


def _transform_key_id(key: str | None) -> str | None:
    # Docstring: A non-secret id of the HASH key, fingerprinted so a new key fails closed.
    #
    # An HMAC under the key itself, so it says nothing about the key without it.

    if not key:
        return None
    digest = hmac.new(key.encode("utf-8"), b"lakeflow-informix-transform-key-id", hashlib.sha256)
    return digest.hexdigest()[:16]


def _apply_column_transforms(
    table: Table, transforms: tuple | None, key: str | None, *, key_id: str | None = None
) -> Table:
    # Docstring: Validate ``transforms`` against ``table`` and record their canonical form.
    #
    # ``key`` is the transform.hash.key connection option, required when HASH is used;
    # a schema refresh, which carries a validated table forward, passes its ``key_id``.

    option = _TRANSFORM_COLUMNS_OPTION
    if transforms is None:
        if table.column_transforms is None:
            return table
        return replace(table, column_transforms=None, transform_key_id=None)
    columns = {column.name: column for column in table.columns}
    uses_hash = False
    for name, canonical, operand in transforms:
        if name not in columns:
            # 94: Option '{}' transforms column {}, which '{}' does not have or does not select
            raise InformixError(_m(94, option, name, table.exposed_name))
        if _expression_column(operand) != name:
            # 95: Option '{}' for {} reads {}; an expression may only read the column it replaces
            raise InformixError(_m(95, option, name, _expression_column(operand)))
        _expression_kind(operand, columns, option, table.exposed_name, filtering=False)
        uses_hash = uses_hash or "HASH" in _operand_functions(operand)
        if name in table.primary_keys and canonical != f"HASH({name})":
            # 96: Option '{}' may only HASH key column {}: any other change could map two keys to
            # one, and deletes would remove the wrong rows
            raise InformixError(_m(96, option, name))
    if uses_hash and key_id is None:
        if not key or len(key) < 16:
            # 97: Option '{}' uses HASH, which needs the connection option '{}' set to a secret of
            # at least 16 characters
            raise InformixError(_m(97, option, _TRANSFORM_HASH_KEY_OPTION))
        key_id = _transform_key_id(key)
    recorded = tuple((name, canonical) for name, canonical, _ in transforms)
    key_id = key_id if uses_hash else None
    if table.column_transforms == recorded and table.transform_key_id == key_id:
        return table
    return replace(table, column_transforms=recorded, transform_key_id=key_id)


def _transform_spark_type(operand: str | tuple, column: "Column", options: dict[str, str]):
    # Docstring: The Spark type a transform lands as, given the column it reads.

    if isinstance(operand, str):
        return _spark_type(column, options)
    name = operand[1]
    if name in _INTEGER_RESULT_FUNCTIONS:
        # Before the string functions: LENGTH and CHAR_LENGTH read a string, give an int.
        return IntegerType()
    if name in ("HASH", "MASK") or name in _STRING_FUNCTION_NAMES:
        return StringType()
    inner = _transform_spark_type(operand[2][0], column, options)
    if name == "ROUND" and isinstance(inner, DecimalType):
        # Rounding up can carry into one more integer digit (999.99 to 1000).
        return DecimalType(min(inner.precision + 1, 38), inner.scale)
    return inner


def _transformed_rows(rows: Iterator[dict], transforms: tuple | None, context: dict):
    # Docstring: ``rows`` with each transformed column's value replaced (source names).

    if not transforms:
        return rows

    def apply(row: dict) -> dict:
        out = dict(row)
        for name, _, operand in transforms:
            if name in out:
                value = _expression_value(operand, out, context)
                out[name] = _framework_value(value)
        return out

    return (apply(row) for row in rows)


def _renamed_rows(rows: Iterator[dict], renames: tuple[tuple[str, str], ...] | None):
    # Docstring: ``rows`` with their keys under the destination names ``renames`` gives.

    if not renames:
        return rows
    mapping = dict(renames)
    return ({mapping.get(key, key): value for key, value in row.items()} for row in rows)


_ROW_FILTER_OPTION = "row_filter"
# The connection option holding transform_columns' HMAC key (see HASH).
_TRANSFORM_HASH_KEY_OPTION = "transform.hash.key"
# row_filter keeps only the rows matching a predicate -- in snapshots, file-sourced
# snapshots, and the change stream alike -- and is named as in Lakeflow Connect. The
# connector parses it itself so the same predicate can be rendered to SQL for snapshots
# and evaluated in Python on CDC before- and after-images and on file records. That
# limits it to a grammar whose meaning is identical both ways: comparisons, IN, BETWEEN,
# LIKE, IS [NOT] NULL, AND/OR/NOT and parentheses, over numeric, string, BOOLEAN, DATE,
# and YEAR-anchored DATETIME columns, with SQL's three-valued NULL logic. Strings compare
# by code point with trailing spaces ignored, which is Informix's CHAR/VARCHAR order for
# ISO 8859-1 and UTF-8 code sets; NCHAR and NVARCHAR collate by locale, so they take
# equality tests and LIKE only. LIKE follows what Informix 14.10 was measured to do on
# every string type: case-sensitive, trailing blanks of the value and of the pattern
# ignored, and an escape character (backslash unless ESCAPE names another) that makes
# the next character literal. The SQL always spells the ESCAPE out, so the server's
# DEFAULTESCCHAR setting cannot change the meaning. FLOAT columns are rejected because
# binary floating point compares differently in SQL and Python. An UPDATE that moves a
# row into the filter is upserted and one that moves it out is deleted, so a keyed
# target holds exactly the matching rows.
_ROW_FILTER_KEYWORDS = frozenset(
    {
        "AND",
        "OR",
        "NOT",
        "IN",
        "BETWEEN",
        "LIKE",
        "ESCAPE",
        "IS",
        "NULL",
        "TRUE",
        "FALSE",
        "DATE",
        "TIMESTAMP",
    }
)
_ROW_FILTER_LIKE_ESCAPE = "\\"
_ROW_FILTER_LIKE_CACHE: dict[tuple[str, str], re.Pattern] = {}
_ROW_FILTER_TOKEN = re.compile(
    r"\s*(?:(?P<number>-?\d+(?:\.\d+)?)|(?P<string>'(?:[^']|'')*')"
    r"|(?P<op><>|!=|<=|>=|=|<|>)|(?P<punct>[(),])|(?P<word>[^\W\d][\w$]*))",
    re.UNICODE,
)
_ROW_FILTER_TEMPORAL = re.compile(
    r"(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2})(?::(\d{2})(?:\.(\d{1,6}))?)?)?"
)
_ROW_FILTER_NUMERIC_TYPES = frozenset(
    {
        "SMALLINT",
        "INT2",
        "INTEGER",
        "INT",
        "SERIAL",
        "BIGINT",
        "INT8",
        "BIGSERIAL",
        "SERIAL8",
        "DECIMAL",
        "NUMERIC",
        "MONEY",
    }
)
_ROW_FILTER_STRING_TYPES = frozenset({"CHAR", "NCHAR", "VARCHAR", "LVARCHAR", "NVARCHAR"})
_ROW_FILTER_CACHE: dict[str, tuple] = {}


# Deterministic functions shared by row_filter and transform_columns: name -> (input
# kinds, literal argument kinds, result kind, filter). An argument kind ending in "?"
# is optional; "same" means the kind of the function's input. row_filter renders each
# function to Informix SQL for snapshots and evaluates it in Python on change images and
# file records, so the two must agree: every filter function's Python twin below was
# measured against Informix 14.10 (see the README). MASK, HASH, and NULLIFY run only in
# Python, where transform_columns applies them, so they are not filter functions.
# Functions whose result depends on the clock, the session, or the database locale's
# collation (TODAY, CURRENT, USER) are deliberately absent: a filter on them would
# change a row's membership without any change event to carry it.
_STRING_KINDS = ("string", "nstring")
_VALUE_KINDS = ("string", "nstring", "number", "bool", "date", "timestamp")
_DATE_KINDS = ("date", "timestamp")
_EXPRESSION_FUNCTIONS = {
    "UPPER": (_STRING_KINDS, (), "same", True),
    "LOWER": (_STRING_KINDS, (), "same", True),
    "TRIM": (_STRING_KINDS, (), "same", True),
    "LTRIM": (_STRING_KINDS, (), "same", True),
    "RTRIM": (_STRING_KINDS, (), "same", True),
    "LENGTH": (_STRING_KINDS, (), "number", True),
    "CHAR_LENGTH": (_STRING_KINDS, (), "number", True),
    "SUBSTR": (_STRING_KINDS, ("number", "number?"), "same", True),
    "REPLACE": (_STRING_KINDS, ("string", "string?"), "same", True),
    "LPAD": (_STRING_KINDS, ("number", "string"), "same", True),
    "RPAD": (_STRING_KINDS, ("number", "string"), "same", True),
    "NVL": (_VALUE_KINDS, ("same",), "same", True),
    "COALESCE": (_VALUE_KINDS, ("same",), "same", True),
    "ABS": (("number",), (), "number", True),
    "MOD": (("number",), ("number",), "number", True),
    "ROUND": (("number",), ("number?",), "number", True),
    "TRUNC": (("number",), ("number?",), "number", True),
    "YEAR": (_DATE_KINDS, (), "number", True),
    "MONTH": (_DATE_KINDS, (), "number", True),
    "DAY": (_DATE_KINDS, (), "number", True),
    "WEEKDAY": (_DATE_KINDS, (), "number", True),
    "MASK": (_STRING_KINDS, ("number?", "string?"), "string", False),
    "HASH": ((*_VALUE_KINDS, "other"), (), "string", False),
    "NULLIFY": ((*_VALUE_KINDS, "other"), (), "same", False),
}


def _expression_text(operand: str | tuple) -> str:
    # Docstring: Canonical text of an operand: a column name or NAME(operand, literals).

    if isinstance(operand, str):
        return operand
    _, name, arguments = operand
    parts = [_expression_text(arguments[0])]
    parts += [_row_filter_literal_text(literal) for literal in arguments[1:]]
    return f"{name}({', '.join(parts)})"


def _expression_column(operand: str | tuple) -> str:
    # Docstring: The column an operand reads (every function applies to one operand).

    while not isinstance(operand, str):
        operand = operand[2][0]
    return operand


def _expression_kind(
    operand: str | tuple,
    columns: dict[str, "Column"],
    option: str,
    table_name: str,
    *,
    filtering: bool,
) -> str:
    # Docstring: The kind ``operand`` evaluates to, failing on anything ill-typed.
    #
    # A column of a type a filter cannot compare has kind "other", which only HASH and
    # NULLIFY accept; in a filter such a column fails outright.

    if isinstance(operand, str):
        column = columns.get(operand)
        if column is None:
            # 98: Option '{}' uses column {}, which '{}' does not have or does not select
            raise InformixError(_m(98, option, operand, table_name))
        kind = _row_filter_kind(column)
        if kind is None and filtering:
            # 99: Option '{}' cannot filter on {} column {}
            raise InformixError(_m(99, option, column.type_name, operand))
        return kind or "other"
    _, name, arguments = operand
    inputs, literal_kinds, result, in_filters = _EXPRESSION_FUNCTIONS[name]
    if filtering and not in_filters:
        # 100: Option '{}' cannot use {}, which only transform_columns applies
        raise InformixError(_m(100, option, name))
    kind = _expression_kind(arguments[0], columns, option, table_name, filtering=filtering)
    if kind not in inputs:
        # 101: Option '{}' cannot apply {} to a {} value
        raise InformixError(_m(101, option, name, kind))
    literals = arguments[1:]
    required = sum(1 for expected in literal_kinds if not expected.endswith("?"))
    if not required <= len(literals) <= len(literal_kinds):
        most = f" to {len(literal_kinds) + 1}" if required < len(literal_kinds) else ""
        # 102: Option '{}' gives {} {} argument(s); it takes {}{}
        raise InformixError(_m(102, option, name, len(literals) + 1, required + 1, most))
    for expected, literal in zip(literal_kinds, literals):
        expected = expected.rstrip("?")
        if expected == "same":
            expected = "string" if kind == "nstring" else kind
        if literal[0] != expected:
            # 103: Option '{}' gives {} a {} where it takes a {}
            raise InformixError(_m(103, option, name, literal[0], expected))
    if name in ("NVL", "COALESCE") and not filtering and kind == "number":
        # A transform's fallback lands in the column's own type (see _fallback_value), so
        # an integer column, or an integer-result function, takes a whole number only.
        column = columns[_expression_column(operand)]
        integral = column.type_name in _INTEGER_RANKS or any(
            inner in _INTEGER_RESULT_FUNCTIONS for inner in _operand_functions(arguments[0])
        )
        fallback = literals[0][1]
        if integral and fallback != fallback.to_integral_value():
            # 104: Option '{}' gives {} the fallback {} for {}, which holds whole numbers only
            raise InformixError(_m(104, option, name, fallback, column.name))
    _check_function_literals(name, [literal[1] for literal in literals], option)
    return kind if result == "same" else result


def _check_function_literals(name: str, values: list, option: str) -> None:
    # Docstring: Refuse literal arguments outside the range each function was measured on.

    def whole(value, low, high) -> bool:
        return value == value.to_integral_value() and low <= value <= high

    if name == "SUBSTR" and not (
        whole(values[0], 1, 32767) and (len(values) == 1 or whole(values[1], 0, 32767))
    ):
        # 105: Option '{}': SUBSTR takes a start from 1 and a length from 0
        raise InformixError(_m(105, option))
    if name in ("LPAD", "RPAD") and not (whole(values[0], 0, 32767) and values[1]):
        # 106: Option '{}': {} takes a length from 0 and a pad string
        raise InformixError(_m(106, option, name))
    if name == "REPLACE" and not values[0]:
        # 107: Option '{}': REPLACE needs a non-empty string to replace
        raise InformixError(_m(107, option))
    if name == "MOD" and not (whole(values[0], -(1 << 31), (1 << 31) - 1) and values[0]):
        # 108: Option '{}': MOD takes a whole, non-zero divisor
        raise InformixError(_m(108, option))
    if name in ("ROUND", "TRUNC") and values and not whole(values[0], -32, 32):
        # 109: Option '{}': {} takes whole digits from -32 to 32
        raise InformixError(_m(109, option, name))
    if name == "MASK" and (
        (values and not whole(values[0], 0, 32767)) or (len(values) > 1 and len(values[1]) != 1)
    ):
        # 110: Option '{}': MASK takes a count from 0 and one character
        raise InformixError(_m(110, option))


def _expression_sql(operand: str | tuple, columns: dict[str, "Column"], literal) -> str:
    # Docstring: Render a filter operand as Informix SQL; ``literal`` renders its literals.

    if isinstance(operand, str):
        return _sql_identifier(columns[operand].name)
    _, name, arguments = operand
    base = columns[_expression_column(operand)]
    parts = [_expression_sql(arguments[0], columns, literal)]
    parts += [literal(value, base) for value in arguments[1:]]
    # COALESCE pads an LVARCHAR result to its declared width on Informix; with the one
    # fallback allowed here NVL is the same function without that, so it is sent instead.
    return f"{'NVL' if name == 'COALESCE' else name}({', '.join(parts)})"


def _case_map(text: str, upper: bool) -> str:
    # Docstring: UPPER/LOWER as Informix applies them: to the ASCII letters only. Measured
    # on an ISO 8859-1 database, where accented letters (\u00e0, \u00c9) stay as they are.

    if upper:
        return text.translate(_ASCII_UPPER)
    return text.translate(_ASCII_LOWER)


_ASCII_UPPER = str.maketrans("abcdefghijklmnopqrstuvwxyz", "ABCDEFGHIJKLMNOPQRSTUVWXYZ")
_ASCII_LOWER = str.maketrans("ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz")


def _temporal(value: Any) -> date:
    # Docstring: A date or datetime from a decoded value or its ISO text at the boundary.

    if isinstance(value, (date, datetime)):
        return value
    text = str(value)
    return datetime.fromisoformat(text) if len(text) > 10 else date.fromisoformat(text)


def _hash_text(value: Any) -> str:
    # Docstring: The text HASH digests: one form per value, whichever path decoded it.
    #
    # Rows reach the output boundary with dates and timestamps already in ISO text (see
    # _framework_value) and CHAR padding removed, identically from snapshots, files, and
    # CDC, so the text of those values is stable; the other cases fix one spelling each.

    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, datetime):
        return value.replace(tzinfo=None).isoformat()
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, (bytes, bytearray)):
        return bytes(value).hex()
    if isinstance(value, (int, float, Decimal)):
        return _hash_number_text(value)
    return str(value)


def _hash_number_text(value: int | float | Decimal) -> str:
    # Docstring: One text per numeric value, whichever Python type carries it: 5, 5.0, and
    # Decimal("5.00") all give "5". A key then keeps its digest when its column widens
    # (INTEGER to DECIMAL or FLOAT, which the stream adopts without a full refresh), and a
    # variable-scale DECIMAL hashes the same from a file ("1.5") and the change stream
    # ("1.50").

    if isinstance(value, float):
        if not math.isfinite(value):
            return repr(value)
        value = Decimal(repr(value))
    elif isinstance(value, int):
        return str(value)
    if not value.is_finite():
        return str(value)
    if not value:
        return "0"
    with localcontext() as context:
        context.prec = 80
        return format(value.normalize(), "f")


def _apply_function(name: str, value: Any, literals: list, context: dict) -> Any:
    # Docstring: Evaluate one function on an already-evaluated operand ``value``.
    #
    # NULL in gives NULL out, except NVL/COALESCE, which replace it, and NULLIFY, which
    # always gives NULL. ``context`` holds the byte encoding LENGTH counts in and the
    # HMAC key HASH uses.

    if name == "NULLIFY":
        return None
    if name in ("NVL", "COALESCE"):
        return literals[0] if value is None else value
    if value is None:
        return None
    if name == "HASH":
        key = context.get("hash_key")
        if not key:
            # 111: HASH needs the connection option '{}'
            raise InformixError(_m(111, _TRANSFORM_HASH_KEY_OPTION))
        return hmac.new(key, _hash_text(value).encode("utf-8"), hashlib.sha256).hexdigest()
    if name in _STRING_FUNCTION_NAMES:
        text = str(value)
        if name in ("UPPER", "LOWER"):
            return _case_map(text, name == "UPPER")
        if name == "TRIM":
            return text.strip(" ")
        if name == "LTRIM":
            return text.lstrip(" ")
        if name == "RTRIM":
            return text.rstrip(" ")
        if name == "LENGTH":
            # Bytes, without trailing blanks, as Informix counts.
            return len(text.rstrip(" ").encode(context.get("encoding", "latin-1"), "replace"))
        if name == "CHAR_LENGTH":
            return len(text)
        if name == "SUBSTR":
            # A start past the end gives NULL, as on Informix; an in-range empty slice is ''.
            start = int(literals[0]) - 1
            if start >= len(text):
                return None
            return text[start:] if len(literals) == 1 else text[start : start + int(literals[1])]
        if name == "REPLACE":
            return text.replace(literals[0], literals[1] if len(literals) > 1 else "")
        if name in ("LPAD", "RPAD"):
            width, pad = int(literals[0]), literals[1]
            if len(text) >= width:
                return text[:width]
            fill = (pad * width)[: width - len(text)]
            return fill + text if name == "LPAD" else text + fill
        # MASK keeps the last ``keep`` characters; a value no longer than that is
        # masked whole, so a short value does not pass through unmasked.
        keep = int(literals[0]) if literals else 0
        character = literals[1] if len(literals) > 1 else "*"
        if len(text) <= keep:
            return character * len(text)
        return character * (len(text) - keep) + (text[len(text) - keep :] if keep else "")
    if name in ("YEAR", "MONTH", "DAY", "WEEKDAY"):
        moment = _temporal(value)
        if name == "WEEKDAY":
            return moment.isoweekday() % 7  # Informix: 0 is Sunday
        return getattr(moment, name.lower())
    with localcontext() as decimal_context:
        decimal_context.prec = 80
        # A float by the digits it shows (1.15, not its binary 1.1499...), as
        # _hash_number_text reads one, so a half rounds as the documentation says.
        number = Decimal(repr(value)) if isinstance(value, float) else Decimal(value)
        if name == "ABS":
            result = abs(number)
        elif name == "MOD":
            # Informix truncates both operands to integers; the sign follows the dividend.
            whole = number.to_integral_value(rounding=ROUND_DOWN)
            result = whole % Decimal(literals[0]).to_integral_value(rounding=ROUND_DOWN)
        else:
            digits = int(literals[0]) if literals else 0
            result = number.quantize(
                Decimal(1).scaleb(-digits),
                rounding=ROUND_HALF_UP if name == "ROUND" else ROUND_DOWN,
            )
            # Negative digits leave a positive exponent (1.2E+4): write it out in full.
            result = result.quantize(Decimal(1)) if digits < 0 else result
    # Back in the type the column's values arrive as, which the schema declares: a
    # variable-scale DECIMAL can arrive as a float or a fixed-point string.
    if isinstance(value, str):
        return format(result, "f")
    if isinstance(value, float):
        return float(result)
    return result if isinstance(value, Decimal) else int(result)


_STRING_FUNCTION_NAMES = frozenset(
    {
        "UPPER",
        "LOWER",
        "TRIM",
        "LTRIM",
        "RTRIM",
        "LENGTH",
        "CHAR_LENGTH",
        "SUBSTR",
        "REPLACE",
        "LPAD",
        "RPAD",
        "MASK",
    }
)


def _expression_value(operand: str | tuple, row: dict, context: dict) -> Any:
    # Docstring: Evaluate an operand on ``row``. In a filter, ``context["pad"]`` names the
    # CHAR columns and their widths: Informix applies functions to the blank-padded
    # value, which decoding stripped, so a CHAR operand is padded back first.

    if isinstance(operand, str):
        value = row.get(operand)
        width = context.get("pad", {}).get(operand)
        if width and value is not None:
            value = _pad_char(str(value), width, context.get("encoding", "latin-1"))
        return value
    _, name, arguments = operand
    value = _expression_value(arguments[0], row, context)
    literals = [literal[1] for literal in arguments[1:]]
    if name in ("NVL", "COALESCE") and value is None:
        return _fallback_value(literals[0], arguments[0], context)
    return _apply_function(name, value, literals, context)


def _pad_char(text: str, width: int, encoding: str) -> str:
    # Docstring: ``text`` blank-padded as Informix stores a CHAR: to ``width`` bytes of the
    # database code set, so a multibyte character takes more than one of them.

    missing = width - len(text.encode(encoding, "replace"))
    return text + " " * missing if missing > 0 else text


def _fallback_value(literal: Any, operand: str | tuple, context: dict) -> Any:
    # Docstring: NVL/COALESCE's fallback in the representation of what it stands in for.
    #
    # In a filter a CHAR column's fallback is padded to the column's width, as Informix
    # pads it. In a transform a number literal, parsed as a Decimal, becomes the Python
    # type the operand's other values have -- an int for an integer column or an
    # integer-result function, a Decimal at the column's scale, or the configured
    # variable-scale form -- so every row of a transformed column carries one type.
    # ``context["columns"]`` supplies the columns, on demand when it is callable.

    if isinstance(literal, str):
        if isinstance(operand, str):
            width = context.get("pad", {}).get(operand)
            if width:
                return _pad_char(literal, width, context.get("encoding", "latin-1"))
        return literal
    if not isinstance(literal, Decimal):
        return literal
    if any(name in _INTEGER_RESULT_FUNCTIONS for name in _operand_functions(operand)):
        return int(literal)
    columns = context.get("columns")
    if callable(columns):
        columns = context["columns"] = {column.name: column for column in columns()}
    column = (columns or {}).get(_expression_column(operand))
    if column is None:
        return literal
    return _number_for_column(literal, column, context.get("options") or {})


def _number_for_column(value: Decimal, column: "Column", options: dict[str, str]) -> Any:
    # Docstring: ``value`` as the Python number ``column``'s decoded values are.

    if column.type_name in _INTEGER_RANKS:
        return int(value)
    if column.type_name in {"DECIMAL", "NUMERIC", "MONEY"}:
        if _is_variable_scale_decimal(column):
            return _coerce_variable_decimal_value(
                value, column, _variable_decimal_target(column, options)
            )
        if column.scale is not None:
            scale = column.scale
        else:
            scale = 2 if column.type_name == "MONEY" else 0
        with localcontext() as decimal_context:
            # Past the default 28 digits: a DECIMAL holds up to 32.
            decimal_context.prec = 80
            return value.quantize(Decimal(1).scaleb(-scale))
    return value


class _RowFilterParser:
    # Docstring: Recursive-descent parser turning row_filter text into a hashable tree.
    #
    # Nodes: ("and"|"or", children), ("not", child), ("cmp", operand, op, literal),
    # ("in", operand, negated, literals), ("between", operand, negated, low, high),
    # ("like", operand, negated, pattern, escape), and ("null", operand, negated). An
    # operand is a column name or a function call ("fn", NAME, (operand, *literals)) --
    # see _EXPRESSION_FUNCTIONS. A literal is (kind, value) with kind number, string,
    # bool, date, or timestamp; a LIKE pattern is a string literal with its trailing
    # blanks removed, since Informix ignores them, and its escape is the one character
    # ESCAPE names (backslash if none). transform_columns parses one operand per column
    # with the same grammar (``option``/``noun`` only change the error text).

    def __init__(self, text: str, option: str = "row_filter", noun: str = "filter") -> None:
        self.option, self.noun = option, noun
        self.tokens: list[tuple[str, str]] = []
        self.index = 0
        text = text.strip()
        position = 0
        while position < len(text):
            match = _ROW_FILTER_TOKEN.match(text, position)
            if match is None or match.lastgroup is None:
                self.fail(f"unexpected character at position {position + 1}")
            self.tokens.append((match.lastgroup, match.group(match.lastgroup)))
            position = match.end()

    def fail(self, message: str) -> None:
        # 112: Option '{}' is not a valid {}: {}
        raise ValueError(_m(112, self.option, self.noun, message))

    def peek(self) -> tuple[str | None, str | None]:
        return self.tokens[self.index] if self.index < len(self.tokens) else (None, None)

    def take(self) -> tuple[str | None, str | None]:
        token = self.peek()
        self.index += 1
        return token

    def at_keyword(self, word: str) -> bool:
        kind, value = self.peek()
        return kind == "word" and str(value).upper() == word

    def accept_keyword(self, word: str) -> bool:
        if self.at_keyword(word):
            self.index += 1
            return True
        return False

    def expect_keyword(self, word: str) -> None:
        if not self.accept_keyword(word):
            self.fail(f"expected {word}")

    def expect_punct(self, character: str) -> None:
        if self.take() != ("punct", character):
            self.fail(f"expected '{character}'")

    def parse(self) -> tuple:
        if not self.tokens:
            self.fail("it is empty")
        tree = self.parse_or()
        if self.index != len(self.tokens):
            self.fail(f"unexpected {self.peek()[1]!r}")
        return tree

    def parse_or(self) -> tuple:
        terms = [self.parse_and()]
        while self.accept_keyword("OR"):
            terms.append(self.parse_and())
        return terms[0] if len(terms) == 1 else ("or", tuple(terms))

    def parse_and(self) -> tuple:
        terms = [self.parse_not()]
        while self.accept_keyword("AND"):
            terms.append(self.parse_not())
        return terms[0] if len(terms) == 1 else ("and", tuple(terms))

    def parse_not(self) -> tuple:
        if self.accept_keyword("NOT"):
            return ("not", self.parse_not())
        if self.peek() == ("punct", "("):
            self.index += 1
            tree = self.parse_or()
            self.expect_punct(")")
            return tree
        return self.parse_predicate()

    def parse_operand(self) -> str | tuple:
        kind, name = self.take()
        if kind != "word" or not _IDENTIFIER.fullmatch(str(name)):
            self.fail(f"expected a column name, found {name!r}")
        upper = str(name).upper()
        if self.peek() == ("punct", "(") and upper not in _EXPRESSION_FUNCTIONS:
            self.fail(f"{upper}() is not a supported function")
        if self.peek() == ("punct", "(") and upper in _EXPRESSION_FUNCTIONS:
            self.index += 1
            arguments = [self.parse_operand()]
            while self.peek() == ("punct", ","):
                self.index += 1
                arguments.append(self.parse_literal())
            self.expect_punct(")")
            return ("fn", upper, tuple(arguments))
        if upper in _ROW_FILTER_KEYWORDS:
            self.fail(f"expected a column name, found {name!r}")
        return str(name)

    def parse_expression(self) -> str | tuple:
        if not self.tokens:
            self.fail("it is empty")
        operand = self.parse_operand()
        if self.index != len(self.tokens):
            self.fail(f"unexpected {self.peek()[1]!r}")
        return operand

    def parse_predicate(self) -> tuple:
        operand = self.parse_operand()
        column = _expression_text(operand)
        if self.accept_keyword("IS"):
            negated = self.accept_keyword("NOT")
            self.expect_keyword("NULL")
            return ("null", operand, negated)
        negated = self.accept_keyword("NOT")
        if self.accept_keyword("IN"):
            self.expect_punct("(")
            values = [self.parse_literal()]
            while self.peek() == ("punct", ","):
                self.index += 1
                values.append(self.parse_literal())
            self.expect_punct(")")
            return ("in", operand, negated, tuple(values))
        if self.accept_keyword("BETWEEN"):
            low = self.parse_literal()
            self.expect_keyword("AND")
            return ("between", operand, negated, low, self.parse_literal())
        if self.accept_keyword("LIKE"):
            return self.parse_like(operand, column, negated)
        if negated:
            self.fail(f"expected IN, BETWEEN, or LIKE after NOT for {column}")
        kind, op = self.take()
        if kind != "op":
            self.fail(f"expected a comparison after {column}")
        return ("cmp", operand, "<>" if op == "!=" else op, self.parse_literal())

    def parse_like(self, operand: str | tuple, column: str, negated: bool) -> tuple:
        kind, pattern = self.parse_literal()
        if kind != "string":
            self.fail(f"LIKE for {column} needs a quoted pattern")
        escape = _ROW_FILTER_LIKE_ESCAPE
        if self.accept_keyword("ESCAPE"):
            kind, escape = self.parse_literal()
            if kind != "string" or len(escape) != 1 or escape in "%_ ":
                self.fail(f"ESCAPE for {column} must be one character other than %, _, or a space")
        pattern = pattern.rstrip(" ")
        index = 0
        while index < len(pattern):
            if pattern[index] == escape:
                if index + 1 == len(pattern):
                    # Informix matches such a pattern inconsistently, so it is refused.
                    self.fail(f"LIKE pattern for {column} ends with its escape character")
                index += 1
            index += 1
        return ("like", operand, negated, ("string", pattern), escape)

    def parse_literal(self) -> tuple:
        kind, value = self.take()
        text = str(value)
        if kind == "number":
            return ("number", Decimal(text))
        if kind == "string":
            return ("string", text[1:-1].replace("''", "'"))
        upper = text.upper()
        if kind == "word" and upper in {"TRUE", "FALSE"}:
            return ("bool", upper == "TRUE")
        if kind == "word" and upper in {"DATE", "TIMESTAMP"}:
            quoted_kind, quoted = self.take()
            match = (
                _ROW_FILTER_TEMPORAL.fullmatch(str(quoted)[1:-1])
                if quoted_kind == "string"
                else None
            )
            if match is None or (upper == "DATE" and match.group(4) is not None):
                self.fail(f"expected {upper} 'YYYY-MM-DD{'' if upper == 'DATE' else ' HH:MM:SS'}'")
            year, month, day, hour, minute, second, fraction = match.groups()
            try:
                if upper == "DATE":
                    return ("date", date(int(year), int(month), int(day)))
                micro = int((fraction + "000000")[:6]) if fraction else 0
                return (
                    "timestamp",
                    datetime(
                        int(year),
                        int(month),
                        int(day),
                        int(hour or 0),
                        int(minute or 0),
                        int(second or 0),
                        micro,
                    ),
                )
            except ValueError:
                self.fail(f"{upper} {quoted} is not a valid calendar value")
        if kind == "word" and upper == "NULL":
            self.fail("compare with NULL using IS NULL or IS NOT NULL")
        self.fail(f"expected a value, found {value!r}")
        raise AssertionError  # unreachable: fail() raises


def _parse_row_filter(text: str) -> tuple:
    # Docstring: Parse ``text`` with :class:`_RowFilterParser`, caching the tree by text.

    tree = _ROW_FILTER_CACHE.get(text)
    if tree is None:
        tree = _RowFilterParser(text).parse()
        if len(_ROW_FILTER_CACHE) >= 64:
            _ROW_FILTER_CACHE.clear()
        _ROW_FILTER_CACHE[text] = tree
    return tree


def _row_filter_literal_text(literal: tuple) -> str:
    kind, value = literal
    if kind == "number":
        return format(value.normalize(), "f")
    if kind == "string":
        return "'" + value.replace("'", "''") + "'"
    if kind == "bool":
        return "TRUE" if value else "FALSE"
    if kind == "date":
        return f"DATE '{value.isoformat()}'"
    return f"TIMESTAMP '{value.isoformat(sep=' ')}'"


def _row_filter_text(tree: tuple) -> str:
    # Docstring: Canonical row_filter text: fully parenthesised with normalised literals.
    #
    # Formatting-only edits (spacing, keyword case, ``!=`` for ``<>``, ``1.50`` for
    # ``1.5``) therefore keep the fingerprint, and the text parses back to the same tree.

    tag = tree[0]
    if tag in ("and", "or"):
        return f" {tag.upper()} ".join(f"({_row_filter_text(child)})" for child in tree[1])
    if tag == "not":
        return f"NOT ({_row_filter_text(tree[1])})"
    column = _expression_text(tree[1])
    if tag == "null":
        return f"{column} IS {'NOT ' if tree[2] else ''}NULL"
    if tag == "cmp":
        return f"{column} {tree[2]} {_row_filter_literal_text(tree[3])}"
    negation = "NOT " if tree[2] else ""
    if tag == "in":
        values = ", ".join(_row_filter_literal_text(value) for value in tree[3])
        return f"{column} {negation}IN ({values})"
    if tag == "like":
        pattern = _row_filter_literal_text(tree[3])
        escape = _row_filter_literal_text(("string", tree[4]))
        return f"{column} {negation}LIKE {pattern} ESCAPE {escape}"
    low, high = _row_filter_literal_text(tree[3]), _row_filter_literal_text(tree[4])
    return f"{column} {negation}BETWEEN {low} AND {high}"


def _row_filter_kind(column: Column) -> str | None:
    # Docstring: The literal kind a row_filter may compare ``column`` with, or None if none.

    name = column.type_name.split("(", 1)[0].strip()
    if name in _ROW_FILTER_NUMERIC_TYPES:
        return "number"
    if name in _ROW_FILTER_STRING_TYPES:
        return "nstring" if name in {"NCHAR", "NVARCHAR"} else "string"
    if name in {"BOOLEAN", "BOOL"}:
        return "bool"
    if name == "DATE":
        return "date"
    if name.startswith("DATETIME"):
        # Only a YEAR-anchored qualifier down to at least DAY decodes to a datetime.
        start, end = ((column.length or 0) >> 8) & 0xF, (column.length or 0) & 0xF
        if start == 0 and end >= 4:
            return "timestamp"
    return None


def _row_filter_datetime_sql(value: datetime, column: Column) -> str:
    # Docstring: Render ``value`` as an Informix DATETIME literal in ``column``'s qualifier.
    #
    # Fails when ``value`` carries a non-zero field finer than the qualifier holds, which
    # could match in Python yet never in SQL.

    end = (column.length or 0) & 0xF
    digits = end - 10 if end > 10 else 0
    scale = 10 ** (6 - digits)
    kept = value.replace(
        hour=value.hour if end >= 6 else 0,
        minute=value.minute if end >= 8 else 0,
        second=value.second if end >= 10 else 0,
        microsecond=(value.microsecond // scale) * scale if digits else 0,
    )
    if kept != value:
        # 113: Option '{}' value TIMESTAMP '{}' is more precise than DATETIME column {}
        raise InformixError(_m(113, _ROW_FILTER_OPTION, value, column.name))
    text = f"{value.year:04d}-{value.month:02d}-{value.day:02d}"
    fields = {6: f" {value.hour:02d}", 8: f":{value.minute:02d}", 10: f":{value.second:02d}"}
    text += "".join(part for code, part in fields.items() if end >= code)
    if digits:
        text += "." + f"{value.microsecond:06d}"[:digits]
    names = {4: "DAY", 6: "HOUR", 8: "MINUTE", 10: "SECOND"}
    qualifier = f"FRACTION({digits})" if digits else names[end]
    return f"DATETIME({text}) YEAR TO {qualifier}"


def _check_row_filter(tree: tuple, table: Table) -> None:
    # Docstring: Fail unless every predicate in ``tree`` compares a well-typed operand over
    # selected, filterable columns of ``table`` with values of its kind.

    columns = {column.name: column for column in table.columns}

    def check(node: tuple) -> None:
        tag = node[0]
        if tag in ("and", "or"):
            for child in node[1]:
                check(child)
            return
        if tag == "not":
            check(node[1])
            return
        operand = node[1]
        name = _expression_text(operand)
        column = columns.get(_expression_column(operand))
        kind = _expression_kind(
            operand, columns, _ROW_FILTER_OPTION, table.exposed_name, filtering=True
        )
        # Typed literals render in the qualifier of the column the operand reads.
        described = column.type_name if isinstance(operand, str) else kind
        if not isinstance(operand, str):
            for literal in _operand_literals(operand):
                if literal[0] == "timestamp":
                    _row_filter_datetime_sql(literal[1], column)
        if tag == "null":
            return
        if tag == "like":
            if kind not in ("string", "nstring"):
                # 114: Option '{}' can only apply LIKE to a string column, not {} {}
                raise InformixError(_m(114, _ROW_FILTER_OPTION, described, name))
            return
        literals = node[3] if tag == "in" else (node[3],) if tag == "cmp" else node[3:5]
        expected = "string" if kind == "nstring" else kind
        for literal in literals:
            if literal[0] != expected:
                raise InformixError(
                    f"Option '{_ROW_FILTER_OPTION}' compares {described} column {name} "
                    f"with a {literal[0]} value"
                    if isinstance(operand, str)
                    else f"Option '{_ROW_FILTER_OPTION}' compares {name}, a {kind}, "
                    f"with a {literal[0]} value"
                )
            if kind == "timestamp":
                _row_filter_datetime_sql(literal[1], column)
        ordered = tag == "between" or (tag == "cmp" and node[2] not in ("=", "<>"))
        if ordered and kind in ("nstring", "bool"):
            raise InformixError(
                f"Option '{_ROW_FILTER_OPTION}' can only test {described} column {name} "
                "for equality"
                if isinstance(operand, str)
                else f"Option '{_ROW_FILTER_OPTION}' can only test {name} for equality"
            )

    check(tree)


def _operand_literals(operand: str | tuple):
    # Docstring: Every literal argument inside an operand's function calls.

    while not isinstance(operand, str):
        yield from operand[2][1:]
        operand = operand[2][0]


def _operand_functions(operand: str | tuple) -> list[str]:
    # Docstring: The functions an operand applies, outermost first.

    names = []
    while not isinstance(operand, str):
        names.append(operand[1])
        operand = operand[2][0]
    return names


def _transform_may_null(operand: str | tuple) -> bool:
    # Docstring: Whether a transform can turn a non-NULL value into NULL: NULLIFY always does
    # and SUBSTR does past the end of the string. Every other function keeps a value, so a
    # NOT NULL column stays NOT NULL through HASH, MASK, UPPER, ABS, and the rest.

    return any(name in ("NULLIFY", "SUBSTR") for name in _operand_functions(operand))


def _apply_row_filter(table: Table, text: str | None) -> Table:
    # Docstring: Validate ``text`` against ``table`` and record its canonical form on the table.

    if text is None or not str(text).strip():
        return table if table.row_filter is None else replace(table, row_filter=None)
    if len(str(text)) > 8192:
        # 115: Option '{}' cannot exceed 8192 characters
        raise ValueError(_m(115, _ROW_FILTER_OPTION))
    tree = _parse_row_filter(str(text))
    _check_row_filter(tree, table)
    canonical = _row_filter_text(tree)
    return table if table.row_filter == canonical else replace(table, row_filter=canonical)


def _row_filter_sql(table: Table) -> str | None:
    # Docstring: ``table``'s row_filter as an Informix SQL predicate, or None.

    if table.row_filter is None:
        return None
    columns = {column.name: column for column in table.columns}

    def literal(value: tuple, column: Column) -> str:
        kind, item = value
        if kind == "number":
            return format(item, "f")
        if kind == "string":
            return "'" + item.replace("'", "''") + "'"
        if kind == "bool":
            return "'t'" if item else "'f'"
        if kind == "date":
            # MDY() builds the DATE without depending on the server's DBDATE format.
            return f"MDY({item.month}, {item.day}, {item.year})"
        return _row_filter_datetime_sql(item, column)

    def render(node: tuple) -> str:
        tag = node[0]
        if tag in ("and", "or"):
            return f" {tag.upper()} ".join(f"({render(child)})" for child in node[1])
        if tag == "not":
            return f"NOT ({render(node[1])})"
        column = columns[_expression_column(node[1])]
        name = _expression_sql(node[1], columns, literal)
        if tag == "null":
            return f"{name} IS {'NOT ' if node[2] else ''}NULL"
        if tag == "cmp":
            return f"{name} {node[2]} {literal(node[3], column)}"
        negation = "NOT " if node[2] else ""
        if tag == "in":
            values = ", ".join(literal(value, column) for value in node[3])
            return f"{name} {negation}IN ({values})"
        if tag == "like":
            escape = literal(("string", node[4]), column)
            return f"{name} {negation}LIKE {literal(node[3], column)} ESCAPE {escape}"
        low, high = literal(node[3], column), literal(node[4], column)
        return f"{name} {negation}BETWEEN {low} AND {high}"

    return render(_parse_row_filter(table.row_filter))


def _row_filter_predicate(table: Table, encoding: str = "latin-1") -> tuple | None:
    # Docstring: ``table``'s parsed row_filter with what evaluating it needs -- each
    # column's kind and, for functions, the CHAR widths to re-pad and the byte encoding
    # LENGTH counts in -- ready for :func:`_row_filter_matches`, or None without a filter.

    if table.row_filter is None:
        return None
    kinds = {column.name: _row_filter_kind(column) for column in table.columns}
    pad = {
        column.name: int(column.length)
        for column in table.columns
        if column.type_name in {"CHAR", "NCHAR"} and column.length
    }
    return _parse_row_filter(table.row_filter), kinds, {"pad": pad, "encoding": encoding}


def _row_filter_matches(predicate: tuple, row: dict) -> bool:
    # Docstring: Whether ``row`` -- decoded Python values by column -- passes the filter.
    # Unknown (NULL) counts as no match, exactly as in a SQL WHERE clause.

    tree, kinds, context = predicate
    return _row_filter_value(tree, row, kinds, context) is True


def _row_filter_value(node: tuple, row: dict, kinds: dict, context: dict) -> bool | None:
    tag = node[0]
    if tag in ("and", "or"):
        # AND stops at the first False, OR at the first True; a NULL otherwise wins.
        stop = tag == "or"
        result: bool | None = not stop
        for child in node[1]:
            value = _row_filter_value(child, row, kinds, context)
            if value is stop:
                return stop
            if value is None:
                result = None
        return result
    if tag == "not":
        value = _row_filter_value(node[1], row, kinds, context)
        return None if value is None else not value
    operand = node[1]
    if isinstance(operand, str):
        value, kind = row.get(operand), kinds[operand]
    else:
        value = _expression_value(operand, row, context)
        kind = _operand_kind(operand, kinds)
    if tag == "null":
        return (value is None) != node[2]
    if value is None:
        return None
    if tag == "cmp":
        return _row_filter_compare(value, node[2], node[3][1], kind)
    if tag == "in":
        hit = any(_row_filter_compare(value, "=", literal[1], kind) for literal in node[3])
        return hit != node[2]
    if tag == "like":
        hit = _row_filter_like(node[3][1], node[4]).fullmatch(str(value).rstrip(" ")) is not None
        return hit != node[2]
    inside = _row_filter_compare(value, ">=", node[3][1], kind) and _row_filter_compare(
        value, "<=", node[4][1], kind
    )
    return inside != node[2]


def _operand_kind(operand: str | tuple, kinds: dict) -> str | None:
    # Docstring: The kind a validated operand evaluates to (see _expression_kind).

    if isinstance(operand, str):
        return kinds[operand]
    result = _EXPRESSION_FUNCTIONS[operand[1]][2]
    return _operand_kind(operand[2][0], kinds) if result == "same" else result


def _row_filter_like(pattern: str, escape: str) -> re.Pattern:
    # Docstring: Compile a LIKE pattern (trailing blanks already removed) to a regex.

    key = (pattern, escape)
    compiled = _ROW_FILTER_LIKE_CACHE.get(key)
    if compiled is None:
        parts = []
        index = 0
        while index < len(pattern):
            character = pattern[index]
            if character == escape:
                index += 1
                parts.append(re.escape(pattern[index]))
            elif character == "%":
                parts.append(".*")
            elif character == "_":
                parts.append(".")
            else:
                parts.append(re.escape(character))
            index += 1
        compiled = re.compile("".join(parts), re.DOTALL)
        if len(_ROW_FILTER_LIKE_CACHE) >= 256:
            _ROW_FILTER_LIKE_CACHE.clear()
        _ROW_FILTER_LIKE_CACHE[key] = compiled
    return compiled


def _row_filter_compare(value: Any, op: str, literal: Any, kind: str | None) -> bool:
    if kind in ("string", "nstring"):
        # Pad to equal width: SQL compares CHAR and VARCHAR as if blank-padded.
        value = str(value)
        width = max(len(value), len(literal))
        value, literal = value.ljust(width), literal.ljust(width)
    elif kind == "timestamp" and isinstance(value, datetime) and value.tzinfo is not None:
        # The decoder tags year-1 values UTC only so PySpark accepts them.
        value = value.replace(tzinfo=None)
    if op == "=":
        return value == literal
    if op == "<>":
        return value != literal
    if op == "<":
        return value < literal
    if op == "<=":
        return value <= literal
    if op == ">":
        return value > literal
    return value >= literal


def _validated_volume_location(location: str, option_name: str, options: dict[str, str]) -> str:
    if not os.path.isabs(location):
        # 116: Option '{}' must be an absolute path
        raise ValueError(_m(116, option_name))
    normalized = os.path.normpath(location)
    if normalized != location.rstrip("/") or any(
        part in {".", ".."} for part in location.split("/")
    ):
        # 117: Option '{}' must not contain traversal
        raise ValueError(_m(117, option_name))
    if options.get("hostname"):
        parts = normalized.split("/")
        if len(parts) < 5 or parts[1] != "Volumes" or any(not part for part in parts[2:5]):
            # 118: Option '{}' must be a Unity Catalog Volume path under
            # /Volumes/<catalog>/<schema>/<volume>
            raise ValueError(_m(118, option_name))
    return normalized


def _newest_created_entry_mtime(path: str, recursive: bool = False) -> float:
    # Docstring: Return the newest storage-assigned timestamp without trusting directory updates.
    #
    # Considers only the creation timestamps of the *files* found beneath ``path``.
    # Every artifact this inspects is created with O_EXCL and never rewritten, so a
    # file's mtime is its creation time.
    #
    # Directory mtimes are excluded because their meaning is filesystem-specific:
    # a local POSIX filesystem advances them when entries are *removed*, while a
    # Volume settles them to a creation-like whole second but briefly surfaces a
    # transient post-mutation value first. Either way, cleaning an artifact's
    # contents could make the artifact look newly created to a caller sampling at
    # the wrong moment, keeping a stale lease alive. The scanned directory's own
    # timestamp is used only when it contains no files at all, where it bounds the
    # age rather than extending it.

    flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0) | getattr(os, "O_NOFOLLOW", 0)
    root = os.open(path, flags)
    newest: float | None = None
    root_mtime = os.fstat(root).st_mtime
    stack = [root]
    try:
        while stack:
            descriptor = stack.pop()
            try:
                with os.scandir(descriptor) as entries:
                    for entry in entries:
                        metadata = entry.stat(follow_symlinks=False)
                        if not stat.S_ISDIR(metadata.st_mode):
                            created_at = metadata.st_mtime
                            newest = created_at if newest is None else max(newest, created_at)
                        elif recursive:
                            stack.append(os.open(entry.name, flags, dir_fd=descriptor))
            finally:
                os.close(descriptor)
        return root_mtime if newest is None else newest
    except BaseException:
        for descriptor in stack:
            os.close(descriptor)
        raise


def _staging_subdirectories(path: str) -> list[str]:
    # Docstring: Immediate subdirectory paths of ``path``; empty if it is absent or unreadable.
    #
    # Best-effort helper for the retention sweep: a missing path (nothing staged) is not
    # an error, and a scan failure must never fail a read -- the sweep is a background
    # safety net.

    try:
        with os.scandir(path) as entries:
            return [entry.path for entry in entries if entry.is_dir(follow_symlinks=False)]
    except FileNotFoundError:
        return []
    except OSError:
        # 119: Cannot scan Informix snapshot staging path: {}
        logging.getLogger(__name__).warning(_m(119, path), exc_info=True)
        return []


def _remove_candidate_tree_at(parent_descriptor: int, name: str) -> None:
    flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0) | getattr(os, "O_NOFOLLOW", 0)
    root = os.open(name, flags, dir_fd=parent_descriptor)
    stack: list[tuple[int, os.ScandirIterator, str | None]] = [(root, os.scandir(root), None)]
    try:
        while stack:
            descriptor, entries, child_name = stack[-1]
            try:
                entry = next(entries)
            except StopIteration:
                entries.close()
                os.close(descriptor)
                stack.pop()
                if stack and child_name is not None:
                    os.rmdir(child_name, dir_fd=stack[-1][0])
                continue
            metadata = entry.stat(follow_symlinks=False)
            if stat.S_ISDIR(metadata.st_mode) and not stat.S_ISLNK(metadata.st_mode):
                child = os.open(entry.name, flags, dir_fd=descriptor)
                stack.append((child, os.scandir(child), entry.name))
            else:
                os.unlink(entry.name, dir_fd=descriptor)
    finally:
        while stack:
            descriptor, entries, _ = stack.pop()
            entries.close()
            os.close(descriptor)


def _dropped_mount_error(error: BaseException) -> OSError | None:
    # Docstring: Return the ENOTCONN in ``error``'s cause chain, if a dropped mount caused it.
    #
    # Snapshot page staging is the only remaining Volume user, but it still touches
    # the mount from several calls -- open, makedirs, rename, listdir -- and only
    # ``os.open`` goes through the retry helper. When the mount drops, whichever
    # call runs first raises ENOTCONN, so no single site can be the place this is
    # handled; production saw it surface from two different sites in consecutive
    # updates.
    #
    # Classifying at the read boundary instead covers every site at once. The
    # caller converts this into the same empty-batch checkpoint retry it already
    # uses for a transiently inaccessible Volume, which is exactly what a remount
    # needs: the mount returns within seconds and the next read proceeds.

    seen: set[int] = set()
    cursor: BaseException | None = error
    while cursor is not None and id(cursor) not in seen:
        seen.add(id(cursor))
        if isinstance(cursor, OSError) and cursor.errno == errno.ENOTCONN:
            return cursor
        cursor = cursor.__cause__ or cursor.__context__
    return None


def _open_state_entry_with_retry(path: str, flags: int, *, dir_fd: int | None = None) -> int:
    # Docstring: Open one state entry, retrying transient Volume permission and mount failures.

    last_error: OSError | None = None
    for attempt in range(_SHARED_STATE_OPEN_ATTEMPTS):
        try:
            return os.open(path, flags, dir_fd=dir_fd)
        except OSError as error:
            if error.errno not in {errno.EPERM, errno.EACCES, errno.ENOTCONN}:
                raise
            if error.errno == errno.ENOTCONN:
                # The Volume's FUSE mount dropped: the filesystem itself is
                # briefly gone rather than this entry being denied. Observed in
                # production taking down 23 flows at once, every one failing on
                # the shared-state root, while the mount was healthy again
                # moments later. A remount settles on a scale of seconds, not the
                # milliseconds a permission blip needs, so this backs off harder
                # (and skips the symlink check below, which exists only to
                # disambiguate EPERM and cannot stat an absent filesystem).
                last_error = error
                if attempt + 1 < _SHARED_STATE_OPEN_ATTEMPTS:
                    delay = min(0.25 * (2**attempt), _SHARED_STATE_MOUNT_RETRY_MAX_SECONDS)
                    time.sleep(random.uniform(delay / 2, delay))
                continue
            # Some filesystems report EPERM rather than ELOOP for O_NOFOLLOW.
            # Preserve the security distinction between a transiently denied
            # Volume entry and a replaceable symlink.
            try:
                entry = os.stat(path, dir_fd=dir_fd, follow_symlinks=False)
            except OSError:
                entry = None
            if entry is not None and stat.S_ISLNK(entry.st_mode):
                # 120: Informix shared-state path traverses symlink: '{}'
                raise InformixError(_m(120, path)) from error
            last_error = error
            if attempt + 1 < _SHARED_STATE_OPEN_ATTEMPTS:
                delay = min(0.01 * (2**attempt), 0.25)
                time.sleep(random.uniform(delay / 2, delay))
    # 121: Informix shared state is temporarily inaccessible: '{}'
    raise SharedStateAccessUnavailable(_m(121, path)) from last_error


def _open_state_directory(root: str, path: str) -> int:
    # Docstring: Open a directory beneath root without following a replaceable symlink.

    if os.path.commonpath((root, path)) != root:
        # 122: Informix shared-state path escapes '{}': '{}'
        raise InformixError(_m(122, root, path))
    flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0) | getattr(os, "O_NOFOLLOW", 0)
    descriptor = _open_state_entry_with_retry(root, flags)
    try:
        relative = os.path.relpath(path, root)
        for part in () if relative == "." else relative.split(os.sep):
            try:
                child = _open_state_entry_with_retry(part, flags, dir_fd=descriptor)
            except OSError as error:
                if error.errno in {errno.ELOOP, errno.ENOTDIR}:
                    # 123: Informix shared-state path traverses symlink or non-directory: '{}'
                    raise InformixError(_m(123, path)) from error
                raise
            os.close(descriptor)
            descriptor = child
        return descriptor
    except BaseException:
        os.close(descriptor)
        raise


def _open_state_file(root: str, path: str) -> int:
    parent = os.path.dirname(path)
    directory = _open_state_directory(root, parent)
    try:
        try:
            return _open_state_entry_with_retry(
                os.path.basename(path),
                os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0),
                dir_fd=directory,
            )
        except OSError as error:
            if error.errno == errno.ELOOP:
                # 124: Informix shared-state path traverses symlink '{}'
                raise InformixError(_m(124, path)) from error
            raise
    finally:
        os.close(directory)


def _redirect_allowlist(value: str) -> frozenset[tuple[str, int]]:
    result: set[tuple[str, int]] = set()
    for item in filter(None, (part.strip() for part in value.split(","))):
        host, separator, port_text = item.rpartition(":")
        if not separator or not host or not port_text.isdigit() or not 1 <= int(port_text) <= 65535:
            # 125: redirect.allowlist entries must be exact host:numeric-port pairs
            raise ValueError(_m(125))
        result.add((host, int(port_text)))
    return frozenset(result)


# These dataclasses generate only the methods the connector uses: none is printed,
# and only Column is compared by value (the schema-change check compares column
# tuples). The merged deployment pickles every generated method, so the rest are off.
@dataclass(frozen=True, repr=False)
class Column:
    name: str
    type_name: str
    nullable: bool = True
    length: int | None = None
    precision: int | None = None
    scale: int | None = None
    cdc_supported: bool = True

    @classmethod
    def parse(cls, raw: dict[str, Any]) -> "Column":
        return cls(
            name=str(raw["name"]),
            type_name=str(raw.get("type_name") or raw.get("type") or "VARCHAR").upper(),
            nullable=bool(raw.get("nullable", True)),
            length=_optional_int(raw.get("length")),
            precision=_optional_int(raw.get("precision")),
            scale=_optional_int(raw.get("scale")),
            cdc_supported=bool(raw.get("cdc_supported", True)),
        )


@dataclass(frozen=True, eq=False, repr=False)
class Table:
    database: str
    owner: str
    name: str
    columns: tuple[Column, ...]
    primary_keys: tuple[str, ...]
    incarnation: str | None = None
    # True when primary_keys came from the primary.keys option rather than the
    # catalog, so a schema refresh preserves them instead of reverting to the
    # catalog's (empty, for a physically keyless table). Not part of the schema
    # fingerprint -- only the resulting primary_keys are.
    key_override: bool = False
    # True when that override is the ``primary.keys: "*"`` wildcard. A schema refresh then
    # re-expands the key to the refreshed columns instead of preserving the old list, so an
    # added column joins the key; the schema transition accepts that growth (see
    # _PRIMARY_KEYS_WILDCARD). Not fingerprinted either.
    key_wildcard: bool = False
    # The columns a ``"* except(...)"`` wildcard leaves out of the key, kept so a refresh
    # re-expands it the same way; empty for a bare ``*``. Not fingerprinted: the resolved
    # primary_keys are, so changing the list changes the key and needs a full refresh.
    key_wildcard_except: tuple[str, ...] = ()
    # Per-column key index direction, parallel to primary_keys: True == DESC.
    # Empty means all-ascending (the common case) -- paging then uses the default
    # lexicographic order untouched. A mixed/descending key carries the full
    # per-column list so snapshot paging and the key bound match the index's own
    # scan order instead of forcing a sort. Derived from the same index as the
    # keys, so it is not fingerprinted separately. Unknown for a primary.keys
    # override (no matching index), so it is cleared to () there.
    key_descending: tuple[bool, ...] = ()
    # A nullable-column UNIQUE index the connector may promote to the key when the
    # table sets allow.nullable.index (columns + parallel directions). A catalog
    # fact, populated only when no PK and no all-NOT-NULL unique index exist; not
    # fingerprinted. ``key_from_nullable_index`` records that the current
    # primary_keys came from it, so a schema refresh preserves the promotion.
    nullable_index_key: tuple[str, ...] = ()
    nullable_index_descending: tuple[bool, ...] = ()
    key_from_nullable_index: bool = False
    # The include_columns / exclude_columns selection as (mode, sorted names), or None.
    # ``columns`` then holds only the selected columns, and ``catalog_columns`` every
    # catalog column, which a positional `.unl` extract still needs. The selection and
    # the canonical row_filter text are fingerprinted when set, so changing either on a
    # running stream fails closed rather than silently diverging from rows already landed.
    column_selection: tuple[str, tuple[str, ...]] | None = None
    catalog_columns: tuple[Column, ...] = ()
    # Columns of a type the connector can't read, left out of ``columns`` (which sets
    # ``catalog_columns`` too) so the rest of the table is ingested; see
    # _leave_out_unsupported_columns. Re-derived from the catalog on every resolve, so
    # neither fingerprinted nor kept in schema history: a table without such columns keeps
    # its fingerprint, and one added at the source later is left out without a transition.
    unsupported_columns: tuple[Column, ...] = ()
    row_filter: str | None = None
    # rename_columns as sorted (source, destination) pairs, or None. Internally every
    # column keeps its source name; only what the connector reports -- the schema, the
    # rows, the key -- uses the destination names. Fingerprinted when set, like the
    # selection, since rows already landed carry the old names.
    column_renames: tuple[tuple[str, str], ...] | None = None
    # transform_columns as sorted (column, canonical expression) pairs, or None, and the
    # id of the HASH key they use; fingerprinted like the renames.
    column_transforms: tuple[tuple[str, str], ...] | None = None
    transform_key_id: str | None = None

    @property
    def exposed_name(self) -> str:
        return _join_identity(self.owner, self.name)

    @property
    def identity(self) -> str:
        return _join_identity(self.database, self.owner, self.name)

    @property
    def native_identity(self) -> str:
        return f"{self.database}:{_sql_identifier(self.owner)}.{_sql_identifier(self.name)}"

    @classmethod
    def parse(cls, raw: dict[str, Any], default_database: str) -> "Table":
        database = str(raw.get("database") or default_database)
        owner = str(raw["owner"])
        name = str(raw["name"])
        for part in (database, owner, name):
            if not _IDENTIFIER.fullmatch(part):
                # 126: Unsafe Informix identifier returned by metadata: {!r}
                raise InformixError(_m(126, part))
        columns = tuple(Column.parse(c) for c in raw.get("columns", ()))
        pks = tuple(str(v) for v in raw.get("primary_keys", ()))
        column_names = tuple(column.name for column in columns)
        for column_name in column_names:
            if not _IDENTIFIER.fullmatch(column_name):
                # 127: Unsafe Informix column identifier returned by metadata: {!r}
                raise InformixError(_m(127, column_name))
        normalized_names = tuple(column_name.casefold() for column_name in column_names)
        if len(normalized_names) != len(set(normalized_names)):
            # 128: Duplicate column names for {}.{}.{}
            raise InformixError(_m(128, database, owner, name))
        reserved = {column.casefold() for column in _INTERNAL_COLUMNS}
        collisions = sorted(
            column_name for column_name in column_names if column_name.casefold() in reserved
        )
        if collisions:
            # 129: Source columns collide with reserved Informix metadata columns: {!r}
            raise InformixError(_m(129, collisions))
        if len(pks) != len(set(pks)):
            # 130: Duplicate primary-key columns for {}.{}.{}
            raise InformixError(_m(130, database, owner, name))
        known = {c.name for c in columns}
        if not columns or any(pk not in known for pk in pks):
            raise InformixError(f"Invalid metadata for {database}.{owner}.{name}")
        incarnation_value = raw.get("incarnation")
        incarnation = None if incarnation_value is None else str(incarnation_value)
        key_descending = tuple(bool(v) for v in raw.get("key_descending", ()))
        if key_descending and len(key_descending) != len(pks):
            # 131: Key direction metadata for {}.{}.{} does not match its {} primary-key column(s)
            raise InformixError(_m(131, database, owner, name, len(pks)))
        nullable_index_raw = list(raw.get("nullable_index_key", ()))
        nullable_index_key = tuple(str(pair[0]) for pair in nullable_index_raw)
        nullable_index_descending = tuple(bool(pair[1]) for pair in nullable_index_raw)
        for column_name in nullable_index_key:
            if column_name not in known:
                # 132: Nullable-index candidate for {}.{}.{} names unknown column {!r}
                raise InformixError(_m(132, database, owner, name, column_name))
        # Only schema-history state carries these two; a catalog description never does.
        selection_raw = raw.get("column_selection")
        selection = None
        if selection_raw is not None:
            mode, names = selection_raw
            if mode not in {"include", "exclude"}:
                # 133: Invalid column selection metadata for {}.{}.{}
                raise InformixError(_m(133, database, owner, name))
            selection = (str(mode), tuple(str(value) for value in names))
        row_filter = raw.get("row_filter")
        transforms_raw = raw.get("column_transforms")
        transforms = (
            None
            if transforms_raw is None
            else tuple((str(name), str(expression)) for name, expression in transforms_raw)
        )
        renames_raw = raw.get("column_renames")
        renames = (
            None
            if renames_raw is None
            else tuple((str(source), str(target)) for source, target in renames_raw)
        )
        return cls(
            database,
            owner,
            name,
            columns,
            pks,
            incarnation,
            key_descending=key_descending,
            nullable_index_key=nullable_index_key,
            nullable_index_descending=nullable_index_descending,
            column_selection=selection,
            row_filter=None if row_filter is None else str(row_filter),
            column_renames=renames,
            column_transforms=transforms,
            transform_key_id=(
                None if raw.get("transform_key_id") is None else str(raw["transform_key_id"])
            ),
        )


@dataclass(eq=False, repr=False)
class Transaction:
    tx_id: int
    begin_lsn: int
    records: list[dict[str, Any]] = field(default_factory=list)
    pending_before: dict[str, Any] | None = None
    # One SPILLED record per table whose changes were written to staged pages (_CdcSpill).
    spilled: list[dict[str, Any]] = field(default_factory=list)
    # One SPILLING record per table while it is open: its changes went to pages, so they no
    # longer show which tables it touches.
    spilling: list[dict[str, Any]] = field(default_factory=list)
    last_lsn: int = field(init=False)

    def __post_init__(self) -> None:
        self.last_lsn = self.begin_lsn

    def advance(self, record: dict[str, Any]) -> int:
        lsn = _lsn(record)
        if lsn < self.last_lsn:
            # 134: CDC LSN regressed in transaction {}: {} < {}
            raise InformixError(_m(134, self.tx_id, lsn, self.last_lsn))
        self.last_lsn = lsn
        return lsn

    def append(self, record: dict[str, Any]) -> None:
        self.advance(record)
        op = _operation(record)
        if op == "BEFORE_UPDATE":
            if self.pending_before is not None:
                # 135: Unpaired BEFORE_UPDATE in transaction {}
                raise InformixError(_m(135, self.tx_id))
            self.pending_before = record
            return
        if op == "AFTER_UPDATE":
            if self.pending_before is None:
                # 136: AFTER_UPDATE without BEFORE_UPDATE in transaction {}
                raise InformixError(_m(136, self.tx_id))
            merged = dict(record)
            merged["op"] = "UPDATE"
            merged["before"] = self.pending_before.get("before", self.pending_before.get("row"))
            merged["after"] = record.get("after", record.get("row"))
            # The merged record is sequenced at the after-image. Keep the before-image's
            # own, strictly earlier, log position too: the append path's old-key
            # tombstone for a key-changing UPDATE is sequenced there, so it never ties
            # with the new key's after-image on the cursor.
            merged["before_lsn"] = _lsn(self.pending_before)
            self.pending_before = None
            self.records.append(merged)
            return
        self.records.append(record)

    def discard(self, lsn: int) -> None:
        # DISCARD carries the rollback cutoff, not the forward position of the
        # DISCARD control record. It may legitimately precede the latest data LSN.
        self.records = [r for r in self.records if _lsn(r) < lsn]
        if self.pending_before is not None and _lsn(self.pending_before) >= lsn:
            self.pending_before = None


@dataclass(frozen=True, eq=False, repr=False)
class CommittedTransaction:
    tx_id: int
    begin_lsn: int
    commit_lsn: int
    restart_lsn: int
    records: tuple[dict[str, Any], ...]
    # UTC epoch seconds from the COMMIT record (kind 2); None if the record carried none.
    # Stamped onto every row of the transaction as ``_informix_commit_time``.
    commit_time: int | None = None
    # The SPILLED records naming the staged pages that hold the rest of its changes.
    spilled: tuple[dict[str, Any], ...] = ()


class TransactionBuffer:
    # Docstring: Buffering for interleaved Informix transactions.

    def __init__(self) -> None:
        self.open: dict[int, Transaction] = {}

    def feed(self, raw: dict[str, Any]) -> CommittedTransaction | None:
        record = _normalise_record(raw)
        op = _operation(record)
        if op in {"TIMEOUT", "METADATA"}:
            return None
        if op == "ERROR":
            detail = record.get("message") or record.get("payload") or ""
            # 137: Informix CDC error {} with flags {}: {}
            raise InformixError(
                _m(137, (record.get("error", "unknown")), (record.get("flags", "unknown")), detail)
            )
        tx_id = _tx_id(record)
        if op == "BEGIN":
            if tx_id in self.open:
                # 138: Duplicate CDC BEGIN for transaction {}
                raise InformixError(_m(138, tx_id))
            self.open[tx_id] = Transaction(tx_id, _lsn(record))
            return None
        tx = self.open.get(tx_id)
        if tx is None:
            # 139: CDC {} for unknown transaction {}
            raise InformixError(_m(139, op, tx_id))
        if op in _DATA_OPS:
            tx.append(record)
            return None
        if op == "SPILLED":
            tx.spilled.append(record)
            return None
        if op == "SPILLING":
            tx.spilling.append(record)
            return None
        if op == "DISCARD":
            tx.discard(_lsn(record))
            return None
        if op == "ROLLBACK":
            tx.advance(record)
            del self.open[tx_id]
            return None
        if op != "COMMIT":
            # 140: Unknown Informix CDC operation {!r}
            raise InformixError(_m(140, op))
        if tx.pending_before is not None:
            # 141: Transaction {} committed with unpaired BEFORE_UPDATE
            raise InformixError(_m(141, tx_id))
        end = tx.advance(record)
        del self.open[tx_id]
        restart = min((item.begin_lsn for item in self.open.values()), default=end)
        commit_time = record.get("timestamp")
        return CommittedTransaction(
            tx_id, tx.begin_lsn, end, restart, tuple(tx.records), commit_time, tuple(tx.spilled)
        )


def _spill_scope(scope: Any) -> str | None:
    # Docstring: The scope spilled pages are named under, or None without a valid scope.
    #
    # The pipeline's, not the update's: a later update reading a transaction again finds the
    # pages and the Lakebase record an earlier one left, so a cancelled update leaves no copy
    # behind. A scope outside a pipeline (random per registration) stays as it is.

    if not isinstance(scope, str) or _PIPELINE_SCOPE.fullmatch(scope) is None:
        return None
    pipeline, separator, _update = scope.partition("_@_")
    return pipeline.replace("-", "") if separator else scope


def _spill_run(layout: str, begin: int, tx_id: int, record: dict[str, Any]) -> str:
    # Docstring: A run's name: its table's capture layout, its transaction's BEGIN LSN and ID,
    # and a digest of the table's first change in it. A reinitialized log reuses positions, so
    # the digest keeps a later transaction from taking an earlier one's pages or record.

    first = json.dumps(
        [record.get("lsn"), record.get("op"), record.get("row")], sort_keys=True, default=str
    )
    return f"{layout}-{begin}-{tx_id}-{hashlib.sha256(first.encode()).hexdigest()[:12]}"


def _spill_run_consumed(record: dict[str, Any]) -> bool:
    # Docstring: Whether every channel a run's record requires has committed past it.

    required, done = record.get("required"), record.get("done") or {}
    return isinstance(required, list) and bool(required) and all(done.get(c) for c in required)


class _CdcSpill:
    # Docstring: One poll's writer for open transactions that outgrow cdc.spill.records.
    #
    # Once an open transaction holds more changes than ``threshold``, those changes and
    # every later one go to staged pages of up to _CDC_SPILL_PAGE_RECORDS, a run per table,
    # instead of the poll's records. A page never ends between an UPDATE's before- and
    # after-image, so each page shapes on its own. At COMMIT the transaction gets one
    # SPILLED record per table naming its run, which the transaction buffer keeps in place
    # of the changes; a ROLLBACK deletes the runs. A DISCARD (rollback to a savepoint) drops
    # the changes it covers still in memory and records the LSN range for the pages, which
    # readers skip. A table's run is named by its capture layout, the BEGIN LSN, the
    # transaction and its first change (see _spill_run), so a poll that reads the
    # transaction again, the other channel's, or a later update's, names the same pages.

    def __init__(self, threshold, write, delete, layouts, scope, natives, commit=None) -> None:
        self.threshold = threshold
        self._write = write  # (native identity, table, run, page index, records)
        self._delete = delete  # (native identity, run)
        self._commit = commit  # (native identity, run, commit LSN), or None
        self._layouts = layouts  # logical identity -> capture layout hash
        self._scope = scope
        self._natives = natives  # logical identity -> native identity
        self._open: dict[int, tuple[int, dict[str, dict[str, Any]]]] = {}

    def holds(self, tx_id: int) -> bool:
        return tx_id in self._open

    def start(self, tx_id: int, begin_lsn: int, records: list[dict[str, Any]]) -> list[str]:
        # Docstring: Start spilling a transaction with the changes it holds; return the tables
        # it has a run for.

        self._open[tx_id] = (begin_lsn, {})
        for record in records:
            if record["op"] == "DISCARD":
                self.discard(tx_id, int(record["lsn"]))
            else:
                self.add(record)
        return list(self._open[tx_id][1])

    def add(self, record: dict[str, Any]) -> bool:
        # Docstring: Add one change; return whether it began its table's run.

        tx_id = int(record.get("tx_id") or 0)
        begin, parts = self._open[tx_id]
        table = str(record.get("table") or "")
        part = parts.get(table)
        began = part is None
        if part is None:
            run = _spill_run(self._layouts.get(table, ""), begin, tx_id, record)
            part = parts[table] = {
                "run": run,
                "pages": 0,
                "rows": [],
                "bytes": 0,
                "last": 0,
                "discarded": [],
                "ops": set(),
            }
        # A capture label is the table's place in one shard's capture list: the other
        # channel's shard can list it elsewhere, and both write the same pages.
        part["rows"].append(
            {key: value for key, value in record.items() if key not in ("label", "capture_label")}
        )
        part["ops"].add(record["op"])
        part["last"] = int(record["lsn"])
        # Wide text or byte columns end a page early, well inside the staged-page bound.
        part["bytes"] += 64 + sum(
            len(value) if isinstance(value, (str, bytes, bytearray)) else 16
            for value in (record.get("row") or {}).values()
        )
        if record["op"] != "BEFORE_UPDATE" and (
            len(part["rows"]) >= _CDC_SPILL_PAGE_RECORDS or part["bytes"] >= 32 << 20
        ):
            self._flush(table, part)
        return began

    def _flush(self, table: str, part: dict[str, Any]) -> None:
        native = self._natives.get(table, table)
        self._write(native, table, part["run"], part["pages"], part["rows"])
        part["pages"] += 1
        part["rows"] = []
        part["bytes"] = 0

    def discard(self, tx_id: int, lsn: int) -> None:
        for part in self._open[tx_id][1].values():
            part["rows"] = [record for record in part["rows"] if int(record["lsn"]) < lsn]
            if part["pages"] and part["last"] >= lsn:
                part["discarded"].append([lsn, part["last"]])

    def drop(self, tx_id: int) -> None:
        _begin, parts = self._open.pop(tx_id)
        for table, part in parts.items():
            if part["pages"]:
                self._delete(self._natives.get(table, table), part["run"])

    def finish(self, tx_id: int, commit_lsn: int | None = None) -> list[dict[str, Any]]:
        # Docstring: The SPILLED records of a transaction at its COMMIT (``commit_lsn``), which
        # each run's record also learns.

        _begin, parts = self._open.pop(tx_id)
        spilled = []
        for table, part in parts.items():
            if part["rows"]:
                self._flush(table, part)
            if part["pages"]:
                native = self._natives.get(table, table)
                if self._commit is not None and commit_lsn is not None:
                    self._commit(native, part["run"], commit_lsn)
                spilled.append(
                    {
                        "op": "SPILLED",
                        "tx_id": tx_id,
                        "lsn": part["last"],
                        "table": table,
                        "native_identity": native,
                        "pipeline_scope": self._scope,
                        "run": part["run"],
                        "pages": part["pages"],
                        "discarded": part["discarded"],
                        "ops": sorted(part["ops"]),
                    }
                )
        return spilled


def _spilled_page_rows(read_page, part, page_index, tx, table, options, **shape):
    # Docstring: One spilled page's rows on one channel, shaped as _read_stream shapes an
    # in-memory transaction. ``tx`` is (tx_id, begin, commit, restart, commit time), ``shape``
    # the deletes, tombstones and encoding _project_transaction takes.

    _header, records = read_page(
        part["native_identity"],
        part["table"],
        part["pipeline_scope"],
        _CDC_SPILL_SCHEMA,
        part["run"],
        page_index,
    )
    discarded = part["discarded"]
    buffer = Transaction(int(tx[0]), int(tx[1]))
    for record in records:
        record = _normalise_record(record)
        if not any(low <= record["lsn"] <= high for low, high in discarded):
            buffer.append(record)
    if buffer.pending_before is not None:
        # A page never ends between an UPDATE's images, so this transaction committed with
        # one unpaired, as an in-memory one fails at its COMMIT.
        # 141: Transaction {} committed with unpaired BEFORE_UPDATE
        raise InformixError(_m(141, buffer.tx_id))
    committed = CommittedTransaction(
        int(tx[0]), int(tx[1]), int(tx[2]), int(tx[3]), tuple(buffer.records), tx[4]
    )
    for row in _project_transaction(committed, table, **shape):
        yield _coerce_variable_decimal_values(row, table, options)


class _SpilledRows:
    # Docstring: A batch that is one spilled transaction: its rows on one channel, shaped
    # from the staged pages only when iterated (the simple reader), or served page by page
    # from executors through ``descriptors`` (the partitioned reader), so the driver never
    # holds them.

    def __init__(self, read_page, parts, tx, table, options, **shape) -> None:
        self._read_page = read_page
        self.parts = parts
        self.tx = (tx.tx_id, tx.begin_lsn, tx.commit_lsn, tx.restart_lsn, tx.commit_time)
        self.table = table
        self.shape = shape
        self._options = options
        self._rows: Iterator[dict[str, Any]] | None = None

    def __iter__(self) -> "_SpilledRows":
        return self

    def __next__(self) -> dict[str, Any]:
        if self._rows is None:
            self._rows = itertools.chain.from_iterable(
                _spilled_page_rows(
                    self._read_page, part, page, self.tx, self.table, self._options, **self.shape
                )
                for part in self.parts
                for page in range(part["pages"])
            )
        return next(self._rows)

    def descriptors(self, extra: dict[str, Any]) -> list[dict[str, Any]]:
        table = _wire_table(self.table)
        return [
            {
                "kind": "spill",
                "part": part,
                "page_index": page,
                "tx": list(self.tx),
                "table": table,
                **self.shape,
                **extra,
            }
            for part in self.parts
            for page in range(part["pages"])
        ]


@dataclass(frozen=True, eq=False, repr=False)
class _SharedCdcSnapshot:
    # Docstring: A coherent (schema, log position, transactions) view a consumer poll reads
    # from a shard in place of touching Informix itself.

    table: "Table"
    fingerprint: str
    min_lsn: int
    current_lsn: int
    committed: list
    caught_up: bool
    open_begin: int | None
    # Where the daemon's latest read went idle (its TIMEOUT LSN), or None.
    reached_lsn: int | None = None
    # Where that idle read started (the shard's restart LSN), or None.
    read_start_lsn: int | None = None


class _SharedCdcShard:
    # Docstring: One shard of the sharded daemon-reader CDC pool.
    #
    # A single daemon thread owns the Informix I/O for this shard's tables -- it reads
    # the shared CDC session, fetches schema, and samples the log bounds -- and publishes
    # the result here. Consumer streaming polls read the fanned-out transactions and the
    # schema/log position from memory rather than connecting themselves. All mutable
    # state is guarded by ``condition``.

    def __init__(self) -> None:
        self.condition = threading.Condition()
        # identity -> {table, capture, checkpoint, floor, last_seen}
        self.subscribers: dict[str, dict[str, Any]] = {}
        self.buffers: dict[str, deque] = {}
        # highest commit_lsn appended per table: dedups re-delivery and lets a lagging
        # or late subscriber replay its own history exactly once.
        self.cursors: dict[str, int] = {}
        self.shared_restart: int | None = None
        # coherent snapshot, published atomically at the end of each read cycle
        self.schema: dict[str, "Table"] = {}
        self.min_lsn: int | None = None
        self.current_lsn: int | None = None
        self.reached_lsn: int | None = None
        self.read_start_lsn: int | None = None
        self.caught_up = False
        self.open_begins: dict[str, int | None] = {}
        self.ready = False
        # daemon configuration, set by the first subscriber
        self.reader_factory: Callable[[], Any] | None = None
        self.timeout_seconds = 5
        self.max_records = _DEFAULT_CDC_MAX_RECORDS
        self.buffer_cap = _DEFAULT_SHARED_CDC_BUFFER
        self.subscriber_ttl = _SHARED_CDC_SUBSCRIBER_TTL_SECONDS
        # The daemon's catalog tables, re-read only when they change; daemon-thread only.
        self.catalog = _ShardCatalog()

    def configure(
        self, *, reader_factory, timeout_seconds, max_records, buffer_cap, subscriber_ttl
    ):
        with self.condition:
            if self.reader_factory is None:
                self.reader_factory = reader_factory
            self.timeout_seconds = timeout_seconds
            self.max_records = max_records
            self.buffer_cap = buffer_cap
            self.subscriber_ttl = subscriber_ttl

    # ---- consumer side ------------------------------------------------------

    def subscribe(self, identity, table, capture, checkpoint_commit_lsn, floor_lsn):
        with self.condition:
            existing = self.subscribers.get(identity)
            if (
                existing is not None
                and existing["capture"] == capture
                and _schema_fingerprint(existing["table"]) != _schema_fingerprint(table)
            ):
                # Another flow reading the table under other options (a schema change
                # changes the capture): the shard keeps the first one's table, buffer and
                # coverage, and this one reads directly, rejecting the view's layout.
                return
            if existing is not None and existing["capture"] != capture:
                # The table's columns changed (its consumer moved to a new schema): what
                # was buffered under the old capture lacks the new columns, so drop it and
                # treat the table as new, re-read from its floor under the new capture.
                self.buffers.pop(identity, None)
                self.cursors.pop(identity, None)
                existing = None
                # And read the table's catalog entry at the daemon's next cycle, not the
                # next scheduled check.
                self.catalog.force_check()
            elif existing is not None and (
                checkpoint_commit_lsn < existing["checkpoint"] or floor_lsn < existing["floor"]
            ):
                # The checkpoint or floor moved back (a consumer replaying from an earlier
                # commit, or an open transaction older than its floor): the buffer may lack
                # what lies above the new floor and the cursor would skip re-reading it, so
                # start the table over from its floor, on direct reads until covered again.
                self.buffers.pop(identity, None)
                self.cursors.pop(identity, None)
                existing = None
            entry = {
                "table": table,
                "capture": capture,
                "checkpoint": checkpoint_commit_lsn,
                "floor": floor_lsn,
                "last_seen": time.monotonic(),
                # The lowest LSN a daemon read that captured this table was activated
                # at, or None until one has run. The table is *covered* -- its buffer
                # is authoritative from its floor on -- only once that read start is
                # at or below its floor (see _covered). Preserved across re-subscribes;
                # a TTL eviction drops the entry and so resets it.
                "covered_from": None if existing is None else existing.get("covered_from"),
            }
            self.subscribers[identity] = entry
            # Drop what the consumer has durably consumed, as a view does. A consumer on
            # direct reads (the shard not ready, or the table not yet covered) gets no view,
            # so without this its buffer could reach the cap and stop the shard reading.
            buf = self.buffers.setdefault(identity, deque())
            while buf and buf[0].commit_lsn <= checkpoint_commit_lsn:
                buf.popleft()
            # Lower the shared read cursor to admit a newly subscribed or lagging
            # table's history. It only moves backward here; the daemon advances it
            # forward as it reads, but never past the floor of a table it has not yet
            # covered (see ingest). Activating too low is merely wasteful (re-read then
            # discarded per cursor / _recover); too high would skip a laggard's changes.
            if self.shared_restart is None:
                self.shared_restart = floor_lsn
            elif not self._covered(entry):
                self.shared_restart = min(self.shared_restart, floor_lsn)
            self.condition.notify_all()

    @staticmethod
    def _covered(entry) -> bool:
        # Docstring: Whether a daemon read that captured this subscriber started at or below
        # its floor, so its buffer holds every transaction above that floor.

        covered_from = entry.get("covered_from")
        return covered_from is not None and covered_from <= entry["floor"]

    def snapshot(self, identity, checkpoint_commit_lsn):
        # Docstring: Return a coherent view for one table, or None to fall back to a direct
        # read (daemon not ready yet, or this table is unknown to the daemon).

        with self.condition:
            if not self.ready or identity not in self.schema:
                return None
            entry = self.subscribers.get(identity)
            if entry is None or not self._covered(entry):
                # No daemon read that captured this table has started at or below its
                # floor yet, so its buffer may have a gap right after its checkpoint. A
                # view is taken as authoritative and would skip that gap silently;
                # keep the consumer on direct reads until a covering read is ingested.
                return None
            table = self.schema.get(identity)
            if table is None or self.min_lsn is None or self.current_lsn is None:
                return None
            if self.current_lsn < checkpoint_commit_lsn:
                # The consumer moved on by a direct read past the shard's last read: its log
                # position would look reinitialized (284) or behind a trigger boundary (295).
                return None
            buf = self.buffers.get(identity)
            if buf is None:
                return None
            # Drop durably-consumed transactions; keep the rest (peek, don't pop) so a
            # poll that consumes only part of its budget re-serves the remainder.
            while buf and buf[0].commit_lsn <= checkpoint_commit_lsn:
                buf.popleft()
            committed = list(buf)
            # ``committed`` is the entire retained buffer, so nothing is withheld:
            # the consumer is caught up exactly when the daemon reached end-of-log.
            caught_up = self.caught_up
            return _SharedCdcSnapshot(
                table=table,
                fingerprint=_schema_fingerprint(table),
                min_lsn=self.min_lsn,
                current_lsn=self.current_lsn,
                committed=committed,
                caught_up=caught_up,
                open_begin=self.open_begins.get(identity),
                reached_lsn=self.reached_lsn if caught_up else None,
                read_start_lsn=self.read_start_lsn if caught_up else None,
            )

    # ---- daemon side --------------------------------------------------------

    def live_subscribers(self):
        # Docstring: Drop subscribers past the TTL (a stopped flow must not pin the shard) and
        # return the current set. Caller holds the lock.

        now = time.monotonic()
        for identity in list(self.subscribers):
            if now - self.subscribers[identity]["last_seen"] > self.subscriber_ttl:
                self._evict_locked(identity)
        return dict(self.subscribers)

    def evict(self, identity):
        # Docstring: Drop one subscriber and its state; it re-subscribes on its next poll.

        with self.condition:
            self._evict_locked(identity)

    def _evict_locked(self, identity):
        self.subscribers.pop(identity, None)
        for store in (self.buffers, self.cursors, self.schema, self.open_begins):
            store.pop(identity, None)

    def ingest(self, raw, schema_map, min_lsn, current_lsn, read_start, captures=None):
        # Docstring: Assemble one read's records into transactions, fan them out per table, and
        # publish the coherent snapshot. Returns whether the shard is caught up.
        #
        # ``schema_map`` names the tables the read captured and ``read_start`` the LSN
        # it was activated at; together they record which subscribers it covered.
        # ``captures`` maps each to the capture the read used: a subscriber that has
        # re-subscribed with another since gets nothing from this read.

        buffer = TransactionBuffer()
        committed = []
        timed_out = False
        reached = None
        for record in raw:
            if _operation(record) == "TIMEOUT":
                timed_out = True
                reached = _lsn(record)
            done = buffer.feed(record)
            if done is not None:
                committed.append(done)
        committed.sort(key=lambda tx: (tx.commit_lsn, tx.tx_id))
        with self.condition:
            stale = {
                identity
                for identity, capture in (captures or {}).items()
                if (self.subscribers.get(identity) or {}).get("capture") != capture
            }
            # A subscriber started over (or joined) while this read was in flight, with a
            # floor below where the read began, gets nothing from it: a partial delivery
            # would move its cursor past the transactions the covering read must add.
            stale |= {
                identity
                for identity, sub in self.subscribers.items()
                if not self._covered(sub) and read_start > sub["floor"]
            }
            for tx in committed:
                for identity, sub in self.subscribers.items():
                    if identity in stale or tx.commit_lsn <= self.cursors.get(identity, 0):
                        continue
                    if any(
                        _record_matches(record, sub["table"])
                        for record in itertools.chain(tx.records, tx.spilled)
                    ):
                        self.buffers.setdefault(identity, deque()).append(tx)
                        self.cursors[identity] = tx.commit_lsn
            # A subscriber is covered once a read that captured it was activated at or
            # below its floor: from then on its buffer holds everything above the floor.
            for identity in schema_map:
                entry = self.subscribers.get(identity)
                if entry is None or identity in stale:
                    continue
                previous = entry.get("covered_from")
                entry["covered_from"] = (
                    read_start if previous is None else min(previous, read_start)
                )
            # Resume the next read from the oldest open BEGIN so open transactions are
            # recaptured; per-table cursors above dedup the resulting re-delivery.
            global_open = min((item.begin_lsn for item in buffer.open.values()), default=None)
            if global_open is not None:
                advanced = global_open
            elif timed_out and reached is not None:
                # Idle with nothing open: everything the shard captures up to where the
                # log reader stopped has been delivered, so resume from there. Resuming
                # from the last commit instead rescans the same stretch of a busy log on
                # every poll and can time out before ever passing it. A position held back
                # short of where the read started (a quiet log, see _shared_cdc_snapshot)
                # resumes from the start: the read had nothing to deliver short of it.
                advanced = max(
                    read_start, reached, committed[-1].commit_lsn if committed else reached
                )
            elif committed:
                advanced = committed[-1].commit_lsn
            else:
                advanced = self.shared_restart
            # Never advance past the floor of a table this read did not cover. A
            # subscriber that joined (or re-joined after TTL eviction) while the read
            # was in flight lowered shared_restart to its floor; overwriting that here
            # left its log between the floor and this read's end unread forever, and
            # its first view then skipped that range silently.
            pending = [
                entry["floor"] for entry in self.subscribers.values() if not self._covered(entry)
            ]
            candidates = [value for value in (advanced, *pending) if value is not None]
            if candidates:
                self.shared_restart = min(candidates)
            open_begins: dict[str, int | None] = {}
            for identity, sub in self.subscribers.items():
                begins = [
                    item.begin_lsn
                    for item in buffer.open.values()
                    if any(
                        _record_matches(record, sub["table"])
                        for record in itertools.chain(item.records, item.spilling)
                    )
                ]
                open_begins[identity] = min(begins) if begins else None
            self.open_begins = open_begins
            self.schema = dict(schema_map)
            self.min_lsn = min_lsn
            # current_lsn was sampled before the read, which can then reach further, into the
            # next logical log: a view must not report a log position older than the commits
            # it hands out, or a consumer that took them reads as being ahead of the log.
            self.current_lsn = max(
                current_lsn, reached or 0, committed[-1].commit_lsn if committed else 0
            )
            self.caught_up = timed_out and not buffer.open
            self.reached_lsn = reached if self.caught_up else None
            self.read_start_lsn = read_start if self.caught_up else None
            self.ready = True
            self.condition.notify_all()
        return self.caught_up

    def mark_unready(self):
        with self.condition:
            self.ready = False


# Serialization-safe registry (a bare module global becomes a function local in the
# merged deployment; a mutated dict survives, as with _lakebase_waiter_lock).
_SHARED_CDC_SHARDS: dict[tuple, _SharedCdcShard] = {}
_SHARED_CDC_THREADS: dict[tuple, threading.Thread] = {}
_SHARED_CDC_REGISTRY_LOCK: dict[str, threading.Lock] = {}


def _shared_cdc_registry_lock() -> threading.Lock:
    lock = _SHARED_CDC_REGISTRY_LOCK.get("lock")
    if lock is None:
        lock = _SHARED_CDC_REGISTRY_LOCK.setdefault("lock", threading.Lock())
    return lock


def _shared_cdc_shard(
    key, *, reader_factory, timeout_seconds, max_records, buffer_cap, subscriber_ttl
) -> _SharedCdcShard:
    with _shared_cdc_registry_lock():
        shard = _SHARED_CDC_SHARDS.get(key)
        if shard is None:
            shard = _SHARED_CDC_SHARDS.setdefault(key, _SharedCdcShard())
        shard.configure(
            reader_factory=reader_factory,
            timeout_seconds=timeout_seconds,
            max_records=max_records,
            buffer_cap=buffer_cap,
            subscriber_ttl=subscriber_ttl,
        )
        thread = _SHARED_CDC_THREADS.get(key)
        if thread is None or not thread.is_alive():
            thread = threading.Thread(
                target=_run_shared_cdc_shard,
                args=(shard,),
                daemon=True,
                name=f"informix-shared-cdc-{key[-2]}-{key[-1]}",
            )
            _SHARED_CDC_THREADS[key] = thread
            thread.start()
        return shard


# Host-shared shards (cdc.shared.session=host, the default). Serverless SDP runs each
# streaming flow's driver-side reader in its own Python process, all in one container on
# the driver host, so a process-local shard serves only its own flow's table and every
# flow opens its own CDC session. In host mode the first process to lock a shard's lock
# file leads it: it runs the shard and its reader thread exactly as process mode does,
# and serves the other flow processes' polls over a Unix socket in the local temp
# directory. A follower that can't reach the leader tries to take the lock, which the
# kernel releases when the leader's process exits, and otherwise reads directly for that
# poll, as any flow does while its shard isn't ready. A new leader starts an empty shard,
# which its subscribers cover again from their own checkpoints, as after a restart.
_SHARED_CDC_SESSION_HOST = "host"
_SHARED_CDC_SESSION_PROCESS = "process"
# How long a follower waits to connect to the leader, or for it to answer one poll,
# before reading directly.
_HOST_SHARD_REPLY_SECONDS = 60.0
# Consecutive accept failures after which a leader gives its shard up to another process.
_HOST_SHARD_ACCEPT_FAILURES = 8
_HOST_SHARD_TABLE_COLUMN_FIELDS = ("columns", "catalog_columns", "unsupported_columns")


def _shared_cdc_mode(options: dict[str, str]) -> str:
    # Docstring: ``cdc.shared.session`` as host (the default) or process.
    #
    # ``host`` shares the shards between the flow processes on one host; ``process``
    # keeps one shard registry per process.

    value = options.get(_SHARED_CDC_SESSION_OPTION, _SHARED_CDC_SESSION_HOST).strip().lower()
    if value in (_SHARED_CDC_SESSION_HOST, _SHARED_CDC_SESSION_PROCESS):
        return value
    # 142: Option '{}' must be 'host' or 'process'
    raise ValueError(_m(142, _SHARED_CDC_SESSION_OPTION))


class _HostShardEndpoints:
    # Docstring: This process's part in each host-shared shard: the lock and listener of a
    # shard it leads, or its connection to the leader of one it follows.
    #
    # Never serialized: a worker that unpickles a reader starts with no roles of its own.

    def __init__(self, directory: str | None = None) -> None:
        self.lock = threading.Lock()
        self.directory = directory
        # key -> {"lock_fd", "listener", "reader_factory", "remote"}: "remote" holds the
        # identities served over the socket, evicted from the shard if it is given up.
        self.leading: dict[tuple, dict[str, Any]] = {}
        self.clients: dict[tuple, Any] = {}
        self.client_locks: dict[tuple, threading.Lock] = {}
        # (key, identity) -> (checkpoint commit LSN, floor, capture, transactions) a follower
        # holds from its earlier polls, so the leader sends each transaction only once.
        self.mirrors: dict[tuple, tuple[int, int, dict, tuple]] = {}
        # Set when this process can't lock or serve a shard at all, so it shares in
        # process mode instead of reading directly on every poll.
        self.unavailable: str | None = None

    def __getstate__(self) -> dict[str, object]:
        return {}

    def __setstate__(self, state: dict[str, object]) -> None:
        del state
        self.__init__()

    def paths(self, key: tuple) -> tuple[str, str, str]:
        # Docstring: The shard's (lock, socket, auth key) paths, short enough for AF_UNIX.
        #
        # Whoever can write the directory could serve forged CDC rows, so one that isn't
        # this user's alone raises, which turns host sharing off in this process.

        directory = self.directory
        if directory is None:
            name = f"informix-cdc-shards-{os.getuid()}"
            directory = os.path.join(tempfile.gettempdir(), name)
            # A socket path must fit AF_UNIX's sun_path (104 bytes on macOS and BSD, 108 on
            # Linux); a long TMPDIR would otherwise turn host sharing off. /tmp is short.
            if len(os.fsencode(os.path.join(directory, "0" * 24 + ".sock"))) > 100:
                directory = os.path.join("/tmp", name)
        os.makedirs(directory, mode=0o700, exist_ok=True)
        info = os.lstat(directory)
        if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid() or info.st_mode & 0o077:
            # 143: {} is not a directory only this user can access
            raise PermissionError(_m(143, directory))
        digest = hashlib.sha256(repr(key).encode()).hexdigest()[:24]
        base = os.path.join(directory, digest)
        return f"{base}.lock", f"{base}.sock", f"{base}.key"


_HOST_SHARD_ENDPOINTS = _HostShardEndpoints()


def _wire_table(table: Table) -> dict[str, Any]:
    # Docstring: ``table`` as plain data. The merged deployment defines Table inside a
    # function, so it can't be pickled by name between processes; Table(**fields) rebuilds it.

    data = {}
    for item in dataclasses.fields(table):
        value = getattr(table, item.name)
        if item.name in _HOST_SHARD_TABLE_COLUMN_FIELDS:
            value = [dataclasses.asdict(column) for column in value]
        data[item.name] = value
    return data


def _unwire_table(data: dict[str, Any]) -> Table:
    fields = dict(data)
    for name in _HOST_SHARD_TABLE_COLUMN_FIELDS:
        fields[name] = tuple(Column(**column) for column in fields[name])
    return Table(**fields)


def _unwire_json_table(data: dict[str, Any]) -> Table:
    # Docstring: _unwire_table for a table that crossed JSON (a partition descriptor), which
    # turned its tuples into lists.

    def tuples(value: Any) -> Any:
        return tuple(tuples(item) for item in value) if isinstance(value, list) else value

    return _unwire_table(
        {
            name: value if name in _HOST_SHARD_TABLE_COLUMN_FIELDS else tuples(value)
            for name, value in data.items()
        }
    )


def _wire_view(view: "_SharedCdcSnapshot") -> dict[str, Any]:
    # Docstring: A shard view as plain data; its records already are (decoded CDC values).

    return {
        "table": _wire_table(view.table),
        "fingerprint": view.fingerprint,
        "min_lsn": view.min_lsn,
        "current_lsn": view.current_lsn,
        "committed": [
            (
                tx.tx_id,
                tx.begin_lsn,
                tx.commit_lsn,
                tx.restart_lsn,
                tx.records,
                tx.commit_time,
                tx.spilled,
            )
            for tx in view.committed
        ],
        "caught_up": view.caught_up,
        "open_begin": view.open_begin,
        "reached_lsn": view.reached_lsn,
        "read_start_lsn": view.read_start_lsn,
    }


def _unwire_view(data: dict[str, Any]) -> "_SharedCdcSnapshot":
    return _SharedCdcSnapshot(
        table=_unwire_table(data["table"]),
        fingerprint=data["fingerprint"],
        min_lsn=data["min_lsn"],
        current_lsn=data["current_lsn"],
        committed=[CommittedTransaction(*tx) for tx in data["committed"]],
        caught_up=data["caught_up"],
        open_begin=data["open_begin"],
        reached_lsn=data["reached_lsn"],
        read_start_lsn=data.get("read_start_lsn"),
    )


def _host_shard_local_poll(key, reader_factory, config, identity, table, capture, commit, floor):
    # Docstring: Subscribe to and read this process's own shard, as process mode does.

    shard = _shared_cdc_shard(key, reader_factory=reader_factory, **config)
    shard.subscribe(identity, table, capture, commit, floor)
    return shard.snapshot(identity, commit)


def _host_shard_socket_timeouts(sock) -> None:
    # Docstring: Bound each blocking send and receive on ``sock`` by the reply timeout.
    #
    # Kernel timeouts rather than ``socket.settimeout``, which would make the descriptor
    # non-blocking, which Connection's reads don't expect.

    import socket
    import struct

    seconds = _HOST_SHARD_REPLY_SECONDS
    timeval = struct.pack("ll", int(seconds), int(seconds % 1 * 1_000_000))
    sock.setblocking(True)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVTIMEO, timeval)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDTIMEO, timeval)


def _host_shard_serve(
    endpoints: _HostShardEndpoints, key: tuple, connection, authkey: bytes
) -> None:
    # Docstring: Authenticate one follower, then answer its polls until it disconnects.
    #
    # The handshake runs here, not in the accept thread, so a follower that stalls in
    # it holds up only itself. The handshake and each message are bounded like the
    # follower's; the wait for its next poll is not, as a follower may poll rarely.

    import multiprocessing.connection
    import socket

    try:
        try:
            # A duplicate descriptor shares the socket, and so its options.
            with socket.fromfd(connection.fileno(), socket.AF_UNIX, socket.SOCK_STREAM) as sock:
                _host_shard_socket_timeouts(sock)
            multiprocessing.connection.deliver_challenge(connection, authkey)
            multiprocessing.connection.answer_challenge(connection, authkey)
        except Exception:  # noqa: BLE001 - a failed or broken handshake
            return
        while True:
            try:
                connection.poll(None)
                request = connection.recv()
            except (EOFError, OSError):
                return
            leading = endpoints.leading.get(key)
            if leading is None:
                # No longer this process's shard: hang up, so the follower takes over.
                return
            try:
                leading["remote"].add(request["identity"])
                view = _host_shard_local_poll(
                    key,
                    leading["reader_factory"],
                    request["config"],
                    request["identity"],
                    _unwire_table(request["table"]),
                    request["capture"],
                    request["commit"],
                    request["floor"],
                )
                after = request.get("after")
                if view is not None and after is not None:
                    # The follower already holds every transaction up to ``after``.
                    view = replace(
                        view, committed=[tx for tx in view.committed if tx.commit_lsn > after]
                    )
                reply = ("ok", None if view is None else _wire_view(view))
            except Exception as error:  # noqa: BLE001 - the follower reads directly instead
                reply = ("error", f"{type(error).__name__}: {error}"[:500])
            try:
                try:
                    connection.send(reply)
                except (OSError, ValueError):
                    raise
                except Exception as error:  # noqa: BLE001 - e.g. a value that doesn't pickle
                    connection.send(("error", f"{type(error).__name__}: {error}"[:500]))
            except (OSError, ValueError):
                return
    finally:
        with contextlib.suppress(OSError):
            connection.close()


def _host_shard_accept(
    endpoints: _HostShardEndpoints, key: tuple, listener, authkey: bytes
) -> None:
    # Docstring: Accept followers while this process leads the shard.
    #
    # Accept failing again and again (out of descriptors, say) gives the shard up:
    # the socket goes while the lock is still held, so it can't remove a successor's,
    # then the lock, so another process can lead.

    failures = 0
    while True:
        try:
            connection = listener.accept()
        except Exception as error:  # noqa: BLE001 - retried, then the shard is given up
            if key not in endpoints.leading:
                return
            failures += 1
            # 144: Host-shared CDC shard {}-{} could not accept a follower ({})
            logging.getLogger(__name__).warning(
                _m(144, key[-2], key[-1], error),
            )
            if failures < _HOST_SHARD_ACCEPT_FAILURES:
                time.sleep(min(5.0, 0.05 * 2**failures))
                continue
            with endpoints.lock:
                leading = endpoints.leading.pop(key, None)
            if leading is not None:
                with contextlib.suppress(OSError):
                    leading["listener"].close()
                os.close(leading["lock_fd"])
                # The successor reads the followers' tables now; keep only this
                # process's own subscribers rather than reading them twice until the TTL.
                shard = _SHARED_CDC_SHARDS.get(key)
                for identity in list(leading["remote"]) if shard is not None else ():
                    shard.evict(identity)
                # 145: Process {} gave up host-shared CDC shard {}-{}
                logging.getLogger(__name__).warning(_m(145, os.getpid(), key[-2], key[-1]))
            return
        failures = 0
        if key not in endpoints.leading:
            connection.close()
            return
        threading.Thread(
            target=_host_shard_serve,
            args=(endpoints, key, connection, authkey),
            daemon=True,
            name=f"informix-host-shard-serve-{key[-2]}-{key[-1]}",
        ).start()


def _host_shard_try_lead(
    endpoints: _HostShardEndpoints, key: tuple, reader_factory, config: dict[str, Any]
) -> bool:
    # Docstring: Lead the shard if no other process holds its lock; True when this one does.
    #
    # The auth key is written before the listener exists, and only a process holding the
    # lock replaces the socket, so a stale socket file of a dead leader is never live.
    # An error other than the lock being taken -- an unusable directory included --
    # marks host sharing unavailable here, so this process shares within itself.

    import fcntl
    import multiprocessing.connection

    with endpoints.lock:
        if key in endpoints.leading:
            return True
        if endpoints.unavailable:
            return False
        descriptor = None
        try:
            lock_path, socket_path, key_path = endpoints.paths(key)
            descriptor = os.open(lock_path, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
            try:
                fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                os.close(descriptor)
                return False
            authkey = secrets.token_bytes(32)
            staged = f"{key_path}.{secrets.token_hex(8)}"
            flags = os.O_CREAT | os.O_EXCL | os.O_WRONLY | os.O_NOFOLLOW
            with open(os.open(staged, flags, 0o600), "wb") as out:
                out.write(authkey)
            os.replace(staged, key_path)
            if os.path.lexists(socket_path):
                os.unlink(socket_path)
            # Followers connect all at once when an update starts: queue them.
            listener = multiprocessing.connection.Listener(
                socket_path, family="AF_UNIX", backlog=128
            )
        except OSError as error:
            if descriptor is not None:
                os.close(descriptor)
            endpoints.unavailable = f"{type(error).__name__}: {error}"
            # 146: Host-shared CDC shards are unavailable in process {} ({}); sharing within the
            # process instead
            logging.getLogger(__name__).warning(
                _m(146, os.getpid(), endpoints.unavailable),
            )
            return False
        endpoints.leading[key] = {
            "lock_fd": descriptor,
            "listener": listener,
            "reader_factory": reader_factory,
            "remote": set(),
        }
    _shared_cdc_shard(key, reader_factory=reader_factory, **config)
    threading.Thread(
        target=_host_shard_accept,
        args=(endpoints, key, listener, authkey),
        daemon=True,
        name=f"informix-host-shard-{key[-2]}-{key[-1]}",
    ).start()
    # 147: Process {} leads host-shared CDC shard {}-{}
    logging.getLogger(__name__).info(_m(147, os.getpid(), key[-2], key[-1]))
    return True


def _host_shard_request(endpoints: _HostShardEndpoints, key: tuple, request: dict[str, Any]):
    # Docstring: Send one poll to the shard's leader over this process's connection to it.
    #
    # Connecting, the handshake and every send and receive time out, so a leader that
    # holds its lock but stops serving can't hang the poll.

    import multiprocessing.connection
    import socket

    with endpoints.lock:
        guard = endpoints.client_locks.setdefault(key, threading.Lock())
    with guard:
        connection = endpoints.clients.get(key)
        if connection is None:
            _lock_path, socket_path, key_path = endpoints.paths(key)
            with open(key_path, "rb") as handle:
                authkey = handle.read()
            with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as sock:
                _host_shard_socket_timeouts(sock)
                sock.connect(socket_path)
                connection = multiprocessing.connection.Connection(sock.detach())
            try:
                multiprocessing.connection.answer_challenge(connection, authkey)
                multiprocessing.connection.deliver_challenge(connection, authkey)
            except BaseException:
                connection.close()
                raise
            endpoints.clients[key] = connection
        try:
            connection.send(request)
            if not connection.poll(_HOST_SHARD_REPLY_SECONDS):
                # 148: the host shard leader did not answer the poll
                raise TimeoutError(_m(148))
            return connection.recv()
        except BaseException:
            endpoints.clients.pop(key, None)
            try:
                connection.close()
            except OSError:
                pass
            raise


def _host_shard_poll(
    key,
    reader_factory,
    config,
    identity,
    table,
    capture,
    commit,
    floor,
    endpoints: _HostShardEndpoints | None = None,
):
    # Docstring: A host-shared shard's view for one consumer poll, or None to read directly.
    #
    # Leads the shard when nobody does, polls the leader otherwise, and takes over when
    # the leader is gone. Where the host can't share at all, shares within the process.

    endpoints = _HOST_SHARD_ENDPOINTS if endpoints is None else endpoints
    local = (key, reader_factory, config, identity, table, capture, commit, floor)
    # The leader sends only transactions after those this follower holds from earlier
    # polls, so each crosses the socket once. A checkpoint moved back past them, a floor
    # moved back (an older open transaction the view they came from lacked), a new capture
    # (they were decoded under the old one), or a poll without a view, starts over with
    # the whole buffer; leading drops them.
    held_commit, held_floor, held_capture, held = endpoints.mirrors.pop(
        (key, identity), (commit, floor, capture, ())
    )
    if key in endpoints.leading or endpoints.unavailable:
        return _host_shard_local_poll(*local)
    if (
        key not in endpoints.clients
        and _host_shard_try_lead(endpoints, key, reader_factory, config)
    ) or endpoints.unavailable:
        return _host_shard_local_poll(*local)
    if held_commit > commit or held_floor > floor or held_capture != capture:
        held = ()
    request = {
        "config": config,
        "identity": identity,
        "table": _wire_table(table),
        "capture": capture,
        "commit": commit,
        "floor": floor,
        "after": held[-1].commit_lsn if held else None,
    }
    try:
        status, payload = _host_shard_request(endpoints, key, request)
    except (OSError, EOFError, TimeoutError, ValueError) as error:
        if _host_shard_try_lead(endpoints, key, reader_factory, config) or endpoints.unavailable:
            return _host_shard_local_poll(*local)
        # 149: Host-shared CDC shard {}-{} leader unreachable ({}); reading directly
        logging.getLogger(__name__).debug(
            _m(149, key[-2], key[-1], error),
        )
        return None
    except Exception as error:  # noqa: BLE001 - e.g. a failed auth handshake
        # 150: Host-shared CDC shard {}-{} poll failed ({}); reading directly
        logging.getLogger(__name__).debug(
            _m(150, key[-2], key[-1], error),
        )
        return None
    if status != "ok":
        # 151: Host-shared CDC shard {}-{} leader refused a poll ({}); reading directly
        logging.getLogger(__name__).warning(
            _m(151, key[-2], key[-1], payload),
        )
        return None
    if payload is None:
        return None
    view = _unwire_view(payload)
    committed = [tx for tx in held if tx.commit_lsn > commit] + view.committed
    endpoints.mirrors[(key, identity)] = (commit, floor, capture, tuple(committed))
    return replace(view, committed=committed)


def _table_id(table: Table) -> int | None:
    # Docstring: The Informix table ID a catalog read recorded as ``table.incarnation``.

    try:
        return int(table.incarnation)
    except (TypeError, ValueError):
        return None


class _ShardCatalog:
    # Docstring: The catalog tables one shard's daemon reads under, re-read only when changed.
    #
    # Describing every subscribed table before every read cost two or three catalog
    # queries a table each cycle. Instead the daemon keeps each table as last read, with
    # its systables.version, and every _SNAPSHOT_SCHEMA_REFRESH_INTERVAL_SECONDS asks for all
    # their versions in one query. Only the tables whose version moved, or whose table ID
    # no longer names them, are read again, together in one batch (get_tables). Informix
    # bumps the version on every change to a table's definition, and on UPDATE STATISTICS,
    # which just costs a needless re-read. A new subscriber is read at once, and a failed
    # read forces a check before the next one.
    #
    # A change waits for the next check without misreading rows. Informix rejects ALTER
    # TABLE while full-row logging is on, which every read switches on, so a column change
    # needs the pipelines stopped (see the README), and the restarted update gets a new
    # shard, read afresh. A captured column changed anyway still fails the read that meets
    # it, which compares the layout Informix reports with the catalog
    # (_assert_capture_layout). What a check does pick up is an index or key constraint
    # created or dropped while the table is captured, which Informix allows and which can
    # change the key a table is merged by; consumers see it at the next check rather than
    # the next read. A bridge without table_versions re-reads every table at each check,
    # and one without get_tables reads them one at a time.
    #
    # Used by the shard's daemon thread alone, so it needs no lock; a consumer only ever
    # calls force_check, a single assignment.

    def __init__(self) -> None:
        # identity -> (systables.version, or None when unknown, and the catalog table)
        self.entries: dict[str, tuple[int | None, Table]] = {}
        self.next_check = 0.0

    def force_check(self) -> None:
        self.next_check = 0.0

    def tables(self, bridge, identities, now: float, check_seconds: float) -> dict[str, Table]:
        # Docstring: The catalog table of each subscribed (identity, table) pair that still
        # names one, re-read as the class describes.

        wanted = dict(identities)
        for identity in [identity for identity in self.entries if identity not in wanted]:
            del self.entries[identity]
        if now >= self.next_check:
            self.next_check = now + check_seconds
            check = wanted
        else:
            check = {
                identity: table
                for identity, table in wanted.items()
                if identity not in self.entries
            }
        if check:
            self._refresh(bridge, check)
        return {
            identity: self.entries[identity][1] for identity in wanted if identity in self.entries
        }

    def _refresh(self, bridge, check: dict[str, Table]) -> None:
        # The versions come first: a definition changed between this query and the reads
        # below leaves an older version on the newer table, which the next check re-reads.
        table_versions = getattr(bridge, "table_versions", None)
        known = {
            identity: self.entries[identity][1] if identity in self.entries else table
            for identity, table in check.items()
        }
        versions = None
        if table_versions is not None:
            versions = table_versions(
                [tabid for tabid in map(_table_id, known.values()) if tabid is not None]
            )
        stale: dict[str, int | None] = {}
        for identity, table in known.items():
            version = None
            found = versions.get(_table_id(table)) if versions is not None else None
            if found is not None and found[:2] == (table.owner.strip(), table.name.strip()):
                version = found[2]
            entry = self.entries.get(identity)
            if entry is None or version is None or entry[0] != version:
                stale[identity] = version
        if not stale:
            return
        logical = {identity: check[identity].identity for identity in stale}
        get_tables = getattr(bridge, "get_tables", None)
        if get_tables is not None:
            described = get_tables(sorted(set(logical.values())))
        else:
            described = {name: bridge.get_table(name) for name in sorted(set(logical.values()))}
        for identity, version in stale.items():
            raw = described.get(logical[identity])
            if raw is None:
                # The name no longer names a table: the subscriber is left to its own
                # direct read, which reports that.
                self.entries.pop(identity, None)
                continue
            fresh = Table.parse(raw, check[identity].database)
            if fresh.incarnation != known[identity].incarnation:
                # Re-created under a new table ID, whose version wasn't asked for: the
                # next check reads it again with its version.
                version = None
            self.entries[identity] = (version, fresh)


def _shard_schema_map(
    bridge, identities, catalog: _ShardCatalog | None = None, check_seconds: float = 0
) -> tuple[dict[str, Table], list[str]]:
    # Docstring: Each subscriber's catalog table with its options carried, as
    # _refresh_table_schema does, for one shard read: ``(identity -> table, unfit)``.
    #
    # The catalog tables come from ``catalog``, which re-reads only what changed (see
    # _ShardCatalog); without one, every table is read now. Without the carry an overridden
    # table's fingerprint never matches its checkpoint, so it would always fall back to a
    # direct read and never benefit from sharding -- and its PK-change detection would use
    # the wrong keys. A table whose options no longer fit its catalog (a selected, renamed,
    # or transformed column gone, a carried key column dropped), or whose name no longer
    # names a table, is listed as unfit instead of failing the whole read: its own direct
    # read reports the error, and the shard keeps serving the others.

    catalog = _ShardCatalog() if catalog is None else catalog
    fresh_tables = catalog.tables(bridge, identities, time.monotonic(), check_seconds)
    schema_map: dict[str, Table] = {}
    unfit: list[str] = []
    for identity, table in identities:
        fresh = fresh_tables.get(identity)
        if fresh is None:
            # 152: Shared CDC shard leaves {} to direct reads: the catalog no longer has it
            logging.getLogger(__name__).warning(
                _m(152, identity),
            )
            unfit.append(identity)
            continue
        try:
            schema_map[identity] = _carry_table_options(fresh, table)
        except (InformixError, ValueError):
            # 153: Shared CDC shard leaves {} to direct reads: its table options no longer fit the
            # catalog
            logging.getLogger(__name__).warning(
                _m(153, identity),
                exc_info=True,
            )
            unfit.append(identity)
    return schema_map, unfit


def _close_shared_cdc_reader(reader) -> None:
    if reader is None:
        return
    try:
        reader.close()
    except Exception:  # noqa: BLE001 - best-effort slot release
        # 154: shared CDC reader close failed
        logging.getLogger(__name__).debug(_m(154), exc_info=True)


def _run_shared_cdc_shard(shard: _SharedCdcShard) -> None:
    # Docstring: Daemon loop for one shard: read the shared CDC session, fetch schema + log
    # bounds, and publish. Holds one connection slot only across consecutive productive
    # reads; releases it before any idle wait so consumer bootstrap can use the slot.

    logger = logging.getLogger(__name__)
    reader = None
    try:
        while True:
            with shard.condition:
                subscribers = shard.live_subscribers()
                have_subscribers = bool(subscribers)
                throttled = have_subscribers and any(
                    len(buf) >= shard.buffer_cap for buf in shard.buffers.values()
                )
                restart = shard.shared_restart
                identities = [(identity, sub["table"]) for identity, sub in subscribers.items()]
            if not have_subscribers or throttled or restart is None or shard.reader_factory is None:
                _close_shared_cdc_reader(reader)
                reader = None
                with shard.condition:
                    shard.condition.wait(timeout=_SHARED_CDC_IDLE_POLL_SECONDS)
                continue
            if reader is None:
                reader = shard.reader_factory()
            try:
                schema_map, unfit = _shard_schema_map(
                    reader._bridge,
                    identities,
                    shard.catalog,
                    _SNAPSHOT_SCHEMA_REFRESH_INTERVAL_SECONDS,
                )
                for identity in unfit:
                    # Its consumer falls back to a direct read, which reports the error;
                    # evicting it keeps its floor from pinning the shared restart.
                    shard.evict(identity)
                if not schema_map:
                    _close_shared_cdc_reader(reader)
                    reader = None
                    with shard.condition:
                        shard.condition.wait(timeout=_SHARED_CDC_IDLE_POLL_SECONDS)
                    continue
                captures = {identity: subscribers[identity]["capture"] for identity in schema_map}
                min_lsn = reader._bridge.minimum_lsn()
                current_lsn = reader._bridge.current_lsn()
                raw = reader._read_changes_with_reconnect(
                    list(captures.values()),
                    restart,
                    shard.timeout_seconds,
                    shard.max_records,
                    table=subscribers[next(iter(schema_map))]["table"],
                )
                caught_up = shard.ingest(raw, schema_map, min_lsn, current_lsn, restart, captures)
            except Exception:  # noqa: BLE001 - surfaced by degrading to direct reads
                # 155: Shared CDC shard read failed; consumers fall back to direct reads until it
                # recovers
                logger.warning(
                    _m(155),
                    exc_info=True,
                )
                shard.mark_unready()
                # Whatever failed, the next read starts from a fresh look at the catalog.
                shard.catalog.force_check()
                _close_shared_cdc_reader(reader)
                reader = None
                time.sleep(_SHARED_CDC_IDLE_POLL_SECONDS)
                continue
            if caught_up:
                _close_shared_cdc_reader(reader)
                reader = None
                with shard.condition:
                    shard.condition.wait(timeout=_SHARED_CDC_IDLE_POLL_SECONDS)
    finally:
        _close_shared_cdc_reader(reader)


class _SnapshotDrainPool:
    # Docstring: Bounded pool that drains ``initial``-mode snapshots off the microbatch thread.
    #
    # A fixed number of driver-resident daemon workers (``snapshot.reader.threads``) pull
    # drain jobs off a shared queue; each builds a private reader, runs the ordinary inline
    # snapshot drain (which stages the pages and publishes the manifest durably), then
    # closes the reader to release its connection slot. Because at most K workers drain at
    # once, at most K slots are ever held by snapshots -- the fairness guarantee that keeps
    # streaming readers from being starved. A consumer subscribes a job and waits, holding
    # no slot, for its result. All state is guarded by ``condition``.
    #
    # The consumer's ``wait`` is a *liveness watchdog*, not a total-duration deadline: the
    # drain reports progress (via ``report_progress``) each time it stages a page, and the
    # wait trips only after progress has gone quiet for a whole idle window. Liveness is
    # scoped by state so a job is neither failed early nor kept alive on someone else's work:
    #
    # - A **running** job (a worker has picked it up) is measured from *its own* progress --
    #   a staged page, or, while its worker is still acquiring a connection slot, a turnover
    #   ping from the slot wait -- so a hung fetch on its worker trips even while other
    #   workers advance, but a worker legitimately queued behind a busy pool does not.
    # - A **queued** job (waiting for a free worker) is measured from *pool-wide* progress,
    #   so it waits its turn behind a large, healthy drain instead of failing while queued,
    #   and only trips when the whole pool goes quiet.
    #
    # Because progress is tied to *actual staged pages* (plus a pickup), a hung fetch cannot
    # masquerade as liveness. At most K workers drain at once, so at most K slots are ever
    # held by snapshots -- the fairness guarantee that keeps streaming readers from being
    # starved. A consumer subscribes a job and waits, holding no slot, for its result.

    def __init__(self) -> None:
        self.condition = threading.Condition()
        self.queue: deque = deque()
        # Job keys queued or running: dedups concurrent subscribers so one table drains
        # exactly once even when several flows (or retries) ask for it at the same time.
        self.pending: set = set()
        self.jobs: dict[tuple, dict[str, Any]] = {}
        # job key -> None on success, or the Exception to re-raise to the waiter.
        self.results: dict[tuple, Any] = {}
        # job key -> monotonic timestamp of the last forward progress (enqueue, worker
        # pickup, or a staged page). A *running* job's waiter is measured from this, so a
        # hung fetch on its own worker is caught even while other workers progress.
        self.progress: dict[tuple, float] = {}
        # Job keys a worker has picked up and is actively draining (vs. still queued).
        self.running: set = set()
        # Pool-wide last-progress clock, bumped by any worker's pickup or staged page. A
        # *queued* job's waiter is measured from max(its own, this), so it waits its turn
        # as long as the pool as a whole is draining something -- and only times out when
        # the whole pool goes quiet, not merely because a big drain is ahead of it.
        self.last_progress_any: float = 0.0
        self.reader_factory: Callable[[], Any] | None = None
        self.thread_count = _DEFAULT_SNAPSHOT_READER_THREADS

    def configure(self, *, reader_factory, thread_count):
        with self.condition:
            if self.reader_factory is None:
                self.reader_factory = reader_factory
            self.thread_count = thread_count

    def submit(self, job_key, *, table, options, pipeline_scope, allow_keyless):
        with self.condition:
            # Drop a prior terminal result so a re-subscribe after a failed drain (or a
            # process restart that left no manifest) enqueues a fresh attempt.
            self.results.pop(job_key, None)
            if job_key not in self.pending:
                self.jobs[job_key] = {
                    "table": table,
                    "options": options,
                    "pipeline_scope": pipeline_scope,
                    "allow_keyless": allow_keyless,
                }
                self.queue.append(job_key)
                self.pending.add(job_key)
                # Start the liveness clock at enqueue; a worker pickup and each staged
                # page reset it, so a queued-but-not-yet-started job is not charged for
                # time it spent waiting behind other drains.
                self.progress[job_key] = time.monotonic()
                self.condition.notify_all()

    def mark_running(self, job_key) -> None:
        # Docstring: Record that a worker has picked this job up (it is no longer merely queued).

        with self.condition:
            self.running.add(job_key)
            now = time.monotonic()
            if job_key in self.pending:
                self.progress[job_key] = now
            # Picking a job up is pool progress: it proves a worker just freed and took
            # the next job, so every queued waiter's idle window resets.
            self.last_progress_any = now
            self.condition.notify_all()

    def report_progress(self, job_key) -> None:
        # Docstring: Record forward progress on a job so waiters' idle windows reset.
        #
        # A staged page advances both this job's own clock (for its running waiter) and the
        # pool-wide clock (for every queued waiter), so a queued job stays alive as long as
        # any worker is draining.

        with self.condition:
            now = time.monotonic()
            if job_key in self.pending:
                self.progress[job_key] = now
            self.last_progress_any = now
            self.condition.notify_all()

    def wait(self, job_key, idle_timeout):
        # Docstring: Block until the job finishes, fails, or goes quiet for ``idle_timeout``.
        #
        # Returns True on success, re-raises the worker's exception on failure, and returns
        # False only when the drain is *stalled*. "Stalled" means different things by state:
        # a **running** job must make its own progress (a hung fetch on its worker times
        # out even while other workers advance); a **queued** job only needs the pool to be
        # making progress (it waits its turn behind a big, healthy drain rather than failing
        # while it is still queued). Either way it fails once the whole pool goes quiet.

        with self.condition:
            while job_key in self.pending:
                own = self.progress.get(job_key, time.monotonic())
                if job_key in self.running:
                    last = own
                else:
                    last = max(own, self.last_progress_any)
                remaining = (last + idle_timeout) - time.monotonic()
                if remaining <= 0:
                    return False
                self.condition.wait(timeout=min(remaining, _SNAPSHOT_DRAIN_IDLE_SECONDS))
            result = self.results.get(job_key)
        if isinstance(result, BaseException):
            raise result
        return True


# Serialization-safe registry (a bare module global becomes a function local in the
# merged deployment; a mutated dict survives, as with the shared-CDC registry).
_SNAPSHOT_DRAIN_POOLS: dict[tuple, _SnapshotDrainPool] = {}
_SNAPSHOT_DRAIN_THREADS: dict[tuple, list] = {}
_SNAPSHOT_DRAIN_REGISTRY_LOCK: dict[str, threading.Lock] = {}


def _snapshot_drain_registry_lock() -> threading.Lock:
    lock = _SNAPSHOT_DRAIN_REGISTRY_LOCK.get("lock")
    if lock is None:
        lock = _SNAPSHOT_DRAIN_REGISTRY_LOCK.setdefault("lock", threading.Lock())
    return lock


def _snapshot_drain_pool(key, *, reader_factory, thread_count) -> _SnapshotDrainPool:
    with _snapshot_drain_registry_lock():
        pool = _SNAPSHOT_DRAIN_POOLS.get(key)
        if pool is None:
            pool = _SNAPSHOT_DRAIN_POOLS.setdefault(key, _SnapshotDrainPool())
        pool.configure(reader_factory=reader_factory, thread_count=thread_count)
        threads = _SNAPSHOT_DRAIN_THREADS.setdefault(key, [])
        threads[:] = [thread for thread in threads if thread.is_alive()]
        index = len(threads)
        while len(threads) < thread_count:
            thread = threading.Thread(
                target=_run_snapshot_drain_worker,
                args=(pool,),
                daemon=True,
                name=f"informix-snapshot-drain-{key[-1]}-{index}",
            )
            threads.append(thread)
            index += 1
            thread.start()
        return pool


def _close_snapshot_drain_reader(reader) -> None:
    if reader is None:
        return
    try:
        reader.close()
    except Exception:  # noqa: BLE001 - best-effort slot release
        # 156: snapshot drain reader close failed
        logging.getLogger(__name__).debug(_m(156), exc_info=True)


def _run_snapshot_drain_worker(pool: _SnapshotDrainPool) -> None:
    # Docstring: Daemon loop: pull one drain job, run the inline snapshot drain under a private
    # reader (staging pages and publishing the manifest durably), then close the reader to
    # release its slot. A failure is recorded on the job so the waiting consumer re-raises
    # and its next microbatch re-subscribes, recovering by restart: with no manifest, the
    # table drains again.

    logger = logging.getLogger(__name__)
    while True:
        with pool.condition:
            while not pool.queue:
                pool.condition.wait(timeout=_SNAPSHOT_DRAIN_IDLE_SECONDS)
            job_key = pool.queue.popleft()
            job = pool.jobs.get(job_key)
            factory = pool.reader_factory
        # Mark the job running (so its waiter switches from pool-wide to own-progress
        # liveness) and reset the idle clock: startup (slot acquisition + first page) gets
        # a fresh window, and every still-queued job sees this pickup as pool progress.
        pool.mark_running(job_key)
        result: Any = None
        reader = None
        if job is not None and factory is not None:
            try:
                reader = factory()
                # The consumer's scope, not whatever this process's registration context
                # holds: staging tokens and stage paths are both keyed by it.
                reader.set_registration_scope(job["pipeline_scope"])
                # Each staged page resets the consumer's liveness watchdog, so a big table
                # that keeps making progress never trips it while a wedged drain does.
                reader._drain_progress = lambda: pool.report_progress(job_key)
                # The reader is marked as a drain worker, so this drains inline and returns
                # the staged page-0 result; the daemon ignores the rows -- it only needs the
                # durable manifest the drain publishes as a side effect -- so page 0 is
                # returned unread.
                reader._defer_staged_rows = True
                reader._read_snapshot(
                    job["table"],
                    None,
                    job["options"],
                    pipeline_scope_override=job["pipeline_scope"],
                    allow_keyless=job["allow_keyless"],
                )
            except Exception as error:  # noqa: BLE001 - surfaced to the waiting consumer
                # 157: Informix snapshot drain job failed; the consumer will re-raise and retry on
                # its next microbatch
                logger.warning(
                    _m(157),
                    exc_info=True,
                )
                result = error
            finally:
                _close_snapshot_drain_reader(reader)
        with pool.condition:
            pool.jobs.pop(job_key, None)
            pool.pending.discard(job_key)
            pool.running.discard(job_key)
            pool.progress.pop(job_key, None)
            pool.results[job_key] = result
            pool.condition.notify_all()


class _AsyncStagePipeline:
    # Docstring: Overlap a drain's next page fetch with the previous page's shape+upload.
    #
    # Wraps the ``page_consumer`` the consistent-snapshot loop calls. ``submit``
    # hands a page to a single background worker and returns, so the loop can fetch
    # the next page while the worker shapes, compresses, and uploads the previous one.
    # A single worker preserves page order; a depth-1 queue bounds resident pages to
    # roughly three (one being fetched, one queued, one uploading) and applies
    # backpressure by blocking ``submit`` when the worker falls behind.
    #
    # The wrapped stage callable owns nonlocal counters (page/row counts); it runs
    # only on the worker thread, and ``close`` joins that thread before the caller
    # reads them. A stage error is captured and re-raised at the next ``submit`` (so
    # the fetch loop stops early) and again at ``close``; ``shutdown`` joins without
    # raising, for the path where a primary error is already propagating.

    def __init__(self, stage: Callable[[int, int, list], None], *, queue_size: int = 1) -> None:
        self._stage = stage
        self._queue: queue.Queue = queue.Queue(maxsize=max(1, queue_size))
        self._error: BaseException | None = None
        self._started = False
        self._thread = threading.Thread(
            target=self._run, name="informix-snapshot-uploader", daemon=True
        )

    def submit(self, snapshot_lsn: int, page_index: int, page_rows: list) -> None:
        if not self._started:
            self._started = True
            self._thread.start()
        if self._error is not None:
            raise self._error
        self._queue.put((snapshot_lsn, page_index, page_rows))

    def _run(self) -> None:
        while True:
            item = self._queue.get()
            if item is None:
                return
            if self._error is not None:
                # Drain the backlog without processing once a page has failed; the
                # error is surfaced to the caller through submit/close.
                continue
            try:
                self._stage(*item)
            except BaseException as error:  # noqa: BLE001 - re-raised on the caller's thread
                self._error = error

    def close(self) -> None:
        # Docstring: Finish all queued pages, join the worker, then re-raise any stage error.

        if self._started:
            self._queue.put(None)
            self._thread.join()
        if self._error is not None:
            raise self._error

    def shutdown(self) -> None:
        # Docstring: Join the worker without raising -- for use while another error propagates.

        if self._started:
            self._queue.put(None)
            self._thread.join()


class _DeferredStagedPage:
    # Docstring: A staged page's rows, read from the stage only once iterated.
    #
    # ``page_batch`` is the page-serve tuple (see _snapshot_page_batch) the partitioned
    # reader uses to serve the page from an executor, so the driver never reads it.

    def __init__(self, read: Callable[[], Iterator[dict]], page_batch: tuple) -> None:
        self.page_batch = page_batch
        self._read = read
        self._rows: Iterator[dict] | None = None

    def __iter__(self) -> "_DeferredStagedPage":
        return self

    def __next__(self) -> dict:
        if self._rows is None:
            self._rows = self._read()
        return next(self._rows)


class InformixLakeflowConnect(LakeflowConnect, SupportsPartitionedStream):
    # Docstring: Pure-Python connector live-validated on disposable Informix 15.
    #
    # Normal auth, queries, discovery, snapshots, transactional CDC, and
    # serverless Lakeflow pipeline execution have been exercised.

    def __init__(self, options: dict[str, str]) -> None:
        super().__init__(options)
        # The Volume now stores exactly one thing: snapshot page payloads. It has
        # no default to fall back on, because there is no longer a shared state
        # location to borrow one from.
        staging_location = options.get("snapshot.staging.location", "").strip()
        if not staging_location:
            # 158: Missing required Informix option: snapshot.staging.location
            raise ValueError(_m(158))
        # Checked here rather than where state is first read: this runs while the
        # pipeline is being set up, so a missing password fails the update
        # immediately instead of surfacing on the first microbatch that needs state.
        if not options.get("lakebase.password", "").strip():
            # 159: Missing required Informix option: lakebase.password
            raise ValueError(_m(159))
        self._snapshot_staging_location = _validated_volume_location(
            staging_location, "snapshot.staging.location", options
        )
        self._snapshot_staging_retention_seconds = (
            int(
                options.get(
                    "snapshot.staging.retention.days",
                    str(_DEFAULT_SNAPSHOT_STAGE_RETENTION_DAYS),
                )
            )
            * 24
            * 60
            * 60
        )
        # Validate numeric configuration without opening a connection.
        for name, default, minimum in (
            ("snapshot.page.size", str(_DEFAULT_SNAPSHOT_PAGE_SIZE), 1),
            (
                "keyless.snapshot.page.size",
                str(_DEFAULT_KEYLESS_SNAPSHOT_PAGE_SIZE),
                1,
            ),
            (
                "snapshot.read.timeout.seconds",
                str(_DEFAULT_SNAPSHOT_READ_TIMEOUT_SECONDS),
                1,
            ),
            ("snapshot.max.rows", "0", 0),
            ("snapshot.max.bytes", "0", 0),
            (
                "snapshot.staging.retention.days",
                str(_DEFAULT_SNAPSHOT_STAGE_RETENTION_DAYS),
                1,
            ),
            (
                _SNAPSHOT_STAGING_TOKEN_LIFETIME_OPTION,
                str(_DEFAULT_STAGING_TOKEN_LIFETIME_SECONDS),
                _STAGING_TOKEN_MIN_LIFETIME_SECONDS,
            ),
            ("metadata.max.bytes", str(64 << 20), 0),
            ("max.records.per.batch", str(_DEFAULT_MAX_RECORDS_PER_BATCH), 1),
            ("cdc.timeout", "5", 1),
            ("cdc.max.records", str(_DEFAULT_CDC_MAX_RECORDS), 1),
            ("cdc.max.frame.bytes", str(16 << 20), 16),
            ("cdc.max.transaction.records", "100000", 1),
            (_CDC_SPILL_RECORDS_OPTION, str(_DEFAULT_CDC_SPILL_RECORDS), 0),
            ("cdc.max.poll.records", "200000", 1),
            ("cdc.max.poll.bytes", "0", 0),
            ("cdc.read.bytes", "32000", 1),
            ("authentication.pam.max.rounds", "16", 1),
            (
                "max.concurrent.connections",
                str(_DEFAULT_MAX_CONCURRENT_CONNECTIONS),
                1,
            ),
            (
                "connection.wait.timeout.seconds",
                str(_DEFAULT_CONNECTION_WAIT_TIMEOUT_SECONDS),
                1,
            ),
            ("redirect.max", "3", 0),
            ("cdc.shared.state.wait.seconds", str(_SHARED_STATE_WAIT_SECONDS), 1),
            (_SHARED_CDC_BUFFER_OPTION, str(_DEFAULT_SHARED_CDC_BUFFER), 1),
            (
                _PARTITIONED_SNAPSHOT_PAGES_PER_BATCH_OPTION,
                str(_DEFAULT_PARTITIONED_SNAPSHOT_PAGES_PER_BATCH),
                1,
            ),
            (_UNL_SPLIT_BYTES_OPTION, str(_UNL_SPLIT_TARGET_BYTES), 1),
        ):
            if int(options.get(name, default)) < minimum:
                raise ValueError(f"Option '{name}' must be >= {minimum}")
        # Startup jitter is a float (fractional seconds), validated here rather than in the
        # integer loop above; 0 disables it.
        _validate_nonneg_float_option(options, _CONNECTION_STARTUP_JITTER_OPTION)
        # Shared-reader thread count defaults to a quarter of the connection budget, so it is
        # validated here rather than in the static-default loop above.
        if _SHARED_CDC_THREADS_OPTION in options and int(options[_SHARED_CDC_THREADS_OPTION]) < 1:
            raise ValueError(f"Option '{_SHARED_CDC_THREADS_OPTION}' must be >= 1")
        if (
            _SNAPSHOT_READER_THREADS_OPTION in options
            and int(options[_SNAPSHOT_READER_THREADS_OPTION]) < 1
        ):
            raise ValueError(f"Option '{_SNAPSHOT_READER_THREADS_OPTION}' must be >= 1")
        # Validate boolean capacity options eagerly (they are otherwise only
        # checked on first read, deep inside a running flow).
        _option_bool(options, "snapshot.incremental.blocking", True)
        _shared_cdc_mode(options)
        # Validate the .unl / HPL DELIMITED field format eagerly (single-character
        # delimiter and optionally-empty escape, which must differ), rather than only
        # on the first file-source read deep inside a running flow.
        _validate_unl_field_format(options)
        _option_bool(options, _PROMOTE_UNIQUE_INDEX_OPTION, True)
        _option_bool(options, _SNAPSHOT_STAGING_PIPELINE_OPTION, True)
        _option_bool(options, _PARTITIONED_STREAM_OPTION, True)
        staging_transport = (
            str(
                options.get(_SNAPSHOT_STAGING_TRANSPORT_OPTION, _DEFAULT_SNAPSHOT_STAGING_TRANSPORT)
            )
            .strip()
            .lower()
        )
        if staging_transport not in _SNAPSHOT_STAGING_TRANSPORTS:
            # 160: Option '{}' must be one of {}; got {!r}
            raise ValueError(
                _m(
                    160,
                    _SNAPSHOT_STAGING_TRANSPORT_OPTION,
                    sorted(_SNAPSHOT_STAGING_TRANSPORTS),
                    staging_transport,
                )
            )
        self._validate_unl_source_options(options)
        _null_byte_mode(options)
        if _APPEND_INGESTION_OPTION in options:
            _append_only_value(options[_APPEND_INGESTION_OPTION])
        if _APPEND_DELETE_TOMBSTONES_OPTION in options:
            _option_bool(options, _APPEND_DELETE_TOMBSTONES_OPTION, True)
        if _SNAPSHOT_SCAN_OPTION in options:
            _snapshot_scan_value(options[_SNAPSHOT_SCAN_OPTION])
        if int(options.get("cdc.max.records", str(_DEFAULT_CDC_MAX_RECORDS))) > 256:
            # 161: Option 'cdc.max.records' must be <= 256
            raise ValueError(_m(161))
        if int(options.get("cdc.read.bytes", "32000")) > 32767:
            # 162: Option 'cdc.read.bytes' must be <= 32767
            raise ValueError(_m(162))
        if (
            int(
                options.get(
                    "max.concurrent.connections",
                    str(_DEFAULT_MAX_CONCURRENT_CONNECTIONS),
                )
            )
            > 9999
        ):
            # 163: Option 'max.concurrent.connections' must be <= 9999
            raise ValueError(_m(163))
        slot_count = int(
            options.get(
                "max.concurrent.connections",
                str(_DEFAULT_MAX_CONCURRENT_CONNECTIONS),
            )
        )
        daemon_reservation = int(
            options.get(
                _DAEMON_RESERVATION_OPTION,
                str(_DEFAULT_DAEMON_CONNECTION_RESERVATION),
            )
        )
        # Reject rather than clamp: at slot_count a daemon could never claim a slot,
        # stranding the sharded CDC session and the snapshot drain permanently.
        if not 0 <= daemon_reservation < slot_count:
            # 17: Option '{}' must be >= 0 and < max.concurrent.connections ({})
            raise ValueError(_m(17, _DAEMON_RESERVATION_OPTION, slot_count))
        port = int(options.get("port", "9088"))
        if not 1 <= port <= 65535:
            # 164: Option 'port' must be between 1 and 65535
            raise ValueError(_m(164))
        login_timeout = float(options.get("authentication.login.timeout", "30"))
        if not math.isfinite(login_timeout) or login_timeout <= 0:
            # 165: Option 'authentication.login.timeout' must be > 0
            raise ValueError(_m(165))
        capacity_delay = float(
            options.get(
                "capacity.retry.max.delay.seconds",
                str(_DEFAULT_CAPACITY_RETRY_MAX_DELAY_SECONDS),
            )
        )
        if not math.isfinite(capacity_delay) or capacity_delay < 0:
            # 166: Option 'capacity.retry.max.delay.seconds' must be >= 0
            raise ValueError(_m(166))
        self._bridge_instance: InformixBridge | None = None
        self._tables: dict[str, Table] | None = None
        self._tables_complete = False
        # Memoizes the key-index directions adopted for a primary.keys override,
        # keyed by (identity, key columns). The override runs on every _table call
        # (including cache hits), so the catalog lookup must happen at most once
        # per table+key rather than per microbatch.
        self._override_direction_cache: dict[tuple[str, tuple[str, ...]], tuple[bool, ...]] = {}
        self._snapshot_high_water: dict[tuple[str, str], int] = {}
        self._snapshot_schema_ids: dict[tuple[str, str], str] = {}
        self._trigger_available_now = False
        self._trigger_boundaries: dict[str, tuple[int, str, str]] = {}
        # When a delete reader first yielded for a schema transition, per (identity,
        # checkpoint schema id); see _ensure_schema_transition_wait_bounded.
        self._schema_transition_waits: dict[tuple[str, str], float] = {}
        self._activity_touched: dict[tuple[str, str], float] = {}
        self._cleaned_update_scopes: set[tuple[str, str]] = set()
        self._cleaned_snapshot_stages: set[str] = set()
        # Snapshot-page staging transport, resolved once on first use: None means the
        # FUSE mount; a WorkspaceFilesApi means the Files REST API. See _staging_transport.
        self._staging_transport_resolved = False
        self._staging_files_api: WorkspaceFilesApi | None = None
        self._staging_rest_required = False
        self._staging_workspace_host = ""
        self._registration_scope: str | None = _INFORMIX_REGISTRATION_CONTEXT["scope"]
        self._metadata_session_lock = threading.RLock()
        # Set by a snapshot-drain worker to a callback that reports a staged page to the
        # pool, resetting the consumer's liveness watchdog. None on a normal reader.
        self._drain_progress: Callable[[], None] | None = None
        # Set while a first microbatch's staged page 0 may be served from an executor (see
        # _staged_snapshot_result): the serve then returns its rows unread.
        self._defer_staged_rows = False
        # Consumed-page cleanup runs off the serve path on a background pool, and a
        # per-stream high-water mark (keyed by scope/schema/snapshot_lsn) makes it
        # incremental: each microbatch schedules only the pages newly advanced past,
        # not a rescan of every earlier page. The executor is lazily created (and
        # excluded from pickling) because it is a driver-only, non-serializable object.
        self._snapshot_cleanup_executor_instance: concurrent.futures.ThreadPoolExecutor | None = (
            None
        )
        self._snapshot_cleanup_watermark: dict[tuple[str, str, int], int] = {}
        # Per-stream monotonic timestamp of the last live schema refresh, keyed by table
        # identity, so a resumed snapshot re-queries Informix for drift only every
        # _snapshot_schema_refresh_interval seconds rather than every microbatch. The
        # interval is an instance attribute so tests can force per-page (0) refreshes.
        self._snapshot_schema_refreshed_at: dict[str, float] = {}
        self._snapshot_schema_refresh_interval = float(_SNAPSHOT_SCHEMA_REFRESH_INTERVAL_SECONDS)
        # Driver-only bridge between the partitioned reader's latest_offset and
        # get_partitions for an *embedded* (non-page-serve) microbatch: the rows the
        # driver already materialized, keyed by the start offset. Excluded from pickling
        # (driver-only) and cleared on scope change. A cache miss recomputes via read_table,
        # so correctness never depends on it -- it only avoids a second driver read.
        # Values are codec-encoded (JSON-safe) rows -- the exact descriptor payload
        # get_partitions emits and read_partition decodes; see _encode_embedded_rows.
        self._partition_embedded_rows: dict[str, list[Any]] = {}
        # The same bridge for a first microbatch that serves staged page 0 from an
        # executor: its page-serve tuple, so get_partitions needs no manifest read.
        self._partition_page_batches: dict[str, tuple] = {}
        # Driver-only gzip record-window state (see _UNL_GZIP_RECORDS_OPTION): the open
        # record iterator for the gzip file being served, as [key, next_record_index,
        # iterator], and the last window read, so a repeated latest_offset for the same
        # start returns the same rows instead of advancing the iterator again. Never
        # pickled; losing either only costs a reopen-and-skip.
        self._unl_gzip_reader: list[Any] | None = None
        self._unl_gzip_window_memo: tuple[Any, Any] | None = None
        # Extract-file fingerprints already sampled by this process, keyed by
        # (path, size, mtime_ns): any change to a file's size or exact mtime re-samples it.
        self._unl_fingerprint_cache: dict[tuple[str, int, int], str] = {}
        # Tables whose stale-stage retention sweep has already been submitted by this
        # reader instance, so the age-based safety net runs at most once per table per
        # instance (off the serve path) instead of every microbatch.
        self._retention_swept: set[str] = set()
        # Driver-only: the spilled runs each (table, channel) has yet to finish, as run ->
        # (spill scope, BEGIN LSN, commit LSN or None), and when each pair last listed its runs
        # from Lakebase (see _settle_spilled_runs).
        self._spill_runs: dict[tuple[str, str], dict[str, tuple[str, int, int | None]]] = {}
        self._spill_runs_listed: dict[tuple[str, str], float] = {}

    def set_registration_scope(self, scope: str) -> None:
        # Docstring: Install the scope shared by every reader serialized from one registration.

        if not isinstance(scope, str) or _PIPELINE_SCOPE.fullmatch(scope) is None:
            # 167: Informix registration scope has an invalid identity
            raise ValueError(_m(167))
        if self._registration_scope != scope:
            self._snapshot_high_water.clear()
            self._snapshot_schema_ids.clear()
            self._trigger_boundaries.clear()
            self._schema_transition_waits.clear()
            self._activity_touched.clear()
            self._cleaned_update_scopes.clear()
            self._cleaned_snapshot_stages.clear()
            self._snapshot_cleanup_watermark.clear()
            self._snapshot_schema_refreshed_at.clear()
            self._partition_embedded_rows.clear()
            self._partition_page_batches.clear()
            self._unl_gzip_reader = None
            self._unl_gzip_window_memo = None
            self._retention_swept.clear()
            self._spill_runs.clear()
            self._spill_runs_listed.clear()
            self._trigger_available_now = False
        self._registration_scope = scope

    def _pipeline_scope(self, checkpoint: dict[str, Any] | None = None) -> str:
        scope = self._registration_scope
        if scope is None and checkpoint:
            scope = checkpoint.get("pipeline_scope")
        if not isinstance(scope, str) or _PIPELINE_SCOPE.fullmatch(scope) is None:
            # 168: Informix reader has no registration or checkpoint scope
            raise InformixError(_m(168))
        return scope

    def _offset_scopes(self, offset: dict[str, Any]) -> tuple[str, str]:
        # Docstring: The scope an offset was written under, and the one its staged state is in.
        #
        # A snapshot resumed in a later update finds its manifest, pages and extract pin under
        # the scope that wrote them, which _cleanup_previous_update_scopes keeps; a legacy
        # offset without one falls back to the registration scope. A handoff relocation's
        # state stays under the capturing flow's scope, carried on stage_scope.
        flow = offset.get("pipeline_scope")
        if not isinstance(flow, str) or _PIPELINE_SCOPE.fullmatch(flow) is None:
            flow = self._pipeline_scope(offset)
        stage = offset.get("stage_scope")
        if not isinstance(stage, str) or _PIPELINE_SCOPE.fullmatch(stage) is None:
            stage = flow
        return flow, stage

    def prepare_for_trigger_available_now(self) -> None:
        # Docstring: Freeze stream high-water marks when Spark selects AvailableNow.

        self._trigger_available_now = True
        self._trigger_boundaries.clear()

    def close(self) -> None:
        # Docstring: Close the live SQLI transport, if one was opened.

        # Stop the background page-cleanup pool without blocking on in-flight
        # deletes -- cleanup is best-effort, so a few pages may be left for the
        # retention sweep. Nulling it lets a later read lazily start a fresh pool.
        executor = self._snapshot_cleanup_executor_instance
        if executor is not None:
            self._snapshot_cleanup_executor_instance = None
            executor.shutdown(wait=False)
        self._reset_lakebase_connection()
        with self._metadata_session_lock:
            bridge = self._bridge_instance
            if bridge is None:
                return
            try:
                release = getattr(bridge, "release_connection", None)
                if release is not None:
                    release()
                    return
                transport = getattr(bridge, "transport", None)
                close = getattr(transport, "close", None)
                if close is not None:
                    close()
            finally:
                # Never retain a closed or partially closed bridge.  The bridge's
                # release path also stops its lease heartbeat and frees its
                # connector-managed connection-capacity slot; its own Lakebase
                # connection, which serves slot operations, closes with it.
                self._bridge_instance = None
                self._reset_lakebase_connection(bridge)

    def __enter__(self) -> "InformixLakeflowConnect":
        return self

    def __exit__(self, exc_type, exc_value, traceback) -> None:
        if exc_value is None:
            self.close()
            return
        try:
            self.close()
        except Exception as close_error:
            add_informix_exception_note(exc_value, f"Informix cleanup also failed: {close_error}")

    def __getstate__(self) -> dict[str, Any]:
        # Docstring: Exclude live SQLI state when Spark serializes the data source.
        #
        # Schema and metadata discovery run before Spark ships the reader to a
        # Python worker, so ``_bridge_instance`` can contain a socket, buffered
        # streams, and a thread lock.  None of those objects is transferable or
        # valid in another process.  The worker reconstructs a fresh bridge from
        # the immutable connection options on its first source operation.

        self.close()
        state = self.__dict__.copy()
        state["_bridge_instance"] = None
        state["_metadata_session_lock"] = None
        # Driver-only; never ship materialized embedded rows to a worker. The worker
        # gets its rows from the partition descriptor, not from this cache.
        state["_partition_embedded_rows"] = {}
        # An open gzip record iterator is a live generator, and a window memo holds rows;
        # neither belongs on a worker.
        state["_unl_gzip_reader"] = None
        state["_unl_gzip_window_memo"] = None
        # close() dropped the Lakebase connection; the provisioned state and the Files
        # API client hold an API session and a lock, so a worker resolves its own.
        state["_lakebase_state"] = None
        state["_staging_files_api"] = None
        state["_staging_transport_resolved"] = False
        state["_partition_page_batches"] = {}
        state["_spill_runs"] = {}
        state["_spill_runs_listed"] = {}
        return state

    def __setstate__(self, state: dict[str, Any]) -> None:
        self.__dict__.update(state)
        self._metadata_session_lock = threading.RLock()

    @property
    def _bridge(self) -> InformixBridge:
        if self._bridge_instance is None:
            factory_path = self.options.get("bridge.factory")
            factory = _load_factory(factory_path) if factory_path else _bridge_factory
            self._bridge_instance = factory(self.options)
        return self._bridge_instance

    @contextlib.contextmanager
    def _metadata_access(self) -> Iterator[None]:
        # Docstring: Bypass connection capacity for a catalog lookup, then give the session back.
        #
        # Registration and reader setup read only metadata. Queued for a slot behind running
        # reads they would stall startup, and a wait that gave up would fail it.

        previous = self.options.get("_informix.bypass.connection.capacity")
        self.options["_informix.bypass.connection.capacity"] = "true"
        try:
            yield
        finally:
            try:
                self._release_worker_connection()
            finally:
                if previous is None:
                    self.options.pop("_informix.bypass.connection.capacity", None)
                else:
                    self.options["_informix.bypass.connection.capacity"] = previous

    def list_tables(self) -> list[str]:
        with self._metadata_access():
            return sorted(self._table_map())

    def get_table_schema(self, table_name: str, table_options: dict[str, str]) -> StructType:
        with self._metadata_access():
            table = self._registration_table(table_name, table_options)
            _ensure_materializable(table, table_options)
            renames = dict(table.column_renames or ())
            transforms = {
                name: operand
                for name, _, operand in _recorded_transforms(table.column_transforms) or ()
            }
            fields = [
                StructField(
                    renames.get(column.name, column.name),
                    _transform_spark_type(transforms[column.name], column, table_options)
                    if column.name in transforms
                    else _spark_type(column, table_options),
                    column.nullable
                    or (column.name in transforms and _transform_may_null(transforms[column.name])),
                )
                for column in table.columns
            ]
            fields.extend(
                (
                    StructField(CURSOR, StringType(), False),
                    StructField(COMMIT_LSN, StringType(), False),
                    StructField(TX_ID, LongType(), True),
                    StructField(OP, StringType(), False),
                    StructField(COMMIT_TIME, TimestampType(), True),
                )
            )
            return StructType(fields)

    def read_table_metadata(self, table_name: str, table_options: dict[str, str]) -> dict:
        with self._metadata_session_lock, self._metadata_access():
            table = self._registration_table(table_name, table_options)
            _ensure_materializable(table, table_options)
            # Only consulted on the append path (tombstones) or at snapshot time
            # (scan), but validated for every table so a malformed value fails at
            # registration rather than on a later read.
            self._append_delete_tombstones(table_options)
            self._snapshot_cursor_scan(table_options)
            if self._append_only_table(table, table_options):
                # Report a cursor even though no primary key is exposed: the
                # cursor is what makes the framework treat this as an
                # incremental stream. Without it the flow would re-read the
                # whole table into an append target every microbatch and
                # accumulate duplicates without bound.
                result = {
                    "primary_keys": [],
                    "cursor_field": CURSOR,
                    "ingestion_type": "append",
                }
            elif not _cdc_capable(table):
                result = {
                    "primary_keys": [],
                    "cursor_field": None,
                    "ingestion_type": "snapshot",
                }
            else:
                renames = dict(table.column_renames or ())
                result = {
                    "primary_keys": [renames.get(key, key) for key in table.primary_keys],
                    "cursor_field": CURSOR,
                    "ingestion_type": "cdc_with_deletes",
                }
            return result

    def _registration_table(self, table_name: str, table_options: dict[str, str]) -> Table:
        # Docstring: Resolve one configured table with a targeted catalog lookup.
        #
        # The framework asks for one specific table at a time (the pipeline spec's
        # exact ``owner.name``), so query just that table rather than scanning and
        # parsing the whole catalog. This keeps an unrelated unsupported table from
        # breaking registration for tables that are configured, and avoids reading
        # a large catalog wholesale. Resolved tables are cached per table in the
        # cross-instance coordinator so repeated registrations reuse them.

        exposed = table_options.get("qualified_source_table", table_name)
        key = self._registration_table_cache_key()
        if key is None:
            return self._table(table_name, table_options, refresh=True)
        coordinator = _STATE_VALIDATION_COORDINATOR
        cache_key = (*key, exposed)
        with coordinator.condition:
            # Held across the catalog lookup on purpose: concurrent registrations of one
            # table share a single lookup instead of each querying Informix.
            table = coordinator.table_caches.get(cache_key)
            if table is None:
                table = self._resolve_registration_table(exposed)
                coordinator.table_caches[cache_key] = table
                while len(coordinator.table_caches) > _MAX_REGISTRATION_TABLE_CACHES:
                    del coordinator.table_caches[next(iter(coordinator.table_caches))]
        if self._tables is None:
            self._tables = {}
        self._tables[exposed] = table
        return self._apply_table_options(table, table_options)

    def _resolve_registration_table(self, exposed: str) -> Table:
        # Docstring: Resolve a single configured table by exposed ``owner.name`` via a
        # targeted catalog query, applying the same table filters ``_table_map`` would.
        # Only this one table is read and parsed, so an unrelated unsupported table
        # elsewhere in the catalog cannot fail it.

        parts = _split_identity(exposed)
        if len(parts) != 2 or not all(_IDENTIFIER.fullmatch(part) for part in parts):
            # 169: Unknown or excluded Informix table '{}'
            raise ValueError(_m(169, exposed))
        database = self.options.get("database", "")
        table = Table.parse(
            self._bridge.get_table(_join_identity(database, parts[0], parts[1])),
            database,
        )
        if not self._selected(table):
            # 169: Unknown or excluded Informix table '{}'
            raise ValueError(_m(169, exposed))
        return table

    def _registration_table_cache_key(self) -> tuple[str, ...] | None:
        scope = self._registration_scope
        hostname = self.options.get("hostname")
        server = self.options.get("server")
        if scope is None or not hostname or not server:
            # Injected test bridges and incomplete discovery configurations do
            # not have a stable source identity and must remain instance-local.
            return None
        return (
            scope,
            hostname.strip().rstrip(".").casefold(),
            self.options.get("port", "9088"),
            server.strip().casefold(),
            self.options.get("database", "").strip().casefold(),
            self.options.get("table.include.list", self.options.get("tables", "")),
            self.options.get("table.exclude.list", ""),
            # Discovery keys a table by its unique index only when this is on.
            self.options.get(_PROMOTE_UNIQUE_INDEX_OPTION, ""),
        )

    def read_table(
        self, table_name: str, start_offset: dict, table_options: dict[str, str]
    ) -> tuple[Iterator[dict], dict]:
        rows, offset = self._read_upserts(table_name, start_offset, table_options)

        def columns():
            return self._table(table_name, table_options).columns

        return self._output_rows(rows, table_options, columns), offset

    def _read_upserts(
        self, table_name: str, start_offset: dict, table_options: dict[str, str]
    ) -> tuple[Iterator[dict], dict]:
        # Docstring: ``read_table`` under source column names; rename_columns is applied
        # only where rows leave the connector.

        effective_start = self._effective_start_offset(start_offset)
        snapshot_mode = self._snapshot_mode(table_options)
        self._publish_checkpoint_channel_start_before_capacity(
            table_name, effective_start, table_options
        )
        replaying = self._replay_stop_lsn(table_options) is not None
        replay_wait_budget = self._replay_connection_wait_budget(table_options)
        with self._capacity_attempt(
            start_offset, replaying=replaying, replay_wait_budget=replay_wait_budget
        ):
            return self._read_table_attempt(
                table_name, start_offset, effective_start, table_options, snapshot_mode
            )

    def _read_table_attempt(
        self,
        table_name: str,
        start_offset: dict,
        effective_start: dict,
        table_options: dict[str, str],
        snapshot_mode: str,
        attempt_index: int = 0,
    ) -> tuple[Iterator[dict], dict]:
        # Re-runs this attempt from the top after a transient shared-state failure.
        # Recursion rather than a loop because the failure surfaces from inside the
        # handlers below, and the retry has to redo the shared-state work that failed
        # rather than resume part-way through it. Bounded by attempt_index.
        def read_again():
            return self._read_table_attempt(
                table_name,
                start_offset,
                effective_start,
                table_options,
                snapshot_mode,
                attempt_index + 1,
            )

        try:
            try:
                table = self._table(table_name, table_options)
                migration = self._table_migration(table_options)
                if not migration and self._replay_stop_lsn(table_options) is None:
                    # A replay is skipped too: an initial range starts from no offset, so
                    # it would retain no scope and drop the one Spark's logged end names.
                    # The read that follows from that end cleans up, keeping it.
                    #
                    # Skip obsolete-scope cleanup for the whole migration window. On a
                    # same-pipeline relocation the *capturing* flow's scope looks like an
                    # ordinary previous update, and the cutover-seed read (empty checkpoint,
                    # so no stage_scope yet to trigger the in-method guard) would otherwise
                    # delete its still-needed snapshot manifest before Restore serves it.
                    # After Restore (table.migration cleared) the stage_scope guard inside
                    # _cleanup_previous_update_scopes protects it until the serve completes.
                    self._cleanup_previous_update_scopes(table, effective_start)
                    if effective_start.get("handoff_seeded"):
                        # First post-Restore read still carrying the marker: drop any token
                        # the cutover run left behind (see _drop_orphaned_handoff_tokens).
                        # Both channels, unconditionally. Once table.migration is cleared the
                        # delete reader can no longer seed from its token (that path is
                        # migration-only), so a lingering delete token is always dead here.
                        # The delete reader drops its own token only when its offset carries
                        # the marker, which never happens if the cutover delete flow arrived
                        # with a non-empty checkpoint (it re-parked instead of seeding), so
                        # its token would otherwise be orphaned with no TTL. This upsert read
                        # is guaranteed to fire post-Restore, so dropping both here is the
                        # reliable one-shot.
                        self._drop_orphaned_handoff_tokens(
                            table, [_HANDOFF_CHANNEL_UPSERT, _HANDOFF_CHANNEL_DELETE]
                        )
                        # Strip the marker so this is one-shot: nothing post-Restore reads
                        # it, and a quiet (no-advance) read would otherwise return it and
                        # re-drop every poll until the stream advances off it. A copy: the
                        # caller's offset is Spark's, and the partition cache is keyed by it.
                        effective_start = {
                            k: v for k, v in effective_start.items() if k != "handoff_seeded"
                        }
                self._touch_table_state(table)
                self._maybe_sweep_stale_snapshot_stages(table)
                _ensure_materializable(table, table_options)
                # A staged snapshot's checkpoint too, mid-serve: it names the snapshot's LSN
                # and schema, which its first batch published for the update that took it.
                if (
                    _cdc_capable(table)
                    and effective_start.get("phase") in ("stream", "snapshot")
                    and effective_start.get("schema_fingerprint") is not None
                ):
                    checkpoint = _validated_offset(effective_start)
                    self._publish_upsert_channel_start(
                        table,
                        int(checkpoint.get("begin_lsn") or checkpoint["commit_lsn"]),
                        str(checkpoint["schema_id"]),
                        str(checkpoint["schema_fingerprint"]),
                        self._pipeline_scope(),
                    )
                if self._append_only_table(table, table_options):
                    # Append-only has exactly two states: establish the boundary once,
                    # then stream. _read_stream needs no primary key, so a key-less
                    # table follows the identical CDC path from here on.
                    if effective_start and migration:
                        # Whatever the phase: a capture parks it and a committed seed drops
                        # the token. A seed from a keyed capture can be mid-snapshot.
                        result = self._append_migration_record_and_stop(table, effective_start)
                    elif effective_start and effective_start.get("phase") == "stream":
                        # After Restore, a handoff seed can carry an in-flight incremental
                        # copy (phase=="stream" with an "incremental" block, only ever from a
                        # keyed capture that was mid-copy); continue the copy from its cursor
                        # rather than treating it as pure CDC, or the un-copied rows are lost.
                        if self._offset_is_incremental_reader(effective_start):
                            result = self._read_incremental(table, effective_start, table_options)
                        else:
                            # An initial snapshot staged pages, as a keyed one does below.
                            self._cleanup_completed_snapshot_stage(table, effective_start)
                            result = self._read_stream(
                                table, effective_start, table_options, deletes=False
                            )
                    elif effective_start and effective_start.get("phase") == "snapshot":
                        # An in-flight snapshot finishes whatever snapshot.mode says now, as a
                        # keyed one does below: a seed from a keyed capture mid-snapshot, or a
                        # mode changed or unset mid-snapshot, would otherwise start CDC at the
                        # boundary (cdc_only) and drop the pages not yet served.
                        result = self._read_snapshot(
                            table, effective_start, table_options, allow_keyless=True
                        )
                    else:
                        result = self._read_append_only(table, effective_start, table_options)
                elif migration:
                    result = self._read_handoff(table, effective_start)
                elif not _cdc_capable(table):
                    if snapshot_mode in {"cdc_only", "recovery"}:
                        # 170: snapshot.mode={} requires a CDC-capable table; '{}' is snapshot-only
                        raise ValueError(_m(170, snapshot_mode, table.exposed_name))
                    result = self._read_snapshot_only(table, table_options)
                elif snapshot_mode == "recovery" and (
                    not effective_start or effective_start.get("phase") != "stream"
                ):
                    # 171: snapshot.mode=recovery requires an existing stream checkpoint; use
                    # snapshot.mode=initial for a new or snapshot-phase table
                    raise InformixError(_m(171))
                elif snapshot_mode == "recovery":
                    checkpoint = _validated_offset(effective_start)
                    current_table = self._refresh_table_schema(table, None)
                    if checkpoint.get("schema_fingerprint") != _schema_fingerprint(current_table):
                        # 172: snapshot.mode=recovery cannot rebuild schema history for '{}' because
                        # the source schema differs from the checkpoint; run a full refresh
                        raise InformixError(_m(172, table.exposed_name))
                    # Recovery explicitly repairs missing immutable schema
                    # history. Ordinary microbatches trust the validated
                    # checkpoint and avoid rereading this Volume record.
                    self._record_current_schema(
                        current_table,
                        int(checkpoint["commit_lsn"]),
                        str(checkpoint["schema_id"]),
                        str(checkpoint["schema_fingerprint"]),
                        self._pipeline_scope(checkpoint),
                        owner=True,
                    )
                    result = self._read_stream(
                        current_table, checkpoint, table_options, deletes=False
                    )
                elif snapshot_mode == "initial_only" and effective_start.get("phase") == "stream":
                    self._cleanup_completed_snapshot_stage(table, effective_start)
                    result = (iter(()), dict(effective_start))
                elif snapshot_mode == "cdc_only" and not effective_start:
                    result = self._read_cdc_only(table)
                elif (
                    snapshot_mode == "auto_snapshot"
                    and effective_start.get("phase") == "stream"
                    and self._checkpoint_requires_snapshot(effective_start)
                ):
                    replaying = self._replay_stop_lsn(table_options) is not None
                    result = self._read_incremental(
                        table,
                        None,
                        # A replayed range from a start the log no longer holds cannot be
                        # reproduced; it resnapshots, as an initial range does. Spark goes on
                        # from the end it logged, so one with no copy cursor drains the copy.
                        {_REPLAY_STOP_PK_OPTION: "null", **table_options}
                        if replaying
                        else table_options,
                        pipeline_scope_override=self._resnapshot_scope(table, effective_start),
                    )
                    if replaying:
                        result = result[0], {**result[1], _REPLAY_REESTABLISHED: True}
                elif snapshot_mode in {"incremental", "auto_snapshot"} and not effective_start:
                    result = self._read_incremental(table, None, table_options)
                elif (
                    snapshot_mode in {"incremental", "auto_snapshot"}
                    and "incremental" in effective_start
                ):
                    result = self._read_incremental(table, effective_start, table_options)
                elif not effective_start or effective_start.get("phase", "snapshot") == "snapshot":
                    result = self._read_snapshot(table, effective_start, table_options)
                else:
                    self._cleanup_completed_snapshot_stage(table, effective_start)
                    result = self._read_stream(table, effective_start, table_options, deletes=False)
                return self._reset_retry_counts(result, start_offset)
            except (SharedStateAccessUnavailable, OSError) as error:
                return self._volume_failure_result(
                    error, read_again, table_options, attempt_index, start_offset
                )
            except ConnectionCapacityUnavailable:
                # Continuous flows are permanent, so capacity pressure is the
                # steady state rather than a fault: always yield and let the
                # framework call again, bounded by the consecutive-miss cap in
                # _capacity_retry_offset so a permanently starved flow still
                # fails loudly instead of silently replicating nothing. Only a
                # triggered flow raises here -- it drains and releases its slot,
                # so an exhausted wait is a genuine end-of-data failure and
                # yielding an empty batch would make AvailableNow stop early.
                if self._trigger_available_now:
                    raise
                if self._replay_stop_lsn(table_options) is not None:
                    raise
                return iter(()), self._capacity_retry_offset(start_offset)
        finally:
            self._release_worker_connection()

    # ------------------------------------------------------------------
    # SupportsPartitionedStream -- partitioned snapshot-page reader
    # ------------------------------------------------------------------
    # Default on (see _PARTITIONED_STREAM_OPTION). Only the staged-snapshot
    # page-serve phase fans out: a microbatch spans up to pages-per-batch staged
    # pages, each read+decoded on its own Spark executor via read_partition, and so
    # is the bootstrap microbatch's page 0. Every other phase (live CDC/incremental
    # stream, transitions, deletes) is embedded partitions whose rows the driver
    # computed via read_table / read_table_deletes -- byte-for-byte the simple
    # reader's output, just wrapped. The delicate phase machine (read_table,
    # _read_stream, _read_snapshot, transitions, _recover) is reused verbatim; only
    # its (rows, offset) output is reshaped into the partitioned contract.

    def _partitioned_stream_enabled(self) -> bool:
        return _option_bool(self.options, _PARTITIONED_STREAM_OPTION, True)

    def _partitioned_pages_per_batch(self) -> int:
        return int(
            self.options.get(
                _PARTITIONED_SNAPSHOT_PAGES_PER_BATCH_OPTION,
                str(_DEFAULT_PARTITIONED_SNAPSHOT_PAGES_PER_BATCH),
            )
        )

    def _is_delete_flow(self) -> bool:
        return self.options.get(_IS_DELETE_FLOW_OPTION) == "true"

    @staticmethod
    def _partition_offset_key(start_offset: dict | None) -> str:
        return json.dumps(start_offset or {}, sort_keys=True)

    @staticmethod
    def _encode_embedded_rows(rows: Iterable[dict[str, Any]]) -> list[Any]:
        # F1: the framework JSON-serializes each partition descriptor
        # (InputPartition(json.dumps(descriptor))), but read_table rows carry native
        # Decimal / bytes / etc. that json cannot encode. Round-trip every row through
        # the staging codec -- the same lossless JSON-safe form staged pages use -- so
        # the descriptor serializes and read_partition reconstructs the exact rows.
        return [_encode_snapshot_stage_value(row) for row in rows]

    @staticmethod
    def _decode_embedded_rows(rows: Iterable[Any]) -> Iterator[dict[str, Any]]:
        for row in rows:
            yield _decode_snapshot_stage_value(row)

    def is_partitioned(self, table_name: str) -> bool:
        # Docstring: Gate the partitioned reader (default on).
        #
        # True only for tables with a bounded staged-snapshot -> stream lifecycle:
        # keyed CDC tables and append-only tables. Their snapshot serves immutable
        # staged pages that fan out across executors, and every microbatch is bounded
        # so the embedded fallback never ships an unbounded batch. Snapshot-only
        # (non-CDC, non-append) tables drain unbounded and stay on the simple reader.
        # Cheap and exception-safe: any doubt returns False -> simpleStreamReader.

        if not self._partitioned_stream_enabled():
            return False
        # Shared CDC is always on, so no shared-session check is needed here. The lookup is
        # the registration one, outside connection capacity: queued for a slot among a
        # starting pipeline's flows, a wait that gave up would leave the table on the simple
        # reader for the whole stream.
        try:
            with self._metadata_access():
                table = self._registration_table(table_name, self.options)
            return bool(_cdc_capable(table) or self._append_only_table(table, self.options))
        except Exception:  # pylint: disable=broad-except
            # 174: Informix reads '{}' with the simple stream reader: its table lookup failed
            logging.getLogger(__name__).warning(
                _m(174, table_name),
                exc_info=True,
            )
            return False

    def _snapshot_page_batch(
        self, table: Table, effective_start: dict, table_options: dict[str, str]
    ) -> tuple[str, str, int, int, int, int] | None:
        # Docstring: Resolve a staged-snapshot page-serve microbatch, else None.
        #
        # Returns ``(stage_scope, schema_id, snapshot_lsn, start_page, end_page,
        # page_count)`` for a snapshot-phase checkpoint whose staged manifest exists,
        # where ``stage_scope`` is the scope the pages are stored under (the capturing
        # flow's, for a handoff relocation; otherwise the offset's own scope),
        # mirroring the resume resolution in :meth:`_read_snapshot`. Deterministic
        # given the start offset + immutable manifest + pages-per-batch, so
        # ``latest_offset`` and ``get_partitions`` agree without sharing state. None
        # means "not a page-serve" -> the embedded path. Never a page-serve for the
        # delete channel (deletes stage no pages).

        if self._is_delete_flow():
            return None
        if self._table_migration(table_options):
            # Migration is record-and-stop: a snapshot-phase offset while table.migration is
            # set must reach the embedded _read_handoff (park the token on capture, drop it
            # on the committed seed) rather than being served here. After Restore
            # (table.migration cleared) this returns a batch and serves the pages -- under
            # stage_scope for a relocation -- as normal.
            return None
        if not effective_start or effective_start.get("phase") not in (None, "snapshot"):
            return None
        try:
            checkpoint = _validated_offset(effective_start)
        except Exception:  # pylint: disable=broad-except
            return None
        snapshot = checkpoint.get("snapshot")
        if not isinstance(snapshot, dict) or "page_index" not in snapshot:
            return None
        # _validated_offset (above) already verified, for a snapshot-phase offset,
        # that schema_id is 32-hex, snapshot_lsn is present and non-negative, and
        # snapshot.page_index is a non-negative int -- so these reads cannot raise. A
        # malformed offset raises inside _validated_offset and is caught above,
        # returning None -> the embedded path.
        schema_id = str(checkpoint["schema_id"])
        snapshot_lsn = int(checkpoint["snapshot_lsn"])
        start_page = int(snapshot["page_index"])
        stage_scope = self._offset_scopes(checkpoint)[1]
        # Staged pages live under the scope that created them. For a handoff relocation
        # that is the *capturing* flow's scope, carried on stage_scope while the offset's
        # own pipeline_scope is already the new flow's; otherwise stage_scope == the
        # offset scope and behaviour is unchanged. The returned scope is the *stage*
        # scope -- it drives the manifest read, the page reads (driver + executor), and
        # consumed-page cleanup. The emitted offset's scope is resolved separately from
        # the checkpoint in _snapshot_page_batch_offset.
        manifest = self._read_snapshot_stage_manifest(table, stage_scope, schema_id)
        if manifest is None or int(manifest["snapshot_lsn"]) != snapshot_lsn:
            return None
        page_count = int(manifest["page_count"])
        if start_page < 0 or start_page >= page_count:
            return None
        end_page = min(start_page + self._partitioned_pages_per_batch(), page_count)
        return (stage_scope, schema_id, snapshot_lsn, start_page, end_page, page_count)

    def _bootstrap_page_batch(
        self, table: Table, effective_start: dict, end_offset: dict, table_options: dict[str, str]
    ) -> tuple[str, str, int, int, int, int] | None:
        # Docstring: Resolve a table's first microbatch as a serve of staged page 0, else None.
        #
        # The first microbatch drains the snapshot to the stage, then serves page 0 from it:
        # an immutable page an executor can stream like every later page. Embedded in the
        # descriptor instead, the executor parses the whole page at once, which passes
        # serverless's 1 GB Python limit for a wide table. Recognised from the (start, end)
        # pair alone, so a batch re-planned after a driver restart is served the same way:
        # an empty start, and the end _staged_snapshot_result emits after page 0 of the
        # manifest pinned at that LSN. Same tuple as _snapshot_page_batch.

        if effective_start or not end_offset or "incremental" in end_offset:
            return None
        if self._is_delete_flow() or self._table_migration(table_options):
            return None
        try:
            end = _validated_offset(end_offset)
        except Exception:  # pylint: disable=broad-except
            return None
        lsn = int(end["commit_lsn"])
        # _staged_snapshot_result pins every LSN of either end at the snapshot boundary.
        if {int(end["begin_lsn"]), int(end["change_lsn"])} != {lsn}:
            return None
        if end.get("tx_id") is not None:
            return None
        if end["phase"] == "snapshot":
            snapshot = end.get("snapshot")
            if "stage_scope" in end or not isinstance(snapshot, dict):
                return None
            if snapshot.get("page_index") != 1 or int(end.get("snapshot_lsn", -1)) != lsn:
                return None
        scope, schema_id = str(end["pipeline_scope"]), str(end["schema_id"])
        manifest = self._read_snapshot_stage_manifest(table, scope, schema_id)
        if manifest is None or int(manifest["snapshot_lsn"]) != lsn:
            return None
        page_count = int(manifest["page_count"])
        # A snapshot-phase end leaves pages to serve; a stream end served the only page, or
        # none for an empty table. Recognising that here keeps a re-plan in a later update
        # from falling through to a replay, which would snapshot the table afresh.
        if (page_count > 1) != (end["phase"] == "snapshot") or page_count < 0:
            return None
        return (scope, schema_id, lsn, 0, min(1, page_count), page_count)

    def _embedded_read(
        self, table_name: str, start_offset: dict, table_options: dict[str, str]
    ) -> tuple[Iterator[dict], dict]:
        # Source names: read_partition renames every partition's rows as they leave.
        if self._is_delete_flow():
            return self._read_deletes(table_name, start_offset, table_options)
        return self._read_upserts(table_name, start_offset, table_options)

    def _served_offset(
        self,
        table_name: str,
        table_options: dict[str, str],
        start_offset: dict,
        effective_start: dict,
    ) -> dict | None:
        # Docstring: The end of a ``.unl`` split window or staged page batch, else None.
        #
        # Both serves plan from metadata without a read, so they run under _metadata_access:
        # no wait behind running reads for a slot, and the session a catalog lookup or the
        # ``.unl`` boundary pin opened is given back whether planning succeeds or fails. A
        # delete flow or a stream-phase offset never serves, so it skips the lookup, which
        # for a delete reader would take a slot its upsert reader may need. A dropped Volume
        # mount is retried in place (_plan_with_mount_retry).

        unl = self._unl_snapshot_serve(table_options, effective_start)
        if not unl and (
            self._is_delete_flow()
            or not effective_start
            or effective_start.get("phase") not in (None, "snapshot")
            # Migration records and stops on the read path, which owns a seed's marker.
            or self._table_migration(table_options)
        ):
            return None
        if not self._is_delete_flow():
            # Planned here rather than read, so published here, as _read_upserts does.
            self._publish_checkpoint_channel_start_before_capacity(
                table_name, effective_start, table_options
            )

        def plan() -> dict | None:
            with self._metadata_access():
                table = self._table(table_name, table_options)
                batch = None
                if not unl:
                    batch = self._snapshot_page_batch(table, effective_start, table_options)
                    if batch is None:
                        # The read path serves it, and drops a restored seed's tokens itself.
                        return None
                if effective_start.get("handoff_seeded"):
                    # The first post-Restore read of a seed taken mid-snapshot is served
                    # here, not by _read_table_attempt, so drop the cutover's tokens here.
                    self._drop_orphaned_handoff_tokens(
                        table, [_HANDOFF_CHANNEL_UPSERT, _HANDOFF_CHANNEL_DELETE]
                    )
                if batch is not None:
                    return self._snapshot_page_batch_offset(table, effective_start, batch)
                # File source: serve the extract as a window of splits per microbatch. Leaving
                # the embedded cache untouched steers the following get_partitions to the
                # unl_split fan-out instead of the driver-side embedded path. A gzip record
                # window is the exception: its rows were read here on the driver, so they are
                # cached for get_partitions exactly as an embedded read's are.
                end, rows = self._unl_snapshot_offset(table, table_options, effective_start)
                if rows is not None:
                    self._partition_embedded_rows.clear()
                    self._partition_embedded_rows[self._partition_offset_key(start_offset)] = (
                        self._encode_embedded_rows(rows)
                    )
                return end

        return self._plan_with_mount_retry(plan)

    @staticmethod
    def _plan_with_mount_retry(  # pylint: disable=inconsistent-return-statements
        plan: Callable[..., Any], *args: Any
    ) -> Any:
        # Docstring: Plan a staged-page or ``.unl`` microbatch, retrying a dropped mount in place.
        #
        # The plan reads the manifest, staged pages and extract files (and, for a ``.unl``
        # boundary pin, the log bounds), so running it again is safe. It cannot answer a
        # dropped Volume mount with an empty batch: returning the start offset from
        # latest_offset would end a triggered update early, and get_partitions must serve
        # the range latest_offset logged. So it tries again with backoff, and the last
        # attempt's error fails the batch, which Spark plans again from the same offsets.

        for attempt_index in itertools.count():
            try:
                return plan(*args)
            except Exception as error:  # pylint: disable=broad-except
                transient = isinstance(error, SharedStateAccessUnavailable) or _dropped_mount_error(
                    error
                )
                if not transient or attempt_index + 1 >= _TRANSIENT_VOLUME_IN_PROCESS_ATTEMPTS:
                    raise
                delay = min(0.25 * (2**attempt_index), _TRANSIENT_VOLUME_IN_PROCESS_MAX_SECONDS)
                time.sleep(random.uniform(delay / 2, delay))

    def latest_offset(
        self,
        table_name: str,
        table_options: dict[str, str],
        start_offset: dict | None = None,
    ) -> dict:
        start_offset = start_offset or {}
        effective_start = self._effective_start_offset(start_offset)
        end = self._served_offset(table_name, table_options, start_offset, effective_start)
        if end is not None:
            return end
        self._defer_staged_rows = not effective_start
        try:
            rows, next_offset = self._embedded_read(table_name, start_offset, table_options)
        finally:
            self._defer_staged_rows = False
        # F1: cache the JSON-safe encoded rows (they are the descriptor payload).
        # F6: keep only this microbatch's entry, so a latest_offset call Spark never
        # follows with get_partitions (speculative discovery, or an empty start==end
        # batch) cannot leak driver memory. A later cache miss recomputes -- safe
        # because partitioned mode requires the shared CDC session, whose reads are
        # idempotent for a committed start.
        self._partition_embedded_rows.clear()
        self._partition_page_batches.clear()
        if isinstance(rows, _DeferredStagedPage):
            # get_partitions serves page 0 from the stage, so the driver never reads it.
            self._partition_page_batches[self._partition_offset_key(start_offset)] = rows.page_batch
            return next_offset
        self._partition_embedded_rows[self._partition_offset_key(start_offset)] = (
            # A spilled transaction stays on its pages, which get_partitions hands to executors.
            rows if isinstance(rows, _SpilledRows) else self._encode_embedded_rows(rows)
        )
        return next_offset

    def _snapshot_page_batch_offset(
        self,
        table: Table,
        effective_start: dict,
        batch: tuple[str, str, int, int, int, int],
    ) -> dict:
        # Docstring: Build the end offset for a page-serve microbatch spanning [start,end) pages.
        #
        # Mirrors :meth:`_staged_snapshot_result`'s offset construction: a
        # snapshot-phase offset that advances ``page_index`` to ``end_page`` and
        # carries the boundary page's ``upper_pk`` as ``last_pk``, or the stream-phase
        # transition offset once the last page is served. The schema fingerprint is
        # carried forward from the checkpoint rather than recomputed from a live
        # catalog read -- staged pages are frozen as-of ``snapshot_lsn`` so a
        # mid-snapshot schema change cannot invalidate them, and drift is still caught
        # at the snapshot->CDC transition by ``_read_stream``. In the (overwhelming)
        # no-drift case this is byte-identical to what the simple reader commits.

        stage_scope, schema_id, snapshot_lsn, start_page, end_page, page_count = batch
        expected_fingerprint = effective_start.get("schema_fingerprint")
        # The flow owns its own scope for the emitted offsets; stage_scope (where the
        # staged pages physically live) drives only the page reads and cleanup, and is
        # carried forward on the non-terminal offset until the snapshot completes.
        flow_scope = self._offset_scopes(effective_start)[0]
        # Pages below this batch's first page are committed -- schedule their async
        # cleanup under the scope that stores them, exactly as the serial serve does.
        self._cleanup_consumed_snapshot_stage_pages(
            table, stage_scope, schema_id, snapshot_lsn, start_page
        )
        if end_page >= page_count:
            # Snapshot complete: transition to the stream phase under the flow's own
            # scope and drop stage_scope -- the offset is now an ordinary stream offset.
            end = _offset(
                snapshot_lsn,
                snapshot_lsn,
                snapshot_lsn,
                None,
                "stream",
                table,
                schema_id,
                flow_scope,
            )
            if expected_fingerprint is not None:
                end["schema_fingerprint"] = expected_fingerprint
            return end
        # Non-terminal: last_pk is the boundary page's upper_pk. Read only that one
        # page's header; its row generator is discarded, so no rows are decoded.
        header, _rows = self._stream_staged_page(
            table, stage_scope, schema_id, snapshot_lsn, end_page - 1
        )
        last_pk = header.get("upper_pk")
        end = _offset(
            snapshot_lsn, snapshot_lsn, snapshot_lsn, None, "snapshot", table, schema_id, flow_scope
        )
        if expected_fingerprint is not None:
            end["schema_fingerprint"] = expected_fingerprint
        end.update(
            {
                "snapshot_lsn": str(snapshot_lsn),
                "snapshot": {"last_pk": last_pk, "page_index": end_page},
            }
        )
        if stage_scope != flow_scope:
            end["stage_scope"] = stage_scope
        return _with_backlog_streak(end, effective_start, True)

    def _served_partitions(
        self,
        table: Table,
        table_options: dict[str, str],
        start_offset: dict | None,
        end_offset: dict | None,
        effective_start: dict,
    ) -> list[dict] | None:
        # Docstring: The partitions of a ``.unl`` split window or staged page batch, else None.
        #
        # Run through _plan_with_mount_retry: like latest_offset's plan it reads only the
        # Volume and Lakebase, so a dropped mount is retried in place. The embedded replay in
        # get_partitions stays outside, as a real read that handles the mount itself.

        if self._unl_snapshot_serve(table_options, effective_start):
            # File source: fan this microbatch's split window across executors -- one
            # unl_split descriptor per byte split in [start_split, start_split+window). The
            # boundary was pinned by latest_offset; take snapshot_lsn from end_offset and
            # the resume point from the start offset's split index (0 on the first read).
            snapshot_lsn = int((end_offset or {})["commit_lsn"])
            start_split, start_record = _unl_position(effective_start)
            splits = self._unl_all_splits(table, table_options)
            end_split, end_record = _unl_position(end_offset or {}, terminal=len(splits))
            # The window Spark logged decides, not the gzip record-window option as it is now
            # (a re-plan after a restart may see it changed): a record window ends inside its
            # file or finishes it, and executors serve a window of several files.
            driver_window = (end_split == start_split and end_record > start_record) or (
                self._unl_gzip_driver_window(table_options, splits, start_split, start_record)
                and end_split <= start_split + 1
            )
            # A batch re-planned after a restart reaches here without its latest_offset, so
            # the extract is checked against its pinned manifest here as well.
            end_checkpoint = _validated_offset(end_offset or {})
            window_paths = (
                {splits[start_split][0]}
                if driver_window
                else {split[0] for split in splits[start_split:end_split]}
            )
            self._verify_unl_extract(
                table,
                table_options,
                # Where the serve pinned the extract: the start's scopes, or for the first
                # window the end's, written by the latest_offset that pinned it.
                self._offset_scopes(effective_start or end_checkpoint)[1],
                str(end_checkpoint["schema_id"]),
                snapshot_lsn,
                window_paths,
            )
            if driver_window:
                encoded = self._partition_embedded_rows.pop(
                    self._partition_offset_key(start_offset), None
                )
                if encoded is None:
                    # Re-planning an uncommitted batch (e.g. after a driver restart):
                    # replay exactly the records between start and the logged end.
                    rows = self._replay_unl_gzip_window(
                        table,
                        table_options,
                        snapshot_lsn,
                        splits[start_split],
                        start_record,
                        stop_record=end_record if end_split == start_split else None,
                    )
                    encoded = self._encode_embedded_rows(rows)
                return self._embedded_descriptors(table, encoded)
            # The window is whatever latest_offset logged: up to pages-per-batch splits,
            # ending early before a gzip split that is served in record windows.
            return self._unl_split_descriptors(
                table,
                table_options,
                snapshot_lsn,
                start_split=start_split,
                window=end_split - start_split,
            )
        batch = (
            self._snapshot_page_batch(table, effective_start, table_options)
            or self._partition_page_batches.pop(self._partition_offset_key(start_offset), None)
            or self._bootstrap_page_batch(table, effective_start, end_offset or {}, table_options)
        )
        if batch is not None:
            scope, schema_id, snapshot_lsn, start_page, end_page, page_count = batch
            # The pages Spark logged for the batch: a re-plan after a restart computes its
            # window afresh, and pages.per.batch may have changed since.
            logged = (end_offset or {}).get("snapshot")
            if (end_offset or {}).get("phase") == "stream":
                end_page = page_count
            elif isinstance(logged, dict) and str((end_offset or {}).get("snapshot_lsn")) == str(
                snapshot_lsn
            ):
                end_page = min(int(logged.get("page_index", end_page)), page_count)
            return [
                {
                    "kind": "page",
                    "native_identity": table.native_identity,
                    "exposed_name": table.exposed_name,
                    "pipeline_scope": scope,
                    "schema_id": schema_id,
                    "snapshot_lsn": snapshot_lsn,
                    "page_index": page_index,
                    **self._transform_descriptor_fields(table),
                }
                for page_index in range(start_page, end_page)
            ]
        return None

    def get_partitions(
        self,
        table_name: str,
        table_options: dict[str, str],
        start_offset: dict | None = None,
        end_offset: dict | None = None,
    ) -> Sequence[dict]:
        if start_offset is None and end_offset is None:
            # Batch read. Not partitioned here -- raising makes LakeflowBatchReader
            # fall back to read_table (a single non-partitioned batch).
            # 175: Informix does not support partitioned batch reads
            raise NotImplementedError(_m(175))
        if start_offset == end_offset:
            return []
        # A metadata lookup, as in latest_offset: no capacity wait if the table is not cached
        # (a re-plan after a restart), and the session it opened is given back even when it
        # fails. An embedded replay below takes its own.
        with self._metadata_access():
            table = self._table(table_name, table_options)
        effective_start = self._effective_start_offset(start_offset or {})
        served = self._plan_with_mount_retry(
            self._served_partitions, table, table_options, start_offset, end_offset, effective_start
        )
        if served is not None:
            return served
        encoded = self._partition_embedded_rows.pop(self._partition_offset_key(start_offset), None)
        if encoded is None:
            # F2: a cache miss (Spark re-planning an uncommitted batch after a driver
            # restart) recomputes the read. The recompute must land on exactly the
            # ``end`` Spark already logged: it commits that offset regardless of what
            # the fresh read reaches, so an under-read -- a direct poll bounded by
            # cdc.max.records while the shared daemon is not ready yet, or a daemon
            # buffer that does not yet cover this table -- would silently drop every
            # row between the two. Bound the read at ``end`` and fail closed on a
            # shortfall, the same contract the simple reader's readBetweenOffsets
            # enforces, rather than trusting the recompute to reproduce the batch.
            rows = self._replay_embedded_range(
                table_name, start_offset or {}, end_offset or {}, table_options
            )
            encoded = rows if isinstance(rows, _SpilledRows) else self._encode_embedded_rows(rows)
        if isinstance(encoded, _SpilledRows):
            return encoded.descriptors(self._transform_descriptor_fields(table))
        return self._embedded_descriptors(table, encoded)

    def _replay_embedded_range(
        self, table_name: str, start: dict, end: dict, table_options: dict[str, str]
    ) -> Iterator[dict]:
        # Docstring: Recompute an embedded microbatch bounded by its committed ``end`` offset.
        #
        # The replay bounds are injected into a private copy of the table options, so
        # the read stops at ``end.commit_lsn`` (and, mid-incremental-copy, at
        # ``end.incremental.last_pk``) and the reached offset is verified before any
        # row is returned; the copy keeps the bound from leaking into later reads.

        options = dict(table_options)
        return _replay_between_offsets(
            start,
            end,
            lambda replay_start: self._embedded_read(table_name, replay_start, options),
            options,
            self.options,
        )

    def read_partition(
        self, table_name: str, partition: dict, table_options: dict[str, str]
    ) -> Iterator[dict]:
        rows = self._read_partition_rows(partition, table_options)
        return self._output_rows(rows, table_options, lambda: _descriptor_columns(partition))

    def _output_rows(
        self,
        rows: Iterator[dict],
        table_options: dict[str, str],
        columns: Callable[[], Iterable[Column]] | None = None,
    ) -> Iterator[dict]:
        # Docstring: Rows as they leave the connector: transformed, then renamed.
        #
        # ``columns`` yields the table's columns on demand. A transform needs them only when
        # NVL or COALESCE replaces a NULL in a numeric column (see _fallback_value), so the
        # lookup -- the reader's cached table, or descriptor metadata on an executor -- waits
        # until then.

        transforms = _column_transforms(table_options)
        if transforms:
            key = self.options.get(_TRANSFORM_HASH_KEY_OPTION) or table_options.get(
                _TRANSFORM_HASH_KEY_OPTION
            )
            context = {
                "hash_key": key.encode("utf-8") if key else None,
                "encoding": self._source_encoding(table_options),
                "columns": columns,
                # The table options alone, as the schema reads them (see _number_for_column).
                "options": table_options,
            }
            rows = _transformed_rows(rows, transforms, context)
        return _renamed_rows(rows, _column_renames(table_options))

    def _source_encoding(self, table_options: dict[str, str]) -> str:
        # Docstring: The database code set's Python encoding for a table: the connection's
        # DB_LOCALE, which a table option may override. LENGTH counts bytes in it and a CHAR
        # operand is re-padded to its byte width, on the snapshot, file, and CDC paths alike.

        return _database_encoding({**self.options, **table_options})

    @staticmethod
    def _transform_descriptor_fields(table: Table) -> dict[str, Any]:
        # Docstring: Column metadata a partition descriptor carries so an executor can type a
        # transform's NVL fallback (see _fallback_value) without a catalog connection.

        if not table.column_transforms:
            return {}
        transformed = {name for name, _ in table.column_transforms}
        return {
            "transform_columns": [
                _partition_column(column) for column in table.columns if column.name in transformed
            ]
        }

    def _embedded_descriptor(self, table: Table, encoded) -> dict[str, Any]:
        return {"kind": "embedded", "rows": encoded, **self._transform_descriptor_fields(table)}

    def _embedded_descriptors(self, table: Table, encoded: list[Any]) -> list[dict[str, Any]]:
        # Docstring: An embedded microbatch as descriptors of at most
        # _MAX_EMBEDDED_PARTITION_BYTES of row JSON each, in row order.

        if len(json.dumps(encoded)) <= _MAX_EMBEDDED_PARTITION_BYTES:
            return [self._embedded_descriptor(table, encoded)]
        chunks: list[list[Any]] = [[]]
        size = 0
        for row in encoded:
            row_size = len(json.dumps(row))
            if chunks[-1] and size + row_size > _MAX_EMBEDDED_PARTITION_BYTES:
                chunks.append([])
                size = 0
            chunks[-1].append(row)
            size += row_size
        return [self._embedded_descriptor(table, chunk) for chunk in chunks]

    def _read_partition_rows(
        self, partition: dict, table_options: dict[str, str]
    ) -> Iterator[dict]:
        kind = partition.get("kind")
        if kind == "embedded":
            # F1: reverse the staging-codec encoding get_partitions applied, so the
            # exact read_table rows (Decimal / bytes / etc.) are yielded to the
            # framework -- identical to what the simple reader produces.
            yield from self._decode_embedded_rows(partition.get("rows", []))
            return
        if kind == "page":
            # Executor side: read the staged page by identity only -- no Table and no
            # Informix catalog connection.
            _header, rows = self._stream_staged_page_for(
                partition["native_identity"],
                partition["exposed_name"],
                partition["pipeline_scope"],
                partition["schema_id"],
                int(partition["snapshot_lsn"]),
                int(partition["page_index"]),
            )
            yield from rows
            return
        if kind == "unl_split":
            # Executor side: read one `.unl` byte split by descriptor only -- no Table
            # and no Informix connection; shape rows identically to the serial path.
            yield from self._read_unl_split(partition, table_options)
            return
        if kind == "spill":
            # Executor side: one staged page of a spilled transaction, shaped here by the
            # table the descriptor carries -- no catalog lookup and no Informix connection.
            yield from _spilled_page_rows(
                self._stream_staged_page_for,
                partition["part"],
                int(partition["page_index"]),
                partition["tx"],
                _unwire_json_table(partition["table"]),
                table_options,
                deletes=bool(partition["deletes"]),
                tombstones=bool(partition["tombstones"]),
                encoding=str(partition["encoding"]),
            )
            return
        # 176: Unknown Informix partition descriptor kind: {!r}
        raise InformixError(_m(176, kind))

    def read_table_deletes(
        self, table_name: str, start_offset: dict, table_options: dict[str, str]
    ) -> tuple[Iterator[dict], dict]:
        rows, offset = self._read_deletes(table_name, start_offset, table_options)

        def columns():
            return self._table(table_name, table_options).columns

        return self._output_rows(rows, table_options, columns), offset

    def _read_deletes(
        self, table_name: str, start_offset: dict, table_options: dict[str, str]
    ) -> tuple[Iterator[dict], dict]:
        # Docstring: ``read_table_deletes`` under source column names.

        effective_start = self._effective_start_offset(start_offset)
        snapshot_mode = self._snapshot_mode(table_options)
        # An uncheckpointed delete reader cannot do useful source work until its
        # paired upsert reader publishes the boundary it is actually using.  The
        # table-state key depends only on the configured native identity, so test
        # Lakebase before resolving Informix metadata: _table() opens Informix and
        # would otherwise let coordination waiters consume every scarce slot from
        # the upsert readers that must unblock them.
        # table.migration is excluded too: a delete cutover seeds from its own parked token
        # (see _read_handoff_deletes), which does not depend on the upsert boundary, so
        # it must reach the attempt rather than parking here to wait for that boundary.
        if (
            not effective_start
            and snapshot_mode not in {"initial_only", "recovery"}
            and not self._table_migration(table_options)
            and not self._upsert_channel_start_exists(table_name, table_options)
        ):
            return iter(()), self._schema_node_fallback_offset(start_offset)
        replaying = self._replay_stop_lsn(table_options) is not None
        replay_wait_budget = self._replay_connection_wait_budget(table_options)
        with self._capacity_attempt(
            start_offset, replaying=replaying, replay_wait_budget=replay_wait_budget
        ):
            return self._read_table_deletes_attempt(
                table_name, start_offset, effective_start, table_options, snapshot_mode
            )

    def _read_table_deletes_attempt(
        self,
        table_name: str,
        start_offset: dict,
        effective_start: dict,
        table_options: dict[str, str],
        snapshot_mode: str,
        attempt_index: int = 0,
    ) -> tuple[Iterator[dict], dict]:
        # See _read_table_attempt: re-runs this attempt after a transient
        # shared-state failure, bounded by attempt_index.
        def read_again():
            return self._read_table_deletes_attempt(
                table_name,
                start_offset,
                effective_start,
                table_options,
                snapshot_mode,
                attempt_index + 1,
            )

        try:
            try:
                migration = self._table_migration(table_options)
                if not migration and effective_start.get("handoff_seeded"):
                    # First post-Restore delete read still carrying the marker: drop the
                    # delete-channel token the cutover left behind, one-shot and best-effort
                    # (see _drop_orphaned_handoff_tokens).
                    self._drop_orphaned_handoff_tokens(
                        self._table(table_name, table_options), [_HANDOFF_CHANNEL_DELETE]
                    )
                    # One-shot, on a copy (see _read_table_attempt).
                    effective_start = {
                        k: v for k, v in effective_start.items() if k != "handoff_seeded"
                    }
                if migration:
                    # Capture parks the delete position and freezes; cutover seeds from it
                    # (keyed relocation keeps the delete channel) or, for the SCD1->append
                    # switch, there is no delete flow so this is never reached.
                    result = self._read_handoff_deletes(
                        table_name, effective_start, table_options, start_offset
                    )
                elif snapshot_mode == "initial_only":
                    result = (iter(()), dict(effective_start))
                elif snapshot_mode == "recovery" and (
                    not effective_start or effective_start.get("phase") != "stream"
                ):
                    # 177: snapshot.mode=recovery requires an existing stream checkpoint
                    raise InformixError(_m(177))
                else:
                    result = self._read_table_deletes(
                        table_name,
                        effective_start,
                        table_options,
                        snapshot_mode=snapshot_mode,
                        bootstrap_offset=start_offset,
                    )
                return self._reset_retry_counts(result, start_offset)
            except (SharedStateAccessUnavailable, OSError) as error:
                return self._volume_failure_result(
                    error, read_again, table_options, attempt_index, start_offset
                )
            except TriggerBoundaryUnavailable:
                if self._replay_stop_lsn(table_options) is not None:
                    raise
                return iter(()), self._trigger_boundary_retry_offset(start_offset)
            except SchemaTransitionUnavailable:
                if self._replay_stop_lsn(table_options) is not None:
                    raise
                return iter(()), self._schema_transition_retry_offset(start_offset)
            except ConnectionCapacityUnavailable:
                # Continuous always yields (bounded by the consecutive-miss cap);
                # only a triggered flow raises, where an exhausted wait is a
                # genuine end-of-data failure rather than transient contention.
                if self._trigger_available_now:
                    raise
                if self._replay_stop_lsn(table_options) is not None:
                    raise
                return iter(()), self._capacity_retry_offset(start_offset)
        finally:
            self._release_worker_connection()

    @staticmethod
    def _shared_state_retry_offset(start_offset: dict) -> dict:
        result = dict(start_offset)
        retry_count = _shared_state_retry_count(result)
        if retry_count >= _SHARED_STATE_ACCESS_MAX_RETRIES:
            # 178: Informix shared state exhausted its checkpoint retry limit
            raise SharedStateAccessUnavailable(_m(178))
        time.sleep(random.uniform(0.05, min(0.1 * (2 ** min(retry_count, 5)), 1.5)))
        result["shared_state_retry_count"] = retry_count + 1
        return result

    def _dropped_mount_retry_offset(self, start_offset: dict, error: OSError) -> dict:
        # Docstring: Yield an empty batch for a dropped Volume mount, bounded by a fail-loud cap.
        #
        # Kept separate from ``_shared_state_retry_offset`` because the two count
        # different things at different cadences: that one bounds a fast in-process
        # retry loop, this one bounds consecutive *microbatches*. Sharing a counter
        # would either let a dropped mount stall for ~100 minutes (see
        # ``_DROPPED_MOUNT_MAX_RETRIES``) or cut the in-process retries far too short.
        #
        # Yielding is still the right first response -- a remount settles in seconds
        # and the checkpoint is untouched -- but it must not be the *only* response.
        # A mount that never returns otherwise leaves every flow yielding empty
        # batches with the pipeline reporting RUNNING and committing zero-row Delta
        # versions on schedule, which is indistinguishable from an idle source. This
        # was observed in production taking all 60 flows offline for 13 minutes with
        # no ERROR or WARN anywhere in the event log; only the offset's retry count
        # revealed it. Failing at the cap turns that into a visible flow failure.
        #
        # ``_reset_retry_counts`` drops the key on the next read that reaches the
        # Volume, so the count only ever measures a current run of consecutive
        # failures and a mount that flaps does not accumulate toward the cap.

        result = dict(start_offset)
        retry_count = _dropped_mount_retry_count(result)
        if retry_count >= self._dropped_mount_max_retries():
            # 179: Informix snapshot staging Volume mount was not connected for {} consecutive
            # reads; this flow yielded empty batches throughout and replicated nothing. The Volume's
            # FUSE mount is down rather than the source being idle: check the Volume's availability.
            logging.getLogger(__name__).error(
                _m(179, retry_count),
            )
            # 180: Informix snapshot staging Volume mount has not been connected for {} consecutive
            # reads; the staging Volume is unavailable
            raise InformixError(_m(180, retry_count)) from error
        result["dropped_mount_retry_count"] = retry_count + 1
        return result

    def _dropped_mount_max_retries(self) -> int:
        # Docstring: Consecutive dropped-mount yields tolerated before the flow fails.
        #
        # Configurable because the right bound depends on the microbatch interval:
        # the cap counts reads, not seconds, so a pipeline with a long trigger
        # interval covers the same wall-clock outage in fewer retries. Defaults to
        # ``_DROPPED_MOUNT_MAX_RETRIES``.

        value = int(
            self.options.get(
                "dropped.mount.max.retries",
                str(_DROPPED_MOUNT_MAX_RETRIES),
            )
        )
        if value < 1:
            # 181: Option 'dropped.mount.max.retries' must be >= 1
            raise ValueError(_m(181))
        return value

    def _capacity_retry_max_delay(self) -> float:
        # Docstring: Maximum jittered delay before a continuous reader retries after a miss.
        #
        # A positive value is the inter-read backoff and also caps each acquisition
        # attempt (a short, miss-scaled budget). ``0`` changes both for a continuous
        # flow: the acquisition attempt blocks the full ``connection.wait.timeout.seconds``
        # (maximum chance to claim a slot) and there is no inter-read delay before
        # the next attempt. A continuous flow still yields rather than fails on
        # exhaustion, bounded by ``capacity.retry.max.retries``. For a triggered
        # flow the value is irrelevant: it always blocks fully and raises on
        # exhaustion.

        value = float(
            self.options.get(
                "capacity.retry.max.delay.seconds",
                str(_DEFAULT_CAPACITY_RETRY_MAX_DELAY_SECONDS),
            )
        )
        if not math.isfinite(value) or value < 0:
            # 166: Option 'capacity.retry.max.delay.seconds' must be >= 0
            raise ValueError(_m(166))
        return value

    @staticmethod
    def _offset_is_incremental_reader(start_offset: dict) -> bool:
        # Docstring: Report whether this read is an in-progress incremental snapshot.
        #
        # The incremental strategy interleaves primary-key snapshot chunks with the
        # live CDC stream, so its offset carries ``phase == "stream"`` *and* an
        # ``incremental`` block while the copy is still in flight; the block is
        # dropped once the snapshot completes and the reader becomes pure CDC. This
        # window is the incremental *reader* phase, distinct from steady-state
        # stream even though both report ``phase == "stream"``.

        return bool(start_offset) and "incremental" in start_offset

    def _offset_is_stream_phase(self, start_offset: dict) -> bool:
        # Docstring: Report whether this read is steady-state CDC for capacity purposes.
        #
        # A first read has no checkpoint and begins with a snapshot; the blocking
        # ``snapshot`` phase carries ``phase != "stream"``. Only ``phase ==
        # "stream"`` is CDC. The incremental *reader* phase also reports ``phase ==
        # "stream"`` but is a bulk copy interleaved with CDC (see
        # :meth:`_offset_is_incremental_reader`); whether it counts as stream for
        # capacity is governed by ``snapshot.incremental.blocking`` -- when that is
        # true (the default) it is treated as non-stream so it blocks for a slot
        # like the consistent snapshot, and when false it is treated as stream and
        # uses the continuous yield budget. The capacity retry offset preserves both
        # ``phase`` and the ``incremental`` block across misses, so this stays
        # correct while a starved reader retries.

        if not start_offset or start_offset.get("phase") != "stream":
            return False
        if self._offset_is_incremental_reader(start_offset):
            return not self._incremental_snapshot_blocking()
        return True

    def _incremental_snapshot_blocking(self) -> bool:
        # Docstring: Whether the incremental snapshot reader phase blocks for a slot.
        #
        # When true (the default), an in-progress incremental snapshot read blocks
        # the full ``connection.wait.timeout.seconds`` to patiently claim a slot,
        # like the consistent snapshot -- bulk copying is latency-tolerant and
        # benefits from pressing for a slot rather than yielding empty. When false,
        # it uses the continuous miss-scaled yield budget and ``capacity.retry.max.delay.seconds``
        # inter-read backoff instead, freeing the worker between attempts at the
        # cost of a slower copy under contention. A triggered flow always blocks
        # regardless of this option.

        return _option_bool(self.options, "snapshot.incremental.blocking", True)

    def _effective_capacity_retry_delay(self, start_offset: dict) -> float:
        # Docstring: Per-read capacity retry delay, treating non-stream reads as ``0``.
        #
        # Snapshot reads (and, by default, the incremental snapshot reader phase)
        # are bulk, latency-tolerant work, so they should patiently wait out
        # contention for a slot: forcing the delay to ``0`` there makes each attempt
        # block the full ``connection.wait.timeout.seconds`` with no inter-read
        # backoff. Only the steady-state ``stream`` phase uses the configured
        # ``capacity.retry.max.delay.seconds``, where prompt yield-and-retry is the
        # right backpressure. Whether the incremental reader phase counts as stream
        # here is governed by ``snapshot.incremental.blocking`` (see
        # :meth:`_offset_is_stream_phase`). The phase override only applies to a
        # positive configured delay; a configured ``0`` already means "block fully
        # in every phase", so there is nothing to override.

        configured = self._capacity_retry_max_delay()
        if configured and not self._offset_is_stream_phase(start_offset):
            return 0.0
        return configured

    def _retried_result(self, result: tuple[Iterator[dict], dict], start_offset: dict):
        # Docstring: Return a retried read's result without disturbing its retry bookkeeping.
        #
        # A nested attempt may itself have given up and yielded, in which case its
        # offset carries the advisory counter that bounds the retry. Passing that
        # through ``_reset_retry_counts`` -- which exists to clear the counters after a
        # read that actually reached the source -- strips it, so the count oscillates
        # instead of climbing and the fail-loud caps can never be reached. Observed
        # directly while building this: successive reads reported 1, absent, 1, absent.

        _, end_offset = result
        if _OFFSET_ADVISORY_FIELDS & set(end_offset):
            return result
        return self._reset_retry_counts(result, start_offset)

    def _volume_failure_result(
        self,
        error: Exception,
        read_again: Callable[[], Any],
        options: dict[str, str],
        attempt_index: int,
        start_offset: dict,
    ) -> tuple[Iterator[dict], dict]:
        # Docstring: Answer a read whose shared-state Volume access failed.
        #
        # A dropped mount (ENOTCONN) can surface from any shared-state helper, not only the
        # one that retries open(2), and from that one wrapped in SharedStateAccessUnavailable
        # once its own retries run out, so it is classified by the error's cause chain. Any
        # other OSError is a real fault and keeps propagating. Both are retried in place
        # first: a remount settles in seconds, and yielding is unavailable during a replay
        # (see _retry_transient_volume_read). A dropped mount then yields under
        # dropped.mount.max.retries with a warning, anything else under the shared-state
        # retry limit.

        dropped = _dropped_mount_error(error)
        if dropped is None and not isinstance(error, SharedStateAccessUnavailable):
            raise error
        retried = self._retry_transient_volume_read(read_again, options, attempt_index)
        if retried is not None:
            return self._retried_result(retried, start_offset)
        if dropped is None:
            return iter(()), self._shared_state_retry_offset(start_offset)
        # 173: Informix snapshot staging Volume mount is not connected; yielding an empty
        # batch and retrying this checkpoint
        logging.getLogger(__name__).warning(_m(173), exc_info=True)
        return iter(()), self._dropped_mount_retry_offset(start_offset, dropped)

    def _retry_transient_volume_read(
        self, attempt: Callable[[], Any], options: dict[str, str], attempt_index: int
    ):
        # Docstring: Re-run a read whose shared-state access failed transiently.
        #
        # Called from the handlers that would otherwise answer a dropped mount by
        # yielding an empty batch with an unchanged position. For a normal read that
        # is correct and cheap -- the framework calls again and nothing is lost. During
        # a replay it is silently destructive: the caller has already committed the
        # range's end offset and reads an empty batch as proof the range held nothing,
        # so the rows vanish. Six tables lost 151 rows this way.
        #
        # Retrying in place removes the dilemma whenever the mount returns, which in
        # production it did within seconds. If it never returns the two cases genuinely
        # differ, so they diverge: a normal read yields (this returns None and the
        # caller falls back), while a replay raises, because failing a batch Spark will
        # retry beats under-delivering one it will not.
        #
        # Performs one further attempt per call. The caller re-enters through the read
        # path, which calls back here on a repeat failure, so ``attempt_index`` bounds
        # the chain; returning None at the bound hands the decision back.

        if attempt_index + 1 >= _TRANSIENT_VOLUME_IN_PROCESS_ATTEMPTS:
            # 182: Informix shared state stayed inaccessible across {} in-process attempts
            logging.getLogger(__name__).warning(
                _m(182, _TRANSIENT_VOLUME_IN_PROCESS_ATTEMPTS),
            )
            if self._replay_stop_lsn(options) is not None:
                # 183: Informix shared state is inaccessible while replaying a committed offset
                # range; failing this batch rather than returning fewer rows than the range holds
                raise InformixError(_m(183))
            return None
        delay = min(0.25 * (2**attempt_index), _TRANSIENT_VOLUME_IN_PROCESS_MAX_SECONDS)
        time.sleep(random.uniform(delay / 2, delay))
        return attempt()

    @staticmethod
    def _replay_stop_lsn(options: dict[str, str]) -> int | None:
        # Docstring: The LSN a replayed read must stop at, or None for an ordinary read.
        #
        # Validated rather than trusted: the value reaches the read through the
        # options dict, and a malformed one would silently become an unbounded read --
        # exactly the behaviour being fixed.

        raw = options.get(_REPLAY_STOP_LSN_OPTION)
        if raw is None:
            return None
        try:
            stop = int(raw)
        except (TypeError, ValueError) as error:
            # 184: Option '{}' must be an integer LSN, got {!r}
            raise InformixError(_m(184, _REPLAY_STOP_LSN_OPTION, raw)) from error
        if stop < 0:
            # 185: Option '{}' must not be negative
            raise InformixError(_m(185, _REPLAY_STOP_LSN_OPTION))
        return stop

    @staticmethod
    def _replay_connection_wait_budget(options: dict[str, str]) -> float | None:
        raw = options.get(_REPLAY_CONNECTION_WAIT_BUDGET_OPTION)
        if raw is None:
            return None
        try:
            budget = float(raw)
        except (TypeError, ValueError) as error:
            # 186: Option '{}' must be a numeric duration, got {!r}
            raise InformixError(_m(186, _REPLAY_CONNECTION_WAIT_BUDGET_OPTION, raw)) from error
        if not math.isfinite(budget) or budget < 0:
            # 187: Option '{}' must be a finite non-negative duration
            raise InformixError(_m(187, _REPLAY_CONNECTION_WAIT_BUDGET_OPTION))
        return budget

    def _capacity_retry_max_retries(self) -> int:
        # Docstring: Consecutive capacity misses a continuous flow tolerates before failing.
        #
        # A continuous reader that never gets a slot yields empty batches, which is
        # indistinguishable from an idle source. This bound makes a permanently
        # undersized endpoint fail loudly instead of replicating nothing forever;
        # acquiring a slot resets the count, so it only ever measures a current run
        # of misses. Defaults to ``_CAPACITY_RETRY_MAX_RETRIES``.

        value = int(
            self.options.get(
                "capacity.retry.max.retries",
                str(_CAPACITY_RETRY_MAX_RETRIES),
            )
        )
        if value < 1:
            # 188: Option 'capacity.retry.max.retries' must be >= 1
            raise ValueError(_m(188))
        return value

    def _capacity_attempt_budget(
        self,
        start_offset: dict,
        *,
        replaying: bool = False,
        replay_wait_budget: float | None = None,
    ) -> float | None:
        # Docstring: Seconds this read may spend acquiring a slot, or None to block fully.
        #
        # The bounded budget is a continuous-mode concept: a continuous flow is a
        # permanent standing consumer, so instead of pinning a worker for the whole
        # ``connection.wait.timeout.seconds`` it spends a short budget, yields an
        # empty batch, and is called again. A triggered flow is the opposite -- it
        # drains and terminates, so it must block for the full wait to actually get
        # a slot, and only fail if that genuinely exhausts. It therefore never uses
        # the yield budget, regardless of ``capacity.retry.max.delay.seconds``
        # (which governs only the continuous yield/backoff and is irrelevant to a
        # triggered read). Returning a short budget to a triggered flow makes it
        # give up in under a second under contention and fail the update, which is
        # the bug this guard prevents.
        #
        # A replay also blocks for the full wait. Spark has already committed the
        # range's end and cannot accept an empty capacity-yield in its place, so a
        # short attempt only creates retry churn and increases the chance of repeated
        # failure under the same contention that caused the first miss.
        #
        # A continuous flow blocks fully whenever its *effective* delay is ``0``
        # (see :meth:`_effective_capacity_retry_delay`): either the configured
        # ``capacity.retry.max.delay.seconds`` is ``0``, or this read is a
        # non-stream (snapshot/incremental) read, which is treated as ``0`` so bulk
        # copying patiently waits out contention for a slot. Blocking fully gives
        # the read the maximum chance to claim a slot before giving up; it still
        # yields rather than fails when the wait exhausts (only a triggered flow
        # raises), bounded by ``capacity.retry.max.retries`` consecutive misses.
        # The guard is an ``or`` (triggered is *always* full-block, plus any read
        # whose effective delay is zero); the earlier bug used ``and`` and so let a
        # triggered flow with a positive delay fall through to the short budget.
        #
        # Otherwise (a continuous stream read with a positive delay) the budget
        # scales with ``capacity_pressure`` -- an acquisition-pressure signal that
        # rises on a miss and *decays* rather than resets on a served read -- so a
        # reader that has been contended presses harder than one that just arrived,
        # and a reader that is intermittently served keeps some of that earned
        # patience instead of dropping straight back to the least-patient budget on
        # every success. (This is deliberately distinct from ``capacity_retry_count``,
        # which counts strictly consecutive misses and resets on success because it
        # is the failure guard.) It is jittered so equally-aged readers do not
        # converge on one give-up instant and re-storm the Volume together on the
        # next round.

        if replaying:
            return replay_wait_budget
        if self._trigger_available_now or not self._effective_capacity_retry_delay(start_offset):
            return None
        pressure = _capacity_pressure(start_offset)
        # A flow that is further behind presses harder for the same pressure, so
        # scarce slots skew toward the readers with the most to catch up. The rank
        # is additive with pressure rather than multiplicative: it biases the
        # budget without letting one very stale flow monopolise the pool, and a
        # missing rank (hints disabled, unpublished, or stale) contributes zero,
        # which leaves this identical to the pre-hint behaviour.
        rank = _backlog_rank_value(start_offset)
        budget = min(
            _CAPACITY_ATTEMPT_BASE_SECONDS
            + pressure * _CAPACITY_ATTEMPT_PER_MISS_SECONDS
            + rank * _CAPACITY_ATTEMPT_PER_RANK_SECONDS,
            _CAPACITY_ATTEMPT_MAX_SECONDS,
        )
        return random.uniform(budget * 0.5, budget)

    @contextlib.contextmanager
    def _capacity_attempt(
        self,
        start_offset: dict,
        *,
        replaying: bool = False,
        replay_wait_budget: float | None = None,
    ):
        # Docstring: Publish this read's acquisition budget and rank, then restore both.
        #
        # The rank is published even when there is no budget. A blocking reader --
        # a triggered flow, or the latency-tolerant snapshot/incremental copy -- has
        # no budget by design, and it is exactly the reader that carries a proven
        # backlog while bulk-copying, so gating the rank on the budget left those
        # readers unprioritised (observed in production: ranks only ever appeared on
        # steady-state CDC offsets, streaks only on blocking copy offsets).

        budget = self._capacity_attempt_budget(
            start_offset,
            replaying=replaying,
            replay_wait_budget=replay_wait_budget,
        )
        # Take the stronger of the persisted rank and one derived from the streak.
        # Only the capacity-miss path writes backlog_rank, so a *blocking* reader's
        # offset carries a streak but no rank -- reading the key alone would leave
        # every bulk-copy reader at zero, which is the gap this exists to close.
        rank = max(
            _backlog_rank_value(start_offset),
            _backlog_rank(0, _backlog_streak(start_offset)),
        )
        previous = self.options.get(_CONNECTION_ATTEMPT_BUDGET_OPTION)
        previous_rank = self.options.get(_CONNECTION_ATTEMPT_RANK_OPTION)
        if budget is not None:
            self.options[_CONNECTION_ATTEMPT_BUDGET_OPTION] = repr(budget)
        if rank > 0:
            self.options[_CONNECTION_ATTEMPT_RANK_OPTION] = str(rank)
        try:
            yield
        finally:
            if previous is None:
                self.options.pop(_CONNECTION_ATTEMPT_BUDGET_OPTION, None)
            else:
                self.options[_CONNECTION_ATTEMPT_BUDGET_OPTION] = previous
            if previous_rank is None:
                self.options.pop(_CONNECTION_ATTEMPT_RANK_OPTION, None)
            else:
                self.options[_CONNECTION_ATTEMPT_RANK_OPTION] = previous_rank

    def _capacity_retry_offset(self, start_offset: dict) -> dict:
        # Docstring: Yield an empty continuous batch when no connection slot is free.
        #
        # The returned offset must differ from ``start_offset``: the framework calls
        # a reader repeatedly until the offset stops changing, so returning it
        # unchanged would signal exhaustion and stop the stream. Bumping the retry
        # count keeps the stream live, and ``_reset_retry_counts`` clears the key on
        # the next read that actually acquires a slot, so a reader that gets served
        # starts again from zero and the count only ever measures a current run of
        # consecutive misses.
        #
        # Only the terminal case is logged: individual retries are the expected
        # steady state, and logging each would bury the driver log.

        result = dict(start_offset)
        retry_count = _capacity_retry_count(result)
        if retry_count >= self._capacity_retry_max_retries():
            # 189: Informix connection capacity was unavailable for {} consecutive continuous reads;
            # this flow yielded empty batches throughout and replicated nothing. Raise
            # max.concurrent.connections, reduce the number of flows, or use a triggered pipeline.
            logging.getLogger(__name__).error(
                _m(189, retry_count),
            )
            # 190: Informix connection capacity exhausted its continuous retry limit; raise
            # max.concurrent.connections or reduce the number of flows
            raise ConnectionCapacityUnavailable(_m(190))
        # Non-stream reads use an effective delay of 0 (no inter-read backoff),
        # matching the full-block acquisition they get above. min() keeps a
        # configured delay below the floor -- notably 0, which means "block fully,
        # no spacing" -- from inverting the bounds.
        delay = self._effective_capacity_retry_delay(start_offset)
        time.sleep(random.uniform(min(_CAPACITY_RETRY_MIN_DELAY_SECONDS, delay), delay))
        result["capacity_retry_count"] = retry_count + 1
        # Pressure rises with every miss and feeds the acquisition budget. Unlike
        # the consecutive-miss count above it decays rather than resets on a
        # served read (see _reset_retry_counts), so an intermittently-served but
        # contended flow keeps pressing rather than snapping back to the base
        # budget on each success.
        result["capacity_pressure"] = _capacity_pressure(result) + 1
        # Carry the backlog rank so the next attempt of this flow can press harder
        # when it is badly behind, and so the value is visible in the offset that
        # every batch logs. Two signals feed it (see _backlog_rank): the published
        # hint, which is comparable across readers but over-states a quiet table's
        # lag because it is a global log position, and this flow's own run of reads
        # that ended at their row budget, which is first-hand proof that work
        # remains for *this* table. The streak survives a capacity miss because it
        # describes the backlog, not the attempt, and a miss reads nothing that
        # could have drained it.
        backlog = self._estimated_backlog(start_offset)
        streak = _backlog_streak(start_offset)
        if streak > 0:
            result["backlog_streak"] = streak
        if backlog is not None or streak > 0:
            result["backlog_rank"] = _backlog_rank(backlog or 0, streak)
        return result

    def _estimated_backlog(self, start_offset: dict) -> int | None:
        # Docstring: Estimate how far this flow trails the source, without a connection.
        #
        # A waiting reader cannot call ``current_lsn()`` -- that needs the very slot
        # it is waiting for -- so it subtracts its own checkpoint (which survives a
        # capacity yield inside the offset) from the log position a slot *holder*
        # published. Returns None whenever no trustworthy hint exists, so callers
        # keep their unprioritised behaviour rather than ranking on a guess.
        #
        # The published position is the server's global log position, so this
        # over-states the backlog of a quiet table: the log advances because *other*
        # tables are written. It measures staleness rather than true per-table lag,
        # which is why callers should compare it on a log scale rather than treat
        # the difference as a row count.

        try:
            checkpoint = start_offset.get("commit_lsn")
            if checkpoint is None:
                return None
            # Deliberately does NOT go through self._bridge_instance. A waiter is
            # precisely the reader that has no bridge: _release_worker_connection
            # clears the instance after every read so a closed bridge is never
            # retained, so requiring one here made this unreachable in production
            # (the rank never appeared in any offset). The hint depends only on
            # the endpoint identity, which comes from options.
            hint = PurePythonInformixBridge._read_connection_backlog_hint_at(self.options)
            if hint is None:
                return None
            return max(0, hint - int(checkpoint))
        except Exception:
            # Advisory signal: never let estimation failure affect a read.
            # 191: Could not estimate Informix backlog from hint
            logging.getLogger(__name__).debug(_m(191), exc_info=True)
            return None

    @staticmethod
    def _trigger_boundary_retry_offset(start_offset: dict) -> dict:
        result = dict(start_offset)
        retry_count = _trigger_boundary_retry_count(result)
        time.sleep(random.uniform(0.05, 0.2))
        result["trigger_boundary_retry_count"] = retry_count + 1
        return result

    @staticmethod
    def _schema_transition_retry_offset(start_offset: dict) -> dict:
        # Docstring: Yield an empty batch while the upsert reader publishes the transition.
        #
        # The offset must differ from ``start_offset`` or the framework reads the
        # unchanged offset as exhaustion and stops the stream, so bump a counter the
        # way the sibling coordination retries do. Unlike the capacity retry this
        # carries no retry cap: the wait is on the paired upsert reader for the
        # *same* table, which either publishes (this reader proceeds) or fails its
        # own flow with a real error. Capping the count would convert a slow schema
        # transition into a delete-channel failure while the upsert side is still
        # healthy, and the whole point of yielding is that the slot is free for that
        # publication to happen. A triggered update is bounded in time instead (see
        # _ensure_schema_transition_wait_bounded): there a failed upsert flow does not
        # end the update, and this reader would otherwise yield forever.

        result = dict(start_offset)
        retry_count = _schema_transition_retry_count(result)
        time.sleep(random.uniform(0.05, 0.2))
        result["schema_transition_retry_count"] = retry_count + 1
        return result

    @staticmethod
    def _effective_start_offset(start_offset: dict) -> dict:
        # Shared with _retried_result: a field that is bookkeeping here must be
        # bookkeeping there too, and duplicating the list let them drift.
        retry_fields = _OFFSET_ADVISORY_FIELDS
        if start_offset and set(start_offset) <= retry_fields:
            if "shared_state_retry_count" in start_offset:
                _shared_state_retry_count(start_offset)
            if "dropped_mount_retry_count" in start_offset:
                _dropped_mount_retry_count(start_offset)
            if "trigger_boundary_retry_count" in start_offset:
                _trigger_boundary_retry_count(start_offset)
            if "schema_transition_retry_count" in start_offset:
                _schema_transition_retry_count(start_offset)
            if "schema_node_fallback_retry_count" in start_offset:
                _schema_node_fallback_retry_count(start_offset)
            if "capacity_pressure" in start_offset:
                _capacity_pressure(start_offset)
            if "backlog_rank" in start_offset:
                _backlog_rank_value(start_offset)
            if "backlog_streak" in start_offset:
                _backlog_streak(start_offset)
            return {}
        return start_offset

    def _reset_retry_counts(
        self, result: tuple[Iterator[dict], dict], start_offset: dict
    ) -> tuple[Iterator[dict], dict]:
        rows, end_offset = result
        if {
            "shared_state_retry_count",
            "dropped_mount_retry_count",
            "trigger_boundary_retry_count",
            "schema_transition_retry_count",
            "schema_node_fallback_retry_count",
            "capacity_retry_count",
            "capacity_pressure",
            "backlog_rank",
        } & set(start_offset):
            end_offset = dict(end_offset)
            end_offset.pop("shared_state_retry_count", None)
            # This read reached the Volume, so the mount is back: the fail-loud
            # guard must start over rather than carry a flapping mount's history
            # toward the cap.
            end_offset.pop("dropped_mount_retry_count", None)
            end_offset.pop("trigger_boundary_retry_count", None)
            end_offset.pop("schema_transition_retry_count", None)
            # Deliberately NOT reset here, unlike every counter above. Those reset
            # because the read succeeded at the thing they counted failures of; a
            # bootstrap that still has no boundary has not succeeded and must keep
            # accumulating, or the count pins at 1 on every retry and the schema-node
            # fallback never becomes eligible. A read that *does* find a boundary
            # returns a freshly built _offset(), which never carries the counter, so
            # it cannot leak onto a real checkpoint either way.
            # Dropping the key resets the consecutive-miss failure guard: this
            # read got a slot, so the reader is no longer starved and the
            # fail-loud counter must start over.
            end_offset.pop("capacity_retry_count", None)
            # Pressure decays rather than resets: a served-but-contended reader
            # keeps some of the elevated budget it earned while starved so it does
            # not snap back to the base budget (and a likely immediate re-miss) on
            # every success. Halving reaches the base budget after a few
            # uncontended reads; drop the key once it decays to zero so a fully
            # recovered flow carries no residual state.
            pressure = _capacity_pressure(start_offset) // 2
            if pressure > 0:
                end_offset["capacity_pressure"] = pressure
            else:
                end_offset.pop("capacity_pressure", None)
            # The rank is a per-attempt observation, not accumulated state: this
            # read got a slot, so any bias it earned while waiting is spent. The
            # next miss re-derives it from a fresh hint.
            end_offset.pop("backlog_rank", None)
            # backlog_streak is deliberately NOT dropped here. It describes the
            # source, not the attempt: a served read has just measured whether it
            # could drain the log, and _with_backlog_streak has already set the
            # fresh value on this end offset (clearing it outright when the read
            # reached the log's end). Popping it would discard that measurement and
            # make a permanently backlogged flow look caught up on every read that
            # happened to get a slot.
        return rows, end_offset

    def _append_only_mode(self, table_options: dict[str, str]) -> str:
        # Docstring: Resolve ``append.only.ingestion`` to ``'true'``, ``'false'``, or ``'auto'``.
        #
        # ``table_options`` override the connection options; when the option is set
        # nowhere the mode defaults to ``'auto'``.

        for source in (table_options, self.options):
            if _APPEND_INGESTION_OPTION in source:
                return _append_only_value(source[_APPEND_INGESTION_OPTION])
        return "auto"

    def _append_delete_tombstones(self, table_options: dict[str, str]) -> bool:
        # Docstring: Resolve ``append.delete.tombstones``; default ``True``.
        #
        # ``table_options`` override the connection options, exactly like
        # ``append.only.ingestion``. Only consulted for a table on the append path: it
        # decides whether a source DELETE lands on the upsert channel as a ``d`` row
        # carrying the full before-image, or is dropped.

        if _APPEND_DELETE_TOMBSTONES_OPTION in table_options:
            return _option_bool(table_options, _APPEND_DELETE_TOMBSTONES_OPTION, True)
        return _option_bool(self.options, _APPEND_DELETE_TOMBSTONES_OPTION, True)

    def _append_only_table(self, table: Table, table_options: dict[str, str]) -> bool:
        # Docstring: Report whether this read should use the append-only path.
        #
        # ``true`` forces append for any capturable table (a caller may want append
        # semantics even for an insert-only keyed table); ``false`` forces the normal
        # CDC/snapshot path; ``auto`` (the default) appends only keyless tables and
        # leaves keyed tables on CDC. A table whose columns cannot be captured always
        # falls back to snapshot, since append cannot represent rows it cannot read.

        if not _cdc_streamable(table):
            return False
        mode = self._append_only_mode(table_options)
        if mode == "auto":
            return not table.primary_keys
        return mode == "true"

    def _apply_primary_key_override(
        self,
        table: Table,
        table_options: dict[str, str],
        override: tuple[list[str], tuple[str, ...]] | None = None,
    ) -> Table:
        # Docstring: Override a table's primary key with the connector ``primary.keys`` option.
        #
        # When set (per table), treat the table as keyed on those columns -- even a
        # physically keyless one -- so it is read as cdc_with_deletes with
        # keyset-paginated snapshots and reported with those keys (which the pipeline
        # also uses as the destination merge key). The caller MUST guarantee the
        # columns are unique for the row: a non-unique override corrupts upserts,
        # delete identification, and snapshot pagination.
        #
        # The override adopts the per-column direction of an index whose key columns
        # exactly match it (see ``_override_key_directions``), so an override that
        # names a mixed-direction index's columns still pages in that index's own
        # order rather than forcing an all-ascending sort. When no index matches,
        # paging stays ascending.
        #
        # ``"*"`` (or ``["*"]``) keys the table on every column in catalog order, nullable
        # ones included, and ``"* except(c1, c2)"`` on every column but those; see
        # ``_PRIMARY_KEYS_WILDCARD``. ``override`` is the option already parsed by
        # _key_override, which runs here when the caller didn't.

        override = _key_override(table_options) if override is None else override
        if override is None:
            return table
        keys, excepted = override
        wildcard = keys == [_PRIMARY_KEYS_WILDCARD]
        if wildcard:
            _ensure_excepted_columns_exist(table, excepted)
            keys = _wildcard_key(table.columns, excepted)
            if not keys:
                # 192: Option '{}' excepts every column of '{}', leaving no key
                raise InformixError(_m(192, _PRIMARY_KEYS_OPTION, table.exposed_name))
        column_names = {column.name for column in table.columns}
        missing = [key for key in keys if key not in column_names]
        if missing:
            # 193: Option '{}' names column(s) not present in '{}': {}
            raise InformixError(
                _m(193, _PRIMARY_KEYS_OPTION, table.exposed_name, (", ".join(missing)))
            )
        if tuple(keys) == table.primary_keys:
            # The override restates the current key; keep its directions (already
            # reflecting the key index) rather than looking them up again. It is now
            # owned by the override, not a nullable-index promotion.
            if (
                table.key_override
                and table.key_wildcard == wildcard
                and table.key_wildcard_except == excepted
            ):
                return table
            return replace(
                table,
                key_override=True,
                key_wildcard=wildcard,
                key_wildcard_except=excepted,
                key_from_nullable_index=False,
            )
        directions = self._override_key_directions(table.identity, tuple(keys))
        return replace(
            table,
            primary_keys=tuple(keys),
            key_override=True,
            key_wildcard=wildcard,
            key_wildcard_except=excepted,
            key_descending=tuple(directions or ()),
            key_from_nullable_index=False,
        )

    def _override_key_directions(self, identity: str, keys: tuple[str, ...]) -> list[bool] | None:
        # Docstring: Memoized key-index direction lookup for a ``primary.keys`` override.
        #
        # The override is applied on every ``_table`` call (cache hits included), so
        # the catalog lookup must run at most once per table+key, not per microbatch.

        cache = self._override_direction_cache
        cache_key = (identity, keys)
        if cache_key not in cache:
            found = self._bridge.key_index_directions(identity, list(keys))
            cache[cache_key] = tuple(found) if found else ()
        cached = cache[cache_key]
        return list(cached) if cached else None

    def _apply_nullable_index_promotion(self, table: Table, table_options: dict[str, str]) -> Table:
        # Docstring: Promote a nullable-column UNIQUE index to the key when the table opts in.
        #
        # Applies only when the table is otherwise key-less (no primary key and no
        # all-NOT-NULL unique index qualified) and the per-table ``allow.nullable.index``
        # option is set. The operator thereby asserts the index's columns are unique and
        # non-null for every row. ``key_from_nullable_index`` marks the result so a schema
        # refresh preserves the promotion (the catalog re-derives it as key-less). An
        # explicit ``primary.keys`` override still wins -- it is applied afterward.

        if table.primary_keys or not table.nullable_index_key:
            return table
        if not _option_bool(table_options, _ALLOW_NULLABLE_INDEX_OPTION, False):
            return table
        return replace(
            table,
            primary_keys=table.nullable_index_key,
            key_descending=table.nullable_index_descending,
            key_from_nullable_index=True,
        )

    def _requested_key(
        self,
        table: Table,
        table_options: dict[str, str],
        override: tuple[list[str], tuple[str, ...]] | None,
    ) -> tuple[str, ...] | None:
        # Docstring: The key the table options will give ``table``, ahead of applying them.
        #
        # In _apply_key_options' precedence: the primary.keys list (``override``, from
        # _key_override), a nullable index the table opts into promoting, then the catalog
        # key. None for the primary.keys "*" wildcard, with or without except(...), which
        # keys on whatever columns are ingested.

        if override is not None:
            keys, _ = override
            return None if keys == [_PRIMARY_KEYS_WILDCARD] else tuple(keys)
        if (
            not table.primary_keys
            and table.nullable_index_key
            and _option_bool(table_options, _ALLOW_NULLABLE_INDEX_OPTION, False)
        ):
            return table.nullable_index_key
        return table.primary_keys

    def _ingested_columns(
        self,
        table: Table,
        table_options: dict[str, str],
        override: tuple[list[str], tuple[str, ...]] | None,
    ) -> Table:
        # Docstring: Narrow ``table`` to the columns it ingests: the column selection, then
        # the columns of a type the connector can't read left out, unless one is in its key.
        #
        # ``override`` is the primary.keys option from _key_override. Opens no Informix
        # connection, unlike the key options, which can query the override's index
        # directions.

        table = _apply_column_selection(table, _column_selection(table_options))
        return _leave_out_unsupported_columns(
            table, self._requested_key(table, table_options, override)
        )

    def _apply_key_options(
        self,
        table: Table,
        table_options: dict[str, str],
        override: tuple[list[str], tuple[str, ...]] | None = None,
    ) -> Table:
        # Docstring: Apply the per-table key options in precedence order: an explicit
        # ``primary.keys`` override wins over a nullable-index promotion, which wins
        # over the catalog-derived key. Promotion runs first so the override, applied
        # last, still takes precedence. ``override`` is as for _apply_primary_key_override.

        return self._apply_primary_key_override(
            self._apply_nullable_index_promotion(table, table_options), table_options, override
        )

    def _apply_table_options(self, table: Table, table_options: dict[str, str]) -> Table:
        # Docstring: Apply every per-table option that reshapes the catalog table.
        #
        # The column selection runs first, then the columns of a type the connector can't
        # read are left out, so the key options see only the columns ingested (a wildcard
        # key covers just those), then row_filter, since it may only use selected columns,
        # then the transforms and the renames, which may only change them.

        override = _key_override(table_options)
        table = self._ingested_columns(table, table_options, override)
        table = self._apply_key_options(table, table_options, override)
        _ensure_selected_keys(table)
        table = _apply_row_filter(table, table_options.get(_ROW_FILTER_OPTION))
        table = _apply_column_transforms(
            table,
            _column_transforms(table_options),
            self.options.get(_TRANSFORM_HASH_KEY_OPTION)
            or table_options.get(_TRANSFORM_HASH_KEY_OPTION),
        )
        return _apply_column_renames(table, _column_renames(table_options))

    def _snapshot_mode(self, table_options: dict[str, str]) -> str:
        mode = (
            str(
                table_options.get(
                    "snapshot.mode",
                    self.options.get("snapshot.mode", _DEFAULT_SNAPSHOT_MODE),
                )
            )
            .strip()
            .lower()
        )
        if mode in _UNSUPPORTED_SNAPSHOT_MODES:
            # 194: snapshot.mode={} is an external extension mechanism and is not supported by the
            # Python Informix connector
            raise ValueError(_m(194, mode))
        if mode == "handoff":
            # 195: snapshot.mode=handoff has been replaced by the 'table.migration' option; keep the
            # table's real snapshot.mode and set table.migration=true to migrate it (SCD1->append
            # switch or destination relocation), then clear table.migration to resume.
            raise ValueError(_m(195))
        if mode not in _SNAPSHOT_MODES:
            allowed = ", ".join(sorted(_SNAPSHOT_MODES))
            # 196: Unsupported snapshot.mode={!r}; supported values are {}
            raise ValueError(_m(196, mode, allowed))
        return mode

    def _table_migration(self, table_options: dict[str, str]) -> bool:
        # Docstring: Whether this table is being migrated (``table.migration=true``).
        #
        # Per-table first, falling back to the connection default; orthogonal to
        # snapshot.mode, which is left unchanged while migrating. When true the read runs
        # the record-and-stop handoff (see :meth:`_read_handoff`) instead of its normal
        # snapshot/stream behaviour.

        if _TABLE_MIGRATION_OPTION in table_options:
            return _option_bool(table_options, _TABLE_MIGRATION_OPTION, False)
        return _option_bool(self.options, _TABLE_MIGRATION_OPTION, False)

    @staticmethod
    def _schema_node_fallback_offset(start_offset: dict[str, Any]) -> dict[str, Any]:
        # Docstring: Carry the bootstrap deferral count on an advisory (non-positional) offset.
        #
        # A delete reader with no offset waits for the upsert reader to publish this
        # update's channel-start and yields an empty advisory batch meanwhile. The count
        # saturates at ``_SCHEMA_NODE_FALLBACK_RETRIES``: past it the returned offset
        # stops changing, which is how a replay (``_replay_between_offsets``) recognises
        # "still waiting for the upsert publication" and waits in place rather than
        # treating the unchanged offset as a failed replay. It rides an offset that has no
        # position at all, so it can never move a checkpoint. The field name is historical
        # -- it once gated a scope-independent schema-node fallback that never became part
        # of the bootstrap -- and is kept for checkpoint compatibility.

        count = _schema_node_fallback_retry_count(start_offset)
        if count >= _SCHEMA_NODE_FALLBACK_RETRIES:
            return dict(start_offset)
        result = dict(start_offset)
        result["schema_node_fallback_retry_count"] = count + 1
        return result

    def _checkpoint_requires_snapshot(self, checkpoint: dict[str, Any]) -> bool:
        validated = _validated_offset(checkpoint)
        restart = int(validated.get("begin_lsn") or validated["commit_lsn"])
        return restart < self._bridge.minimum_lsn()

    def _resnapshot_scope(self, table: Table, checkpoint: dict[str, Any]) -> str:
        del table
        _validated_offset(checkpoint)
        return self._pipeline_scope()

    def _bootstrap_seed_table(self, table: Table, schema_id: str, fingerprint: str) -> Table:
        # Docstring: The layout a delete bootstrap seeds under: the live one, or a recorded node.
        #
        # The upsert reader publishes the update's channel start at its checkpoint before it
        # steps, and a snapshot floor keeps the schema it was captured under, so the seed's
        # schema can be one the live layout has moved past (a column changed while the
        # pipeline was stopped). The seed names that recorded node; the next poll steps from
        # it as any lagging reader does.

        if fingerprint == _schema_fingerprint(table):
            return table
        record = self._read_immutable_head(
            self._immutable_namespace(table, "schema-nodes", schema_id)
        )
        node = record.get("schema") if isinstance(record, dict) else None
        if not isinstance(node, dict) or node.get("id") != schema_id:
            # 199: Informix upsert/delete bootstrap schema mismatch for '{}'
            raise InformixError(_m(199, table.exposed_name))
        self._validate_immutable_record_header(record, "schema-node", table.exposed_name)
        seed_table = _table_from_schema_state(node, table.database)
        if (
            seed_table.native_identity != table.native_identity
            or _schema_fingerprint(seed_table) != fingerprint
        ):
            # 199: Informix upsert/delete bootstrap schema mismatch for '{}'
            raise InformixError(_m(199, table.exposed_name))
        return seed_table

    def _resnapshot_delete_seed(self, table: Table, scope: str) -> dict | None:
        # Docstring: The delete seed at the update's resnapshot boundary, once it is published.
        #
        # The resnapshot ran under the live layout, which this reader's cached table may
        # predate, and the boundary lookup checks the two match.

        table = self._refresh_table_schema(table, None)
        high_water = self._initial_lsn(table, owner=False, wait=False, scope=scope)
        if high_water is None:
            return None
        self._schema_transition_waits.pop((table.identity, "resnapshot"), None)
        schema_id = self._snapshot_schema_ids[(scope, table.identity)]
        return {
            **_offset(high_water, high_water, high_water, None, "stream", table, schema_id, scope),
            # The seed is this update's first offset for the flow: see _read_stream.
            "update_fingerprint": _schema_fingerprint(table),
        }

    def _read_resnapshotted_deletes(
        self, table: Table, start_offset: dict, table_options: dict[str, str]
    ) -> tuple[Iterator[dict], dict]:
        # Docstring: Move a delete checkpoint the log no longer retains to its resnapshot.
        #
        # auto_snapshot replaces it with a snapshot whose boundary the upsert reader
        # publishes on its read. Until it has, this yields a retry offset at the same
        # position: an unchanged offset reads as a drained source, which would end a
        # triggered update with no seed, and a later update's scope never gets one. A
        # replayed wait stays where it was; a replayed move to the boundary lands on it.

        checkpoint = _validated_offset(start_offset)
        replay_stop = self._replay_stop_lsn(table_options)
        if replay_stop is not None and replay_stop <= int(checkpoint["commit_lsn"]):
            return iter(()), dict(start_offset)
        if replay_stop is not None:
            # From an expired checkpoint this reader only waits in place or moves to the
            # resnapshot boundary, a batch with no rows. Replayed in a later update, that
            # boundary is under the earlier update's scope, so a lookup here never finds it:
            # land on the logged end instead. A batch read before the log expired under a
            # stopped pipeline held deletes that are gone from the log either way.
            # 426: Informix delete channel for '{}' replays a batch from expired checkpoint LSN
            # {} by landing on its logged end {} without reading: such a batch moved the channel
            # to the resnapshot boundary and held no rows, unless the log expired while the
            # pipeline was stopped, in which case the deletes it read are no longer in the log
            logging.getLogger(__name__).warning(
                _m(426, table.exposed_name, checkpoint["commit_lsn"], replay_stop)
            )
            position = str(replay_stop)
            return iter(()), {
                **checkpoint,
                "commit_lsn": position,
                "change_lsn": position,
                "begin_lsn": position,
                "tx_id": None,
                # No transaction to match: the batch's deletes, if any, are gone.
                _REPLAY_REESTABLISHED: True,
            }
        seed = self._resnapshot_delete_seed(table, self._resnapshot_scope(table, checkpoint))
        if seed is not None:
            return iter(()), seed
        return iter(()), self._resnapshot_retry_offset(table, start_offset)

    def _read_table_deletes(
        self,
        table_name: str,
        start_offset: dict,
        table_options: dict[str, str],
        *,
        snapshot_mode: str = "initial",
        bootstrap_offset: dict | None = None,
    ) -> tuple[Iterator[dict], dict]:
        # ``start_offset`` has already been through _effective_start_offset, which
        # collapses an all-advisory offset to {} so a retry looks like a fresh
        # bootstrap positionally. The bootstrap deferral counter lives in exactly such
        # an offset, so it has to be read from the raw one instead or it would reset to
        # zero on every retry and the fallback would never become eligible.
        bootstrap_offset = start_offset if bootstrap_offset is None else bootstrap_offset
        table = self._table(table_name, table_options)
        self._touch_table_state(table)
        _ensure_materializable(table, table_options)
        if self._append_only_table(table, table_options):
            # The framework does not open a delete flow for ingestion_type="append",
            # so reaching here means the two sides disagree about this table. Returning
            # an empty batch would look like "no deletes" forever; fail loudly instead.
            # 197: Table '{}' is configured for append-only ingestion ({}), which has no delete
            # channel
            raise ValueError(_m(197, table_name, _APPEND_INGESTION_OPTION))
        if not _cdc_capable(table):
            # 198: Table '{}' lacks a primary key or has columns unsupported by Informix CDC and is
            # snapshot-only
            raise ValueError(_m(198, table_name))
        if (
            snapshot_mode == "auto_snapshot"
            and start_offset.get("phase") == "stream"
            and self._checkpoint_requires_snapshot(start_offset)
        ):
            return self._read_resnapshotted_deletes(table, start_offset, table_options)
        # Lakeflow checkpoints this independently from read_table(). The
        # upsert reader owns initialization and publishes the table boundary
        # through durable shared state; delete readers only consume it.
        if not start_offset:
            channel_start = self._read_upsert_channel_start(table, self._pipeline_scope())
            if channel_start is None:
                # The two Lakeflow flows have independent Spark checkpoints.  A
                # delete flow with no checkpoint must therefore wait until the
                # upsert reader publishes the position it is *actually* using in
                # this update.  Inferring from current_lsn or a scope-independent
                # schema node can start ahead of a resumed upsert checkpoint and
                # permanently skip old-key deletes after a cancelled refresh.
                return iter(()), self._schema_node_fallback_offset(bootstrap_offset)
            high_water, schema_id, fingerprint = channel_start
            # The upsert channel-start records the upsert reader's *resume* position
            # for the current scope, which the restart/replay cycles push forward past
            # the snapshot boundary. Bootstrapping a delete flow there skips before-image
            # deletes for rows the snapshot already wrote -- notably a mutated-primary-key
            # row's old-key delete, which orphans the pre-update version permanently.
            # Anchor instead at the durable snapshot floor for this pipeline when one is
            # recorded: it is the LSN the current destination rows were captured at, is
            # never above the upsert resume LSN, and -- because apply_as_deletes is
            # idempotent (ordered by sequence_by) -- a lower start only ever re-reads, it
            # cannot remove a newer row or apply a delete twice. This is a bootstrap-only
            # cost; once the delete flow checkpoints, it resumes from its own cursor.
            minimum = self._bridge.minimum_lsn()
            if snapshot_mode == "auto_snapshot" and high_water < minimum:
                # auto_snapshot replaces the expired checkpoint the channel start names (it was
                # published before the resnapshot, and the lowest start wins) with a snapshot
                # whose boundary the upsert reader publishes: seed there once it has, and
                # until then yield a retry that does not run out, as a checkpointed reader of
                # an expired position does (_read_resnapshotted_deletes).
                seed = self._resnapshot_delete_seed(table, self._pipeline_scope())
                return iter(()), seed or self._resnapshot_retry_offset(table, bootstrap_offset)
            floor_state = self._read_delete_snapshot_floor(table, schema_id, fingerprint)
            floor = floor_state[0] if floor_state else None
            bootstrap_lsn = high_water
            if floor is not None and floor < minimum:
                # The floor has aged below the retained log, so the upsert channel-start
                # is the only boundary left. Deletes committed between the two are gone
                # from the source and cannot be replicated: say so, loudly, rather than
                # bootstrapping ahead of them in silence.
                # 200: Informix delete snapshot floor {} for '{}' precedes the minimum retained LSN
                # {}; bootstrapping the delete channel at the upsert resume position {} instead, so
                # deletes committed between the floor and it can no longer be replicated. Run a full
                # refresh if the destination must match the source exactly
                logging.getLogger(__name__).warning(
                    _m(200, floor, table.exposed_name, minimum, high_water),
                )
            elif floor is not None and floor < high_water:
                # The range between them was never consumed by a delete checkpoint, so it
                # is re-read from the floor. Visible in the event log because it can be
                # long (days of log after a stalled bootstrap) and lowers the delete
                # shard's shared restart under the sharded daemon.
                # Under the floor's own schema, which the channel start's can descend from.
                bootstrap_lsn, schema_id, fingerprint = floor_state
                # 201: Informix delete channel for '{}' bootstraps at the snapshot floor {} rather
                # than the upsert resume position {}: no delete checkpoint has consumed that range
                # yet, so it is re-read (idempotent for the target)
                logging.getLogger(__name__).info(
                    _m(201, table.exposed_name, floor, high_water),
                )
            if bootstrap_lsn < minimum:
                # 202: Informix delete bootstrap boundary {} for '{}' precedes the minimum retained
                # LSN {}; the delete channel is waiting for a resnapshot
                logging.getLogger(__name__).warning(
                    _m(202, bootstrap_lsn, table.exposed_name, minimum),
                )
                return iter(()), self._schema_node_fallback_offset(bootstrap_offset)
            current = self._bridge.current_lsn()
            if (bootstrap_lsn >> 32) > (current >> 32):
                # 203: Informix delete bootstrap boundary {} for '{}' is ahead of the source's
                # current logical log {}; the delete channel is waiting for a new snapshot
                # generation
                logging.getLogger(__name__).warning(
                    _m(203, bootstrap_lsn, table.exposed_name, current),
                )
                return iter(()), self._schema_node_fallback_offset(bootstrap_offset)
            # The seed is this update's first offset for the flow: see _read_stream.
            return iter(()), {
                **_offset(
                    bootstrap_lsn,
                    bootstrap_lsn,
                    bootstrap_lsn,
                    None,
                    "stream",
                    self._bootstrap_seed_table(table, schema_id, fingerprint),
                    schema_id,
                    self._pipeline_scope(),
                ),
                "update_fingerprint": _schema_fingerprint(table),
            }
        if start_offset.get("phase") == "snapshot":
            snapshot_checkpoint = _validated_offset(start_offset)
            expected = snapshot_checkpoint.get("schema_fingerprint")
            if expected is None:
                # 204: Informix delete checkpoint for '{}' predates schema-safe offsets; run a full
                # refresh
                raise InformixError(_m(204, table.exposed_name))
            table = self._refresh_table_schema(table, expected)
            high_water = int(start_offset.get("snapshot_lsn", start_offset.get("commit_lsn", 0)))
            start_offset = _offset(
                high_water,
                high_water,
                high_water,
                None,
                "stream",
                table,
                str(snapshot_checkpoint["schema_id"]),
                self._pipeline_scope(snapshot_checkpoint),
            )
        return self._read_stream(table, start_offset, table_options, deletes=True)

    def _release_worker_connection(self) -> None:
        # sys.exception() is Python 3.11+, while the connector supports 3.10.
        primary_error = sys.exc_info()[1]
        if self._bridge_instance is None:
            return
        release = getattr(self._bridge_instance, "release_connection", None)
        if not callable(release):
            # 205: Configured Informix bridge does not implement release_connection()
            contract_error = InformixError(_m(205))
            if primary_error is None:
                raise contract_error
            add_informix_exception_note(primary_error, str(contract_error))
            return
        try:
            release()  # pylint: disable=not-callable
        except Exception as cleanup_error:
            if primary_error is None:
                raise
            add_informix_exception_note(
                primary_error,
                f"Releasing the Informix worker connection also failed: {cleanup_error}",
            )

    def _reset_lakebase_connection(self, owner: Any = None) -> None:
        # Docstring: Drop the cached Lakebase state connection so the next use reopens fresh.
        #
        # ``owner`` is whose connection to drop: this connector's by default, or a
        # discarded bridge's.
        #
        # A psycopg connection left open across a long, idle wait -- worse, left
        # idle inside the implicit read transaction that a bare SELECT starts --
        # is reaped by Lakebase's ``idle_in_transaction_session_timeout``, and
        # ``.closed`` stays False until the next query fails, so
        # ``_lakebase_connection`` cannot tell it is dead and hands it back. The
        # snapshot-drain consumer blocks for the whole drain without touching
        # state, so it closes the connection here and lets the post-wait manifest
        # read reopen a guaranteed-live one.

        owner = self if owner is None else owner
        connection = getattr(owner, "_lakebase_conn", None)
        owner._lakebase_conn = None
        if connection is not None:
            try:
                connection.close()
            except Exception:  # pragma: no cover - best-effort teardown
                pass

    def _write_handoff_token(
        self, table: Table, offset: dict, channel: int = _HANDOFF_CHANNEL_UPSERT
    ) -> None:
        # Docstring: Park a stream-phase offset so a later flow can resume from it.

        _, table_key = self._table_state_keys(table)
        namespace = self._lakebase_state_namespace()
        offset_json = json.dumps(_validated_offset(offset))
        schema_fp = str(offset.get("schema_fingerprint") or _schema_fingerprint(table))
        self._state_op_with_reconnect(
            lambda: put_cdc_handoff(
                self._lakebase_connection(),
                namespace,
                table_key,
                channel,
                offset_json,
                schema_fp,
            ),
            operation="handoff token write",
        )

    def _read_handoff_token(
        self, table: Table, channel: int = _HANDOFF_CHANNEL_UPSERT
    ) -> dict[str, str] | None:
        # Docstring: Return the parked handoff token for this table, or None when absent.

        _, table_key = self._table_state_keys(table)
        namespace = self._lakebase_state_namespace()
        return self._state_op_with_reconnect(
            lambda: get_cdc_handoff(self._lakebase_connection(), namespace, table_key, channel),
            operation="handoff token read",
        )

    def _delete_handoff_token(self, table: Table, channel: int = _HANDOFF_CHANNEL_UPSERT) -> None:
        # Docstring: Drop a consumed handoff token. Best-effort and idempotent.

        _, table_key = self._table_state_keys(table)
        namespace = self._lakebase_state_namespace()
        self._state_op_with_reconnect(
            lambda: delete_cdc_handoff(self._lakebase_connection(), namespace, table_key, channel),
            operation="handoff token delete",
        )

    def _append_migration_record_and_stop(
        self, table: Table, effective_start: dict
    ) -> tuple[Iterator[dict], dict]:
        # Docstring: Record-and-stop for an append flow at stream phase under table.migration.
        #
        # Migration never streams, so emit no rows and return the same offset. Capture and
        # the committed cutover seed are told apart by ``handoff_seeded`` exactly as on the
        # keyed path in :meth:`_read_handoff`:
        #
        # * **Capture** (no marker) -- this append flow is the *source* of a relocation (an
        #   already-append table moving destination), so park its current stream offset for
        #   the new flow to seed from. Append has no delete channel, so only the upsert
        #   offset is parked.
        # * **Cutover, seed committed** (marker present) -- drop the now-consumed token(s).
        #   Crash-safe: a crash before the seed committed re-seeds from the still-present
        #   token, and a later full refresh under table.migration then finds no token and
        #   fails closed rather than silently re-seeding. The delete-channel token is dropped
        #   too: an SCD1->append switch parked one while the table was still keyed, and an
        #   append flow has no delete reader to consume it. The marker is kept on the
        #   outgoing offset so a later steady-state read stays a stop.

        if effective_start.get("handoff_seeded"):
            self._delete_handoff_token(table)
            self._delete_handoff_token(table, _HANDOFF_CHANNEL_DELETE)
        else:
            self._write_handoff_token(table, effective_start)
        return iter(()), dict(effective_start)

    def _drop_orphaned_handoff_tokens(self, table: Table, channels: list[int]) -> None:
        # Docstring: Best-effort, one-shot drop of a handoff token left behind after Restore.
        #
        # The committed seed drops the token from inside ``_read_handoff`` /
        # ``_read_handoff_deletes`` -- but only while ``table.migration`` is still set.
        # If a cutover run committed the seed without a later same-mode read to consume it
        # (and Restore then cleared table.migration, so reads no longer enter those methods),
        # the
        # token would linger: it has no TTL, and a *future* cutover of the same table could
        # adopt it. So when a post-Restore read still carries the ``handoff_seeded`` marker,
        # drop the token here. This is one-shot -- the marker is not carried onto this read's
        # output offset -- and best-effort: a lingering token never justifies failing a read.

        for channel in channels:
            try:
                self._delete_handoff_token(table, channel)
            except Exception:  # pylint: disable=broad-except
                # 206: Best-effort cleanup of a lingering handoff token for '{}' (channel {})
                # failed; it will be retried on a later read
                logging.getLogger(__name__).warning(
                    _m(206, table.exposed_name, channel),
                    exc_info=True,
                )

    def _handoff_seed_from_token(self, table: Table, token: dict[str, str]) -> dict:
        # Docstring: Build the seed offset from a parked token, failing closed on schema drift.
        #
        # The parked ``schema_fp`` is the source schema at capture time. If the source
        # schema changed before cutover the parked LSN position no longer aligns with the
        # current layout, so resuming would misread the stream -- fail closed and tell the
        # operator to re-capture or start fresh instead of silently corrupting the seam.

        current = self._refresh_table_schema(table, None)
        parked_fp = token.get("schema_fp")
        if parked_fp and parked_fp != _schema_fingerprint(current):
            # 207: table.migration for '{}' cannot resume: the source schema changed between capture
            # and cutover, so the parked position no longer aligns with the current schema. Re-run
            # the capture step against the current schema, or start fresh (clear table.migration and
            # use snapshot.mode=cdc_only for no history, or snapshot.mode=initial for a full
            # snapshot).
            raise InformixError(_m(207, table.exposed_name))
        # Adopt this flow's scope, and stamp a one-shot marker so the *next* read on this
        # flow (once Spark has committed the seed) recognises it as a cutover continuation
        # rather than a fresh capture -- the two are otherwise indistinguishable on the
        # keyed path, where capture and cutover share _read_handoff. The token is dropped
        # only when that marked offset arrives, so a crash before commit re-seeds.
        seeded = _validated_offset(json.loads(token["offset_json"]))
        # Where the pages live: a serve relocated once already keeps them under its first
        # capture's scope (stage_scope), not under the scope that parked it again.
        origin_scope = seeded.get("stage_scope") or seeded.get("pipeline_scope")
        seeded["pipeline_scope"] = self._pipeline_scope()
        if seeded.get("phase") == "snapshot" and origin_scope:
            # A blocking initial snapshot parked mid-serve. The new flow owns a fresh
            # scope for its boundary and stream, but the staged pages physically live
            # under the capturing flow's scope. stage_scope redirects *only* the
            # page/manifest reads and consumed-page cleanup there; it is dropped at the
            # snapshot->stream transition, after which the offset is an ordinary
            # new-scope stream offset. See _snapshot_page_batch / _staged_snapshot_result.
            seeded["stage_scope"] = origin_scope
        seeded["handoff_seeded"] = True
        return seeded

    def _read_handoff(self, table: Table, effective_start: dict) -> tuple[Iterator[dict], dict]:
        # Docstring: Both sides of ``table.migration`` for a **keyed** (merge) CDC flow.
        #
        # A keyed table keeps its ``scd_type`` across a destination relocation, so both
        # the capture (old flow) and the cutover (new flow) reach here -- unlike the
        # SCD1->append switch, whose cutover changes ingestion type and lands in
        # :meth:`_read_append_only`. Migration **never streams and never snapshots**: every
        # read records a checkpoint, emits no rows, and stops, or fails closed. Streaming
        # (and finishing an in-flight snapshot) resumes only once the operator clears
        # ``table.migration`` (the "Restore" step), after which the flow reads
        # normally from the checkpoint recorded here. The states:
        #
        # * **Capture** (old flow) -- a stream-phase offset (steady-state CDC, or an
        #   in-flight incremental copy whose ``incremental`` block fully describes a
        #   resumable position), or a blocking ``initial`` snapshot parked mid-serve
        #   (``phase=="snapshot"``, whose staged pages are portable *by reference* -- a new
        #   flow reads them under the capturing scope via ``stage_scope``). Park it and
        #   stop: an empty batch at the same offset is the AvailableNow "caught up, stop"
        #   signal, so the parked offset equals the flow's committed position exactly.
        # * **Cutover seed** (new flow) -- an empty checkpoint with a parked token. Adopt
        #   the parked offset as this flow's checkpoint, emit no rows, and stop. The token
        #   is kept (not dropped) so a crash before the seed commits re-seeds rather than
        #   failing closed; a ``handoff_seeded`` marker on the seed lets the next read drop
        #   it (see :meth:`_handoff_seed_from_token`).
        # * **Seed committed** (new flow) -- the marker is present, so the seed committed.
        #   Drop the now-consumed token and stop, still emitting no rows. The marker is
        #   **kept on the outgoing offset** so a later steady-state read is not mistaken for
        #   a fresh capture and re-parked; the flow idles here until Restore clears
        #   table.migration.
        # * **Fail closed** -- an empty checkpoint with no parked token means the flow has
        #   not reached a hand-off-able position (steady-state streaming, an in-flight
        #   incremental copy, or a mid-serve blocking snapshot). There is nothing to record,
        #   so raise rather than silently snapshotting: the operator must run the flow
        #   without table.migration until it is streaming (or mid initial snapshot), then
        #   set it.

        if not _cdc_capable(table):
            # 208: table.migration requires a CDC-capable table; '{}' is snapshot-only
            raise ValueError(_m(208, table.exposed_name))
        if effective_start and effective_start.get("handoff_seeded"):
            # The committed seed has arrived: the token has served its purpose, so drop it
            # (crash-safe -- a crash before this re-seeds from the still-present token).
            # Record and stop: no rows, same offset back. Keep the marker so a later
            # steady-state read is not mistaken for a fresh capture and re-parked. Streaming
            # resumes only after Restore clears table.migration.
            self._delete_handoff_token(table)
            return iter(()), dict(effective_start)
        if not effective_start:
            token = self._read_handoff_token(table)
            if token is not None:
                seeded = self._handoff_seed_from_token(table, token)
                # The seed is this update's resume position, as a checkpoint's is (see
                # _read_table_attempt): a delete reader with no token of its own bootstraps
                # from it now, not after this reader's next read -- which, for a seed taken
                # mid-snapshot, comes only once Restore has let the snapshot finish.
                self._publish_upsert_channel_start(
                    table,
                    int(seeded.get("begin_lsn") or seeded["commit_lsn"]),
                    str(seeded["schema_id"]),
                    str(seeded["schema_fingerprint"]),
                    self._pipeline_scope(),
                )
                return iter(()), seeded
            # 209: table.migration=true for '{}' has no checkpoint to record and no parked token:
            # the flow has not reached a hand-off-able position. Run it without table.migration
            # until it is streaming (or mid initial snapshot), then set table.migration=true so it
            # parks its offset -- or start fresh with snapshot.mode=cdc_only (no history) or
            # snapshot.mode=initial (full snapshot).
            raise InformixError(_m(209, table.exposed_name))
        # A stream-phase offset, or a blocking initial snapshot parked mid-serve
        # (phase=="snapshot"): both are portable, so park the offset as the token and
        # stop. A snapshot offset's staged pages stay under this (capturing) scope; the
        # cutover records that scope on stage_scope so the new flow can read them, and
        # after Restore finishes the snapshot from the parked page_index before streaming.
        self._write_handoff_token(table, effective_start)
        return iter(()), dict(effective_start)

    def _read_handoff_deletes(
        self,
        table_name: str,
        effective_start: dict,
        options: dict[str, str],
        bootstrap_offset: dict,
    ) -> tuple[Iterator[dict], dict]:
        # Docstring: Delete-channel side of ``table.migration``.
        #
        # Mirrors :meth:`_read_handoff` on the independently checkpointed delete reader,
        # so a keyed relocation that keeps its ``scd_type`` records the delete position
        # across the seam too -- so that, after Restore, the delete reader resumes at
        # *exactly* where the old flow's delete reader stopped, rather than restarting from
        # the upsert boundary (which could skip deletes that lay between the two readers'
        # independent positions). Like :meth:`_read_handoff`, it never streams: it records a
        # checkpoint, emits no rows, and stops. The delete token uses a separate channel
        # from the upsert token.
        #
        # The SCD1->append switch has no delete flow at all, so this is only reached for
        # a table that keeps a delete channel; a snapshot-only or append table freezes.

        table = self._table(table_name, options)
        if self._append_only_table(table, options) or not _cdc_capable(table):
            # No delete channel to hand off; freeze at the current offset like any other
            # handoff read so the flow stops without advancing.
            return iter(()), dict(effective_start)
        if effective_start and effective_start.get("handoff_seeded"):
            # Seed committed: drop the delete-channel token and stop, like _read_handoff.
            # Keep the marker so a later read is not mistaken for a capture and re-parked.
            self._delete_handoff_token(table, _HANDOFF_CHANNEL_DELETE)
            return iter(()), dict(effective_start)
        if not effective_start:
            token = self._read_handoff_token(table, _HANDOFF_CHANNEL_DELETE)
            if token is not None:
                return iter(()), self._handoff_seed_from_token(table, token)
            # No parked delete position (e.g. capture ran before the delete reader had a
            # checkpoint): fall back to the ordinary bootstrap, which adopts the upsert
            # channel's newly published boundary under this flow's scope.
            rows, seeded = self._read_table_deletes(
                table_name,
                effective_start,
                options,
                snapshot_mode="cdc_only",
                bootstrap_offset=bootstrap_offset,
            )
            if "commit_lsn" in seeded:
                # A seed, marked as a token's is, so the next read during the migration
                # keeps it rather than parking it as a delete token of its own.
                seeded = {**seeded, "handoff_seeded": True}
            return rows, seeded
        if effective_start.get("phase") == "stream":
            self._write_handoff_token(table, effective_start, _HANDOFF_CHANNEL_DELETE)
        return iter(()), dict(effective_start)

    def _read_cdc_only(self, table: Table) -> tuple[Iterator[dict], dict]:
        # Docstring: Establish a schema-safe CDC boundary without reading existing rows.

        pipeline_scope = self._pipeline_scope()
        table = self._refresh_table_schema(table, None)
        if not _cdc_capable(table):
            # 210: snapshot.mode=cdc_only requires a CDC-capable table; '{}' is snapshot-only
            raise ValueError(_m(210, table.exposed_name))
        high_water = self._initial_lsn(table, scope=pipeline_scope)
        if high_water is None:  # owner=True always publishes or raises
            # 211: Unable to establish no-data boundary for '{}'
            raise InformixError(_m(211, table.exposed_name))
        schema_id = self._snapshot_schema_ids[(pipeline_scope, table.identity)]
        self._publish_snapshot_boundary(table, schema_id, high_water, high_water, pipeline_scope)
        return iter(()), _offset(
            high_water,
            high_water,
            high_water,
            None,
            "stream",
            table,
            schema_id,
            pipeline_scope,
        )

    def _table_state_keys(self, table: Table) -> tuple[str, str]:
        # Docstring: Return the (connection, table) key pair that identifies a table's state.
        #
        # The single source of truth for both. ``_shared_table_state_root`` joins
        # these under the shared state location; snapshot staging joins the same two
        # under the staging location. Deriving them here rather than recovering them
        # by relpath is what lets staging stand alone once the shared state location
        # is gone.

        return self._table_state_keys_for(table.native_identity)

    def _table_state_keys_for(self, native_identity: str) -> tuple[str, str]:
        # Docstring: Identity-string form of :meth:`_table_state_keys`.
        #
        # Depends only on ``native_identity`` and the connection options (both
        # available on a Spark executor), so the staged-page read path can run there
        # without a ``Table`` -- i.e. without a live Informix catalog lookup.

        namespace = "\0".join(
            (
                "v2",
                self.options.get("hostname", "").strip().rstrip(".").casefold(),
                str(int(self.options.get("port", "9088"))),
                self.options.get("server", "").strip(),
                self.options.get("database", "").strip(),
            )
        )
        return (
            hashlib.sha256(namespace.encode()).hexdigest()[:24],
            hashlib.sha256(native_identity.encode()).hexdigest()[:24],
        )

    def _snapshot_stage_namespace(self, table: Table, pipeline_scope: str, schema_id: str) -> str:
        return self._snapshot_stage_namespace_for(table.native_identity, pipeline_scope, schema_id)

    def _snapshot_stage_namespace_for(
        self, native_identity: str, pipeline_scope: str, schema_id: str
    ) -> str:
        # Computed directly from the table's identity rather than recovered by
        # relpath against the shared state location, so staging no longer depends
        # on that location existing at all. The resulting path is byte-identical
        # to what the relpath form produced.
        connection_key, table_key = self._table_state_keys_for(native_identity)
        return os.path.join(
            self._snapshot_staging_location,
            connection_key,
            table_key,
            "snapshot-page-data",
            pipeline_scope,
            schema_id,
        )

    def _snapshot_manifest_namespace(
        self, table: Table, pipeline_scope: str, schema_id: str
    ) -> str:
        # Docstring: Record key for a staged snapshot's manifest.
        #
        # The manifest is metadata -- page count, row count, snapshot LSN -- so it
        # lives with the rest of the state rather than beside the page payloads it
        # describes. Keying it by identity instead of by staging path means moving
        # or repointing the staging Volume does not orphan it.

        connection_key, table_key = self._table_state_keys(table)
        return "/".join(
            (
                connection_key,
                table_key,
                "snapshot-page-manifest",
                pipeline_scope,
                schema_id,
            )
        )

    def _cleanup_completed_snapshot_stage(self, table: Table, checkpoint: dict[str, Any]) -> None:
        validated = _validated_offset(checkpoint)
        # The scope that staged the pages: a snapshot finished in a later update than it
        # started keeps the starting update's scope on its offsets.
        scope = self._offset_scopes(validated)[1]
        schema_id = str(validated["schema_id"])
        path = self._snapshot_stage_namespace(table, scope, schema_id)
        if path in self._cleaned_snapshot_stages:
            return
        # The serve path deletes consumed pages on a background pool (see
        # _cleanup_consumed_snapshot_stage_pages), so a page can vanish while this walk is
        # visiting it, and the walk then stops part-way with FileNotFoundError. Walk again
        # until the stage is gone, and record it as cleaned only then, so the rest of it
        # is not left behind for the retention sweep.
        for _ in range(_SNAPSHOT_STAGE_CLEANUP_ATTEMPTS):
            try:
                PurePythonInformixBridge._remove_connection_slot_tree(path)
            except FileNotFoundError:
                if os.path.lexists(path):
                    continue
            except OSError:
                # 212: Cannot remove completed Informix snapshot staging data: {}
                logging.getLogger(__name__).warning(
                    _m(212, path),
                    exc_info=True,
                )
                return
            break
        if os.path.lexists(path):
            # 213: Completed Informix snapshot staging data is still changing; leaving {} for a
            # later read or the retention sweep
            logging.getLogger(__name__).warning(
                _m(213, path),
            )
            return
        self._cleaned_snapshot_stages.add(path)

    def _staging_transport(self) -> WorkspaceFilesApi | None:
        # Docstring: Resolve the snapshot-page staging transport once, caching the choice.
        #
        # Returns a :class:`WorkspaceFilesApi` to stage pages over the Files REST API,
        # or ``None`` to use the FUSE mount. ``fuse`` forces FUSE; ``rest`` forces REST
        # and raises if a token cannot be minted; ``auto`` (default) uses REST when a
        # staging token can be minted and falls back to FUSE when the workspace forbids
        # token creation. The first mint is forced here so a "creation disabled"
        # workspace falls back at resolution time rather than mid-drain.

        if self._staging_transport_resolved:
            files_api = self._staging_files_api
            if (
                files_api is not None
                and getattr(files_api, "rejected", False)
                and not self._staging_rest_required
            ):
                # The token was rejected and nothing could mint a successor (the
                # reader's starting credential lasts about an hour): stage over FUSE
                # from now on, as when no token could be minted at all.
                # 214: The snapshot-staging token was rejected and can't be replaced; snapshot
                # staging uses the FUSE transport from now on
                logging.getLogger(__name__).warning(_m(214))
                self._staging_files_api = files_api = None
            return files_api
        self._staging_transport_resolved = True
        mode = (
            str(
                self.options.get(
                    _SNAPSHOT_STAGING_TRANSPORT_OPTION, _DEFAULT_SNAPSHOT_STAGING_TRANSPORT
                )
            )
            .strip()
            .lower()
        )
        self._staging_rest_required = mode == "rest"
        if mode == "fuse":
            return None
        provider = self._build_staging_credential_provider(required=mode == "rest")
        if provider is None:
            return None
        files_api = WorkspaceFilesApi(self._staging_workspace_host, provider)
        try:
            provider.bearer()
        except StagingTokenUnavailable:
            if mode == "rest":
                raise
            # 215: Personal access token creation is unavailable; snapshot staging uses the FUSE
            # transport
            logging.getLogger(__name__).info(_m(215))
            return None
        except WorkspaceHttpError as error:
            # A 401 here is the reader's starting credential expiring (it lasts about an
            # hour, and every reader, a drain worker's included, mints its first token
            # from it): stage over FUSE, as when token creation is forbidden.
            if mode == "rest" or error.status_code != 401:
                raise
            # 216: The credential that mints the snapshot-staging token was rejected; snapshot
            # staging uses the FUSE transport
            logging.getLogger(__name__).warning(_m(216))
            return None
        self._staging_files_api = files_api
        return files_api

    def _staging_fell_back(self, error: WorkspaceHttpError) -> bool:
        # Docstring: Whether a Files API error was a 401 nothing could recover that moved an
        # ``auto`` staging transport to FUSE, so the caller can redo its operation there.
        # ``rest`` keeps its transport, and every other error stands.

        return error.status_code == 401 and self._staging_transport() is None

    def _should_pipeline_staging(self, scan_keys: tuple[str, ...]) -> bool:
        # Docstring: Whether to overlap this drain's page fetch with the page upload.
        #
        # Only for a positional drain over the REST transport -- ``scan_keys`` empty: a
        # keyless table, or a keyed one on ``snapshot.scan=cursor``. Keyset drains are
        # out of scope, and pipelining FUSE writes would raise the mount's write
        # frequency -- the exact condition the REST transport exists to avoid.

        if scan_keys:
            return False
        if not _option_bool(self.options, _SNAPSHOT_STAGING_PIPELINE_OPTION, True):
            return False
        return self._staging_transport() is not None

    def _build_staging_credential_provider(
        self, *, required: bool
    ) -> StagingCredentialProvider | None:
        # Docstring: Build the Files-API credential provider, or ``None`` to fall back to FUSE.
        #
        # In ``auto`` mode with neither explicit workspace credentials nor a Databricks
        # runtime there is no ambient identity to mint from, so it returns ``None``
        # without probing the SDK -- which also keeps offline tests on FUSE. ``rest``
        # mode (``required``) always attempts resolution and lets a failure propagate.

        explicit = bool(
            self.options.get("lakebase.workspace.token")
            and self.options.get("lakebase.workspace.host")
        )
        if not required and not explicit and not os.environ.get("DATABRICKS_RUNTIME_VERSION"):
            return None
        try:
            host, token = _workspace_credentials(self.options)
        except Exception:  # noqa: BLE001 - any resolution failure falls back to FUSE in auto
            if required:
                raise
            return None
        self._staging_workspace_host = host
        pipeline_id, _, update_id = self._pipeline_scope().partition("_@_")
        pipeline_id = pipeline_id.strip() or "default"
        lifetime = self._table_int_option(
            self.options,
            _SNAPSHOT_STAGING_TOKEN_LIFETIME_OPTION,
            _DEFAULT_STAGING_TOKEN_LIFETIME_SECONDS,
            minimum=_STAGING_TOKEN_MIN_LIFETIME_SECONDS,
        )
        return StagingCredentialProvider(
            host,
            token,
            pipeline_id,
            lifetime_seconds=lifetime,
            secret_scope=_SNAPSHOT_STAGING_SECRET_SCOPE,
            secret_key=pipeline_id,
            update_id=update_id.strip(),
        )

    def _publish_snapshot_stage_page(
        self,
        table: Table,
        pipeline_scope: str,
        schema_id: str,
        snapshot_lsn: int,
        page_index: int,
        rows: list[dict[str, Any]],
        lower_pk: list[Any] | None,
    ) -> Any:
        # Docstring: Stage one page; returns the encoded upper_pk its header records.

        namespace = os.path.join(
            self._snapshot_stage_namespace(table, pipeline_scope, schema_id),
            "runs",
            str(snapshot_lsn),
        )
        encoded_rows = _encode_snapshot_stage_value(rows)
        body = {
            "lower_pk": _encode_snapshot_stage_value(lower_pk),
            "page_index": page_index,
            "pipeline_scope": pipeline_scope,
            "row_count": len(rows),
            "rows": encoded_rows,
            "schema_id": schema_id,
            "snapshot_lsn": str(snapshot_lsn),
            "table": table.native_identity,
            "upper_pk": _encode_snapshot_stage_value([rows[-1][key] for key in table.primary_keys]),
            "version": _SNAPSHOT_STAGE_VERSION,
        }
        payload, digest = _staged_page_payload(body)
        record = {**body, "sha256": digest}
        if len(payload) > _MAX_SNAPSHOT_STAGE_PAGE_BYTES:
            # 217: Staged snapshot page {} for '{}' exceeds {} decoded bytes; reduce
            # snapshot.page.size
            raise InformixError(
                _m(217, page_index, table.exposed_name, _MAX_SNAPSHOT_STAGE_PAGE_BYTES)
            )
        compressed = gzip.compress(payload, compresslevel=6, mtime=0)
        page_name = f"page-{page_index:08d}"
        files_api = self._staging_transport()
        if files_api is not None:
            # REST transport: write the payload straight to the Volume over the Files
            # API, never touching the FUSE mount. Head election lives in Postgres, so a
            # single overwrite PUT is sufficient -- no candidate/atomic-rename fence is
            # needed (a page's content is a pure function of its committed rows, so a
            # re-published page is byte-identical). Reads still go through FUSE.
            try:
                files_api.put(os.path.join(namespace, page_name, "data.json.gz"), compressed)
                return body["upper_pk"]
            except WorkspaceHttpError as error:
                # After a 401 nothing could recover, FUSE writes this page too.
                if not self._staging_fell_back(error):
                    raise
        # No filesystem capability probe: the exclusive-create and atomic-rename
        # guarantees it checked were needed by the head-election protocol, which
        # Postgres now performs. Writing a page needs only ordinary directory
        # creation, and a failure surfaces from the write itself.
        os.makedirs(namespace, mode=0o700, exist_ok=True)
        target = os.path.join(namespace, page_name)
        candidate = os.path.join(namespace, f"candidate-{secrets.token_hex(16)}")
        try:
            os.mkdir(candidate, mode=0o700)
            descriptor = os.open(
                os.path.join(candidate, "data.json.gz"),
                os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0),
                0o600,
            )
            with os.fdopen(descriptor, "wb") as handle:
                handle.write(compressed)
                handle.flush()
                os.fsync(handle.fileno())
            candidate_descriptor = os.open(
                candidate,
                os.O_RDONLY | getattr(os, "O_DIRECTORY", 0) | getattr(os, "O_NOFOLLOW", 0),
            )
            try:
                os.fsync(candidate_descriptor)
            finally:
                os.close(candidate_descriptor)
            os.rename(candidate, target)
        except OSError:
            if not os.path.isdir(target):
                raise
            existing = self._read_snapshot_stage_page_record(
                table, pipeline_scope, schema_id, snapshot_lsn, page_index
            )
            if existing != record:
                # 218: Conflicting immutable snapshot page {} for '{}'
                raise InformixError(_m(218, page_index, table.exposed_name))
        finally:
            try:
                PurePythonInformixBridge._remove_connection_slot_tree(candidate)
            except FileNotFoundError:
                pass
            except OSError:
                # 219: Cannot remove Informix snapshot-page candidate: {}
                logging.getLogger(__name__).warning(
                    _m(219, candidate),
                    exc_info=True,
                )
        return body["upper_pk"]

    def _read_staged_page_payload(
        self,
        table: Table,
        pipeline_scope: str,
        schema_id: str,
        snapshot_lsn: int,
        page_index: int,
    ) -> bytes:
        # Docstring: Open, size-guard, and decompress one staged page into its raw JSON bytes.
        #
        # Both the whole-record reader (used by the staging conflict check) and the
        # streaming serve reader go through this, so the file-open/decompress/ceiling
        # logic lives in one place.

        return self._read_staged_page_payload_for(
            table.native_identity,
            table.exposed_name,
            pipeline_scope,
            schema_id,
            snapshot_lsn,
            page_index,
        )

    def _read_staged_page_payload_for(
        self,
        native_identity: str,
        exposed_name: str,
        pipeline_scope: str,
        schema_id: str,
        snapshot_lsn: int,
        page_index: int,
    ) -> bytes:
        # Docstring: Identity-string form of :meth:`_read_staged_page_payload`.
        #
        # Uses only the page's identity strings + the staging location, so it runs on
        # a Spark executor (the partitioned reader's ``read_partition``) with no live
        # Informix ``Table`` and therefore no catalog connection.

        path = os.path.join(
            self._snapshot_stage_namespace_for(native_identity, pipeline_scope, schema_id),
            "runs",
            str(snapshot_lsn),
            f"page-{page_index:08d}",
            "data.json.gz",
        )
        try:
            descriptor = _open_state_file(self._snapshot_staging_location, path)
            metadata = os.fstat(descriptor)
            if metadata.st_size > _MAX_SNAPSHOT_STAGE_PAGE_BYTES:
                os.close(descriptor)
                # 220: Compressed staged snapshot page {} for '{}' is too large
                raise InformixError(_m(220, page_index, exposed_name))
            with os.fdopen(descriptor, "rb") as raw_handle:
                with gzip.GzipFile(fileobj=raw_handle, mode="rb") as handle:
                    payload = handle.read(_MAX_SNAPSHOT_STAGE_PAGE_BYTES + 1)
        except (OSError, EOFError) as error:
            if _dropped_mount_error(error) is not None:
                raise  # unwrapped, so a read's dropped-mount retry sees it
            # 221: Cannot read staged snapshot page {} for '{}'
            raise InformixError(_m(221, page_index, exposed_name)) from error
        if len(payload) > _MAX_SNAPSHOT_STAGE_PAGE_BYTES:
            # 222: Staged snapshot page {} for '{}' exceeds its decoded size bound
            raise InformixError(_m(222, page_index, exposed_name))
        return payload

    def _read_snapshot_stage_page_record(
        self,
        table: Table,
        pipeline_scope: str,
        schema_id: str,
        snapshot_lsn: int,
        page_index: int,
    ) -> dict[str, Any]:
        payload = self._read_staged_page_payload(
            table, pipeline_scope, schema_id, snapshot_lsn, page_index
        )
        try:
            record = json.loads(payload)
            # Free the decompressed page bytes (up to the 256 MB ceiling) before
            # building the canonical form and the row graph, so they do not stack
            # on top of the peak. Matters for a wide table's large page.
            del payload
        except (UnicodeError, json.JSONDecodeError) as error:
            # 221: Cannot read staged snapshot page {} for '{}'
            raise InformixError(_m(221, page_index, table.exposed_name)) from error
        if not isinstance(record, dict):
            # 223: Invalid staged snapshot page {} for '{}'
            raise InformixError(_m(223, page_index, table.exposed_name))
        digest = record.get("sha256")
        body = {key: value for key, value in record.items() if key != "sha256"}
        # Hash the canonical body, then release that (also up to ~256 MB) before the
        # validation so it does not coexist with the row graph the caller decodes.
        computed_digest = hashlib.sha256(
            json.dumps(body, allow_nan=False, separators=(",", ":"), sort_keys=True).encode("utf-8")
        ).hexdigest()
        del body
        if (
            record.get("version") != _SNAPSHOT_STAGE_VERSION
            or record.get("table") != table.native_identity
            or record.get("pipeline_scope") != pipeline_scope
            or record.get("schema_id") != schema_id
            or record.get("page_index") != page_index
            or isinstance(record.get("row_count"), bool)
            or record.get("row_count") != len(record.get("rows", []))
            or not isinstance(digest, str)
            or not hmac.compare_digest(digest, computed_digest)
        ):
            # 223: Invalid staged snapshot page {} for '{}'
            raise InformixError(_m(223, page_index, table.exposed_name))
        return record

    def _stream_staged_page(
        self,
        table: Table,
        pipeline_scope: str,
        schema_id: str,
        snapshot_lsn: int,
        page_index: int,
    ) -> tuple[dict[str, Any], Iterator[dict[str, Any]]]:
        # Docstring: Read a staged page without ever materializing its whole row graph.
        #
        # The blocker for wide pages is that ``json.loads`` builds the entire page's
        # Python object graph (multiple GB) before a row is served, OOM-ing the
        # worker. Here the page is parsed structurally instead: the small header
        # fields are decoded, the huge ``rows`` array is *located* (not parsed), and
        # the rows are streamed one at a time by the returned generator, so peak
        # memory is the ~256 MB page text plus a single row rather than the whole
        # graph.
        #
        # Integrity is still verified over the exact same bytes the writer hashed.
        # The writer stores ``sha256(json.dumps(body))`` and the page is
        # ``json.dumps({**body, "sha256": digest})`` with identical ``json.dumps``
        # settings, so the page bytes with the ``"sha256":"..."`` field excised are
        # byte-for-byte that canonical body -- hashed here via a ``memoryview`` (no
        # copy). ``json.dumps`` defaults to ``ensure_ascii=True``, so the page is
        # ASCII and character offsets equal byte offsets, letting the text scan and
        # the byte hash share indices.
        #
        # Returns ``(header, rows)`` where ``header`` holds every field except
        # ``rows`` (already validated for version/identity/scope/schema/page and
        # integrity) and ``rows`` is a single-use generator of decoded rows that also
        # enforces the row count.

        return self._stream_staged_page_for(
            table.native_identity,
            table.exposed_name,
            pipeline_scope,
            schema_id,
            snapshot_lsn,
            page_index,
        )

    def _stream_staged_page_for(
        self,
        native_identity: str,
        exposed_name: str,
        pipeline_scope: str,
        schema_id: str,
        snapshot_lsn: int,
        page_index: int,
    ) -> tuple[dict[str, Any], Iterator[dict[str, Any]]]:
        # Docstring: Identity-string form of :meth:`_stream_staged_page`.
        #
        # Takes the page's identity strings instead of a ``Table`` so it runs on a
        # Spark executor (the partitioned reader's ``read_partition``) without a live
        # Informix catalog lookup. Integrity, structural scan, and row-count checks
        # are identical.

        payload = self._read_staged_page_payload_for(
            native_identity, exposed_name, pipeline_scope, schema_id, snapshot_lsn, page_index
        )

        def invalid() -> InformixError:
            # 223: Invalid staged snapshot page {} for '{}'
            return InformixError(_m(223, page_index, exposed_name))

        try:
            text = payload.decode("ascii")
        except UnicodeError as error:
            raise invalid() from error
        try:
            header, array_start, sha_span = _scan_staged_page(text)
        except InformixError as error:
            raise invalid() from error
        # Integrity over the exact canonical body: the page bytes with the sha256
        # field excised are byte-identical to what the writer hashed. memoryview
        # slices avoid copying the (up to 256 MB) payload.
        stored_digest = header.get("sha256")
        digest = hashlib.sha256()
        view = memoryview(payload)
        digest.update(view[: sha_span[0]])
        digest.update(view[sha_span[1] :])
        computed_digest = digest.hexdigest()
        view.release()
        del payload
        if not isinstance(stored_digest, str) or not hmac.compare_digest(
            computed_digest, stored_digest
        ):
            raise invalid()
        expected_row_count = header.get("row_count")
        expected_identity = (
            _SNAPSHOT_STAGE_VERSION,
            native_identity,
            pipeline_scope,
            schema_id,
            page_index,
        )
        actual_identity = (
            header.get("version"),
            header.get("table"),
            header.get("pipeline_scope"),
            header.get("schema_id"),
            header.get("page_index"),
        )
        if (
            actual_identity != expected_identity
            or isinstance(expected_row_count, bool)
            or not isinstance(expected_row_count, int)
        ):
            raise invalid()

        def stream_rows() -> Iterator[dict[str, Any]]:
            row_decoder = json.JSONDecoder()
            position = _skip_json_whitespace(text, array_start + 1)
            count = 0
            # array_end is just past the matching ']'; a non-empty array has an
            # element here, an empty one has the ']' itself.
            if text[position] != "]":
                while True:
                    row, position = row_decoder.raw_decode(text, position)
                    if not isinstance(row, dict):
                        # 224: Invalid staged snapshot rows for '{}'
                        raise InformixError(_m(224, exposed_name))
                    count += 1
                    yield _decode_snapshot_stage_value(row)
                    position = _skip_json_whitespace(text, position)
                    if position < len(text) and text[position] == ",":
                        position = _skip_json_whitespace(text, position + 1)
                    elif position < len(text) and text[position] == "]":
                        break
                    else:
                        # 224: Invalid staged snapshot rows for '{}'
                        raise InformixError(_m(224, exposed_name))
            if count != expected_row_count:
                # 225: Staged snapshot row count mismatch for '{}'
                raise InformixError(_m(225, exposed_name))

        return header, stream_rows()

    def _snapshot_cleanup_executor(self) -> concurrent.futures.ThreadPoolExecutor:
        # Docstring: Lazily start the background pool that deletes consumed staged pages.
        #
        # Created on first use rather than in ``__init__`` and never pickled (see
        # ``close``/``__getstate__``): it is a driver-only, non-serializable object.

        executor = self._snapshot_cleanup_executor_instance
        if executor is None:
            executor = concurrent.futures.ThreadPoolExecutor(
                max_workers=_SNAPSHOT_CLEANUP_THREADS,
                thread_name_prefix="informix-page-cleanup",
            )
            self._snapshot_cleanup_executor_instance = executor
        return executor

    @staticmethod
    def _delete_snapshot_page(path: str) -> None:
        # Docstring: Remove one consumed staged page. Best-effort: a leak only wastes space.

        try:
            PurePythonInformixBridge._remove_connection_slot_tree(path)
        except FileNotFoundError:
            pass
        except OSError:
            # 226: Cannot remove consumed Informix snapshot page: {}
            logging.getLogger(__name__).warning(
                _m(226, path),
                exc_info=True,
            )

    def _cleanup_consumed_snapshot_stage_pages(
        self,
        table: Table,
        pipeline_scope: str,
        schema_id: str,
        snapshot_lsn: int,
        before_page_index: int,
    ) -> None:
        # Docstring: Schedule deletion of pages the reader has advanced past.
        #
        # Incremental and off the serve path. A per-stream high-water mark makes
        # this schedule only the pages consumed since the last call, so it is O(1)
        # amortized per microbatch instead of the old O(page_index) rescan that
        # re-walked every earlier page each time -- at thousands of pages that
        # quadratic pile of FUSE lookups, not decode, dominated serve time. The
        # deletes run on a background pool so the microbatch never blocks on the
        # Volume. The mark lives on the reader instance, so a fresh stream (or a
        # restart) starts at zero and schedules every earlier page once; that
        # catch-up is still asynchronous. Deletion stays best-effort: a leaked page
        # only wastes space and is reclaimed by the retention sweep.

        key = (pipeline_scope, schema_id, snapshot_lsn)
        already_scheduled = self._snapshot_cleanup_watermark.get(key, 0)
        if before_page_index <= already_scheduled:
            return
        self._snapshot_cleanup_watermark[key] = before_page_index
        run = os.path.join(
            self._snapshot_stage_namespace(table, pipeline_scope, schema_id),
            "runs",
            str(snapshot_lsn),
        )
        executor = self._snapshot_cleanup_executor()
        for page_index in range(already_scheduled, before_page_index):
            path = os.path.join(run, f"page-{page_index:08d}")
            executor.submit(self._delete_snapshot_page, path)

    def _maybe_sweep_stale_snapshot_stages(self, table: Table) -> None:
        # Docstring: Submit a one-shot background sweep of this table's stale staged snapshot runs.
        #
        # The consumed-page and completed-stage cleanups reclaim staging in the normal
        # lifecycle, but a crash, an abandoned resnapshot, or a superseded schema/scope can
        # leave a whole ``runs/<snapshot_lsn>`` subtree behind. This is the age-based safety
        # net that ``snapshot.staging.retention.days`` promises. It runs off the serve path
        # (on the same background pool as page deletion) and at most once per table per
        # reader instance -- so it never blocks a microbatch and never rescans -- and it is
        # keyed on file mtime, so an active run (recent page writes) is never swept.

        location = self._snapshot_staging_location
        retention = self._snapshot_staging_retention_seconds
        if not location or retention <= 0:
            return
        identity = table.native_identity
        if identity in self._retention_swept:
            return
        self._retention_swept.add(identity)
        connection_key, table_key = self._table_state_keys_for(identity)
        root = os.path.join(location, connection_key, table_key, "snapshot-page-data")
        self._snapshot_cleanup_executor().submit(
            self._sweep_stale_snapshot_stages, root, float(retention)
        )

    @staticmethod
    def _sweep_stale_snapshot_stages(root: str, retention_seconds: float) -> None:
        # Docstring: Delete ``runs/<snapshot_lsn>`` subtrees under a table's staging root whose
        # newest page is older than the retention window.
        #
        # Best-effort and idempotent, and safe to run concurrently with serving: an active
        # run's pages carry a recent mtime so it is never selected, and a path that is
        # missing or removed by a racing cleanup is skipped. Runs on a background thread.

        cutoff = time.time() - retention_seconds
        for scope in _staging_subdirectories(root):
            for schema in _staging_subdirectories(scope):
                for run in _staging_subdirectories(os.path.join(schema, "runs")):
                    try:
                        if _newest_created_entry_mtime(run, recursive=True) >= cutoff:
                            continue
                    except OSError:
                        continue  # vanished or unreadable -- nothing to reclaim
                    try:
                        PurePythonInformixBridge._remove_connection_slot_tree(run)
                    except FileNotFoundError:
                        pass
                    except OSError:
                        # 227: Cannot remove stale Informix snapshot run: {}
                        logging.getLogger(__name__).warning(_m(227, run), exc_info=True)

    def _read_snapshot_stage_manifest(
        self, table: Table, pipeline_scope: str, schema_id: str
    ) -> dict[str, Any] | None:
        record = self._read_immutable_head(
            self._snapshot_manifest_namespace(table, pipeline_scope, schema_id)
        )
        if record is None:
            return None
        if (
            record.get("record_type") != "snapshot-page-manifest"
            or record.get("table") != table.native_identity
            or record.get("scope") != pipeline_scope
            or record.get("schema_id") != schema_id
            or isinstance(record.get("page_count"), bool)
            or not isinstance(record.get("page_count"), int)
            or int(record["page_count"]) < 0
            or isinstance(record.get("row_count"), bool)
            or not isinstance(record.get("row_count"), int)
            or int(record["row_count"]) < 0
        ):
            # 228: Invalid staged snapshot manifest for '{}'
            raise InformixError(_m(228, table.exposed_name))
        _strict_lsn(record.get("snapshot_lsn"), "snapshot_lsn")
        return record

    def _publish_snapshot_stage_manifest(
        self,
        table: Table,
        pipeline_scope: str,
        schema_id: str,
        snapshot_lsn: int,
        page_count: int,
        row_count: int,
        first_upper_pk: str | None = None,
    ) -> dict[str, Any]:
        # first_upper_pk is page 0's header upper_pk as sorted-key JSON text, so the first
        # microbatch's end offset can be built without reading the page. Text, because the
        # jsonb column reorders nested keys and the offset must match the page's byte for byte.
        recorded = {} if first_upper_pk is None else {"first_upper_pk": first_upper_pk}
        self._publish_immutable_head(
            self._snapshot_manifest_namespace(table, pipeline_scope, schema_id),
            {
                **recorded,
                "created_at": time.time(),
                "page_count": page_count,
                "row_count": row_count,
                "schema_id": schema_id,
                "scope": pipeline_scope,
                "snapshot_lsn": str(snapshot_lsn),
                "table": table.native_identity,
            },
            record_type="snapshot-page-manifest",
        )
        manifest = self._read_snapshot_stage_manifest(table, pipeline_scope, schema_id)
        if (
            manifest is None
            or int(manifest["snapshot_lsn"]) != snapshot_lsn
            or int(manifest["page_count"]) != page_count
            or int(manifest["row_count"]) != row_count
        ):
            # 229: Conflicting staged snapshot manifest for '{}'
            raise InformixError(_m(229, table.exposed_name))
        return manifest

    def _staged_snapshot_result(
        self,
        table: Table,
        pipeline_scope: str,
        schema_id: str,
        manifest: dict[str, Any],
        page_index: int,
        checkpoint: dict | None = None,
        *,
        stage_scope: str | None = None,
    ) -> tuple[Iterator[dict], dict]:
        # stage_scope is where the pages physically live (the capturing flow's scope for
        # a handoff relocation); pipeline_scope is this flow's own scope, stamped on the
        # emitted offsets. They coincide for every non-handoff serve.
        stage_scope = stage_scope or pipeline_scope
        page_count = int(manifest["page_count"])
        snapshot_lsn = _strict_lsn(manifest["snapshot_lsn"], "snapshot_lsn")
        if page_index < 0 or page_index >= page_count:
            # 230: Invalid staged snapshot page index {} for '{}'
            raise InformixError(_m(230, page_index, table.exposed_name))

        def read_page() -> tuple[dict[str, Any], Iterator[dict[str, Any]]]:
            # Stream the page: the header (all fields except rows) is parsed and
            # integrity-verified eagerly, and rows are yielded one at a time by the
            # returned generator, so the whole-page object graph is never materialized.
            header, rows = self._stream_staged_page(
                table, stage_scope, schema_id, snapshot_lsn, page_index
            )
            if _strict_lsn(header.get("snapshot_lsn"), "snapshot_lsn") != snapshot_lsn:
                # 231: Staged snapshot boundary mismatch for '{}'
                raise InformixError(_m(231, table.exposed_name))
            return header, rows

        if self._defer_staged_rows and page_index == 0:
            # The caller (the partitioned reader's first microbatch, or a drain worker)
            # needs only the end offset; page 0 is read here only if its rows are iterated
            # after all. The boundary cursor comes from the manifest, or from the page
            # header for a manifest an earlier connector version published; a one-page
            # snapshot needs neither.
            recorded = manifest.get("first_upper_pk")
            if page_count == 1:
                header = {}
            elif isinstance(recorded, str):
                header = {"upper_pk": json.loads(recorded)}
            else:
                header = read_page()[0]
            rows = _DeferredStagedPage(
                lambda: read_page()[1], (stage_scope, schema_id, snapshot_lsn, 0, 1, page_count)
            )
        else:
            header, rows = read_page()
        # The shared reader replays a batch from its start offset. Receiving
        # page_index=N as that start means Spark has advanced beyond every page
        # below N; retries continue from N, so those earlier immutable pages are
        # no longer required. Keep the current page and manifest intact.
        self._cleanup_consumed_snapshot_stage_pages(
            table,
            stage_scope,
            schema_id,
            snapshot_lsn,
            page_index,
        )
        next_page = page_index + 1
        if next_page < page_count:
            # The stored ``upper_pk`` is the encoded PK of the page's last row --
            # identical to encoding decoded[-1]'s key columns -- so the resume cursor
            # matches the whole-decode path without holding any row in memory.
            last_pk = header.get("upper_pk")
            end = _offset(
                snapshot_lsn,
                snapshot_lsn,
                snapshot_lsn,
                None,
                "snapshot",
                table,
                schema_id,
                pipeline_scope,
            )
            end.update(
                {
                    "snapshot_lsn": str(snapshot_lsn),
                    "snapshot": {"last_pk": last_pk, "page_index": next_page},
                }
            )
            # Carry stage_scope forward so the next microbatch still finds the pages under
            # the capturing scope; it is dropped at the stream transition (else branch),
            # after which the offset is an ordinary new-scope stream offset.
            if stage_scope != pipeline_scope:
                end["stage_scope"] = stage_scope
            # Staged pages remain, so work outstanding is a certainty rather than
            # an estimate. Carrying the streak here keeps a mid-snapshot reader
            # ranked above an idle one while it competes for slots; the streak is
            # cleared when the final page is served (the branch below).
            end = _with_backlog_streak(end, checkpoint or {}, True)
        else:
            end = _offset(
                snapshot_lsn,
                snapshot_lsn,
                snapshot_lsn,
                None,
                "stream",
                table,
                schema_id,
                pipeline_scope,
            )
        return rows, end

    def _incremental_datetime_chunk_exprs(
        self, table: Table, options: dict[str, str]
    ) -> tuple[dict[str, str], bool]:
        # Docstring: Return ``(chunk_exprs, viable)`` for incremental chunking.
        #
        # ``chunk_exprs`` maps each DATETIME primary-key column to a fixed-width
        # SQL text expression so keyset pagination can compare strings instead of
        # DATETIME literals. Any contiguous DATETIME qualifier is supported,
        # including HOUR-anchored TIME-of-day and DATE-only ranges, and a DATETIME
        # key column combined with non-DATETIME key columns in a composite key.
        # ``viable`` is False when the table has a DATETIME key that cannot be
        # string-chunked (option off or a malformed qualifier), signalling the
        # caller to fall back to the blocking snapshot rather than risk skipped
        # rows.

        if any(
            column.name in table.primary_keys
            and (column.type_name == "INTERVAL" or column.type_name in _FLOAT_KEY_TYPES)
            for column in table.columns
        ):
            # An INTERVAL key has no order-preserving string cast (a sign and an
            # unpadded leading field), and a float key has no exact literal for the keyset
            # bound, so either is copied by the blocking snapshot, whose positional paging
            # never renders a key back into SQL.
            return {}, False
        datetime_keys = [
            column
            for column in table.columns
            if column.name in table.primary_keys and column.type_name == "DATETIME"
        ]
        if not datetime_keys:
            return {}, True
        enabled = _option_bool(
            options,
            "snapshot.incremental.datetime.as.string",
            _option_bool(self.options, "snapshot.incremental.datetime.as.string", True),
        )
        if not enabled:
            return {}, False
        exprs: dict[str, str] = {}
        for column in datetime_keys:
            expr = datetime_order_preserving_cast(
                _sql_identifier(column.name), int(column.length or 0)
            )
            if expr is None:
                return {}, False
            exprs[column.name] = expr
        return exprs, True

    def _read_incremental(
        self,
        table: Table,
        start: dict | None,
        options: dict[str, str],
        *,
        pipeline_scope_override: str | None = None,
    ) -> tuple[Iterator[dict], dict]:
        # Docstring: Interleave a PK-chunked snapshot with the live CDC stream.
        #
        # Unlike the blocking consistent snapshot, CDC begins immediately at the
        # captured boundary and the table is copied in primary-key chunks, one
        # per microbatch, interleaved with change events. Each chunk is read in
        # its own short repeatable-read transaction and its READ rows are stamped
        # with the LSN captured just before that chunk's SELECT. Correctness for
        # keyed (apply_changes) targets follows from LSN sequencing: any
        # concurrent or later change to a chunked key commits at a higher LSN and
        # supersedes the READ row, so no in-memory deduplication window is needed.

        checkpoint = _validated_offset(start) if start else None
        # A truncated destination discards the offset, and with it the whole
        # incremental block, so this branch is also what a full refresh takes.
        if checkpoint is None:
            return self._begin_incremental(
                table, None, options, pipeline_scope_override=pipeline_scope_override
            )
        incremental = checkpoint.get("incremental")
        if isinstance(incremental, dict) and self._incremental_bound_is_foreign(incremental):
            # A bound from an earlier update was captured before this update's CDC
            # start, which would orphan rows inserted in between. Recapture it --
            # and only it, since the cursor still names rows this table holds.
            # 232: Informix incremental snapshot bound for '{}' was captured by scope={} but this
            # update is scope={}; recapturing the snapshot bound so rows above a stale bound are not
            # orphaned between the snapshot and the change stream
            logging.getLogger(__name__).warning(
                _m(232, table.exposed_name, incremental.get("scope"), self._registration_scope),
            )
            chunk_exprs, viable = self._incremental_datetime_chunk_exprs(table, options)
            if viable:
                checkpoint = dict(checkpoint)
                checkpoint["incremental"] = self._rebound_incremental_block(
                    table, incremental, chunk_exprs
                )
        return self._read_incremental_step(table, checkpoint, options)

    def _begin_incremental(
        self,
        table: Table,
        checkpoint: dict | None,
        options: dict[str, str],
        *,
        pipeline_scope_override: str | None = None,
    ) -> tuple[Iterator[dict], dict]:
        if checkpoint is not None:
            # 233: Informix incremental snapshot for '{}' resumed without its progress state; run a
            # full refresh
            raise InformixError(_m(233, table.exposed_name))
        pipeline_scope = pipeline_scope_override or self._pipeline_scope()
        table = self._refresh_table_schema(table, None)
        if not _cdc_capable(table):
            # 234: Table '{}' is not CDC-capable; incremental snapshot requires a primary key and
            # CDC-supported columns
            raise InformixError(_m(234, table.exposed_name))
        # snapshot.scan=cursor reads without key order, so there are no key ranges to
        # chunk by: take the blocking consistent snapshot, which honours the cursor scan.
        if self._snapshot_cursor_scan(options):
            # 235: Informix incremental snapshot for '{}' using the blocking consistent snapshot
            # because {}={} reads without key order
            logging.getLogger(__name__).info(
                _m(235, table.exposed_name, _SNAPSHOT_SCAN_OPTION, _SNAPSHOT_SCAN_CURSOR),
            )
            return self._read_snapshot(
                table, None, options, pipeline_scope_override=pipeline_scope_override
            )
        # DATETIME primary keys cannot use native keyset (WHERE pk > ?)
        # pagination reliably. When every DATETIME key column has an
        # order-preserving string cast we chunk by that string instead;
        # otherwise fall back to the blocking consistent snapshot.
        chunk_exprs, viable = self._incremental_datetime_chunk_exprs(table, options)
        if not viable:
            # 236: Informix incremental snapshot for '{}' falling back to the blocking consistent
            # snapshot because a DATETIME, INTERVAL or floating-point primary-key column cannot be
            # chunked by an exact key bound
            logging.getLogger(__name__).info(
                _m(236, table.exposed_name),
            )
            return self._read_snapshot(
                table, None, options, pipeline_scope_override=pipeline_scope_override
            )
        table, schema_id, incremental = self._seed_incremental_block(
            table, pipeline_scope, chunk_exprs, _snapshot_filter(options)
        )
        high_water = int(incremental["boundary_lsn"])
        seed = _offset(
            high_water,
            high_water,
            high_water,
            None,
            "stream",
            table,
            schema_id,
            pipeline_scope,
            incremental=incremental,
        )
        # An empty table needs no chunks; behave as a plain stream from here.
        if incremental["done"]:
            seed.pop("incremental", None)
            return iter(()), seed
        return self._read_incremental_step(table, _validated_offset(seed), options)

    def _seed_incremental_block(
        self,
        table: Table,
        pipeline_scope: str,
        chunk_exprs: dict[str, str],
        snapshot_filter: str | None,
    ) -> tuple[Table, str, dict]:
        # Docstring: Capture a fresh, self-describing incremental snapshot block.
        #
        # The correctness of an incremental copy rests on one ordering: ``max_pk``
        # is read at or after the CDC start LSN. A row above ``max_pk`` is then
        # necessarily inserted later, commits above the start LSN, and so is
        # carried by the change stream that begins there. Reverse the order and
        # rows inserted in between fall above the key bound *and* below the stream
        # start -- owned by neither, and lost silently.
        #
        # Production hit exactly that (tw214): a cancelled update published
        # max_pk=W0056332 at 22:41:58, the restart published a fresh, higher
        # initial_lsn at 22:46:29, and the copy ran with the OLD key bound against
        # the NEW stream start. Four rows inserted in between were never emitted.
        # The bound cannot have been captured fresh -- rows above it already
        # existed when the copy began.
        #
        # ``max_pk`` rides in the Spark checkpoint while the LSN is published
        # durably per scope, so nothing tied the pair together. Stamping the block
        # with the scope that captured it makes the pair checkable wherever it is
        # later resumed; see ``_incremental_bound_is_foreign``.

        high_water = self._initial_lsn(table, scope=pipeline_scope)
        schema_id = self._snapshot_schema_ids[(pipeline_scope, table.identity)]
        table = self._refresh_table_schema(table, _schema_fingerprint(table))
        self._publish_snapshot_boundary(table, schema_id, high_water, high_water, pipeline_scope)
        # Strictly after the boundary above, never before it.
        max_pk = self._snapshot_read_with_reconnect(
            lambda: self._bridge.max_primary_key(
                table.identity,
                list(table.primary_keys),
                chunk_exprs=chunk_exprs or None,
                snapshot_filter=_snapshot_predicate(snapshot_filter, table),
                key_descending=list(table.key_descending),
            ),
            table=table,
            operation="key bound read",
        )
        incremental = {
            "started": True,
            "last_pk": None,
            "max_pk": (None if max_pk is None else _encode_snapshot_stage_value(list(max_pk))),
            "done": max_pk is None,
            "chunk_exprs": chunk_exprs,
            "snapshot_filter": snapshot_filter,
            # Provenance: which scope captured this block, and against which
            # boundary. A resumed block that disagrees with either describes a
            # different copy and cannot be trusted.
            "scope": pipeline_scope,
            "boundary_lsn": str(high_water),
            # The key ordering the cursor and bound were paged in. If the table's
            # key index direction later differs (e.g. an all-ascending checkpoint
            # resumed under mixed-direction paging), the cursor is not comparable
            # across the change and resuming would silently skip rows -- so the
            # copy must restart. See the guard in _next_incremental_chunk.
            "key_descending": [bool(v) for v in table.key_descending],
        }
        return table, schema_id, incremental

    def _rebound_incremental_block(
        self, table: Table, incremental: dict, chunk_exprs: dict[str, str]
    ) -> dict:
        # Docstring: Recapture ``max_pk`` when the block was bounded by another update.
        #
        # The snapshot bound is only sound if it was read at or after the CDC start
        # LSN this update is streaming from: a row above ``max_pk`` then necessarily
        # commits above that LSN, so the change stream carries it. A bound inherited
        # from an earlier update inverts that -- it was read before this update's
        # boundary, so rows inserted in between sit above the key bound and below
        # the stream start, owned by neither side.
        #
        # Production hit exactly that (tw214). A cancelled update bounded the copy
        # at W0056332 at 22:41:58; the restart published a fresh, higher boundary at
        # 22:46:29 and copied with the OLD bound. Four rows inserted in between were
        # never emitted. The bound provably could not have been captured fresh --
        # rows above it already existed when that copy began.
        #
        # Only the bound is recaptured. ``last_pk`` is kept: it names rows this
        # destination still holds, because the framework only discards the offset
        # when it truncates the table, and a discarded offset takes the whole
        # ``incremental`` block with it (start is None, which re-seeds from
        # scratch). Resetting the cursor here would re-read a prefix that is still
        # present -- measured as a 5x throughput drop across restarts -- and protect
        # nothing.

        max_pk = self._snapshot_read_with_reconnect(
            lambda: self._bridge.max_primary_key(
                table.identity,
                list(table.primary_keys),
                chunk_exprs=chunk_exprs or None,
                snapshot_filter=_snapshot_predicate(incremental.get("snapshot_filter"), table),
                key_descending=list(table.key_descending),
            ),
            table=table,
            operation="key bound read",
        )
        rebound = dict(incremental)
        rebound["max_pk"] = None if max_pk is None else _encode_snapshot_stage_value(list(max_pk))
        rebound["scope"] = self._registration_scope
        if max_pk is None:
            # The table is empty as of this boundary; the change stream owns it.
            rebound["done"] = True
        return rebound

    def _incremental_bound_is_foreign(self, incremental: dict) -> bool:
        # Docstring: True when this block's bound was captured by a different update.

        # The reader's own registration, read directly rather than through
        # _pipeline_scope: that helper falls back to the checkpoint's own
        # pipeline_scope field, which _read_stream rewrites to the reading scope
        # on every batch (see end["pipeline_scope"] there). Comparing the stamp
        # against a rewritten field would let a foreign block vouch for itself.
        scope = self._registration_scope
        if scope is None:
            # No registration to compare against, so the stamp cannot be checked.
            return False
        return incremental.get("scope") != scope

    def _read_incremental_step(
        self, table: Table, checkpoint: dict, options: dict[str, str]
    ) -> tuple[Iterator[dict], dict]:
        incremental = dict(checkpoint["incremental"])
        # Stream a bounded batch of committed changes from the current cursor.
        cdc_rows, end = self._read_stream(table, checkpoint, options, deletes=False)
        output = list(cdc_rows)
        # The stream reader may return a freshly built offset that drops the
        # incremental block; the schema it used is authoritative for chunking.
        live = self._refresh_table_schema(table, None)
        if (
            end.get("schema_fingerprint") != _schema_fingerprint(live)
            and self._replay_stop_lsn(options) is None
        ):
            # A step to a generation the live layout has moved past reads nothing under it
            # (see _read_stream), so the copy keeps its cursor until a read reaches the live
            # schema: a chunk read now would land rows under columns that are not current.
            # A replay reads the chunk its batch read, under the live layout, to the cursor
            # Spark logged (none past a metadata-only step, whose cursor did not move).
            return iter(output), _with_backlog_streak(
                {**end, "incremental": incremental}, checkpoint, True
            )
        table = live
        if not incremental["done"]:
            chunk_rows, incremental = self._next_incremental_chunk(table, incremental, options)
            output.extend(chunk_rows)
        if incremental["done"]:
            end.pop("incremental", None)
        else:
            end = dict(end)
            end["incremental"] = incremental
            # An unfinished incremental copy is *exact* proof of outstanding work,
            # stronger than the CDC row-budget signal _read_stream just applied:
            # the chunk cursor has not yet reached the snapshot's upper bound, so
            # rows demonstrably remain. Without this the backlog signal is blind
            # for the whole bulk-copy phase -- which is precisely when a flow has
            # the most to catch up (observed after a full refresh: every reader
            # was in the incremental phase and none recorded a streak).
            #
            # Idempotent with the call inside _read_stream: both derive the new
            # value from ``checkpoint``, not from ``end``.
            end = _with_backlog_streak(end, checkpoint, True)
        return iter(output), end

    def _next_incremental_chunk(
        self, table: Table, incremental: dict, options: dict[str, str]
    ) -> tuple[list[dict[str, Any]], dict]:
        # The cursor and bound were paged in the key ordering recorded at seed
        # time. If the table's key index direction now differs -- e.g. an
        # all-ascending checkpoint resumed under mixed-direction paging, or vice
        # versa -- the persisted cursor is not comparable in the new order, and
        # resuming would silently skip rows. Fail closed: the copy must restart.
        seeded_descending = tuple(bool(v) for v in (incremental.get("key_descending") or ()))
        if seeded_descending != tuple(table.key_descending):
            # 237: Incremental snapshot for '{}' was seeded with a different key ordering than the
            # table's current key index; the paged cursor cannot be compared across the change. Run
            # a full refresh.
            raise InformixError(_m(237, table.exposed_name))
        page_size = self._table_int_option(
            options, "snapshot.page.size", _DEFAULT_SNAPSHOT_PAGE_SIZE, minimum=1
        )
        chunk_exprs = dict(incremental.get("chunk_exprs") or {})
        # Columns chunked by an order-preserving expression are compared and
        # cursored on the rendered "__chunk_<key>" string, not the raw value.
        cursor_names = [
            f"__chunk_{key}" if key in chunk_exprs else key for key in table.primary_keys
        ]
        # The cursor/bound comparisons below must run in the key index's own scan
        # order. For a mixed-direction key that is not Python's all-ascending tuple
        # order, so wrap the DESC columns to flip just those positions. A chunked
        # key compares on the always-ascending "__chunk_" strings, and an
        # all-ascending key is left exactly as before.
        order_desc = () if chunk_exprs else tuple(table.key_descending)

        def order_key(values: Sequence[Any]) -> tuple:
            return _order_key(values, order_desc)

        last_pk = (
            None
            if incremental.get("last_pk") is None
            else _decode_snapshot_stage_value(incremental["last_pk"])
        )
        max_pk = tuple(_decode_snapshot_stage_value(incremental["max_pk"]))
        # The cursor and the bound are compared against keys read from the
        # refreshed table, which _read_incremental_step may have re-read between
        # the CDC read and this chunk. A cursor of the wrong arity would compare
        # mismatched tuples: every value still exists, so rows would be skipped
        # with no error. The blocking path validates this in snapshot_page; do the
        # same here rather than rely on the schema guards upstream.
        if last_pk is not None:
            validate_snapshot_arity(last_pk, table.primary_keys)
        validate_snapshot_arity(max_pk, table.primary_keys)
        # A replay must reproduce the whole committed key range, so it stops at
        # the cursor ``end`` recorded rather than after one page. ``null`` means
        # the copy finished inside that range, which leaves max_pk as the bound.
        replay_stop_pk = self._replay_stop_pk(options, table.primary_keys)
        replaying_chunk = replay_stop_pk is not None
        bound = max_pk
        if replay_stop_pk is not None and replay_stop_pk is not _REPLAY_DRAIN_TO_MAX_PK:
            # min() in the key's own paging order, not Python's default.
            bound = replay_stop_pk if order_key(replay_stop_pk) < order_key(max_pk) else max_pk

        if (
            replaying_chunk
            and last_pk is not None
            and replay_stop_pk is not _REPLAY_DRAIN_TO_MAX_PK
            and order_key(tuple(last_pk)) >= order_key(bound)
        ):
            # A replay already at its committed cursor, as a second poll of a range is,
            # has no chunk rows left to read.
            return [], dict(incremental)

        def cursor_key(row: dict[str, Any]) -> tuple:
            return tuple(row[name] for name in cursor_names)

        chunk_lsn: int | None = None
        bounded: list[dict[str, Any]] = []
        passed_upper_bound = False
        has_more = False
        cursor = last_pk
        # One fetch for an ordinary read. A replay keeps paging until it reaches
        # the committed cursor, because rows inserted into that range since the
        # original read can push it beyond a single page -- and stopping short is
        # the truncation this bound exists to prevent.
        for _ in range(_REPLAY_MAX_CHUNK_FETCHES):
            # Ask for one row more than the page keeps, so "the page filled" and
            # "rows remain" are distinguishable rather than inferred: the same
            # probe the blocking consistent_snapshot loop uses.
            fetch_lsn, raw = self._snapshot_read_with_reconnect(
                lambda cursor=cursor: self._bridge.snapshot_chunk(
                    table.identity,
                    [column.name for column in table.columns],
                    list(table.primary_keys),
                    cursor,
                    page_size + 1,
                    chunk_exprs=chunk_exprs or None,
                    snapshot_filter=_snapshot_predicate(incremental.get("snapshot_filter"), table),
                    key_descending=list(table.key_descending),
                ),
                table=table,
                operation="chunk read",
            )
            try:
                fetch_lsn = _strict_lsn(fetch_lsn, "chunk_lsn")
            except ValueError as error:
                # 238: Incremental snapshot chunk for '{}' returned an invalid LSN
                raise InformixError(_m(238, table.exposed_name)) from error
            # Every row in this batch is stamped with the LSN of the fetch that
            # read it, so a multi-fetch replay keeps each row's own read point.
            if chunk_lsn is None:
                chunk_lsn = fetch_lsn
            has_more = len(raw) > page_size
            # Rows beyond the snapshot's captured upper bound are left to the
            # change stream (maximum-key semantics). A replay's own bound
            # is tracked separately: stopping there says nothing about whether the
            # snapshot is finished.
            page: list[dict[str, Any]] = []
            stopped_at_bound = False
            for row in raw[:page_size]:
                key = cursor_key(row)
                if order_key(key) > order_key(max_pk):
                    passed_upper_bound = True
                    break
                if order_key(key) > order_key(bound):
                    stopped_at_bound = True
                    break
                page.append(row)
            bounded.extend(page)
            if page:
                cursor = cursor_key(page[-1])
            reached_bound = cursor is not None and order_key(cursor) >= order_key(bound)
            if not replaying_chunk or passed_upper_bound or stopped_at_bound:
                break
            if reached_bound or not page or not has_more:
                break
        else:
            # 239: Replayed incremental snapshot range for '{}' did not reach its committed cursor
            # within {} chunk reads
            raise InformixError(_m(239, table.exposed_name, _REPLAY_MAX_CHUNK_FETCHES))
        last_cursor = cursor_key(bounded[-1]) if bounded else None
        to_cursor = replaying_chunk and replay_stop_pk is not _REPLAY_DRAIN_TO_MAX_PK
        if to_cursor:
            # The key-ordered scan went past the replay's bound, reached it, or reached the
            # end of the table: every row of the range that still exists was read. A chunk
            # holds no lock across batches, so the rows at its end may have been deleted
            # since its batch, and the replay stands at the cursor Spark logged regardless.
            last_cursor = bound
        # Strip the "__chunk_<key>" helper aliases before shaping so they never
        # reach the emitted row or the destination schema.
        chunk_aliases = [f"__chunk_{key}" for key in chunk_exprs]
        cleaned = [
            {key: value for key, value in row.items() if key not in chunk_aliases}
            for row in bounded
        ]
        stamp = chunk_lsn if chunk_lsn is not None else 0
        commit_time = self._source_utc_time()
        shaped = [
            _shape_snapshot(row, stamp, table, options, commit_time=commit_time) for row in cleaned
        ]
        result = dict(incremental)
        result["chunk_lsn"] = str(stamp)
        if last_cursor is not None:
            result["last_pk"] = _encode_snapshot_stage_value(list(last_cursor))
        # Only the snapshot's own bound ends the copy. A replay stops at the
        # committed cursor, which normally sits well below max_pk, so treating
        # that stop as completion would abandon the rest of the copy: the flow
        # would leave the incremental phase with most of the table uncopied. A row
        # past max_pk, or the end of the table, says the same only for a replay of
        # the batch that finished the copy, which drains to max_pk as that batch did.
        reached_max_key = last_cursor is not None and order_key(last_cursor) >= order_key(max_pk)
        if to_cursor:
            done = reached_max_key
        else:
            done = passed_upper_bound or not has_more or reached_max_key
        result["done"] = done
        return shaped, result

    @staticmethod
    def _replay_stop_pk(
        options: dict[str, str], primary_keys: tuple[str, ...]
    ) -> object | tuple | None:
        # Docstring: The chunk cursor a replayed read must stop at, or None if unbounded.
        #
        # JSON ``null`` returns a sentinel rather than None: both use max_pk as the
        # numerical bound, but the replay must keep fetching pages until it reaches
        # that bound while an ordinary read intentionally fetches only one page.
        #
        # Validated rather than trusted, for the same reason as the LSN bound: a
        # malformed value would silently widen the replay back to the behaviour
        # being fixed.

        raw = options.get(_REPLAY_STOP_PK_OPTION)
        if raw is None:
            return None
        try:
            decoded = json.loads(raw)
        except ValueError as error:
            # 240: Informix replay stop cursor is not valid JSON
            raise InformixError(_m(240)) from error
        if decoded is None:
            return _REPLAY_DRAIN_TO_MAX_PK
        if not isinstance(decoded, list):
            # 241: Informix replay stop cursor must be a list or null
            raise InformixError(_m(241))
        cursor = _decode_snapshot_stage_value(decoded)
        validate_snapshot_arity(cursor, primary_keys)
        return tuple(cursor)

    def _read_snapshot(
        self,
        table: Table,
        start: dict | None,
        options: dict[str, str],
        *,
        pipeline_scope_override: str | None = None,
        allow_keyless: bool = False,
    ):
        checkpoint = _validated_offset(start) if start else None
        pipeline_scope = pipeline_scope_override or self._pipeline_scope()
        # Hand the bridge the same progress callback the drain worker installed, so a worker
        # blocked acquiring its slot (before any page is staged) can keep the consumer's
        # liveness watchdog alive while the pool is turning over. None for non-drain reads,
        # where slot-wait liveness is off anyway. Constructs the bridge without connecting.
        self._bridge._slot_wait_liveness = self._drain_progress
        if checkpoint and checkpoint.get("schema_fingerprint") is None:
            # 242: Informix snapshot checkpoint for '{}' predates schema-safe offsets; run a full
            # refresh
            raise InformixError(_m(242, table.exposed_name))
        expected_fingerprint = checkpoint.get("schema_fingerprint") if checkpoint else None
        if checkpoint:
            # Staged serve reads immutable, self-describing pages from the Volume, so it
            # needs no live Informix schema. Re-query it only every
            # _snapshot_schema_refresh_interval seconds to catch mid-snapshot drift;
            # between refreshes, validate the pinned fingerprint against the cached table
            # (no connection, no catalog query). The first resume microbatch always
            # refreshes (no timestamp yet), and drift is caught within the interval and at
            # the snapshot->CDC transition -- a change cannot invalidate pages frozen
            # as-of snapshot_lsn, so serving a few extra before an abort is harmless.
            now = time.monotonic()
            last = self._snapshot_schema_refreshed_at.get(table.identity)
            if last is None or now - last >= self._snapshot_schema_refresh_interval:
                table = self._refresh_table_schema(table, expected_fingerprint)
                self._snapshot_schema_refreshed_at[table.identity] = now
            elif expected_fingerprint != _schema_fingerprint(table):
                # 243: Informix schema changed for '{}' during ingestion; run a full refresh before
                # reading additional snapshot or CDC records
                raise InformixError(_m(243, table.exposed_name))
        else:
            table = self._refresh_table_schema(table, expected_fingerprint)
        if not _cdc_capable(table) and not (
            allow_keyless and all(column.cdc_supported for column in table.columns)
        ):
            # 244: Table '{}' is no longer CDC-capable after metadata refresh; run a full refresh
            # after restoring its primary key and supported schema
            raise InformixError(_m(244, table.exposed_name))
        # The key columns the drain pages by: none for a keyless table or a cursor scan,
        # which then reads through one unordered forward-only cursor.
        scan_keys = () if self._snapshot_cursor_scan(options) else table.primary_keys
        if scan_keys:
            page_size = self._table_int_option(
                options, "snapshot.page.size", _DEFAULT_SNAPSHOT_PAGE_SIZE, minimum=1
            )
        else:
            # A keyless initial snapshot pages positionally and stages larger pages by
            # default; its own knob so it never changes keyed keyset chunk sizing. A
            # cursor scan of a keyed table pages the same way, so it shares the knob.
            page_size = self._table_int_option(
                options,
                "keyless.snapshot.page.size",
                _DEFAULT_KEYLESS_SNAPSHOT_PAGE_SIZE,
                minimum=1,
            )
        if checkpoint:
            # Resolve the staging scope from the *checkpoint*, not this update's
            # registration scope. The staged pages and manifest were written under the
            # update scope that created them (``{pipeline_id}_@_{update_id}``), which the
            # checkpoint records; the current registration scope carries a fresh update_id
            # after a stop/start. Locating the pages by their creating scope -- together
            # with the schema_id and snapshot_lsn the checkpoint also pins -- lets a
            # resumed read find them instead of missing the manifest and forcing a full
            # refresh mid-load. Full-refresh semantics are untouched: a full refresh clears
            # the Spark checkpoint, so it arrives with no offset and takes the else branch,
            # where the update-scoped initialization record establishes a fresh boundary
            # and re-snapshots. A legacy offset without a stored scope falls back to the
            # registration scope (the prior behaviour).
            # For a handoff relocation the pages live under the *capturing* flow's scope,
            # carried on stage_scope; the offset's own pipeline_scope is already the new
            # flow's. stage_scope drives the manifest and page reads; pipeline_scope drives
            # the emitted offsets. Absent stage_scope, the two coincide (unchanged).
            pipeline_scope, stage_scope = self._offset_scopes(checkpoint)
            high_water = int(checkpoint["snapshot_lsn"])
            schema_id = str(checkpoint["schema_id"])
            manifest = self._read_snapshot_stage_manifest(table, stage_scope, schema_id)
            if manifest is None:
                if self._table_snapshot_source(options) is not None:
                    # A .unl serve stages no pages: its checkpoint is a split position the
                    # partitioned reader's windows advance, and the simple reader can only
                    # serve an extract whole.
                    # 423: Informix file snapshot of '{}' is part-way through a serve in split
                    # windows, which only stream.partitioned=true can continue; set it back to true
                    # until the snapshot has finished, and no full refresh is needed
                    raise InformixError(_m(423, table.exposed_name))
                # 245: Incremental snapshot state for '{}' is missing; run a full refresh
                raise InformixError(_m(245, table.exposed_name))
            if int(manifest["snapshot_lsn"]) != high_water:
                # 246: Incremental snapshot boundary mismatch for '{}'
                raise InformixError(_m(246, table.exposed_name))
            page_index = int(checkpoint["snapshot"].get("page_index", -1))
            return self._staged_snapshot_result(
                table,
                pipeline_scope,
                schema_id,
                manifest,
                page_index,
                checkpoint,
                stage_scope=stage_scope,
            )
        elif self._table_snapshot_source(options):
            # File source: serve the initial snapshot from Informix UNLOAD (`.unl`) files
            # on a Volume instead of a live scan. Serial driver fallback used when the
            # partitioned reader is off; the partitioned path fans the same splits across
            # executors (see get_partitions/read_partition). Both pin the boundary via
            # _pin_unl_boundary and hand back the shaped rows with a stream-phase offset --
            # the same transition a completed live snapshot makes, so the CDC stream
            # resumes at the boundary and _recover discards anything at/below it. The whole
            # extract serves in one microbatch (rows stream lazily, so driver memory stays
            # bounded); a restart before the offset commits simply replays it (idempotent).
            table, schema_id, snapshot_lsn = self._pin_unl_boundary(table, options, pipeline_scope)
            rows = self._serve_unl_snapshot(table, options, snapshot_lsn)
            return rows, _offset(
                snapshot_lsn,
                snapshot_lsn,
                snapshot_lsn,
                None,
                "stream",
                table,
                schema_id,
                pipeline_scope,
            )
        else:
            consistent_snapshot = getattr(self._bridge, "consistent_snapshot", None)
            if not callable(consistent_snapshot):
                # 247: Configured Informix bridge does not implement consistent_snapshot()
                raise InformixError(_m(247))
            # Validate the complete snapshot contract before _initial_lsn()
            # enables full-row logging or publishes durable initialization.
            high_water = self._initial_lsn(table, scope=pipeline_scope)
            schema_id = self._snapshot_schema_ids[(pipeline_scope, table.identity)]
            manifest = self._read_snapshot_stage_manifest(table, pipeline_scope, schema_id)
            if manifest is not None:
                page_count = int(manifest["page_count"])
                if page_count == 0:
                    snapshot_lsn = int(manifest["snapshot_lsn"])
                    return iter(()), _offset(
                        snapshot_lsn,
                        snapshot_lsn,
                        snapshot_lsn,
                        None,
                        "stream",
                        table,
                        schema_id,
                        pipeline_scope,
                    )
                return self._staged_snapshot_result(table, pipeline_scope, schema_id, manifest, 0)
            if not self._is_snapshot_drain_worker():
                # Hand the long drain to the bounded daemon pool. Free this reader's
                # connection slot first so the wait holds none, then serve the pages the
                # daemon stages -- exactly as a resumed snapshot does. At most
                # ``snapshot.reader.threads`` drains run at once in a process, so streaming
                # readers keep the remaining slots. ``_initial_lsn`` above already established
                # the durable boundary; the daemon reads it rather than redoing it.
                self._release_worker_connection()
                manifest = self._drain_via_snapshot_daemon(
                    table, options, pipeline_scope, schema_id, allow_keyless
                )
                page_count = int(manifest["page_count"])
                if page_count == 0:
                    snapshot_lsn = int(manifest["snapshot_lsn"])
                    return iter(()), _offset(
                        snapshot_lsn,
                        snapshot_lsn,
                        snapshot_lsn,
                        None,
                        "stream",
                        table,
                        schema_id,
                        pipeline_scope,
                    )
                return self._staged_snapshot_result(table, pipeline_scope, schema_id, manifest, 0)
            # A drain worker drains inline below, on the slot floor of its band.
            max_rows = self._table_int_option(options, "snapshot.max.rows", 0, minimum=0)
            expected_columns = {column.name for column in table.columns}
            page_count = 0
            row_count = 0
            shaped_bytes = 0
            previous_upper_pk: list[Any] | None = None
            first_upper_pk: str | None = None
            max_bytes = self._table_int_option(options, "snapshot.max.bytes", 0, minimum=0)
            # Capture the source's UTC time once, at drain start, and bake it into every
            # staged page's `r` rows as their commit time -- so the whole snapshot shares one
            # as-of instant and the served (immutable) pages carry it without re-deriving.
            commit_time = self._source_utc_time()

            def stage_page(
                snapshot_lsn: int,
                page_index: int,
                page_rows: list[dict[str, Any]],
            ) -> None:
                nonlocal page_count, row_count, shaped_bytes, previous_upper_pk, first_upper_pk
                if not page_rows:
                    return
                for index, row in enumerate(page_rows):
                    if not isinstance(row, dict) or set(row) != expected_columns:
                        # 248: Consistent snapshot row {} does not exactly match table columns for
                        # '{}'
                        raise InformixError(_m(248, row_count + index, table.exposed_name))
                try:
                    shaped = [
                        _shape_snapshot(row, snapshot_lsn, table, options, commit_time=commit_time)
                        for row in page_rows
                    ]
                except Exception as error:
                    if isinstance(error, InformixError):
                        raise
                    # 249: Cannot materialize consistent snapshot rows for '{}'
                    raise InformixError(_m(249, table.exposed_name)) from error
                if max_bytes:
                    shaped_bytes += _deep_size(shaped)
                    if shaped_bytes > max_bytes:
                        # 250: Initial shaped snapshot exceeds snapshot.max.bytes={}
                        raise InformixError(_m(250, max_bytes))
                upper_pk = self._publish_snapshot_stage_page(
                    table,
                    pipeline_scope,
                    schema_id,
                    snapshot_lsn,
                    page_index,
                    shaped,
                    previous_upper_pk,
                )
                if page_index == 0:
                    first_upper_pk = json.dumps(upper_pk, allow_nan=False, sort_keys=True)
                previous_upper_pk = [page_rows[-1][key] for key in table.primary_keys]
                page_count = max(page_count, page_index + 1)
                row_count += len(page_rows)
                # A staged page is forward progress: reset the drain pool's liveness
                # watchdog so a large-but-progressing drain is never mistaken for a stall.
                # No-op when no pool set the callback.
                if self._drain_progress is not None:
                    self._drain_progress()

            # A positional REST drain (keyless, or keyed under snapshot.scan=cursor)
            # overlaps the next page fetch with the previous page's shape+upload through
            # a bounded background uploader; the counters stage_page owns are then read
            # only after the pipeline is joined below.
            pipeline = (
                _AsyncStagePipeline(stage_page)
                if self._should_pipeline_staging(scan_keys)
                else None
            )
            page_consumer = pipeline.submit if pipeline is not None else stage_page
            try:
                snapshot_lsn, rows = consistent_snapshot(  # pylint: disable=not-callable
                    table.identity,
                    [c.name for c in table.columns],
                    scan_keys,
                    page_size,
                    max_rows,
                    self._table_int_option(options, "snapshot.max.bytes", 0, minimum=0),
                    datetime_primary_key=any(
                        column.name in scan_keys and column.type_name in _LITERAL_UNSAFE_KEY_TYPES
                        for column in table.columns
                    ),
                    page_consumer=page_consumer,
                    snapshot_filter=_snapshot_predicate(_snapshot_filter(options), table),
                    isolation=self._snapshot_isolation(options),
                )
                if pipeline is not None:
                    # Finish and join every queued upload so page_count/row_count are
                    # complete before the manifest is published, re-raising any error.
                    pipeline.close()
            except BaseException:
                if pipeline is not None:
                    pipeline.shutdown()
                raise
            try:
                snapshot_lsn = _strict_lsn(snapshot_lsn, "snapshot_lsn")
            except ValueError as error:
                # 251: Consistent snapshot bridge returned an invalid snapshot LSN
                raise InformixError(_m(251)) from error
            if snapshot_lsn < high_water:
                # 252: Consistent snapshot LSN {} precedes prepared LSN {} for '{}'
                raise InformixError(_m(252, snapshot_lsn, high_water, table.exposed_name))
            try:
                current_lsn = _strict_lsn(self._bridge.current_lsn(), "current_lsn")
            except ValueError as error:
                # 253: Informix bridge returned an invalid current source LSN
                raise InformixError(_m(253)) from error
            if snapshot_lsn > current_lsn:
                # 254: Consistent snapshot LSN {} exceeds current source LSN {} for '{}'
                raise InformixError(_m(254, snapshot_lsn, current_lsn, table.exposed_name))
            if not isinstance(rows, list):
                # 255: Consistent snapshot bridge must return rows as a list
                raise InformixError(_m(255))
            if max_rows and len(rows) > max_rows:
                # 52: Initial snapshot exceeds snapshot.max.rows={}
                raise InformixError(_m(52, max_rows))
            if rows:
                if page_count:
                    # 256: Consistent snapshot bridge returned rows after consuming pages
                    raise InformixError(_m(256))
                stage_page(snapshot_lsn, 0, rows)
            retained_bytes = _deep_size(rows) if max_bytes else 0
            if max_bytes and retained_bytes > max_bytes:
                # 53: Initial snapshot exceeds snapshot.max.bytes={}
                raise InformixError(_m(53, max_bytes))
            table = self._refresh_table_schema(table, _schema_fingerprint(table))
            self._publish_snapshot_boundary(
                table, schema_id, high_water, snapshot_lsn, pipeline_scope
            )
            manifest = self._publish_snapshot_stage_manifest(
                table,
                pipeline_scope,
                schema_id,
                snapshot_lsn,
                page_count,
                row_count,
                first_upper_pk,
            )
            if page_count == 0:
                return iter(()), _offset(
                    snapshot_lsn,
                    snapshot_lsn,
                    snapshot_lsn,
                    None,
                    "stream",
                    table,
                    schema_id,
                    pipeline_scope,
                )
            return self._staged_snapshot_result(table, pipeline_scope, schema_id, manifest, 0)

    @staticmethod
    def _validate_unl_source_options(options: dict[str, str]) -> None:
        # Docstring: Eagerly validate the connection-level `.unl` source options (per-table too).

        if _SNAPSHOT_SOURCE_OPTION in options and not str(options[_SNAPSHOT_SOURCE_OPTION]).strip():
            # 257: Option '{}' must be a non-empty path
            raise ValueError(_m(257, _SNAPSHOT_SOURCE_OPTION))
        if _SNAPSHOT_BOUNDARY_LSN_OPTION in options:
            raw = str(options[_SNAPSHOT_BOUNDARY_LSN_OPTION]).strip()
            if not raw or not raw.isdigit():
                # 258: Option '{}' must be a non-negative integer
                raise ValueError(_m(258, _SNAPSHOT_BOUNDARY_LSN_OPTION))

    def _table_snapshot_source(self, table_options: dict[str, str]) -> str | None:
        # Docstring: The table's ``snapshot.source`` Volume path (table option, then connection).

        value = table_options.get(_SNAPSHOT_SOURCE_OPTION) or self.options.get(
            _SNAPSHOT_SOURCE_OPTION
        )
        value = str(value).strip() if value is not None else ""
        return value or None

    def _source_utc_time(self) -> int | None:
        # Docstring: Best-effort source-server UTC epoch seconds for a snapshot row's commit time.
        #
        # Captured at the snapshot's boundary/LSN capture so ``r`` rows carry the snapshot's
        # as-of time (``<=`` every later CDC commit time, keeping the column monotonic across
        # the snapshot->CDC handoff). Returns None -- a NULL commit time -- if the bridge does
        # not implement it or the source cannot answer, so a snapshot never fails over a time.

        getter = getattr(self._bridge, "current_utc_time", None)
        if getter is None:
            return None
        try:
            value = getter()  # pylint: disable=not-callable
        except Exception:
            return None
        return int(value) if value is not None else None

    def _unl_field_format(self, table_options: dict[str, str]) -> tuple[str, str]:
        # Docstring: The ``(delimiter, escape)`` for a `.unl`/HPL DELIMITED serve.
        #
        # Resolved table option, then connection, then the UNLOAD defaults (``|``/backslash),
        # so a plain UNLOAD extract needs no options and an HPL extract sets only what differs.
        # Both are validated to a single character (empty escape allowed = escaping disabled),
        # and the two must differ.

        delimiter = _unl_char(
            table_options.get(
                _UNL_DELIMITER_OPTION,
                self.options.get(_UNL_DELIMITER_OPTION, _UNL_DEFAULT_DELIMITER),
            ),
            _UNL_DELIMITER_OPTION,
            allow_empty=False,
        )
        escape = _unl_char(
            table_options.get(
                _UNL_ESCAPE_OPTION,
                self.options.get(_UNL_ESCAPE_OPTION, _UNL_DEFAULT_ESCAPE),
            ),
            _UNL_ESCAPE_OPTION,
            allow_empty=True,
        )
        if escape and escape == delimiter:
            # 259: Options '{}' and '{}' must differ
            raise ValueError(_m(259, _UNL_DELIMITER_OPTION, _UNL_ESCAPE_OPTION))
        return delimiter, escape

    def _unl_snapshot_serve(self, table_options: dict[str, str], effective_start: dict) -> bool:
        # Docstring: Whether this read belongs to a file-source initial snapshot's split serve.
        #
        # The single gate the partitioned ``latest_offset``/``get_partitions`` branches
        # share: a non-delete flow, ``snapshot.source`` set, and ``snapshot.mode=initial``
        # (the only mode that routes to the file serve, keyed or keyless-append). It fires
        # on the first read (no committed offset) and on every continuation microbatch (a
        # snapshot-phase offset), so the serve fans out ``stream.partitioned.snapshot.pages.
        # per.batch`` splits at a time until the boundary offset transitions to the stream
        # phase; after that ``effective_start`` is a stream offset and every later read
        # takes the ordinary CDC path. A ``.unl`` table never stages pages, so a
        # snapshot-phase offset here is always a ``.unl`` split window (never a staged page).

        if self._is_delete_flow() or self._table_migration(table_options):
            # A cutover seeds from the parked token, never from the extract.
            return False
        if self._table_snapshot_source(table_options) is None:
            return False
        if not effective_start:
            return self._snapshot_mode(table_options) == "initial"
        # A serve part-way through finishes as a staged one does, whatever snapshot.mode
        # says now: the mode chooses how a snapshot starts.
        return effective_start.get("phase") == "snapshot"

    def _list_unl_files(self, source: str, exposed_name: str) -> list[str]:
        # Docstring: Sorted `.unl`/`.unl.gz` files under ``source`` (listing/stat only -- no content
        # read).
        #
        # Both plain and gzip-compressed extracts are listed; whether a given file is gzip is
        # decided per file by its magic bytes at read time (see :func:`_unl_file_is_gzip`), not
        # by its name, so a mislabelled file is still handled correctly.

        try:
            names = sorted(
                name for name in os.listdir(source) if name.endswith((".unl", ".unl.gz"))
            )
        except OSError as error:
            if _dropped_mount_error(error) is not None:
                raise  # unwrapped, so a read's dropped-mount retry sees it
            # 260: snapshot.source '{}' for '{}' is not readable
            raise InformixError(_m(260, source, exposed_name)) from error
        files = [
            os.path.join(source, name)
            for name in names
            if os.path.isfile(os.path.join(source, name))
        ]
        if not files:
            # 261: snapshot.source '{}' for '{}' contains no .unl files
            raise InformixError(_m(261, source, exposed_name))
        return files

    def _unl_read_chunk(self, path: str) -> Callable[[int, int], bytes]:
        # Docstring: A ``(offset, length) -> bytes`` range reader for one `.unl` file.
        #
        # Prefers the Files REST API (ranged GET, 206) when a staging token can be
        # minted -- the whole point, since serverless FUSE caches an entire file to
        # local disk on first access, fatal for a large `.unl`. Falls back to a local
        # seek/read when REST is unavailable (offline tests, or a workspace that forbids
        # token minting), mirroring ``snapshot.staging.transport=auto`` for writes, and
        # after a 401 nothing could recover. The transport is consulted on every read, so
        # once it has moved to FUSE the reads still to come go there directly.

        def local(offset: int, length: int) -> bytes:
            with open(path, "rb") as handle:
                handle.seek(offset)
                return handle.read(length)

        def read(offset: int, length: int) -> bytes:
            files_api = self._staging_transport()
            if files_api is not None:
                try:
                    return files_api.get_range(path, offset, offset + length)
                except WorkspaceHttpError as error:
                    if not self._staging_fell_back(error):
                        raise
            return local(offset, length)

        return read

    def _resolve_unl_boundary_lsn(self, table_options: dict[str, str], source: str) -> int | None:
        # Docstring: Resolve the operator-supplied boundary LSN, or None to self-pin.
        #
        # Order (first hit wins): the ``snapshot.boundary.lsn`` table option (table
        # options first, connection fallback -- same shape as :meth:`_table_snapshot_source`),
        # then ``_manifest.json`` in the source directory (``{"boundary_lsn": "<X>"}``).
        # Fails closed on a non-integer value in either place.

        raw = table_options.get(_SNAPSHOT_BOUNDARY_LSN_OPTION) or self.options.get(
            _SNAPSHOT_BOUNDARY_LSN_OPTION
        )
        if raw is not None and str(raw).strip():
            try:
                return _strict_lsn(str(raw).strip(), _SNAPSHOT_BOUNDARY_LSN_OPTION)
            except ValueError as error:
                raise InformixError(str(error)) from error
        manifest = self._read_unl_manifest(source)
        if manifest is None or manifest.get("boundary_lsn") is None:
            return None
        try:
            return _strict_lsn(manifest["boundary_lsn"], f"{_SNAPSHOT_MANIFEST_NAME} boundary_lsn")
        except ValueError as error:
            raise InformixError(str(error)) from error

    def _resolve_unl_commit_time(self, source: str) -> int | None:
        # Docstring: The `.unl` extract's snapshot commit time (UTC epoch seconds) for its ``r``
        # rows.
        #
        # Read from the optional ``_manifest.json`` ``boundary_time`` the extract records
        # beside ``boundary_lsn`` -- the wall-clock instant the extract reflects. A file-source
        # snapshot has no live boundary to query, so absent a manifest time these rows carry
        # NULL rather than a fabricated time (which would break the monotonic-handoff
        # guarantee that snapshot commit time is ``<=`` every later CDC commit time). Fails
        # closed on a present-but-invalid value.

        manifest = self._read_unl_manifest(source)
        if manifest is None or manifest.get("boundary_time") is None:
            return None
        try:
            value = int(manifest["boundary_time"])
        except (TypeError, ValueError) as error:
            # 262: snapshot.source '{}' has a non-integer {} boundary_time
            raise InformixError(_m(262, source, _SNAPSHOT_MANIFEST_NAME)) from error
        if value < 0:
            # 263: snapshot.source '{}' has a negative {} boundary_time
            raise InformixError(_m(263, source, _SNAPSHOT_MANIFEST_NAME))
        return value

    def _read_unl_manifest(self, source: str) -> dict | None:
        # Docstring: Read ``<source>/_manifest.json`` (small file, whole), or None if absent.
        #
        # Uses the Files REST API when a staging token is available (a 404 means absent),
        # else, or after a 401 nothing could recover, a local read (a missing file means
        # absent). A present-but-malformed manifest fails closed.

        path = os.path.join(source, _SNAPSHOT_MANIFEST_NAME)
        files_api = self._staging_transport()
        data = None
        try:
            if files_api is not None:
                try:
                    data = files_api.get(path)
                except WorkspaceHttpError as error:
                    if not self._staging_fell_back(error):
                        raise
            if data is None:
                with open(path, "rb") as handle:
                    data = handle.read()
        except FileNotFoundError:
            return None
        except WorkspaceHttpError as error:
            if getattr(error, "status_code", None) == 404:
                return None
            raise
        try:
            parsed = json.loads(data.decode("utf-8"))
        except (ValueError, UnicodeDecodeError) as error:
            # 264: snapshot.source '{}' has an unreadable {}
            raise InformixError(_m(264, source, _SNAPSHOT_MANIFEST_NAME)) from error
        return parsed if isinstance(parsed, dict) else None

    def _publish_unl_initialization(self, table: Table, scope: str, boundary: int) -> str:
        # Docstring: Publish the durable initialization record at an operator-supplied ``boundary``.
        #
        # A variant of the owner path in :meth:`_shared_table_lsn` that pins ``initial_lsn``
        # to the operator's LSN (X) rather than the connector's freshly-captured
        # registration LSN -- X is authoritative, so the schema node's ``start_lsn`` and
        # the init record's ``initial_lsn`` are both X. Full-row logging is still enabled
        # (idempotent) and the boundary validated at X. Election makes it idempotent: a
        # re-call with the same X adopts the same winner; a table already initialized at a
        # different LSN loses the election and fails closed (run a full refresh).

        capture = _capture_descriptor(table, _client_encoding(self.options))
        self._bridge.prepare_initial_capture([table.native_identity])
        self._bridge.validate_initial_lsn(capture, boundary)
        node = _schema_state(table, boundary)
        winner = self._publish_immutable_head(
            self._immutable_namespace(table, "initialization", scope),
            {
                "created_at": time.time(),
                "initial_lsn": str(boundary),
                "schema": node,
                "scope": scope,
                "table": table.native_identity,
            },
            record_type="initialization",
        )
        self._validate_immutable_record_header(winner, "initialization", table.exposed_name)
        if (
            self._immutable_lsn(winner, "initial_lsn", table.exposed_name) != boundary
            or winner.get("scope") != scope
            or winner.get("table") != table.native_identity
        ):
            # 265: Conflicting Informix initialization boundary for '{}': the table was already
            # initialized at a different LSN; run a full refresh
            raise InformixError(_m(265, table.exposed_name))
        schema = winner.get("schema")
        if not isinstance(schema, dict) or not re.fullmatch(r"[0-9a-f]{32}", str(schema.get("id"))):
            # 316: Invalid Informix immutable initialization schema
            raise InformixError(_m(316))
        if (
            schema.get("fingerprint") != _schema_fingerprint(table)
            or schema.get("predecessor") is not None
            or self._immutable_lsn(schema, "start_lsn", table.exposed_name) != boundary
            or _table_from_schema_state(schema, table.database).native_identity
            != table.native_identity
        ):
            # 316: Invalid Informix immutable initialization schema
            raise InformixError(_m(316))
        # The node every later schema step and delete seed starts from, as a self-pinned
        # initialization records it.
        schema_winner = self._publish_immutable_head(
            self._immutable_namespace(table, "schema-nodes", str(schema["id"])),
            {"created_at": winner.get("created_at", time.time()), "schema": schema},
            record_type="schema-node",
        )
        self._validate_schema_node_winner(schema_winner, schema, table)
        return str(schema["id"])

    def _pin_unl_boundary(
        self, table: Table, options: dict[str, str], pipeline_scope: str
    ) -> tuple[Table, str, int]:
        # Docstring: Pin and durably publish the file-source snapshot boundary; idempotent.
        #
        # With an operator-supplied boundary (``snapshot.boundary.lsn`` or ``_manifest.json``,
        # see :meth:`_resolve_unl_boundary_lsn`) the LSN X is authoritative: guard
        # ``minimum_lsn() <= X <= current_lsn()`` (below min = the logical log recycled past
        # X -> gap; above current = bogus), then publish the initialization + snapshot
        # boundary at ``initial_lsn == snapshot_lsn == X`` so the CDC stream and the
        # delete-channel bootstrap both start at X. Otherwise self-pin via ``_initial_lsn``
        # (the connector's registration LSN, cached -> stable across re-calls). Either way
        # the durable records are elected/immutable, so a speculative ``latest_offset``
        # re-call is idempotent.

        boundary = self._resolve_unl_boundary_lsn(options, self._table_snapshot_source(options))
        if boundary is None:
            high_water = self._initial_lsn(table, scope=pipeline_scope)
            schema_id = self._snapshot_schema_ids[(pipeline_scope, table.identity)]
            table = self._refresh_table_schema(table, _schema_fingerprint(table))
            self._publish_snapshot_boundary(
                table, schema_id, high_water, high_water, pipeline_scope
            )
            self._pin_unl_extract(table, options, pipeline_scope, schema_id, high_water)
            return table, schema_id, high_water
        minimum = self._bridge.minimum_lsn()
        current = self._bridge.current_lsn()
        if not minimum <= boundary <= current:
            # 266: {}={} for '{}' is outside the retained/current log range [{}, {}]: below the
            # minimum means the logical log recycled past it (gap); above current is invalid.
            # Re-extract at a retained position.
            raise InformixError(
                _m(
                    266,
                    _SNAPSHOT_BOUNDARY_LSN_OPTION,
                    boundary,
                    table.exposed_name,
                    minimum,
                    current,
                )
            )
        table = self._refresh_table_schema(table, _schema_fingerprint(table))
        schema_id = self._publish_unl_initialization(table, pipeline_scope, boundary)
        self._publish_snapshot_boundary(table, schema_id, boundary, boundary, pipeline_scope)
        self._pin_unl_extract(table, options, pipeline_scope, schema_id, boundary)
        return table, schema_id, boundary

    def _unl_extract_namespace(self, table: Table, pipeline_scope: str, schema_id: str) -> str:
        return self._immutable_namespace(table, "unl-extract", pipeline_scope, schema_id)

    def _unl_extract_files(self, table: Table, table_options: dict[str, str]) -> list[dict]:
        # Docstring: The extract's files as they are now: name, path, size and modification time.

        source = self._table_snapshot_source(table_options)
        entries = []
        for path in self._list_unl_files(source, table.exposed_name):
            info = os.stat(path)
            entries.append(
                {
                    "name": os.path.basename(path),
                    "path": path,
                    "size": int(info.st_size),
                    "mtime": float(info.st_mtime),
                    "mtime_ns": int(info.st_mtime_ns),
                }
            )
        return entries

    def _unl_fingerprint(self, entry: dict) -> str:
        # Docstring: SHA-256 of a file's size with its first and last sample bytes; cached per
        # version.

        key = (entry["path"], entry["size"], entry["mtime_ns"])
        cached = self._unl_fingerprint_cache.get(key)
        if cached is not None:
            return cached
        size = entry["size"]
        sample = _UNL_FINGERPRINT_SAMPLE_BYTES
        digest = hashlib.sha256(f"{size}\0".encode())
        if size:
            read_chunk = self._unl_read_chunk(entry["path"])
            if size <= 2 * sample:
                digest.update(read_chunk(0, size))
            else:
                digest.update(read_chunk(0, sample))
                digest.update(read_chunk(size - sample, sample))
        value = digest.hexdigest()
        self._unl_fingerprint_cache[key] = value
        return value

    def _pin_unl_extract(
        self,
        table: Table,
        table_options: dict[str, str],
        pipeline_scope: str,
        schema_id: str,
        snapshot_lsn: int,
    ) -> None:
        # Docstring: Pin the extract's manifest with the snapshot boundary; idempotent.
        #
        # The record is elected, so a retried first read compares the directory with the
        # manifest the snapshot actually started from rather than re-pinning it.

        entries = self._unl_extract_files(table, table_options)
        winner = self._publish_immutable_head(
            self._unl_extract_namespace(table, pipeline_scope, schema_id),
            {
                "created_at": time.time(),
                "scope": pipeline_scope,
                "schema_id": schema_id,
                "snapshot_lsn": str(snapshot_lsn),
                "files": [
                    {
                        "name": entry["name"],
                        "size": entry["size"],
                        "mtime": entry["mtime"],
                        "fingerprint": self._unl_fingerprint(entry),
                    }
                    for entry in entries
                ],
            },
            record_type="unl-extract",
        )
        self._validate_immutable_record_header(winner, "unl-extract", table.exposed_name)
        self._compare_unl_extract(table, winner, entries, fingerprint_paths=None)

    def _verify_unl_extract(
        self,
        table: Table,
        table_options: dict[str, str],
        pipeline_scope: str,
        schema_id: str,
        snapshot_lsn: int,
        read_paths: Iterable[str],
    ) -> None:
        # Docstring: Fail closed when the extract no longer matches the manifest its snapshot
        # pinned.
        #
        # Checks every file's name, size and modification time, and the fingerprint of each
        # file in ``read_paths`` -- the ones this read will serve. A snapshot that began
        # before manifests existed pins one now, which guards the rest of its serve.

        record = self._read_immutable_head(
            self._unl_extract_namespace(table, pipeline_scope, schema_id)
        )
        if record is None:
            # 267: Informix file snapshot for '{}' has no pinned extract manifest; pinning the
            # extract as it is now
            logging.getLogger(__name__).info(
                _m(267, table.exposed_name),
            )
            self._pin_unl_extract(table, table_options, pipeline_scope, schema_id, snapshot_lsn)
            return
        self._validate_immutable_record_header(record, "unl-extract", table.exposed_name)
        entries = self._unl_extract_files(table, table_options)
        self._compare_unl_extract(table, record, entries, fingerprint_paths=set(read_paths))

    def _compare_unl_extract(
        self,
        table: Table,
        record: dict,
        entries: list[dict],
        *,
        fingerprint_paths: set[str] | None,
    ) -> None:
        # Docstring: Raise if ``entries`` differ from the pinned manifest ``record``.
        #
        # ``fingerprint_paths`` limits the content check to those files; None checks all.

        pinned = record.get("files")
        if not isinstance(pinned, list) or not all(isinstance(item, dict) for item in pinned):
            # 268: Invalid pinned extract manifest for '{}'; run a full refresh
            raise InformixError(_m(268, table.exposed_name))
        pinned_names = [str(item.get("name")) for item in pinned]
        current_names = [entry["name"] for entry in entries]
        problem = None
        if pinned_names != current_names:
            added = sorted(set(current_names) - set(pinned_names))
            removed = sorted(set(pinned_names) - set(current_names))
            problem = "; ".join(
                part
                for part in (
                    f"added {', '.join(added)}" if added else "",
                    f"removed {', '.join(removed)}" if removed else "",
                )
                if part
            )
        else:
            for item, entry in zip(pinned, entries):
                name = entry["name"]
                if int(item.get("size", -1)) != entry["size"]:
                    problem = (
                        f"{name} changed size from {item.get('size')} to {entry['size']} bytes"
                    )
                elif (
                    abs(float(item.get("mtime", 0.0)) - entry["mtime"])
                    > _UNL_MTIME_TOLERANCE_SECONDS
                ):
                    problem = f"{name} has a different modification time"
                elif (
                    fingerprint_paths is None or entry["path"] in fingerprint_paths
                ) and self._unl_fingerprint(entry) != item.get("fingerprint"):
                    problem = f"{name} has different content"
                if problem:
                    break
        if problem:
            # 269: The {} extract for '{}' changed after its snapshot started ({}), so resuming
            # would skip or repeat rows. Run a full refresh to ingest the current extract, or
            # restore the original files with their modification times.
            raise InformixError(_m(269, _SNAPSHOT_SOURCE_OPTION, table.exposed_name, problem))

    def _unl_snapshot_offset(
        self, table: Table, table_options: dict[str, str], effective_start: dict
    ) -> tuple[dict, list[dict[str, Any]] | None]:
        # Docstring: End offset for one windowed ``.unl`` snapshot microbatch, plus any driver rows.
        #
        # On the first read (empty start) the boundary is pinned durably and idempotently
        # (see :meth:`_pin_unl_boundary`) and the serve begins at split 0; on a continuation
        # the boundary/schema come from the checkpoint and the serve resumes at the recorded
        # split index (and, inside a gzip file served in record windows, its record index).
        # An executor window advances by up to ``stream.partitioned.snapshot.pages.per.batch``
        # splits, stopping early before a gzip split that ``snapshot.gzip.records.per.batch``
        # serves in record windows. Such a window is read here on the driver -- its rows are
        # returned so latest_offset can cache them -- and advances by up to that many records,
        # moving to the next split once the file is exhausted. A non-terminal microbatch
        # returns a snapshot-phase offset (so the serve is resumable mid-snapshot), and the
        # microbatch that finishes the last split transitions to the stream phase at the
        # boundary -- where the CDC stream resumes and ``_recover`` discards everything at or
        # below it. The schema fingerprint is carried forward from the checkpoint on a
        # continuation (the extract is frozen as of the boundary; drift is still caught at the
        # snapshot->CDC transition by ``_read_stream``), matching the staged-page serve. An
        # empty extract transitions to the stream phase immediately.

        if not effective_start:
            pipeline_scope = pin_scope = self._pipeline_scope()
            table, schema_id, snapshot_lsn = self._pin_unl_boundary(
                table, table_options, pipeline_scope
            )
            start_split, start_record = 0, 0
            expected_fingerprint = None
        else:
            checkpoint = _validated_offset(effective_start)
            # The serve keeps the scopes it started under, as a staged one does: its extract
            # pin lives there, and in a later update the registration scope has none, which
            # would re-pin whatever files are there now instead of failing on a change.
            pipeline_scope, pin_scope = self._offset_scopes(checkpoint)
            schema_id = str(checkpoint["schema_id"])
            snapshot_lsn = int(checkpoint["snapshot_lsn"])
            start_split, start_record = _unl_position(checkpoint)
            expected_fingerprint = checkpoint.get("schema_fingerprint")
        splits = self._unl_all_splits(table, table_options)
        total = len(splits)
        window_rows: list[dict[str, Any]] | None = None
        driver_window = self._unl_gzip_driver_window(
            table_options, splits, start_split, start_record
        )
        if effective_start:
            # The first read just pinned the manifest; a continuation checks the extract
            # still matches it before serving anything more.
            self._verify_unl_extract(
                table,
                table_options,
                pin_scope,
                schema_id,
                snapshot_lsn,
                self._unl_window_paths(table_options, splits, start_split, driver_window),
            )
        if driver_window:
            limit = self._table_int_option(table_options, _UNL_GZIP_RECORDS_OPTION, 0, minimum=0)
            window_rows, exhausted, read = self._read_unl_gzip_window(
                table,
                table_options,
                snapshot_lsn,
                splits[start_split],
                start_record,
                limit or None,
            )
            if exhausted:
                end_split, end_record = start_split + 1, 0
            else:
                end_split, end_record = start_split, start_record + read
        else:
            end_split = self._unl_executor_window_end(table_options, splits, start_split)
            end_record = 0
        if end_split >= total:
            # Last window (or empty extract): the snapshot is complete -> transition to the
            # stream phase at the boundary, an ordinary stream offset from here on.
            end = _offset(
                snapshot_lsn,
                snapshot_lsn,
                snapshot_lsn,
                None,
                "stream",
                table,
                schema_id,
                pipeline_scope,
            )
            if expected_fingerprint is not None:
                end["schema_fingerprint"] = expected_fingerprint
            return end, window_rows
        end = _offset(
            snapshot_lsn,
            snapshot_lsn,
            snapshot_lsn,
            None,
            "snapshot",
            table,
            schema_id,
            pipeline_scope,
        )
        if expected_fingerprint is not None:
            end["schema_fingerprint"] = expected_fingerprint
        # No PK cursor for byte splits: page_index is the split index; last_pk is an unused
        # placeholder that satisfies the snapshot-offset schema. record_index, present only
        # inside a gzip file served in record windows, counts that file's records done.
        snapshot: dict[str, Any] = {"last_pk": [], "page_index": end_split}
        if end_record:
            snapshot["record_index"] = end_record
        end.update({"snapshot_lsn": str(snapshot_lsn), "snapshot": snapshot})
        if pin_scope != pipeline_scope:
            end["stage_scope"] = pin_scope
        return end, window_rows

    def _unl_executor_window_end(
        self,
        table_options: dict[str, str],
        splits: list[tuple[str, int, int, bool]],
        start_split: int,
    ) -> int:
        # Docstring: End split of an executor window: up to pages-per-batch splits, stopping before
        # a
        # gzip split that ``snapshot.gzip.records.per.batch`` serves on the driver.

        end_split = min(start_split + self._partitioned_pages_per_batch(), len(splits))
        if self._table_int_option(table_options, _UNL_GZIP_RECORDS_OPTION, 0, minimum=0):
            end_split = next(
                (index for index in range(start_split + 1, end_split) if splits[index][3]),
                end_split,
            )
        return end_split

    def _unl_window_paths(
        self,
        table_options: dict[str, str],
        splits: list[tuple[str, int, int, bool]],
        start_split: int,
        driver_window: bool,
    ) -> set[str]:
        # Docstring: The files the window starting at ``start_split`` will read.

        if start_split >= len(splits):
            return set()
        if driver_window:
            return {splits[start_split][0]}
        end_split = self._unl_executor_window_end(table_options, splits, start_split)
        return {split[0] for split in splits[start_split:end_split]}

    def _unl_gzip_driver_window(
        self,
        table_options: dict[str, str],
        splits: list[tuple[str, int, int, bool]],
        start_split: int,
        start_record: int,
    ) -> bool:
        # Docstring: Whether the window starting at ``start_split`` is a driver-read gzip record
        # window.
        #
        # True for a gzip split when ``snapshot.gzip.records.per.batch`` is set, and also for
        # one already part-served (``start_record`` > 0) after the option was cleared, so that
        # file finishes from its recorded position instead of being re-read whole.

        if start_split >= len(splits) or not splits[start_split][3]:
            if start_record:
                # 270: File snapshot offset records a record index for a split that is not a gzip
                # file; the extract changed under a running snapshot -- run a full refresh
                raise InformixError(_m(270))
            return False
        if start_record:
            return True
        return bool(self._table_int_option(table_options, _UNL_GZIP_RECORDS_OPTION, 0, minimum=0))

    def _read_unl_gzip_window(
        self,
        table: Table,
        table_options: dict[str, str],
        snapshot_lsn: int,
        split: tuple[str, int, int, bool],
        start_record: int,
        limit: int | None,
    ) -> tuple[list[dict[str, Any]], bool, int]:
        # Docstring: Read up to ``limit`` records (None: the rest) of a gzip split from
        # ``start_record``.
        #
        # Returns the shaped rows, whether the file is now exhausted -- a short window, or
        # an empty one when the previous window ended exactly at the last record -- and how
        # many records the window read. That count, not the rows, positions the next window:
        # a row_filter can drop records, so a window may hold fewer rows than it read. The open
        # record iterator is kept between microbatches, so consecutive windows decompress the
        # file once; a window that does not continue it (a restart, or a different file)
        # reopens the file and skips ``start_record`` records. A repeated request for the
        # window just read returns the same rows without touching the iterator.

        path, _start_byte, size, _is_gzip = split
        key = (path, size, snapshot_lsn)
        memo_key = (key, start_record, limit)
        memo = self._unl_gzip_window_memo
        if memo is not None and memo[0] == memo_key:
            return memo[1]
        reader = self._unl_gzip_reader
        if reader is None or reader[0] != key or reader[1] != start_record:
            self._unl_gzip_reader = None
            records = self._open_unl_gzip_records(path, size, table_options)
            skipped = sum(1 for _ in itertools.islice(records, start_record))
            if skipped != start_record:
                # 271: gzip snapshot file {} for '{}' holds {} records, fewer than the {} the
                # checkpoint has served; the extract changed under a running snapshot -- run a full
                # refresh
                raise InformixError(_m(271, path, table.exposed_name, skipped, start_record))
            reader = [key, start_record, records]
        try:
            raw_records = list(itertools.islice(reader[2], limit) if limit else reader[2])
        except BaseException:
            self._unl_gzip_reader = None
            raise
        exhausted = limit is None or len(raw_records) < limit
        rows = self._shape_unl_records(table, table_options, snapshot_lsn, raw_records)
        reader[1] = start_record + len(raw_records)
        self._unl_gzip_reader = None if exhausted else reader
        result = (rows, exhausted, len(raw_records))
        self._unl_gzip_window_memo = (memo_key, result)
        return result

    def _replay_unl_gzip_window(
        self,
        table: Table,
        table_options: dict[str, str],
        snapshot_lsn: int,
        split: tuple[str, int, int, bool],
        start_record: int,
        *,
        stop_record: int | None,
    ) -> list[dict[str, Any]]:
        # Docstring: Recompute a logged gzip record window: records ``[start_record, stop_record)``.
        #
        # ``stop_record`` None means the window ran to the end of the file. The logged end is
        # what Spark commits, so a shortfall (the file holds fewer records than the window
        # claimed) fails closed rather than silently dropping rows.

        limit = None if stop_record is None else stop_record - start_record
        if limit is not None and limit <= 0:
            return []
        rows, _exhausted, read = self._read_unl_gzip_window(
            table, table_options, snapshot_lsn, split, start_record, limit
        )
        if limit is not None and read != limit:
            # 272: gzip snapshot file {} for '{}' ended after {} records, short of the {} the logged
            # microbatch covers; the extract changed under a running snapshot -- run a full refresh
            raise InformixError(
                _m(272, split[0], table.exposed_name, start_record + read, stop_record)
            )
        return rows

    def _open_unl_gzip_records(
        self, path: str, size: int, table_options: dict[str, str]
    ) -> Iterator[bytes]:
        # Docstring: A fresh raw-record iterator over a whole gzip `.unl.gz` file, from its start.

        _delimiter, escape = self._unl_field_format(table_options)
        escape_byte = _unl_escape_byte(escape, _client_encoding(self.options))
        return _iter_gzip_unl_records(self._unl_read_chunk(path), size, escape=escape_byte)

    def _shape_unl_records(
        self,
        table: Table,
        table_options: dict[str, str],
        snapshot_lsn: int,
        raw_records: list[bytes],
    ) -> list[dict[str, Any]]:
        # Docstring: Shape raw `.unl` records exactly as the serial and executor serves do.

        encoding = _client_encoding(self.options)
        delimiter, escape = self._unl_field_format(table_options)
        commit_time = self._resolve_unl_commit_time(
            self._table_snapshot_source(table_options) or ""
        )
        predicate = _row_filter_predicate(table, self._source_encoding(table_options))
        shaped = (
            _shape_unl_record(
                raw,
                table,
                snapshot_lsn,
                table_options,
                encoding,
                delimiter=delimiter,
                escape=escape,
                commit_time=commit_time,
                predicate=predicate,
                null_byte=_null_byte_mode(self.options),
            )
            for raw in raw_records
        )
        return [row for row in shaped if row is not None]

    def _serve_unl_snapshot(
        self, table: Table, options: dict[str, str], snapshot_lsn: int
    ) -> Iterator[dict[str, Any]]:
        # Docstring: Lazily yield shaped rows read from the table's `.unl` files (serial driver
        # path).
        #
        # The partitioned executor path (``read_partition`` ``unl_split``) shapes each
        # record through the same :func:`_shape_unl_record`, so both produce identical
        # rows. Streams each file record by record (constant memory); the serial path
        # reads the whole file, the executor path reads one byte split. A gzip file (magic
        # bytes ``1f 8b``) is decompressed as a single non-splittable stream.

        source = self._table_snapshot_source(options)
        files = self._list_unl_files(source, table.exposed_name)
        encoding = _client_encoding(self.options)
        delimiter, escape = self._unl_field_format(options)
        escape_byte = _unl_escape_byte(escape, encoding)
        commit_time = self._resolve_unl_commit_time(source)
        predicate = _row_filter_predicate(table, self._source_encoding(options))
        for path in files:
            size = os.path.getsize(path)
            if not size:
                # An empty table unloads to an empty file; a ranged read of it fails (416).
                continue
            read_chunk = self._unl_read_chunk(path)
            if _unl_file_is_gzip(read_chunk):
                records = _iter_gzip_unl_records(read_chunk, size, escape=escape_byte)
            else:
                records = _iter_unl_records(read_chunk, 0, size, escape=escape_byte)
            for raw in records:
                row = _shape_unl_record(
                    raw,
                    table,
                    snapshot_lsn,
                    options,
                    encoding,
                    delimiter=delimiter,
                    escape=escape,
                    commit_time=commit_time,
                    predicate=predicate,
                    null_byte=_null_byte_mode(self.options),
                )
                if row is not None:
                    yield row

    def _read_unl_split(
        self, partition: dict, table_options: dict[str, str]
    ) -> Iterator[dict[str, Any]]:
        # Docstring: Executor side: shape the rows of one `.unl` byte split, without a live Table.
        #
        # The descriptor carries the column metadata, so a Table is rebuilt from it
        # purely for shaping (variable-scale DECIMAL coercion needs the column list); no
        # catalog connection and no Informix session run here. The range is read via a
        # Files-API ranged GET when the descriptor carries a token/host, else a local
        # seek -- the same fallback shape as the driver's ``_unl_read_chunk``. A gzip split
        # (``gzip=True``) spans the whole file and is decompressed as one stream.

        # ``columns`` is the extract's full catalog layout; ``selected`` (absent when every
        # column is ingested) names the columns to keep, and ``row_filter`` the filter.
        catalog = tuple(Column.parse(raw) for raw in partition["columns"])
        selected = partition.get("selected")
        columns = catalog
        if selected is not None:
            wanted = set(selected)
            columns = tuple(column for column in catalog if column.name in wanted)
        table = Table(
            database="",
            owner="",
            name=str(partition.get("exposed_name", "")),
            columns=columns,
            primary_keys=(),
            catalog_columns=catalog if selected is not None else (),
            row_filter=partition.get("row_filter"),
        )
        snapshot_lsn = int(partition["snapshot_lsn"])
        encoding = str(partition.get("encoding") or "utf-8")
        exposed_name = str(partition.get("exposed_name", ""))
        # Delimiter/escape ride the descriptor so an HPL DELIMITED extract parses on the
        # executor exactly as on the driver; absent (older descriptor) they fall back to
        # the UNLOAD defaults. An escape stored as "" means escaping is disabled.
        delimiter = str(partition.get("delimiter") or _UNL_DEFAULT_DELIMITER)
        escape = partition.get("escape", _UNL_DEFAULT_ESCAPE)
        escape = "" if escape is None else str(escape)
        # Manifest boundary_time (UTC epoch seconds) rides the descriptor so every split's
        # `r` rows share the extract's one commit time; None -> NULL commit time.
        raw_commit_time = partition.get("commit_time")
        commit_time = None if raw_commit_time is None else int(raw_commit_time)
        # The filter counts LENGTH in the connection's DB_LOCALE here as on the driver; the
        # connection options travel with the pickled connector, the catalog does not.
        predicate = _row_filter_predicate(table, self._source_encoding(table_options))
        read_chunk = _unl_split_read_chunk(partition)
        start = int(partition["start_byte"])
        end = int(partition["end_byte"])
        escape_byte = _unl_escape_byte(escape, encoding)
        if partition.get("gzip"):
            records = _iter_gzip_unl_records(read_chunk, end, escape=escape_byte)
        else:
            records = _iter_unl_records(read_chunk, start, end, escape=escape_byte)
        for raw in records:
            row = _shape_unl_record(
                raw,
                table,
                snapshot_lsn,
                table_options,
                encoding,
                exposed_name=exposed_name,
                delimiter=delimiter,
                escape=escape,
                commit_time=commit_time,
                predicate=predicate,
                null_byte=_null_byte_mode(self.options),
            )
            if row is not None:
                yield row

    def _unl_all_splits(
        self, table: Table, table_options: dict[str, str]
    ) -> list[tuple[str, int, int, bool]]:
        # Docstring: The full ordered ``(path, start_byte, end_byte, gzip)`` split plan for the
        # extract.
        #
        # Files are listed sorted; a plain file is split into ~``snapshot.split.bytes`` byte
        # pieces (per-table, connection fallback, then :data:`_UNL_SPLIT_TARGET_BYTES`), while
        # a gzip file (magic bytes ``1f 8b``) is non-splittable and yields a single whole-file
        # split flagged ``gzip=True``. The plan is deterministic given the immutable extract
        # and target size, so ``latest_offset`` and ``get_partitions`` -- separate calls --
        # agree on the same global split ordering without sharing state, and a windowed serve
        # tiles ``[0, total)`` across microbatches with no gap, overlap, or duplication.

        target_bytes = self._table_int_option(
            table_options, _UNL_SPLIT_BYTES_OPTION, _UNL_SPLIT_TARGET_BYTES, minimum=1
        )
        source = self._table_snapshot_source(table_options)
        # The split planner must skip escaped newlines exactly as the record readers
        # do, so it takes the same escape byte (in the extract's encoding).
        _delimiter, escape = self._unl_field_format(table_options)
        escape_byte = _unl_escape_byte(escape, _client_encoding(self.options))
        splits: list[tuple[str, int, int, bool]] = []
        for path in self._list_unl_files(source, table.exposed_name):
            size = os.path.getsize(path)
            if not size:
                # No records to split, and a ranged read of an empty file fails (416).
                continue
            read_chunk = self._unl_read_chunk(path)
            if _unl_file_is_gzip(read_chunk):
                # Gzip is not seekable, so the whole compressed file is one split.
                splits.append((path, 0, size, True))
                continue
            for start_byte, end_byte in _unl_byte_splits(
                read_chunk, size, target_bytes=target_bytes, escape=escape_byte
            ):
                splits.append((path, start_byte, end_byte, False))
        return splits

    def _unl_split_descriptors(
        self,
        table: Table,
        table_options: dict[str, str],
        snapshot_lsn: int,
        *,
        start_split: int,
        window: int,
    ) -> list[dict]:
        # Docstring: ``unl_split`` partition descriptors for the split window ``[start_split,
        # +window)``.
        #
        # The window (``stream.partitioned.snapshot.pages.per.batch`` splits) is sliced from
        # the deterministic :meth:`_unl_all_splits` plan, so this microbatch serves only its
        # slice and the offset advances by ``window`` splits per read. Mints a per-batch
        # staging token when REST is available so executors read via ranged GET; omitting it
        # makes executors fall back to a local seek. The token rides only this batch's
        # transient descriptors, never the checkpoint offset.

        all_splits = self._unl_all_splits(table, table_options)
        end_split = min(start_split + window, len(all_splits))
        columns = [_partition_column(column) for column in table.catalog_columns or table.columns]
        encoding = _client_encoding(self.options)
        delimiter, escape = self._unl_field_format(table_options)
        commit_time = self._resolve_unl_commit_time(
            self._table_snapshot_source(table_options) or ""
        )
        # Resolved after the manifest read, so a token that read found rejected (moving
        # ``auto`` to the mount) isn't handed to the executors.
        files_api = self._staging_transport()
        token = files_api._credential.bearer() if files_api is not None else None
        host = files_api._host if files_api is not None else None
        descriptors: list[dict] = []
        for path, start_byte, end_byte, is_gzip in all_splits[start_split:end_split]:
            descriptor = {
                "kind": "unl_split",
                "path": path,
                "start_byte": start_byte,
                "end_byte": end_byte,
                "gzip": is_gzip,
                "columns": columns,
                # Set whenever the table ingests fewer columns than the extract holds: under
                # a column selection, or with columns of a type the connector can't read.
                **(
                    {}
                    if not table.catalog_columns
                    else {"selected": [column.name for column in table.columns]}
                ),
                **({} if table.row_filter is None else {"row_filter": table.row_filter}),
                "snapshot_lsn": snapshot_lsn,
                "exposed_name": table.exposed_name,
                "encoding": encoding,
                "delimiter": delimiter,
                "escape": escape,
                "commit_time": commit_time,
            }
            if token and host:
                descriptor["token"] = token
                descriptor["host"] = host
                # An executor can't replace a rejected token, so under ``auto`` it reads
                # the split through the mount instead, as the driver would.
                descriptor["fuse_fallback"] = not self._staging_rest_required
            descriptors.append(descriptor)
        return descriptors

    def _read_append_only(self, table: Table, start: dict | None, options: dict[str, str]):
        # Docstring: Begin an append-only flow, then hand off to the ordinary CDC stream.
        #
        # Only the *first* read reaches here. It establishes a stream-phase offset and
        # every later read is routed straight to :meth:`_read_stream`, which needs no
        # changes: it derives its restart position from ``begin_lsn``/``commit_lsn``
        # and never consults ``table.primary_keys``.
        #
        # Two startup behaviours, selected by ``snapshot.mode``:
        #
        # ``cdc_only`` (also the append-only default when snapshot.mode is unset)
        #     Start at the server's current log position and emit nothing now. Rows
        #     that predate the flow are not captured. No size ceiling, no memory
        #     spike, and no failure mode -- which is why it is the default. An
        #     append-only table is usually one that is actively being appended to, so
        #     the interesting rows are the arriving ones.
        #
        # ``initial``
        #     Read the table once under REPEATABLE READ and continue from that
        #     snapshot's LSN, so history is captured and the handoff is gapless: the
        #     snapshot is consistent as-of one LSN and the stream resumes from exactly
        #     that LSN. Because a key-less table has no stable monotonic cursor, this
        #     uses one forward-only cursor and one REPEATABLE READ transaction. Fetched
        #     rows are written to immutable staged pages and become visible only after
        #     the completed snapshot manifest is published.
        #
        # When ``table.migration=true`` (checked before either mode), the flow instead
        # records the checkpoint a prior flow parked in Lakebase (see :meth:`_read_handoff`),
        # emits no rows, and stops -- skipping the snapshot entirely. Used to switch a table
        # SCD1->append-only, or relocate its destination, without a re-snapshot. The table
        # keeps its real ``snapshot.mode``; migration never streams, and clearing
        # table.migration (Restore) resumes streaming from the recorded offset, with
        # _recover's strict ``commit_lsn > C`` filter keeping the seam gapless and
        # duplicate-free.

        _ensure_materializable(table, options)
        table = self._refresh_table_schema(table, None)
        pipeline_scope = self._pipeline_scope()
        if self._table_migration(options):
            token = self._read_handoff_token(table)
            if token is None:
                # 273: table.migration=true for '{}' found no parked checkpoint in Lakebase. Before
                # switching a table to append-only (or relocating it), run its source flow once in
                # triggered mode with table.migration=true so it parks its stream offset, then
                # switch. To start fresh instead, clear table.migration and use
                # snapshot.mode=cdc_only (no history) or snapshot.mode=initial (full snapshot).
                raise InformixError(_m(273, table.exposed_name))
            # Seed from the parked position and stop (no rows); migration never streams.
            # Adopts this flow's scope -- the seam is carried by the scope-independent LSNs,
            # and the first stream read (after Restore clears table.migration) re-publishes
            # the scoped channel-start record under the new scope. Schema drift since capture
            # fails closed inside the helper. The token is not deleted here -- it is dropped
            # only once Spark has committed this seed (see the append+stream branch in
            # _read_table_attempt), so a crash before commit re-seeds rather than failing
            # closed.
            return iter(()), self._handoff_seed_from_token(table, token)

        configured_mode = options.get("snapshot.mode", self.options.get("snapshot.mode"))
        snapshot_mode = (
            "cdc_only" if configured_mode is None else str(configured_mode).strip().lower()
        )
        if snapshot_mode not in {"initial", "cdc_only"}:
            # 274: Append-only table '{}' supports only snapshot.mode=initial or
            # snapshot.mode=cdc_only
            raise ValueError(_m(274, table.exposed_name))

        if snapshot_mode == "initial":
            return self._read_snapshot(table, start, options, allow_keyless=True)

        # The boundary is durable and shared, exactly as for a keyed table, so a
        # restart before the first checkpoint commits resumes from the same position
        # instead of skipping or re-reading whatever the log had reached by then.
        boundary = self._initial_lsn(table, scope=pipeline_scope)
        if boundary is None:
            # 275: Could not establish an append-only start boundary for '{}'
            raise InformixError(_m(275, table.exposed_name))
        schema_id = self._snapshot_schema_ids[(pipeline_scope, table.identity)]

        rows: Iterator[dict] = iter(())

        # phase="stream" so the next read goes straight to _read_stream. tx_id is None
        # and change_lsn equals commit_lsn because no transaction has been read yet --
        # the same shape the keyed snapshot-to-stream transition produces.
        return rows, _offset(
            boundary,
            boundary,
            boundary,
            None,
            "stream",
            table,
            schema_id,
            pipeline_scope,
        )

    def _read_snapshot_only(self, table: Table, options: dict[str, str]):
        _ensure_materializable(table, options)
        table = self._refresh_table_schema(table, None)
        fingerprint = _schema_fingerprint(table)
        # PK-less tables cannot be seek-paginated safely.  Read exactly once;
        # returning None signals non-checkpointable full refresh semantics.
        limit = self._table_int_option(options, "snapshot.max.rows", 0, minimum=0)
        if limit == 0:
            limit = 100000
        rows = self._snapshot_read_with_reconnect(
            lambda: self._bridge.snapshot_page(
                table.identity,
                [c.name for c in table.columns],
                (),
                None,
                limit + 1,
                self._table_int_option(options, "snapshot.max.bytes", 0, minimum=0),
                snapshot_filter=_snapshot_predicate(_snapshot_filter(options), table),
            ),
            table=table,
            operation="snapshot read",
        )
        table = self._refresh_table_schema(table, fingerprint)
        if len(rows) > limit:
            # 276: Snapshot-only table {} exceeds snapshot.max.rows={}
            raise InformixError(_m(276, table.exposed_name, limit))
        lsn = self._bridge.current_lsn()
        commit_time = self._source_utc_time()
        return (
            iter(
                _shape_snapshot(row, lsn, table, options, commit_time=commit_time) for row in rows
            ),
            None,
        )

    def _read_changes_with_reconnect(
        self, captures, restart, timeout_seconds, max_records, *, table: Table
    ):
        # Docstring: Run one bounded CDC poll, retrying in place on a mid-read drop.
        #
        # A connection dropped during ``read_changes`` raises ``SqliProtocolError``
        # (e.g. ``SQ_LODATA server/ISAM error -1`` when the socket dies mid-poll).
        # The read has not advanced any offset, so it is safe to reset the dead
        # transport and reissue the identical poll under the connection slot the
        # reader already holds. Bounded attempts with short backoff absorb a
        # transient blip; exhausting them re-raises so a genuinely-down source
        # still fails honestly.
        #
        # This retries synchronously inside the single ``latestOffset`` call rather
        # than yielding an empty batch, so it is correct for a triggered
        # (AvailableNow) flow too: an empty batch below the frozen high-water mark
        # would let AvailableNow complete the batch and skip the un-read changes,
        # whereas retrying in place either returns the real records or raises.
        #
        # A lost connection-capacity lease (``ConnectionCapacityUnavailable``) is
        # not a transport drop and is never retried here; it propagates to the
        # capacity-aware handler.

        attempt = 0
        while True:
            # A fresh spill each attempt: a retried read writes its transactions' pages again.
            self._bridge.cdc_spill = self._cdc_spill(captures)
            try:
                return self._bridge.read_changes(captures, restart, timeout_seconds, max_records)
            except ConnectionCapacityUnavailable:
                raise
            except SqliProtocolError as error:
                lease_lost = getattr(self._bridge, "_connection_lease_lost", None)
                if lease_lost is not None and lease_lost.is_set():
                    # The drop is a deliberate lease-loss shutdown, not a blip.
                    raise
                if attempt >= _CDC_RECONNECT_MAX_RETRIES:
                    raise
                delay = min(
                    _CDC_RECONNECT_BASE_SECONDS * (2**attempt),
                    _CDC_RECONNECT_MAX_SECONDS,
                )
                # 277: Informix CDC poll for '{}' lost its connection ({}); resetting the transport
                # and retrying the same read (attempt {}/{}) after {:.1f}s
                logging.getLogger(__name__).warning(
                    _m(
                        277,
                        table.exposed_name,
                        error,
                        attempt + 1,
                        _CDC_RECONNECT_MAX_RETRIES,
                        delay,
                    ),
                    exc_info=True,
                )
                reset = getattr(self._bridge, "reset_transport", None)
                if reset is not None:
                    reset()
                time.sleep(delay)
                attempt += 1
            finally:
                self._bridge.cdc_spill = None

    def _cdc_spill(self, captures: Sequence[dict[str, Any]]) -> _CdcSpill | None:
        # Docstring: The spill writer for one poll over ``captures``, or None when
        # cdc.spill.records is 0. Pages go to the staging Volume under the pipeline's spill
        # scope (see _spill_scope), in a "cdc-spill" stage the stale-stage sweep also clears.

        threshold = int(self.options.get(_CDC_SPILL_RECORDS_OPTION, _DEFAULT_CDC_SPILL_RECORDS))
        scope = _spill_scope(getattr(self, "_registration_scope", None))
        if (
            threshold <= 0
            or not getattr(self, "_snapshot_staging_location", None)
            # A reader without a scope can't name pages another process finds: it keeps
            # every transaction in memory instead of failing the read.
            or scope is None
        ):
            return None
        natives = {str(c["logical_identity"]): str(c["identity"]) for c in captures}
        # Each table's run is named by its own capture, so the upsert and delete channels,
        # whose shards capture different sets of tables, name the same pages.
        layouts = {
            str(c["logical_identity"]): hashlib.sha256(
                json.dumps(c, sort_keys=True, default=str).encode("utf-8")
            ).hexdigest()[:12]
            for c in captures
        }
        # Whether each run this poll writes is consumed already, asked once per run.
        consumed: dict[str, bool] = {}

        def write(native: str, name: str, run: str, page_index: int, records: list) -> None:
            target = types.SimpleNamespace(
                native_identity=native, exposed_name=name, primary_keys=()
            )
            self._maybe_sweep_stale_snapshot_stages(target)
            if run not in consumed:
                consumed[run] = self._register_spill_run(native, scope, run)
            if consumed[run]:
                # Every channel has committed past this transaction, so no batch reads these
                # pages: a poll that reads it again (a shard reading below it for another
                # table) writes none.
                return
            # The upsert and delete channels read the same transaction under the same
            # capture and scope, so they name the same pages with the same contents: a page
            # the other channel has written already is kept, not encoded and written again.
            # Both are written atomically, so one that exists is whole.
            namespace = self._snapshot_stage_namespace_for(native, scope, _CDC_SPILL_SCHEMA)
            page = f"page-{page_index:08d}"
            if os.path.isfile(os.path.join(namespace, "runs", run, page, "data.json.gz")):
                return
            self._publish_snapshot_stage_page(
                target, scope, _CDC_SPILL_SCHEMA, run, page_index, records, None
            )

        def delete(native: str, run: str) -> None:
            # A rolled-back transaction: its pages and its record go.
            path = os.path.join(
                self._snapshot_stage_namespace_for(native, scope, _CDC_SPILL_SCHEMA), "runs", run
            )
            with contextlib.suppress(OSError):
                PurePythonInformixBridge._remove_connection_slot_tree(path)
            key = self._spill_run_key(native, scope, run)
            self._spill_run_state(
                run,
                lambda: delete_spill_run(
                    self._lakebase_connection(), self._lakebase_state_namespace(), key
                ),
            )

        def commit(native: str, run: str, commit_lsn: int) -> None:
            # The commit LSN finishes the run for each channel whose checkpoint reaches it.
            record = {**self._spill_run_record(native, scope, run), "commit_lsn": str(commit_lsn)}
            key = self._spill_run_key(native, scope, run)
            self._spill_run_state(
                run,
                lambda: merge_spill_run(
                    self._lakebase_connection(), self._lakebase_state_namespace(), key, record
                ),
            )

        return _CdcSpill(threshold, write, delete, layouts, scope, natives, commit)

    def _spill_run_key(self, native_identity: str, scope: str, run: str) -> str:
        # Docstring: A run's Lakebase record key, under its table's state prefix so the
        # table-state GC removes it with the table.

        return "/".join(
            (*self._table_state_keys_for(native_identity), _CDC_SPILL_SCHEMA, scope, run)
        )

    @staticmethod
    def _spill_run_record(native_identity: str, scope: str, run: str) -> dict[str, Any]:
        return {
            "format_version": 1,
            "table": native_identity,
            "spill_scope": scope,
            "run": run,
            "begin_lsn": run.split("-")[1],
            "done": {},
        }

    def _spill_run_state(self, run: str, thunk):
        # Docstring: One Lakebase update of a run's record, or None when it fails.
        #
        # Best-effort: without the record the pages are written all the same, and only their
        # cleanup falls to the retention sweep.

        try:
            return self._state_op_with_reconnect(thunk, operation="spilled-run record")
        except Exception:  # pylint: disable=broad-except
            # 429: Cannot update spilled CDC run {} in Lakebase; its pages are left for the
            # retention sweep
            logging.getLogger(__name__).warning(_m(429, run), exc_info=True)
            return None

    def _register_spill_run(self, native_identity: str, scope: str, run: str) -> bool:
        # Docstring: Record a run a poll writes in Lakebase; report whether it is consumed.

        record = self._spill_run_record(native_identity, scope, run)
        key = self._spill_run_key(native_identity, scope, run)
        elected = self._spill_run_state(
            run,
            lambda: publish_state_record(
                self._lakebase_connection(),
                self._lakebase_state_namespace(),
                key,
                record,
                record_type=_CDC_SPILL_RECORD_TYPE,
            ),
        )
        return elected is not None and _spill_run_consumed(elected)

    def _note_spilled_runs(self, spilled, tx: CommittedTransaction, deletes: bool) -> None:
        # Docstring: Remember the runs of a spilled transaction this channel serves, by commit.

        channel = "delete" if deletes else "upsert"
        for part in spilled:
            runs = self._spill_runs.setdefault((str(part["native_identity"]), channel), {})
            runs[str(part["run"])] = (str(part["pipeline_scope"]), tx.begin_lsn, tx.commit_lsn)

    def _settle_spilled_runs(self, table: Table, checkpoint: dict, options, deletes: bool) -> None:
        # Docstring: Mark the spilled runs this channel has committed past, in Lakebase, and
        # delete the pages of each run whose last channel this is.
        #
        # Spark gives a reader only a start it has committed, and _recover never serves a
        # transaction at or below it, so a run is finished for this channel once the start's
        # commit LSN reaches its transaction's commit: the commit of a run this reader served,
        # or the commit LSN a poll recorded at the COMMIT. Its BEGIN proves nothing: Informix
        # hands a channel a transaction whose BEGIN is below its restart LSN when the first
        # captured change came later. Runs are listed from Lakebase at the first read and every
        # _CDC_SPILL_LIST_SECONDS, which also expires the table's old records of every
        # pipeline, so a channel that read a transaction in memory finishes the other shard's
        # run too. Not called on a replay, whose later polls start at positions Spark has not
        # committed. The table's channels are the upsert one and, unless it is append-only,
        # the delete one: the connector already serves one of each per table per pipeline.

        scope = _spill_scope(getattr(self, "_registration_scope", None))
        if scope is None or not getattr(self, "_snapshot_staging_location", None):
            return
        native = table.native_identity
        channel = "delete" if deletes else "upsert"
        pending = self._spill_runs.setdefault((native, channel), {})
        now = time.monotonic()
        due = now - self._spill_runs_listed.get((native, channel), -math.inf)
        due = due >= _CDC_SPILL_LIST_SECONDS
        if not due and not pending:
            return
        namespace = self._lakebase_state_namespace()
        try:
            if due:
                prefix = "/".join((*self._table_state_keys_for(native), _CDC_SPILL_SCHEMA))
                listed = self._state_op_with_reconnect(
                    lambda: list_spill_runs(
                        self._lakebase_connection(),
                        namespace,
                        prefix,
                        scope,
                        channel,
                        self._snapshot_staging_retention_seconds,
                    ),
                    operation="spilled-run listing",
                )
                self._spill_runs_listed[(native, channel)] = now
                runs = {
                    str(record["run"]): (
                        scope,
                        int(record["begin_lsn"]),
                        int(record["commit_lsn"]) if record.get("commit_lsn") else None,
                    )
                    for record in listed
                }
                for run, entry in list(pending.items()):
                    # A listed run gone since (rolled back, finished, expired) is dropped; a
                    # served one keeps the commit it was served with.
                    if entry[2] is None and run not in runs:
                        del pending[run]
                for run, entry in runs.items():
                    if run not in pending or pending[run][2] is None:
                        pending[run] = entry
            commit = int(checkpoint["commit_lsn"])
            finished = [
                (run, entry)
                for run, entry in pending.items()
                if entry[2] is not None and entry[2] <= commit
            ]
            if not finished:
                return
            required = (
                ["upsert"] if self._append_only_table(table, options) else ["upsert", "delete"]
            )
            for run, (run_scope, _begin, _end) in finished:
                record = {
                    **self._spill_run_record(native, run_scope, run),
                    "done": {channel: True},
                    "required": required,
                }
                key = self._spill_run_key(native, run_scope, run)
                marked = self._state_op_with_reconnect(
                    lambda key=key, record=record: merge_spill_run(
                        self._lakebase_connection(), namespace, key, record
                    ),
                    operation="spilled-run settlement",
                )
                del pending[run]
                if _spill_run_consumed(marked):
                    path = os.path.join(
                        self._snapshot_stage_namespace_for(native, run_scope, _CDC_SPILL_SCHEMA),
                        "runs",
                        run,
                    )
                    self._snapshot_cleanup_executor().submit(self._delete_spill_pages, path)
        except Exception:  # pylint: disable=broad-except
            # 430: Cannot update the spilled CDC runs of '{}' in Lakebase; trying again on the
            # next batch
            logging.getLogger(__name__).warning(_m(430, table.exposed_name), exc_info=True)

    def _delete_spill_pages(self, path: str) -> None:
        # Docstring: Delete a consumed run's pages, then the run once nothing else is in it.
        #
        # A candidate page another writer is still renaming into place keeps the run, for
        # the retention sweep.

        try:
            names = os.listdir(path)
        except OSError:
            return
        for name in names:
            if name.startswith("page-"):
                self._delete_snapshot_page(os.path.join(path, name))
        with contextlib.suppress(OSError):
            os.rmdir(path)

    def _snapshot_read_with_reconnect(self, thunk, *, table: Table, operation: str):
        # Docstring: Run one snapshot page or key-bound read, retrying in place on a drop.
        #
        # A connection dropped mid-read raises ``SqliTransportError`` ("truncated
        # SQLI stream ..."), a subclass of ``SqliProtocolError``; the enclosing
        # repeatable-read transaction's rollback then fails because the session is
        # already gone. The read has advanced no offset -- the incremental cursor is
        # committed only after the read returns, and each read (``max_primary_key``,
        # ``snapshot_chunk``, the keyless one-shot ``snapshot_page``) opens its own
        # repeatable-read transaction -- so the dead transport can be reset and the
        # identical read reissued under the connection slot already held. Bounded
        # attempts with short backoff absorb a transient blip; exhausting them
        # re-raises so a genuinely-down source still fails honestly. This is the
        # snapshot counterpart of ``_read_changes_with_reconnect``.
        #
        # A deliberate lease-loss shutdown (``ConnectionCapacityUnavailable`` or a
        # set ``_connection_lease_lost``) is never retried; it propagates.

        attempt = 0
        while True:
            try:
                return thunk()
            except ConnectionCapacityUnavailable:
                raise
            except SqliProtocolError as error:
                lease_lost = getattr(self._bridge, "_connection_lease_lost", None)
                if lease_lost is not None and lease_lost.is_set():
                    # The drop is a deliberate lease-loss shutdown, not a blip.
                    raise
                if attempt >= _SNAPSHOT_RECONNECT_MAX_RETRIES:
                    raise
                delay = min(
                    _SNAPSHOT_RECONNECT_BASE_SECONDS * (2**attempt),
                    _SNAPSHOT_RECONNECT_MAX_SECONDS,
                )
                # 278: Informix snapshot {} for '{}' lost its connection ({}); resetting the
                # transport and retrying the same read (attempt {}/{}) after {:.1f}s
                logging.getLogger(__name__).warning(
                    _m(
                        278,
                        operation,
                        table.exposed_name,
                        error,
                        attempt + 1,
                        _SNAPSHOT_RECONNECT_MAX_RETRIES,
                        delay,
                    ),
                    exc_info=True,
                )
                reset = getattr(self._bridge, "reset_transport", None)
                if reset is not None:
                    reset()
                time.sleep(delay)
                attempt += 1

    def _state_op_with_reconnect(self, thunk, *, operation: str):
        # Docstring: Run one Lakebase state read/write, retrying in place on a dropped connection.
        #
        # A state connection reaped while idle (typically across a long wait for
        # connection capacity) is handed back by ``_lakebase_connection`` because
        # psycopg leaves ``.closed`` False until a query fails; the next
        # ``cursor.execute`` then raises ``OperationalError``/``InterfaceError``.
        # The operation committed nothing (the failure precedes ``commit``) and is
        # idempotent, so the dead handle is dropped and the identical operation
        # reissued on a fresh connection. ``thunk`` must re-fetch
        # ``self._lakebase_connection()`` each call so the retry uses the reopened
        # handle. Bounded attempts with short backoff absorb a transient reap;
        # exhausting them re-raises. Postgres counterpart of
        # ``_snapshot_read_with_reconnect``.
        #
        # Only a genuinely-dead connection is retried: after the error the cached
        # handle must report closed. A failure on a still-live connection (e.g. a
        # serialization conflict, also an ``OperationalError`` subclass) is not a
        # drop and propagates unchanged.

        connection_lost = connection_lost_error_types()
        if not connection_lost:
            return thunk()
        attempt = 0
        while True:
            try:
                return thunk()
            except connection_lost as error:
                connection = getattr(self, "_lakebase_conn", None)
                try:
                    still_alive = connection is not None and not connection.closed
                except Exception:  # pragma: no cover - a broken handle counts as dead
                    still_alive = False
                if still_alive or attempt >= _LAKEBASE_RECONNECT_MAX_RETRIES:
                    raise
                delay = min(
                    _LAKEBASE_RECONNECT_BASE_SECONDS * (2**attempt),
                    _LAKEBASE_RECONNECT_MAX_SECONDS,
                )
                # 279: Informix Lakebase state {} lost its connection ({}); reconnecting and
                # retrying the same operation (attempt {}/{}) after {:.1f}s
                logging.getLogger(__name__).warning(
                    _m(279, operation, error, attempt + 1, _LAKEBASE_RECONNECT_MAX_RETRIES, delay),
                    exc_info=True,
                )
                self._reset_lakebase_connection()
                time.sleep(delay)
                attempt += 1

    def _snapshot_cursor_scan(self, options: dict[str, str]) -> bool:
        # Docstring: Whether ``snapshot.scan=cursor`` asks for an unordered one-pass snapshot.
        #
        # The table option wins over connection scope; the default is ``keyset``. See
        # ``_SNAPSHOT_SCAN_OPTION``.

        raw = options.get(
            _SNAPSHOT_SCAN_OPTION, self.options.get(_SNAPSHOT_SCAN_OPTION, _SNAPSHOT_SCAN_KEYSET)
        )
        return _snapshot_scan_value(raw) == _SNAPSHOT_SCAN_CURSOR

    def _snapshot_isolation(self, options: dict[str, str]) -> str:
        # Docstring: Resolve the ``snapshot.isolation`` table option to its SQL clause.
        #
        # Defaults to COMMITTED READ LAST COMMITTED (non-locking; see the README
        # duplicate warning). Tokens are whitespace/hyphen-insensitive; an unknown
        # value fails loudly rather than silently falling back.

        token = (
            str(options.get(_SNAPSHOT_ISOLATION_OPTION, _DEFAULT_SNAPSHOT_ISOLATION))
            .strip()
            .lower()
            .replace("-", "_")
            .replace(" ", "_")
        )
        try:
            return _SNAPSHOT_ISOLATION_SQL[token]
        except KeyError:
            # 160: Option '{}' must be one of {}; got {!r}
            raise ValueError(
                _m(160, _SNAPSHOT_ISOLATION_OPTION, sorted(_SNAPSHOT_ISOLATION_SQL), token)
            ) from None

    def _is_snapshot_drain_worker(self) -> bool:
        # Docstring: Whether this reader is a drain-pool worker, which drains its table inline.

        return self.options.get(_SNAPSHOT_DAEMON_SLOT_MARKER_OPTION) == "true"

    def _snapshot_reader_thread_count(self) -> int:
        return _resolve_snapshot_reader_threads(self.options)

    def _snapshot_drain_reader_factory(self) -> Callable[[], "InformixLakeflowConnect"]:
        # The daemon worker gets its OWN options copy. Capacity accounting is left intact --
        # the drain must count against the same connection budget so
        # ``snapshot.reader.threads`` bounds the slots it holds.
        reader_options = dict(self.options)
        # The drain runs on a daemon thread and holds its slot for the whole scan, but it
        # is bootstrap work that must finish to unblock its consumer. Floor it one band
        # below the CDC daemon (not at the CDC floor), so a saturated CDC daemon cannot
        # starve it -- it always has slots the CDC daemon is locked out of. The marker also
        # makes the worker's ``_read_snapshot`` drain inline rather than recurse into the
        # pool (see _is_snapshot_drain_worker).
        reader_options[_SNAPSHOT_DAEMON_SLOT_MARKER_OPTION] = "true"
        # The worker waits for its slot using its own ``connection.wait.timeout.seconds`` as
        # a *per-turnover* window, not a hard cap: it resets every time the pool claims a slot
        # (see the slot-wait liveness in ``_acquire_connection_slot``), so it waits out a busy
        # backfill and only gives up when the pool is wedged. It is also the consumer's
        # per-progress idle window, so the single knob governs both. Drop any inherited
        # per-read attempt budget so it cannot cap the slot wait below that window.
        reader_options.pop(_CONNECTION_ATTEMPT_BUDGET_OPTION, None)
        reader_options.pop(_REPLAY_CONNECTION_WAIT_BUDGET_OPTION, None)
        cls = type(self)
        return lambda: cls(reader_options)

    def _drain_via_snapshot_daemon(
        self,
        table: Table,
        options: dict[str, str],
        pipeline_scope: str,
        schema_id: str,
        allow_keyless: bool,
    ) -> dict[str, Any]:
        # Docstring: Enqueue this table's drain on the bounded pool and wait -- holding no slot
        # or state connection -- for the daemon to stage it and publish the manifest,
        # then return that manifest.

        namespace = self._lakebase_state_namespace()
        pool = _snapshot_drain_pool(
            (namespace, pipeline_scope),
            reader_factory=self._snapshot_drain_reader_factory(),
            thread_count=self._snapshot_reader_thread_count(),
        )
        job_key = (namespace, pipeline_scope, table.native_identity, schema_id)
        pool.submit(
            job_key,
            table=table,
            options=dict(options),
            pipeline_scope=pipeline_scope,
            allow_keyless=allow_keyless,
        )
        # The wait is a liveness watchdog, not a total-duration cap: it trips only after
        # the worker reports no progress for a whole ``connection.wait.timeout.seconds``
        # window. "Progress" is a staged page *or* -- while the worker is still acquiring
        # its slot -- a turnover ping from ``_acquire_connection_slot``, so a drain that is
        # legitimately queued behind a busy-but-live pool never trips here; the worker's own
        # slot-wait watchdog owns the wedged-capacity case and raises a precise
        # ConnectionCapacityUnavailable. The consumer waits one extra grace beyond the
        # worker's window so, on a genuine wedge, that precise error (recorded by the worker
        # when it gives up) surfaces instead of this generic message racing it out -- which
        # then means only one thing: the worker went dark without recording an error.
        idle_timeout = float(
            self.options.get(
                "connection.wait.timeout.seconds",
                str(_DEFAULT_CONNECTION_WAIT_TIMEOUT_SECONDS),
            )
        )
        # Hold no Lakebase connection across the drain wait: the caller's manifest
        # probe left this connection idle inside a read transaction, which Lakebase
        # reaps as an idle-in-transaction timeout over a multi-minute drain. The
        # daemon stages on its own connection; the post-wait read reopens fresh.
        self._reset_lakebase_connection()
        if not pool.wait(job_key, idle_timeout + _SNAPSHOT_DRAIN_STALL_GRACE_SECONDS):
            # 280: Shared snapshot drain of '{}' made no progress for {:g}s and appears stalled: the
            # drain worker stopped reporting progress without failing. Check the source for a hung
            # query, or raise connection.wait.timeout.seconds.
            raise InformixError(_m(280, table.exposed_name, idle_timeout))
        manifest = self._read_snapshot_stage_manifest(table, pipeline_scope, schema_id)
        if manifest is None:
            # 281: Shared snapshot drain of '{}' completed without publishing a manifest
            raise InformixError(_m(281, table.exposed_name))
        return manifest

    def _shared_cdc_thread_count(self) -> int:
        explicit = self.options.get(_SHARED_CDC_THREADS_OPTION)
        if explicit is not None:
            return max(1, int(explicit))
        # Threads are per channel and the upsert/delete channels shard independently, so K
        # threads means up to 2K daemon slot-holders. Default K to a quarter of the pool so
        # total daemon demand stays near half the pool, leaving room for consumer bootstrap
        # reads and the snapshot drain. The old default (= max.concurrent.connections)
        # targeted 2N holders against an N-slot pool and pinned the entire daemon
        # reservation band, starving bootstrap/drain reads on a small pool.
        slot_count = int(
            self.options.get("max.concurrent.connections", str(_DEFAULT_MAX_CONCURRENT_CONNECTIONS))
        )
        return max(1, slot_count // 4)

    def _shared_cdc_reader_factory(self) -> Callable[[], "InformixLakeflowConnect"]:
        # The daemon reader gets its OWN options copy: the connector mutates options
        # mid-read (capacity hints), so a shared dict would race. It reads
        # through its bridge and _read_changes_with_reconnect, never _read_stream, so it
        # can't recurse into the shards.
        reader_options = dict(self.options)
        # The shard reads on a daemon thread, so floor its slot above the daemon
        # reservation to leave headroom for consumer bootstrap reads.
        reader_options[_DAEMON_SLOT_MARKER_OPTION] = "true"
        # The daemon waits for its slot on the turnover watchdog (see the liveness path in
        # _acquire_connection_slot), using ``connection.wait.timeout.seconds`` as a
        # per-turnover window rather than a hard cap, so it holds its queue ticket long
        # enough for the round-robin rotation to reach it. Drop any per-read attempt budget
        # inherited from the parent's options so a short consumer budget cannot cap that
        # wait below the window and send the daemon back to the end of the queue.
        reader_options.pop(_CONNECTION_ATTEMPT_BUDGET_OPTION, None)
        reader_options.pop(_REPLAY_CONNECTION_WAIT_BUDGET_OPTION, None)
        cls = type(self)
        # The shard is keyed by this reader's scope, and its reads spill under it.
        scope = self._registration_scope

        def factory() -> "InformixLakeflowConnect":
            reader = cls(reader_options)
            if scope is not None:
                reader.set_registration_scope(scope)
            return reader

        return factory

    def _shared_cdc_snapshot(self, table, checkpoint, options, deletes, pipeline_scope):
        # Docstring: Subscribe this table to its shard and return the daemon's coherent view, or
        # None to fall back to a direct read (daemon not ready, or a schema transition).

        channel = "delete" if deletes else "upsert"
        threads = self._shared_cdc_thread_count()
        shard_id = int(hashlib.sha256(table.native_identity.encode()).hexdigest(), 16) % threads
        key = (self._lakebase_state_namespace(), pipeline_scope, channel, shard_id)
        capture = _capture_descriptor(table, _client_encoding(self.options))
        checkpoint_commit = int(checkpoint["commit_lsn"])
        floor = int(checkpoint.get("begin_lsn") or checkpoint["commit_lsn"])
        config = {
            "timeout_seconds": self._table_int_option(options, "cdc.timeout", 5, minimum=1),
            "max_records": self._table_int_option(
                options, "cdc.max.records", _DEFAULT_CDC_MAX_RECORDS, minimum=1, maximum=256
            ),
            "buffer_cap": int(
                self.options.get(_SHARED_CDC_BUFFER_OPTION, str(_DEFAULT_SHARED_CDC_BUFFER))
            ),
            "subscriber_ttl": float(
                self.options.get("cdc.shared.state.wait.seconds", str(_SHARED_STATE_WAIT_SECONDS))
            ),
        }
        reader_factory = self._shared_cdc_reader_factory()
        replay_stop = self._replay_stop_lsn(options)
        deadline = (
            time.monotonic()
            + _SHARED_VIEW_WAIT_TIMEOUTS * config["timeout_seconds"]
            + _SHARED_VIEW_WAIT_MARGIN_SECONDS
        )
        while True:
            if _shared_cdc_mode(self.options) == _SHARED_CDC_SESSION_HOST:
                view = _host_shard_poll(
                    key,
                    reader_factory,
                    config,
                    table.native_identity,
                    table,
                    capture,
                    checkpoint_commit,
                    floor,
                )
            else:
                shard = _shared_cdc_shard(key, reader_factory=reader_factory, **config)
                shard.subscribe(table.native_identity, table, capture, checkpoint_commit, floor)
                view = shard.snapshot(table.native_identity, checkpoint_commit)
            # A fingerprint mismatch means a schema transition is in flight; defer to the
            # direct-read path, which owns the transition/replay logic. So does a view of
            # another layout than this reader's: two flows can read one table under different
            # options with the same capture, and the shard keeps the first one's table.
            if (
                view is None
                or view.fingerprint != str(checkpoint.get("schema_fingerprint"))
                or view.fingerprint != _schema_fingerprint(table)
            ):
                return None
            if not (self._trigger_available_now or replay_stop is not None) or view.committed:
                return view
            # A bounded read -- an AvailableNow update, or a replay -- ends at the first read
            # that moves it nowhere. A view that cannot move this consumer on (the shard's
            # scan has not reached it yet, or went idle where the consumer already is)
            # yields to a direct read, which waits on the log itself -- unless it shows the
            # read done. A replay is done once the shard went idle at or past its stop. Not
            # a checkpoint the log no longer retains: the read reports that first.
            reached = view.reached_lsn if view.caught_up else None
            if (
                reached is None
                or reached > checkpoint_commit
                or replay_stop is not None
                or floor < view.min_lsn
            ):
                moved_on = reached is not None and reached > checkpoint_commit
                at_stop = replay_stop is not None and reached is not None and reached >= replay_stop
                return view if moved_on or at_stop else None
            # An AvailableNow read takes the update's frozen boundary here when this process
            # has not read it yet, the upsert reader publishing it from this view's sample as
            # it would on taking the view. The boundary is current_lsn, the end of the log
            # page being written, which an idle read never reaches; and on a quiet log the
            # server's CDC reader, shared by every session, reports a TIMEOUT position held
            # dozens of pages back until the next checkpoint, even to a session started past
            # it. A direct read, started from the checkpoint, is done when the server reports
            # no position past it. The shard's read is as good once the log had reached the
            # boundary when it started (its sample, current_lsn, is at or past it) and it
            # went idle where it started or short of it. A scan stopped short, its timeout
            # spent on other tables' log, ends past where it started instead -- even where
            # that is where this consumer now is, the quiet advance having taken it there
            # before the shard's next read. Within the boundary's page is done as well.
            bound, _ = self._shared_trigger_boundary(
                table, checkpoint, owner=not deletes, current_lsn=view.current_lsn
            )
            started = view.read_start_lsn
            if view.current_lsn >= bound and (
                reached >= bound - (1 << 12) or (started is not None and reached <= started)
            ):
                return view
            # Otherwise the shard's next read, started later, is waited for.
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return None
            time.sleep(min(_SHARED_VIEW_WAIT_POLL_SECONDS, remaining))

    def _read_stream(self, table: Table, start: dict, options: dict[str, str], deletes: bool):
        checkpoint = _validated_offset(start)
        pipeline_scope = self._pipeline_scope()
        # A daemon reader owns this shard's Informix I/O: it supplies the schema, log
        # bounds, and change records, so a steady-state poll touches Informix for
        # nothing. A None view (daemon not ready yet, or a schema transition in flight)
        # transparently falls back to the direct-read path below.
        shared_view = self._shared_cdc_snapshot(table, checkpoint, options, deletes, pipeline_scope)
        if shared_view is not None:
            table = shared_view.table
        else:
            table = self._refresh_table_schema(table, None)
        fingerprint = _schema_fingerprint(table)
        checkpoint_fingerprint = checkpoint.get("schema_fingerprint")
        checkpoint_schema_id = str(checkpoint["schema_id"])
        if checkpoint_fingerprint is None:
            # 282: Informix checkpoint for '{}' predates schema-safe offsets; run a full refresh
            # before resuming CDC
            raise InformixError(_m(282, table.exposed_name))
        restart = int(checkpoint.get("begin_lsn") or checkpoint["commit_lsn"])
        minimum = shared_view.min_lsn if shared_view is not None else self._bridge.minimum_lsn()
        if restart < minimum:
            # 283: Restart LSN {} is older than minimum retained LSN {}; resnapshot required
            raise LogRetentionError(_m(283, restart, minimum))
        # A restart position in a *higher log file* than the server's current one
        # means the source reinitialized its logical log under this checkpoint, so
        # the position will never be reached again. Without this the reader
        # activates CDC at an unreachable LSN and returns nothing on every poll
        # while re-returning the same checkpoint -- a permanent silent stall that
        # reports RUNNING and replicates no rows. Observed in production on the
        # delete channel, whose bootstrap path already validates both bounds (see
        # _initial_lsn) while this resume path validated only the lower one.
        #
        # Compare log-file numbers rather than raw LSNs. ``current_lsn`` derives
        # its byte offset from ``syslogs.used``, a sampled page count, so a
        # transaction committed between that sample and this read legitimately sits
        # a few pages beyond it -- a raw ``>`` comparison would reject that benign
        # race. Only a lower *uniqid* is unambiguous: log files advance
        # monotonically, so a checkpoint naming a file above the current one cannot
        # be explained by sampling lag.
        #
        # Fail loudly rather than advancing: the checkpoint's position is unrelated
        # to the current log, so no safe resume point can be inferred from it and
        # only a full refresh can re-establish one.
        current = shared_view.current_lsn if shared_view is not None else self._bridge.current_lsn()
        if (restart >> 32) > (current >> 32):
            # 284: Restart LSN {} for '{}' names logical log {}, which is ahead of the source's
            # current log {}, so the source reinitialized its logical log; this checkpoint can never
            # be resumed. Run a full refresh; changes committed before the reinitialization are no
            # longer in the log.
            raise LogRetentionError(
                _m(284, restart, table.exposed_name, restart >> 32, current >> 32)
            )
        capture_table = table
        transition_table = table
        transition_lsn: int | None = None
        capture_schema_id = checkpoint_schema_id
        transition_schema_id = checkpoint_schema_id
        projection_schema_transition = False
        # The live layout this flow saw on its first read of the update, carried on every
        # offset the update writes. A whole-row key shrinks only by a drop the update's
        # destination already merges without, one made before it started: the update's first
        # read may take one, and so may a later read while the live layout is still the one
        # that read saw. An offset written without reading (a delete seed, a metadata-only
        # step) then leaves a drop made while the pipeline was stopped to its next read.
        first_read = checkpoint.get("pipeline_scope") != pipeline_scope
        update_layout = fingerprint if first_read else checkpoint.get("update_fingerprint")
        if checkpoint_fingerprint != fingerprint:
            (
                _previous_table,
                transition_table,
                transition_lsn,
                transition_schema_id,
            ) = self._schema_transition(
                table,
                checkpoint_schema_id,
                int(checkpoint["commit_lsn"]),
                owner=not deletes,
                # An incremental copy still in progress keeps its chunk position in the
                # offset, laid out by the old key, so a wildcard key may only grow once
                # the copy has finished and dropped that block.
                allow_key_extension=not isinstance(checkpoint.get("incremental"), dict),
                # Every offset records the update that wrote it, so a checkpoint from an
                # earlier update marks this update's first read: the destination's merge
                # key was read at its start and already reflects a dropped column.
                new_update=first_read or update_layout == fingerprint,
            )
            # Informix capture registration is a projection, not a raw decoder
            # tied to the catalog layout at ``start_lsn``.  For an appended
            # nullable column, registering the expanded descriptor at the old
            # checkpoint safely spans the DDL: records written before the ALTER
            # contain NULL for the appended field, while records written after
            # it contain the logged value.  Live Informix 15 validation covers
            # both transactions in one replay session.  The same holds for the
            # other changes _ensure_compatible_schema_change accepts: live
            # Informix 14.10 returned records logged before a CHAR/VARCHAR
            # widening, numeric widenings (SMALLINT/INTEGER -> BIGINT/INT8, a
            # widened key included, SMALLFLOAT -> FLOAT, DECIMAL and MONEY
            # precision), and a column drop in the current layout, so they decode
            # with the new descriptor.
            #
            # Previously this method captured with the predecessor descriptor
            # only up to a restart-time ``current_lsn`` and then advanced the
            # checkpoint to that sampled boundary.  A transaction committed
            # after the DDL but before restart could fall on the wrong side of
            # that artificial boundary and be skipped.  Schema history is still
            # published above so the independently checkpointed delete reader
            # selects the same successor generation, but it is not a data
            # boundary: replay the successor projection from the retained Spark
            # checkpoint itself.
            capture_table = transition_table
            capture_schema_id = transition_schema_id
            transition_lsn = None
            projection_schema_transition = True
        max_rows = self._table_int_option(
            options, "max.records.per.batch", _DEFAULT_MAX_RECORDS_PER_BATCH, minimum=1
        )
        stop_lsn: int | None = None
        trigger_high_water: int | None = None
        trigger_generation: str | None = None
        # A replay reproduces a committed [start, end) range bounded by its end offset
        # (``replay_stop`` below). It must NOT consult the shared trigger boundary: that
        # boundary is published per update scope by the upsert (owner) reader, so after a
        # driver restart a replay -- planned in a fresh scope -- finds no boundary for the
        # replayed generation, and the delete (non-owner) reader's _shared_trigger_boundary
        # raises TriggerBoundaryUnavailable, which is fatal inside get_partitions
        # (planPartitions has no latestOffset retry). The replay's own committed end LSN is
        # the correct stop and is applied below, so skip the live handshake while replaying.
        # A normal (non-replay) read has no replay stop and takes the boundary as before.
        replay_stop = self._replay_stop_lsn(options)
        if replay_stop is None:
            self._settle_spilled_runs(table, checkpoint, options, deletes)
        if self._trigger_available_now and replay_stop is None:
            stop_lsn, trigger_generation = self._shared_trigger_boundary(
                table,
                checkpoint,
                owner=not deletes,
                current_lsn=shared_view.current_lsn if shared_view is not None else None,
            )
            trigger_high_water = stop_lsn
        if transition_lsn is not None:
            stop_lsn = transition_lsn if stop_lsn is None else min(stop_lsn, transition_lsn)
        # A replay must land on the offset Spark already committed, so it reads to
        # that LSN and stops there -- the same bounded read the trigger boundary
        # above performs, reached through the one channel the connector owns.
        #
        # Without a bound a replay is not reproducible: the read stops at whichever
        # transaction boundary the row budget happens to fall on, so the same start
        # LSN over the same log can end in different places. Measured directly --
        # budget 10 ended at LSN 107, budget 2 at 104, identical data. The framework
        # discards the offset a replay reaches and commits its own `end` regardless,
        # so an unbounded short read silently drops everything in between; that is
        # how six tables lost 151 rows. Bounding the read removes the divergence at
        # its source rather than detecting it afterwards, which is all a comparison
        # could do -- and failing there just turns lost rows into a retry loop,
        # because the next attempt is no more reproducible than the last.
        # (``replay_stop`` was resolved above, before the trigger-boundary block.)
        if replay_stop is not None:
            stop_lsn = replay_stop if stop_lsn is None else min(stop_lsn, replay_stop)
            # The committed range may hold more rows than a normal batch admits, and
            # truncating it is the very divergence being removed. The LSN bound caps
            # the read instead, so the budget must not also cut it short.
            max_rows = _REPLAY_UNBOUNDED_ROWS
        past_step = projection_schema_transition and (
            _schema_fingerprint(capture_table) != fingerprint
        )
        if shared_view is not None:
            # The daemon already assembled and fanned out this shard's transactions and
            # re-validated the schema; take them as-is (no Informix I/O, no re-fetch).
            committed, caught_up, open_begin, reached = (
                shared_view.committed,
                shared_view.caught_up,
                shared_view.open_begin,
                shared_view.reached_lsn,
            )
        elif (past_step and replay_stop is None) or (
            replay_stop is not None and replay_stop <= int(checkpoint["commit_lsn"])
        ):
            # A step to a generation the live schema has moved past: commit its schema and
            # read nothing under it. Its columns are not the live ones -- a column added
            # since would go uncaptured in every change read here, and one dropped since
            # cannot be captured -- so the changes wait for the step to the live schema,
            # which captures them with the live layout from this same position. A replay
            # that ends where it starts (such a step, or a metadata-only step to the live
            # schema) has no transaction to read either: none commits after its start and
            # at or before its stop.
            committed, caught_up, open_begin, reached = [], False, None, None
        else:
            # A replay of a step that read changes reads its committed range, every change
            # of which was committed while the step's generation was live. It captures with
            # the live layout, which spans the ALTERs since, and is shaped by it below.
            raw_records = self._read_changes_with_reconnect(
                [
                    _capture_descriptor(
                        table if past_step else capture_table, _client_encoding(self.options)
                    )
                ],
                restart,
                self._table_int_option(options, "cdc.timeout", 5, minimum=1),
                self._table_int_option(
                    options, "cdc.max.records", _DEFAULT_CDC_MAX_RECORDS, minimum=1, maximum=256
                ),
                table=table,
            )
            table = self._refresh_table_schema(table, fingerprint)
            committed, caught_up, open_begin, reached = _transaction_batch(raw_records)
        recovered = _recover(committed, checkpoint)
        output: list[dict[str, Any]] = []
        end = dict(start)
        end["pipeline_scope"] = pipeline_scope
        if projection_schema_transition:
            # A metadata-only poll still has to commit the successor schema so
            # Spark can evolve the target before the next batch.  Keep every
            # positional field unchanged: schema discovery is not evidence that
            # CDC reached a newer LSN.
            end["schema_id"] = capture_schema_id
            end["schema_fingerprint"] = _schema_fingerprint(capture_table)
        consumed = 0
        crossed_transition = False
        crossed_trigger_boundary = False
        # Set when the row budget, rather than the end of the log, ended this read.
        # It is the one proof a reader has that work remains for *this* table, so
        # it is what the backlog rank is built from.
        row_budget_reached = False
        # Delete handling on the upsert channel follows the destination. A keyed table's
        # upsert view merges every row it receives, so its DELETEs are skipped here and
        # applied only through the separate delete channel (``deletes=True``). An append
        # destination lands rows as-is and never reads _informix_op, so a DELETE on the
        # append path is emitted as a full-before-image ``d`` tombstone unless the
        # operator switched tombstones off for this table. So is the old key of a
        # key-changing UPDATE on a keyed table forced to append. A transaction is never
        # split across batches, so such a tombstone always ships with its ``u`` row.
        # Shaped by the generation the read captured, which a reader a step behind the live
        # schema registers (capture_table): the live table can key or type a column the
        # captured records lack. A schema record keeps the table's options, filter and
        # transforms included, so the projection loses none of them. A replay of a step
        # the live schema moved past captured with the live layout, and this update's
        # destination keys by it: the step's own key can name a column dropped since.
        shape_table = table if past_step else capture_table
        tombstones = (
            not deletes
            and self._append_only_table(shape_table, options)
            and self._append_delete_tombstones(options)
        )
        for tx in recovered:
            if transition_lsn is not None and tx.commit_lsn > transition_lsn:
                if tx.begin_lsn < transition_lsn:
                    # 285: Transaction {} spans schema transition LSN {} for '{}'; keep source
                    # writes quiesced until schema transition completes or run a full refresh
                    raise InformixError(_m(285, tx.tx_id, transition_lsn, table.exposed_name))
                crossed_transition = True
                break
            if stop_lsn is not None and tx.commit_lsn > stop_lsn:
                crossed_trigger_boundary = True
                break
            spilled = [part for part in tx.spilled if _record_matches(part, shape_table)]
            if spilled:
                self._note_spilled_runs(spilled, tx, deletes)
            if deletes:
                # The delete channel shapes nothing from a run of inserts: it skips its pages.
                spilled = [
                    part
                    for part in spilled
                    if part.get("ops") is None or _SPILL_DELETE_OPS.intersection(part["ops"])
                ]
            elif not tombstones:
                # Nor does an upsert channel without tombstones from a run of DELETEs. A
                # TRUNCATE is not a DELETE, so it still reaches the shaping that rejects it.
                spilled = [part for part in spilled if part.get("ops") != ["DELETE"]]
            if spilled and output:
                # A spilled transaction is a batch of its own: it waits for the next one.
                row_budget_reached = True
                break
            projected = _project_transaction(
                tx,
                shape_table,
                deletes,
                tombstones=tombstones,
                encoding=self._source_encoding(options),
            )
            projected = [
                _coerce_variable_decimal_values(row, shape_table, options) for row in projected
            ]
            # Never split a transaction.  A single large transaction is
            # accepted; subsequent complete transactions wait for next poll.
            if output and len(output) + len(projected) > max_rows:
                row_budget_reached = True
                break
            output.extend(projected)
            consumed += 1
            end = _offset(
                tx.commit_lsn,
                tx.commit_lsn,
                tx.restart_lsn,
                tx.tx_id,
                "stream",
                capture_table,
                capture_schema_id,
                pipeline_scope,
                trigger_generation=checkpoint.get("trigger_generation"),
                trigger_high_water=checkpoint.get("trigger_high_water"),
            )
            if spilled:
                # Its changes stay on the staged pages until the batch is served. All of
                # them went there once it spilled, so nothing was projected above.
                output = _SpilledRows(
                    self._stream_staged_page_for,
                    spilled,
                    tx,
                    shape_table,
                    options,
                    deletes=deletes,
                    tombstones=tombstones,
                    encoding=self._source_encoding(options),
                )
                # Work remains for this table only if a transaction follows it.
                row_budget_reached = tx is not recovered[-1]
                break
            if len(output) >= max_rows:
                row_budget_reached = True
                break
        if (
            transition_lsn is not None
            and crossed_transition
            and open_begin is not None
            and open_begin < transition_lsn
        ):
            # 286: An open transaction beginning at LSN {} spans schema transition LSN {} for '{}';
            # keep source writes quiesced until schema transition completes or run a full refresh
            raise InformixError(_m(286, open_begin, transition_lsn, table.exposed_name))
        if (
            transition_lsn is not None
            and (trigger_high_water is None or transition_lsn <= trigger_high_water)
            and (
                (caught_up and consumed == len(recovered))
                or (crossed_transition and (open_begin is None or open_begin >= transition_lsn))
            )
        ):
            end = _offset(
                transition_lsn,
                transition_lsn,
                transition_lsn,
                None,
                "stream",
                transition_table,
                transition_schema_id,
                pipeline_scope,
                trigger_generation=checkpoint.get("trigger_generation"),
                trigger_high_water=checkpoint.get("trigger_high_water"),
            )
        drained = (
            caught_up
            and open_begin is None
            and consumed == len(recovered)
            and not crossed_transition
        )
        # Caught up only counts once Informix's log reader is past the frozen boundary:
        # a poll can go idle short of it, and stopping there would leave the changes in
        # between for a later update. An unknown position keeps the old reading.
        reached_trigger_boundary = trigger_generation is not None and (
            crossed_trigger_boundary
            or (drained and (reached is None or reached >= trigger_high_water))
        )
        # A triggered or replayed read that went idle with nothing left to emit moves its
        # checkpoint to where the log reader stopped (capped at the read's bound), so the
        # next read continues from there rather than rescanning -- and, below the
        # boundary, so AvailableNow sees progress and keeps reading. Everything this
        # table needs up to that position was delivered: an open transaction keeps the
        # offset at its BEGIN instead (drained is False), and Informix delivers a
        # transaction's BEGIN with its first captured change, as the commit-based
        # offsets above already rely on. A continuous read keeps its checkpoint: idle
        # polls there would otherwise each become an empty microbatch.
        quiet_bound = None
        if trigger_high_water is not None:
            quiet_bound = trigger_high_water
        if replay_stop is not None:
            quiet_bound = replay_stop if quiet_bound is None else min(quiet_bound, replay_stop)
        if (
            quiet_bound is not None
            and drained
            and reached is not None
            and transition_lsn is None
            # A metadata-only step keeps its position for Spark to evolve the target first;
            # a replay's end is already logged, so it lands there through a step too.
            and (not projection_schema_transition or replay_stop is not None)
            and min(reached, quiet_bound) > int(end["commit_lsn"])
        ):
            quiet = min(reached, quiet_bound)
            end = _offset(
                quiet,
                quiet,
                quiet,
                None,
                "stream",
                capture_table,
                capture_schema_id,
                pipeline_scope,
                trigger_generation=checkpoint.get("trigger_generation"),
                trigger_high_water=checkpoint.get("trigger_high_water"),
            )
        # A replay of a range whose original read went idle lands on that idle end even
        # when the log has since moved on. The replay then delivers a commit beyond its
        # bound instead of going idle, so it is not drained, but the crossing commit
        # proves the log reader passed the bound, and every transaction committed below
        # it was consumed in commit order before the loop broke. A transaction still open
        # with its BEGIN below the bound keeps the replay short, as before: the original
        # read went idle with nothing open, so the replay cannot account for it, and a
        # retry lands once it commits. _replay_between_offsets refuses this landing for
        # an end that names a transaction the replay did not reach.
        if (
            replay_stop is not None
            and crossed_trigger_boundary
            and transition_lsn is None
            and (open_begin is None or open_begin >= replay_stop)
            and replay_stop > int(end["commit_lsn"])
        ):
            end = _offset(
                replay_stop,
                replay_stop,
                replay_stop,
                None,
                "stream",
                capture_table,
                capture_schema_id,
                pipeline_scope,
                trigger_generation=checkpoint.get("trigger_generation"),
                trigger_high_water=checkpoint.get("trigger_high_water"),
            )
        if reached_trigger_boundary:
            end = dict(end)
            end["trigger_generation"] = trigger_generation
            end["trigger_high_water"] = str(trigger_high_water)
        if update_layout is not None:
            end["update_fingerprint"] = update_layout
        end = _with_backlog_streak(end, start, row_budget_reached)
        return iter(output), end

    def _record_current_schema(
        self,
        table: Table,
        checkpoint_lsn: int,
        checkpoint_schema_id: str,
        checkpoint_fingerprint: str,
        pipeline_scope: str,
        *,
        owner: bool,
    ) -> None:
        if not owner:
            return
        existing = self._read_immutable_head(
            self._immutable_namespace(table, "schema-nodes", checkpoint_schema_id)
        )
        if existing is not None:
            self._validate_immutable_record_header(existing, "schema-node", table.exposed_name)
            schema = existing.get("schema")
            predecessor = schema.get("predecessor") if isinstance(schema, dict) else None
            if (
                not isinstance(schema, dict)
                or schema.get("id") != checkpoint_schema_id
                or schema.get("fingerprint") != checkpoint_fingerprint
                or checkpoint_fingerprint != _schema_fingerprint(table)
                or (
                    predecessor is not None
                    and (
                        not isinstance(predecessor, str)
                        or not re.fullmatch(r"[0-9a-f]{32}", predecessor)
                    )
                )
            ):
                # 287: Checkpoint schema {} conflicts with immutable history for '{}'
                raise InformixError(_m(287, checkpoint_schema_id, table.exposed_name))
            if (
                _table_from_schema_state(schema, table.database).native_identity
                != table.native_identity
            ):
                # 288: Invalid immutable schema-node state for '{}'
                raise InformixError(_m(288, table.exposed_name))
            return
        minimum, current = self._bridge.minimum_lsn(), self._bridge.current_lsn()
        if not minimum <= checkpoint_lsn <= current:
            # 289: Cannot rebuild immutable schema state for '{}' from checkpoint LSN {};
            # retained/current range is [{}, {}]
            raise InformixError(_m(289, table.exposed_name, checkpoint_lsn, minimum, current))
        self._bridge.validate_initial_lsn(
            _capture_descriptor(table, _client_encoding(self.options)), checkpoint_lsn
        )
        authoritative = self._find_immutable_schema_record(
            table, checkpoint_schema_id, pipeline_scope
        )
        if authoritative is None:
            if checkpoint_fingerprint != _schema_fingerprint(table):
                # 290: Schema history for checkpoint node {} is missing for '{}' and cannot be
                # reconstructed after a schema change; run a full refresh
                raise InformixError(_m(290, checkpoint_schema_id, table.exposed_name))
            authoritative = {
                "created_at": time.time(),
                "schema": _schema_state(table, checkpoint_lsn, schema_id=checkpoint_schema_id),
            }
        # Schema nodes are global for a physical table and schema ID. Pipeline
        # scope belongs to initialization/trigger records, not this shared node.
        authoritative = {
            "created_at": authoritative.get("created_at", time.time()),
            "schema": authoritative["schema"],
        }
        winner = self._publish_immutable_head(
            self._immutable_namespace(table, "schema-nodes", checkpoint_schema_id),
            authoritative,
            record_type="schema-node",
        )
        self._validate_immutable_record_header(winner, "schema-node", table.exposed_name)
        schema = winner.get("schema")
        if (
            not isinstance(schema, dict)
            or schema.get("id") != checkpoint_schema_id
            or _table_from_schema_state(schema, table.database).native_identity
            != table.native_identity
            or schema.get("fingerprint") != _schema_fingerprint(table)
        ):
            # 287: Checkpoint schema {} conflicts with immutable history for '{}'
            raise InformixError(_m(287, checkpoint_schema_id, table.exposed_name))

    def _shared_trigger_boundary(
        self,
        table: Table,
        checkpoint: dict[str, Any],
        *,
        owner: bool,
        current_lsn: int | None = None,
    ) -> tuple[int, str]:
        # One pipeline update owns exactly one immutable per-table boundary.
        # Upsert and delete checkpoints may legitimately have different prior
        # generations after retries or cancellation, so predecessor identity
        # must not partition their current-update coordination.
        scope = self._pipeline_scope(checkpoint)
        cached = self._trigger_boundaries.get(table.identity)
        if cached is not None:
            high_water, generation, cached_scope = cached
            if cached_scope == scope:
                # Once Spark checkpoints this trigger's generation it invokes
                # latestOffset again to prove that AvailableNow is exhausted.
                # Keep returning the same frozen boundary in this reader
                # instance; a new pipeline update constructs a new reader and
                # legitimately advances from generation as its predecessor.
                if high_water < int(checkpoint.get("commit_lsn", 0)):
                    # 291: Cached trigger boundary {} precedes checkpoint LSN {} for '{}'
                    raise InformixError(
                        _m(291, high_water, checkpoint.get("commit_lsn"), table.exposed_name)
                    )
                return high_water, generation
            self._trigger_boundaries.pop(table.identity, None)
        namespace = self._immutable_namespace(table, "triggers", "scopes", scope)
        deadline = time.monotonic() + int(
            self.options.get("cdc.shared.state.wait.seconds", str(_SHARED_STATE_WAIT_SECONDS))
        )
        delay = 0.1
        while True:
            trigger = self._read_immutable_head(namespace)
            if isinstance(trigger, dict):
                self._validate_immutable_record_header(trigger, "trigger", table.exposed_name)
                generation = trigger.get("generation")
                try:
                    high_water = self._immutable_lsn(trigger, "high_water", table.exposed_name)
                except InformixError as error:
                    # 292: Invalid shared trigger boundary for '{}'
                    raise InformixError(_m(292, table.exposed_name)) from error
                if not isinstance(generation, str) or not re.fullmatch(r"[0-9a-f]{32}", generation):
                    # 293: Invalid shared trigger generation for '{}'
                    raise InformixError(_m(293, table.exposed_name))
                if trigger.get("scope") != scope or high_water < int(
                    checkpoint.get("commit_lsn", 0)
                ):
                    # 294: Invalid immutable trigger identity for '{}'
                    raise InformixError(_m(294, table.exposed_name))
                self._trigger_boundaries[table.identity] = (
                    high_water,
                    generation,
                    scope,
                )
                return high_water, generation
            if owner:
                candidate_high_water = (
                    current_lsn if current_lsn is not None else self._bridge.current_lsn()
                )
                if candidate_high_water < int(checkpoint["commit_lsn"]):
                    # 295: Current LSN {} precedes checkpoint LSN {} for '{}'
                    raise InformixError(
                        _m(295, candidate_high_water, checkpoint["commit_lsn"], table.exposed_name)
                    )
                self._publish_immutable_head(
                    namespace,
                    {
                        "created_at": time.time(),
                        "generation": secrets.token_hex(16),
                        "high_water": str(candidate_high_water),
                        "scope": scope,
                    },
                    record_type="trigger",
                )
                if time.monotonic() >= deadline:
                    # 296: Timed out waiting for the upsert reader to publish a triggered boundary
                    # for '{}' in update scope '{}'
                    raise InformixError(_m(296, table.exposed_name, scope))
                delay = _sleep_with_backoff(deadline, delay)
                continue
            # 297: The upsert reader has not published the triggered boundary for '{}' in update
            # scope '{}' yet
            raise TriggerBoundaryUnavailable(_m(297, table.exposed_name, scope))

    def _ensure_recorded_path_to_live(
        self, table: Table, node_table: Table, node_id: str, rules: dict[str, Any]
    ) -> None:
        # Docstring: Check the steps a reader takes from a step's target on to the live layout.
        #
        # A reader that steps to a generation the live schema has moved past takes the rest
        # one recorded step at a time, so they are checked that way here: a whole-row key
        # may make only a drop or an add in one step, and the target and the live layout can
        # differ by both. Where the recorded history ends short of the live layout, the
        # owner records the rest as one step, so the last node is checked against it, with
        # the default check that step gets when a column joins the key. A record that is
        # not a valid successor fails as the step would, and so does history that loops
        # (layout-only ids recorded before transition ids hashed their predecessor); one
        # running past the bound is checked against the live layout from where it stopped.

        live = _schema_fingerprint(table)
        seen: set[str] = set()
        while _schema_fingerprint(node_table) != live:
            if node_id in seen:
                # No node of a loop is left without a recorded successor, so a reader steps
                # around it forever and never reaches the live layout.
                # 425: Informix schema history for '{}' returns to node {} without reaching the
                # live layout; run a full refresh
                raise InformixError(_m(425, table.exposed_name, node_id))
            if len(seen) >= _MAX_SCHEMA_DESCENT:
                break
            seen.add(node_id)
            record = self._read_immutable_head(self._immutable_namespace(table, "schemas", node_id))
            successor = None
            if record is not None:
                self._validate_immutable_record_header(
                    record, "schema-transition", table.exposed_name
                )
                successor = record.get("schema")
                if not isinstance(successor, dict):
                    # 300: Invalid immutable Informix schema transition
                    raise InformixError(_m(300))
                if (
                    not re.fullmatch(r"[0-9a-f]{32}", str(successor.get("id")))
                    or successor.get("predecessor") != node_id
                ):
                    # 302: Invalid immutable schema identity for '{}'
                    raise InformixError(_m(302, table.exposed_name))
            following = (
                None if successor is None else _table_from_schema_state(successor, table.database)
            )
            # rules: the wildcard-key growth and shrink the caller allows.
            _ensure_compatible_schema_change(
                node_table, following or table, wildcard_except=table.key_wildcard_except, **rules
            )
            if following is None:
                if set(table.primary_keys) - set(node_table.primary_keys):
                    self._ensure_added_key_columns_have_no_default(node_table, table)
                return
            node_table, node_id = following, str(successor["id"])
        else:
            return
        _ensure_compatible_schema_change(
            node_table, table, wildcard_except=table.key_wildcard_except, **rules
        )
        if set(table.primary_keys) - set(node_table.primary_keys):
            self._ensure_added_key_columns_have_no_default(node_table, table)

    def _schema_transition(
        self,
        table: Table,
        checkpoint_schema_id: str,
        checkpoint_lsn: int,
        *,
        owner: bool,
        allow_key_extension: bool = False,
        new_update: bool = False,
    ) -> tuple[Table, Table, int, str]:
        # A wildcard key may grow by the appended columns, and on the first read of a new
        # update shrink by the dropped ones (see _PRIMARY_KEYS_WILDCARD).
        extend_key = allow_key_extension and table.key_wildcard
        shrink_key = extend_key and new_update
        namespace = self._immutable_namespace(table, "schemas", checkpoint_schema_id)
        deadline = time.monotonic() + int(
            self.options.get("cdc.shared.state.wait.seconds", str(_SHARED_STATE_WAIT_SECONDS))
        )
        delay = 0.1
        while True:
            previous_record = self._read_immutable_head(
                self._immutable_namespace(table, "schema-nodes", checkpoint_schema_id)
            )
            previous = previous_record.get("schema") if previous_record else None
            if not isinstance(previous, dict):
                # 298: Schema history for checkpoint node {} is missing for '{}'; run a full refresh
                raise InformixError(_m(298, checkpoint_schema_id, table.exposed_name))
            self._validate_immutable_record_header(
                previous_record, "schema-node", table.exposed_name
            )
            if previous.get("id") != checkpoint_schema_id:
                # 299: Immutable schema node identity mismatch for '{}'
                raise InformixError(_m(299, table.exposed_name))
            previous_table = _table_from_schema_state(previous, table.database)
            transition_record = self._read_immutable_head(namespace)
            if transition_record is None:
                # No step recorded yet: the owner records one straight to the live schema.
                # A recorded step is checked below one step at a time instead, so a reader
                # a generation behind is not refused a drop and an add the pipeline ran
                # between, as each step may make only one of them.
                try:
                    _ensure_compatible_schema_change(
                        previous_table,
                        table,
                        extend_wildcard_key=extend_key,
                        shrink_wildcard_key=shrink_key,
                        wildcard_except=table.key_wildcard_except,
                    )
                except InformixError as error:
                    if owner:
                        # The delete reader can pass this check (no incremental copy in its
                        # offset, or its own first read of the update) and would wait for a
                        # step that never comes: it fails with this error instead.
                        self._publish_schema_rejection(table, checkpoint_schema_id, error)
                    raise
            if transition_record is None and owner:
                try:
                    if set(table.primary_keys) - set(previous_table.primary_keys):
                        # The key grew: only safe when existing rows really hold NULL in
                        # the new columns at the source, as they will in the target. A
                        # key that shrank needs no check: the dropped columns leave it.
                        self._ensure_added_key_columns_have_no_default(previous_table, table)
                    transition = self._bridge.current_lsn()
                    if transition < checkpoint_lsn:
                        # 295: Current LSN {} precedes checkpoint LSN {} for '{}'
                        raise InformixError(_m(295, transition, checkpoint_lsn, table.exposed_name))
                    self._bridge.validate_initial_lsn(
                        _capture_descriptor(table, _client_encoding(self.options)),
                        transition,
                    )
                except InformixError as error:
                    # The delete reader waits for this transition; record why it won't
                    # come, so that reader fails with this error instead of waiting.
                    # Transient failures (socket timeouts) aren't InformixError and
                    # leave nothing behind.
                    self._publish_schema_rejection(table, checkpoint_schema_id, error)
                    raise
                node = _schema_state(table, transition, predecessor=checkpoint_schema_id)
                transition_record = self._publish_immutable_head(
                    namespace,
                    {"created_at": time.time(), "schema": node},
                    record_type="schema-transition",
                )
            if transition_record is not None:
                self._schema_transition_waits.pop((table.identity, checkpoint_schema_id), None)
                self._validate_immutable_record_header(
                    transition_record, "schema-transition", table.exposed_name
                )
                current = transition_record.get("schema")
                if not isinstance(current, dict):
                    # 300: Invalid immutable Informix schema transition
                    raise InformixError(_m(300))
                transition = self._immutable_lsn(current, "start_lsn", table.exposed_name)
                minimum, now = self._bridge.minimum_lsn(), self._bridge.current_lsn()
                if not minimum <= transition <= now:
                    # 301: Schema transition LSN {} for '{}' is outside retained/current range [{},
                    # {}]
                    raise InformixError(_m(301, transition, table.exposed_name, minimum, now))
                # The transition LSN records when this immutable successor was
                # first observed; it is not a replay boundary.  Another update
                # can therefore retain the transition after this checkpoint has
                # advanced beyond that observation.  The identity and additive
                # successor checks below make it safe to adopt the metadata while
                # continuing replay from checkpoint_lsn.
                target_table = _table_from_schema_state(current, table.database)
                if (
                    not isinstance(current.get("id"), str)
                    or not re.fullmatch(r"[0-9a-f]{32}", str(current["id"]))
                    or current.get("predecessor") != checkpoint_schema_id
                ):
                    # 302: Invalid immutable schema identity for '{}'
                    raise InformixError(_m(302, table.exposed_name))
                _ensure_compatible_schema_change(
                    previous_table,
                    target_table,
                    extend_wildcard_key=extend_key,
                    shrink_wildcard_key=shrink_key,
                    wildcard_except=table.key_wildcard_except,
                )
                self._ensure_recorded_path_to_live(
                    table,
                    target_table,
                    str(current["id"]),
                    {"extend_wildcard_key": extend_key, "shrink_wildcard_key": shrink_key},
                )
                schema_winner = self._publish_immutable_head(
                    self._immutable_namespace(table, "schema-nodes", str(current["id"])),
                    transition_record,
                    record_type="schema-node",
                )
                self._validate_schema_node_winner(schema_winner, current, table)
                return previous_table, target_table, transition, str(current["id"])
            if not owner:
                # Never wait here while holding a connection slot. Reaching this
                # method already acquired one (the schema refresh in _read_stream
                # connects before this call), so a delete reader that slept until
                # the deadline would occupy a slot for the whole wait while doing
                # no source work -- and the upsert reader it is waiting for needs
                # a slot of its own to publish (current_lsn above). Because both
                # channels can claim every slot, enough waiting delete readers hold
                # the entire pool and the publication can never happen: a genuine deadlock,
                # broken only by this deadline expiring and failing the flow.
                #
                # Yield instead, exactly as the other two non-owner coordination
                # points do (_shared_table_lsn returns None via wait=False, and
                # _shared_trigger_boundary raises TriggerBoundaryUnavailable). The
                # caller converts this into an unchanged-offset empty batch, which
                # releases the slot and lets the owning upsert reader acquire one.
                #
                # Fail with the upsert reader's own error where it refused the change
                # before publishing, or this reader would wait for a transition that
                # never comes. A published transition wins over a refusal, read first
                # above: an upsert retry in the same update may have succeeded since.
                refusal = self._schema_rejection(table, checkpoint_schema_id)
                if refusal is not None:
                    # 303: The upsert reader refused the schema change for '{}': {}
                    raise InformixError(_m(303, table.exposed_name, refusal))
                self._ensure_schema_transition_wait_bounded(table, checkpoint_schema_id)
                # 304: The upsert reader has not published the schema transition for '{}' from
                # schema node {} yet
                raise SchemaTransitionUnavailable(_m(304, table.exposed_name, checkpoint_schema_id))
            if time.monotonic() >= deadline:
                # 305: Timed out waiting for the upsert reader to publish schema transition state
                # for '{}'
                raise InformixError(_m(305, table.exposed_name))
            delay = _sleep_with_backoff(deadline, delay)

    def _schema_rejection_namespace(self, table: Table, checkpoint_schema_id: str) -> str | None:
        # Docstring: Where an update's upsert reader records refusing a schema change.
        #
        # Scoped to the update: the next one may succeed where this one failed (the cause
        # fixed, or a refusal that no longer holds), so its delete reader must not inherit
        # the refusal. Without a registration scope the two readers share no update, and
        # the delete reader falls back to its bounded wait.

        scope = self._registration_scope
        if not isinstance(scope, str) or _PIPELINE_SCOPE.fullmatch(scope) is None:
            return None
        return self._immutable_namespace(
            table, "schema-rejections", "scopes", scope, checkpoint_schema_id
        )

    def _publish_schema_rejection(
        self, table: Table, checkpoint_schema_id: str, error: Exception
    ) -> None:
        # Docstring: Record the upsert reader's refusal of a schema change; best effort.
        #
        # The refusal itself fails the upsert flow either way; if it can't be recorded,
        # the delete reader still stops at its bounded wait.

        namespace = self._schema_rejection_namespace(table, checkpoint_schema_id)
        if namespace is None:
            return
        try:
            self._publish_immutable_head(
                namespace,
                {"created_at": time.time(), "error": str(error)},
                record_type="schema-rejection",
            )
        except Exception as publish_error:  # pylint: disable=broad-except
            # 306: Could not record that the upsert reader refused the schema change for {}: {}
            logging.getLogger(__name__).warning(
                _m(306, table.exposed_name, publish_error),
            )

    def _schema_rejection(self, table: Table, checkpoint_schema_id: str) -> str | None:
        # Docstring: This update's recorded refusal of the schema change, if any.

        namespace = self._schema_rejection_namespace(table, checkpoint_schema_id)
        if namespace is None:
            return None
        record = self._read_immutable_head(namespace)
        if record is None:
            return None
        self._validate_immutable_record_header(record, "schema-rejection", table.exposed_name)
        return str(record.get("error") or "no reason was recorded")

    def _triggered_wait_exceeded(self, key: tuple) -> int | None:
        # Docstring: The wait limit once a triggered reader has waited past it on ``key``.
        #
        # Measured from the first yield of the wait, at cdc.shared.state.wait.seconds; None
        # for a continuous update, which fails as a whole once the flow it waits on fails.

        if not self._trigger_available_now:
            return None
        started = self._schema_transition_waits.setdefault(key, time.monotonic())
        limit = int(
            self.options.get("cdc.shared.state.wait.seconds", str(_SHARED_STATE_WAIT_SECONDS))
        )
        return limit if time.monotonic() - started >= limit else None

    def _resnapshot_retry_offset(self, table: Table, start_offset: dict) -> dict:
        # Docstring: Yield while the upsert reader publishes the update's resnapshot boundary.
        #
        # Bounded in a triggered update, which ends only when every flow has: the upsert
        # reader's flow may have failed, or its own checkpoint is still retained while this
        # reader's is not, and then no boundary comes.

        limit = self._triggered_wait_exceeded((table.identity, "resnapshot"))
        if limit is not None:
            # 427: The upsert reader has not published a resnapshot boundary for '{}' in {}
            # seconds, so this update cannot finish: its flow has most likely failed (see its
            # error), or its checkpoint is still retained while the delete channel's is not, which
            # needs a full refresh
            raise InformixError(_m(427, table.exposed_name, limit))
        return self._trigger_boundary_retry_offset(start_offset)

    def _ensure_schema_transition_wait_bounded(
        self, table: Table, checkpoint_schema_id: str
    ) -> None:
        # Docstring: Fail a triggered delete reader that has waited too long for its upsert reader.
        #
        # A triggered update ends only when every flow has. If the upsert reader fails
        # before publishing the transition, its flow stops but this reader keeps yielding
        # empty batches, so the update never ends. A continuous update fails as a whole
        # once a flow fails, so only AvailableNow is bounded, at
        # cdc.shared.state.wait.seconds from the first yield. A healthy upsert reader
        # publishes on its first read after the change.

        limit = self._triggered_wait_exceeded((table.identity, checkpoint_schema_id))
        if limit is not None:
            # 307: The upsert reader has not published the schema transition for '{}' in {} seconds,
            # so this update cannot finish. Its flow has most likely failed: see its error, fix the
            # cause, and restart the pipeline
            raise InformixError(_m(307, table.exposed_name, limit))

    def _ensure_added_key_columns_have_no_default(self, previous: Table, current: Table) -> None:
        # Docstring: Fail closed when a column joining a wildcard key was added with a default.
        #
        # Existing rows would carry the default in their before-images at the source while
        # the target holds NULL for them, so their updates and deletes would never match.

        known = {column.name for column in previous.columns}
        joining = set(current.primary_keys)
        # Only the added columns that join the key: a "* except(...)" wildcard may leave one
        # out, and it then needs no NULL in existing rows to match by.
        added = [
            column.name
            for column in current.columns
            if column.name not in known and column.name in joining
        ]
        lookup = getattr(self._bridge, "column_defaults", None)
        if not callable(lookup):
            # 308: Cannot check the columns added to '{}' for defaults, so its {}='{}' key cannot
            # grow to include them; run a full refresh
            raise InformixError(
                _m(308, current.exposed_name, _PRIMARY_KEYS_OPTION, _PRIMARY_KEYS_WILDCARD)
            )
        with_default = lookup(current.identity, added)  # pylint: disable=not-callable
        if with_default:
            # 309: Column(s) {} were added to '{}' with a default and join its {}='{}' key. Existing
            # rows carry that default at the source but NULL in the target, so their updates and
            # deletes would not match; run a full refresh
            raise InformixError(
                _m(
                    309,
                    (", ".join(with_default)),
                    current.exposed_name,
                    _PRIMARY_KEYS_OPTION,
                    _PRIMARY_KEYS_WILDCARD,
                )
            )

    def _refresh_table_schema(self, table: Table, expected_fingerprint: str | None) -> Table:
        bare = Table.parse(self._bridge.get_table(table.identity), table.database)
        refreshed = bare
        # Keep the table options (and therefore the fingerprint) across a schema refresh
        # instead of reverting to the bare catalog table. A primary.keys override is only
        # carried when the caller was already overridden, so a genuine catalog key change
        # on a normal table is still detected as drift; its adopted key-index directions
        # come along, so a mixed-direction override keeps paging in its index order. A
        # wildcard key is every column, so it is re-expanded instead: an added column
        # joins the key, which the schema transition accepts for a streaming table.
        refreshed = _carry_table_options(refreshed, table)
        _ensure_materializable(refreshed)
        fingerprint = _schema_fingerprint(refreshed)
        if expected_fingerprint is not None and expected_fingerprint != fingerprint:
            # 243: Informix schema changed for '{}' during ingestion; run a full refresh before
            # reading additional snapshot or CDC records
            raise InformixError(_m(243, table.exposed_name))
        if self._tables is not None:
            # The cache holds catalog tables as read; _table applies the options per call.
            self._tables[table.exposed_name] = bare
        return refreshed

    def _table_int_option(
        self,
        table_options: dict[str, str],
        name: str,
        default: int,
        *,
        minimum: int,
        maximum: int | None = None,
    ) -> int:
        value = int(table_options.get(name, self.options.get(name, str(default))))
        if value < minimum:
            raise ValueError(f"Option '{name}' must be >= {minimum}")
        if maximum is not None and value > maximum:
            raise ValueError(f"Option '{name}' must be <= {maximum}")
        return value

    def _initial_lsn(
        self,
        table: Table,
        *,
        owner: bool = True,
        wait: bool = True,
        scope: str | None = None,
    ) -> int | None:
        # Docstring: Return one durable per-table boundary shared by upsert and delete readers.

        scope = scope or self._pipeline_scope()
        cache_key = (scope, table.identity)
        if cache_key not in self._snapshot_high_water:
            shared = self._shared_table_lsn(table, owner=owner, wait=wait, scope=scope)
            if shared is None:
                return None
            value, schema_id = shared
            minimum = self._bridge.minimum_lsn()
            if value < minimum:
                # 310: Configured initial LSN {} is older than minimum retained LSN {}; choose a
                # retained boundary after enabling full-row logging
                raise LogRetentionError(_m(310, value, minimum))
            current = self._bridge.current_lsn()
            if value > current:
                # 311: Configured initial LSN {} is newer than current Informix LSN {}; choose a
                # position captured after enabling full-row logging
                raise InformixError(_m(311, value, current))
            self._snapshot_high_water[cache_key] = value
            self._snapshot_schema_ids[cache_key] = schema_id
        return self._snapshot_high_water[cache_key]

    def _publish_upsert_channel_start(
        self,
        table: Table,
        start_lsn: int,
        schema_id: str,
        fingerprint: str,
        scope: str,
    ) -> None:
        # Docstring: Publish the upsert reader's effective start for an unseeded delete flow.
        #
        # Lakeflow checkpoints the upsert and delete flows independently.  The
        # incoming upsert offset is the only authoritative evidence of where a
        # resumed update starts; source ``current_lsn`` and global schema history
        # can both be later. A later poll can discover an older open transaction,
        # so publishers atomically lower the shared boundary and never raise it.

        namespace = self._immutable_namespace(table, "channel-starts", scope, "upsert")
        winner = self._state_op_with_reconnect(
            lambda: publish_minimum_lsn_state_record(
                self._lakebase_connection(),
                self._lakebase_state_namespace(),
                namespace,
                {
                    "created_at": time.time(),
                    "fingerprint": fingerprint,
                    "format_version": _IMMUTABLE_STATE_VERSION,
                    "record_type": "channel-start",
                    "schema_id": schema_id,
                    "scope": scope,
                    "start_lsn": str(start_lsn),
                    "table": table.native_identity,
                },
                record_type="channel-start",
            ),
            operation="upsert channel-start publish",
        )
        self._validate_immutable_record_header(winner, "channel-start", table.exposed_name)
        winner_start = self._immutable_lsn(winner, "start_lsn", table.exposed_name)
        same_position_schema_change = winner_start == start_lsn and (
            winner.get("schema_id") != schema_id or winner.get("fingerprint") != fingerprint
        )
        compatible_successor = same_position_schema_change and self._schema_descends_from(
            table, schema_id, fingerprint, winner.get("schema_id")
        )
        if (
            winner.get("scope") != scope
            or winner.get("table") != table.native_identity
            or winner_start > start_lsn
            or (same_position_schema_change and not compatible_successor)
        ):
            # 312: Conflicting Informix upsert start boundary for '{}' in update scope '{}'
            raise InformixError(_m(312, table.exposed_name, scope))

    def _schema_descends_from(
        self,
        table: Table,
        schema_id: str,
        fingerprint: str,
        ancestor_id: Any,
    ) -> bool:
        # Docstring: Return whether a schema node safely replaces one at the same position.
        #
        # A reader can step more than once without moving (metadata-only steps while no
        # change commits), so the update's channel start keeps its first schema while the
        # reader holds a later one. Any node reached from it through recorded predecessors
        # is a step the delete flow takes the same way once it seeds there.

        if not isinstance(ancestor_id, str):
            return False
        current, expected_fingerprint, seen = schema_id, fingerprint, set()
        while current not in seen and len(seen) < _MAX_SCHEMA_DESCENT:
            seen.add(current)
            record = self._read_immutable_head(
                self._immutable_namespace(table, "schema-nodes", current)
            )
            schema = record.get("schema") if isinstance(record, dict) else None
            if not isinstance(schema, dict) or schema.get("id") != current:
                return False
            if (
                expected_fingerprint is not None
                and schema.get("fingerprint") != expected_fingerprint
            ):
                return False
            predecessor = schema.get("predecessor")
            if predecessor == ancestor_id:
                return True
            if not isinstance(predecessor, str):
                return False
            current, expected_fingerprint = predecessor, None
        return False

    def _read_upsert_channel_start(self, table: Table, scope: str) -> tuple[int, str, str] | None:
        record = self._read_immutable_head(
            self._immutable_namespace(table, "channel-starts", scope, "upsert")
        )
        if record is None:
            return None
        self._validate_immutable_record_header(record, "channel-start", table.exposed_name)
        schema_id = record.get("schema_id")
        fingerprint = record.get("fingerprint")
        if (
            record.get("scope") != scope
            or record.get("table") != table.native_identity
            or not isinstance(schema_id, str)
            or not re.fullmatch(r"[0-9a-f]{32}", schema_id)
            or not isinstance(fingerprint, str)
            or not re.fullmatch(r"[0-9a-f]{64}", fingerprint)
        ):
            # 313: Invalid Informix upsert start boundary for '{}'
            raise InformixError(_m(313, table.exposed_name))
        return (
            self._immutable_lsn(record, "start_lsn", table.exposed_name),
            schema_id,
            fingerprint,
        )

    @staticmethod
    def _pipeline_id(scope: str) -> str:
        # Docstring: The stable pipeline identity within an update scope.
        #
        # A scope is ``<pipeline_id>_@_<update_id>``; the pipeline id is constant across
        # a pipeline's restarts (only the update id changes) yet distinct between
        # pipelines, which is exactly the key the delete-floor needs: it must persist
        # across the restarts that push the upsert resume position forward, without one
        # pipeline's snapshot boundary ever lowering another's (concurrent full refreshes
        # of the same table land on different destinations at different snapshot LSNs).

        return scope.partition("_@_")[0]

    def _publish_delete_snapshot_floor(
        self, table: Table, schema_id: str, snapshot_lsn: int, pipeline_scope: str
    ) -> None:
        # Docstring: Record the snapshot boundary a delete flow should bootstrap from.
        #
        # Keyed by table and pipeline id, so it outlives update-scope GC and survives
        # restarts while staying isolated per pipeline. The schema generation the snapshot
        # was taken under rides inside the record rather than in the key, so a bootstrap
        # after a schema change can tell that its floor belongs to a superseded layout
        # (and say so) instead of simply not finding one. Forward-moving: a resnapshot
        # repopulates the destination as-of a later ``snapshot_lsn`` and must advance the
        # floor -- under a new schema generation too -- while ordinary polls leave it
        # untouched. The delete channel is idempotent, so a floor that lags a resnapshot in
        # flight only causes a harmless re-read, never a lost or double delete.

        self._state_op_with_reconnect(
            lambda: publish_maximum_lsn_state_record(
                self._lakebase_connection(),
                self._lakebase_state_namespace(),
                self._immutable_namespace(table, "delete-floor", self._pipeline_id(pipeline_scope)),
                {
                    "created_at": time.time(),
                    "fingerprint": _schema_fingerprint(table),
                    "format_version": _IMMUTABLE_STATE_VERSION,
                    "record_type": "delete-floor",
                    "schema_id": schema_id,
                    "start_lsn": str(snapshot_lsn),
                    "table": table.native_identity,
                },
                record_type="delete-floor",
            ),
            operation="delete-floor publish",
        )

    def _read_delete_snapshot_floor(
        self, table: Table, schema_id: str, fingerprint: str
    ) -> tuple[int, str, str] | None:
        # Docstring: Return the snapshot-boundary floor for a bootstrapping delete flow.
        #
        # The floor with the schema id and fingerprint it was captured under: the channel
        # start's, or one the channel start's descends from through recorded predecessors
        # (the source was altered after the snapshot while the delete flow never
        # checkpointed). The bootstrap seeds under that schema and steps from it as any
        # lagging reader does. ``None`` when no compatible floor exists, so the caller keeps
        # anchoring at the upsert channel-start: this pipeline has not published one, or the
        # floor's schema is not in the channel start's history. The latter is reported: the
        # deletes committed between the snapshot and the resume position are not replayed.

        record = self._read_immutable_head(
            self._immutable_namespace(
                table, "delete-floor", self._pipeline_id(self._pipeline_scope())
            )
        )
        if record is None:
            return None
        self._validate_immutable_record_header(record, "delete-floor", table.exposed_name)
        if record.get("table") != table.native_identity:
            return None
        floor = self._immutable_lsn(record, "start_lsn", table.exposed_name)
        floor_schema_id, floor_fingerprint = record.get("schema_id"), record.get("fingerprint")
        if (floor_schema_id, floor_fingerprint) != (schema_id, fingerprint) and not (
            isinstance(floor_fingerprint, str)
            and self._schema_descends_from(table, schema_id, fingerprint, floor_schema_id)
        ):
            # 314: Informix delete snapshot floor {} for '{}' was captured under schema generation
            # {}, but the upsert channel now runs generation {}; the delete channel bootstraps at
            # the upsert resume position instead, so deletes committed between that snapshot and the
            # resume position are not replayed. Run a full refresh if the destination must match the
            # source exactly
            logging.getLogger(__name__).warning(
                _m(314, floor, table.exposed_name, floor_schema_id, schema_id),
            )
            return None
        return floor, str(floor_schema_id), floor_fingerprint

    def _upsert_channel_start_exists(self, table_name: str, table_options: dict[str, str]) -> bool:
        # Docstring: Check current-scope delete coordination without opening Informix.

        exposed = table_options.get("qualified_source_table", table_name)
        # Preserve eager configuration/schema failures. Registration commonly
        # leaves the table in this process-local cache, so validation here costs
        # no source connection. An explicitly append-only table (per table or for the
        # connection) must always reach the normal path, which raises that it has no
        # delete channel.
        if self._append_only_mode(table_options) == "true":
            return True
        cached = self._tables.get(exposed) if self._tables is not None else None
        if cached is not None:
            # The cache holds the bare catalog table, so narrow it to the columns the read
            # path ingests first, or a column left out there would fail the check here. Then
            # give it the key the read path will (primary.keys, or a promoted nullable index)
            # without the index lookup that can need: a keyless table keyed by an option has
            # a delete channel, and must wait here for its upsert reader like any keyed one.
            override = _key_override(table_options)
            cached = self._ingested_columns(cached, table_options, override)
            key = self._requested_key(cached, table_options, override)
            # A key the options name but the table does not ingest fails here as the read
            # path would, instead of waiting on an upsert reader that fails the same way.
            if key is None:
                # The primary.keys wildcard: every ingested column but those it excepts.
                _ensure_excepted_columns_exist(cached, override[1])
                key = tuple(_wildcard_key(cached.columns, override[1]))
                if not key:
                    # 192: Option '{}' excepts every column of '{}', leaving no key
                    raise InformixError(_m(192, _PRIMARY_KEYS_OPTION, cached.exposed_name))
            elif override is not None:
                ingested = {column.name for column in cached.columns}
                missing = [name for name in key if name not in ingested]
                if missing:
                    # 193: Option '{}' names column(s) not present in '{}': {}
                    raise InformixError(
                        _m(193, _PRIMARY_KEYS_OPTION, cached.exposed_name, ", ".join(missing))
                    )
            cached = replace(cached, primary_keys=key)
            _ensure_selected_keys(cached)
            _ensure_materializable(cached, table_options)
            if self._append_only_table(cached, table_options) or not _cdc_capable(cached):
                return True
        identity = self._native_table_state_identity(exposed)
        if identity is None:
            return True
        _, connection_key, table_key = identity
        record_key = "/".join(
            (
                connection_key,
                table_key,
                "channel-starts",
                self._pipeline_scope(),
                "upsert",
            )
        )
        return (
            self._state_op_with_reconnect(
                lambda: read_state_record(self._lakebase_connection(), connection_key, record_key),
                operation="channel-start probe",
            )
            is not None
        )

    def _native_table_state_identity(self, exposed: str) -> tuple[str, str, str] | None:
        # Docstring: Derive native and Lakebase table identities without opening Informix.

        parts = _split_identity(exposed)
        if len(parts) == 2:
            database = self.options.get("database", "")
            owner, name = parts
        elif len(parts) == 3:
            database, owner, name = parts
        else:
            # Preserve the normal metadata path and its user-facing validation
            # for connector-specific aliases that are not native identities.
            return None
        if not database or not all(_IDENTIFIER.fullmatch(part) for part in (database, owner, name)):
            return None
        native_identity = f"{database}:{_sql_identifier(owner)}.{_sql_identifier(name)}"
        connection_key = self._lakebase_state_namespace()
        table_key = hashlib.sha256(native_identity.encode()).hexdigest()[:24]
        return native_identity, connection_key, table_key

    def _publish_checkpoint_channel_start_before_capacity(
        self,
        table_name: str,
        effective_start: dict[str, Any],
        table_options: dict[str, str],
    ) -> None:
        # Docstring: Publish an authoritative resume checkpoint before waiting for a slot.
        #
        # A canceled microbatch leaves its positional end in Spark's checkpoint but
        # no commit marker. The next update must replay that range, and replay may
        # wait for capacity for minutes. Publishing only after acquiring capacity
        # leaves the paired delete reader unable to initialize for that entire wait.
        # The incoming positional checkpoint already fixes the safe resume boundary,
        # schema id, and fingerprint, so publishing it requires Lakebase only.

        if (
            effective_start.get("phase") not in ("stream", "snapshot")
            or effective_start.get("schema_fingerprint") is None
        ):
            return
        checkpoint = _validated_offset(effective_start)
        exposed = table_options.get("qualified_source_table", table_name)
        identity = self._native_table_state_identity(exposed)
        if identity is None:
            return
        native_identity, connection_key, table_key = identity
        scope = self._pipeline_scope()
        start_lsn = int(checkpoint.get("begin_lsn") or checkpoint["commit_lsn"])
        schema_id = str(checkpoint["schema_id"])
        fingerprint = str(checkpoint["schema_fingerprint"])
        record_key = "/".join(
            (
                connection_key,
                table_key,
                "channel-starts",
                scope,
                "upsert",
            )
        )
        winner = self._state_op_with_reconnect(
            lambda: publish_minimum_lsn_state_record(
                self._lakebase_connection(),
                connection_key,
                record_key,
                {
                    "created_at": time.time(),
                    "fingerprint": fingerprint,
                    "format_version": _IMMUTABLE_STATE_VERSION,
                    "record_type": "channel-start",
                    "schema_id": schema_id,
                    "scope": scope,
                    "start_lsn": str(start_lsn),
                    "table": native_identity,
                },
                record_type="channel-start",
            ),
            operation="pre-capacity channel-start publish",
        )
        winner_start = self._immutable_lsn(winner, "start_lsn", exposed)
        if (
            winner.get("format_version") != _IMMUTABLE_STATE_VERSION
            or winner.get("record_type") != "channel-start"
            or winner.get("scope") != scope
            or winner.get("table") != native_identity
            or winner_start > start_lsn
        ):
            # 312: Conflicting Informix upsert start boundary for '{}' in update scope '{}'
            raise InformixError(_m(312, exposed, scope))

    def _shared_table_lsn(
        self,
        table: Table,
        *,
        owner: bool,
        wait: bool = True,
        scope: str | None = None,
    ) -> tuple[int, str] | None:
        scope = scope or self._pipeline_scope()
        namespace = self._immutable_namespace(table, "initialization", scope)
        deadline = time.monotonic() + int(
            self.options.get("cdc.shared.state.wait.seconds", str(_SHARED_STATE_WAIT_SECONDS))
        )
        delay = 0.1
        while True:
            record = self._read_immutable_head(namespace)
            if record is not None:
                self._validate_immutable_record_header(record, "initialization", table.exposed_name)
                if record.get("table") != table.native_identity or record.get("scope") != scope:
                    # 315: Informix immutable initialization table mismatch
                    raise InformixError(_m(315))
                node = record.get("schema")
                if (
                    not isinstance(node, dict)
                    or not isinstance(node.get("id"), str)
                    or not re.fullmatch(r"[0-9a-f]{32}", str(node.get("id")))
                    or node.get("fingerprint") != _schema_fingerprint(table)
                ):
                    # 316: Invalid Informix immutable initialization schema
                    raise InformixError(_m(316))
                value = self._immutable_lsn(record, "initial_lsn", table.exposed_name)
                if (
                    self._immutable_lsn(node, "start_lsn", table.exposed_name) != value
                    or _table_from_schema_state(node, table.database).native_identity
                    != table.native_identity
                    or node.get("predecessor") is not None
                ):
                    # 316: Invalid Informix immutable initialization schema
                    raise InformixError(_m(316))
                if not owner:
                    snapshot = self._read_immutable_head(
                        self._immutable_namespace(table, "snapshots", scope, str(node["id"]))
                    )
                    if snapshot is None:
                        record = None
                    else:
                        self._validate_immutable_record_header(
                            snapshot, "snapshot", table.exposed_name
                        )
                        if (
                            snapshot.get("scope") != scope
                            or snapshot.get("schema_id") != node["id"]
                            or self._immutable_lsn(snapshot, "initial_lsn", table.exposed_name)
                            != value
                        ):
                            # 317: Invalid immutable snapshot boundary for '{}'
                            raise InformixError(_m(317, table.exposed_name))
                        value = self._immutable_lsn(snapshot, "snapshot_lsn", table.exposed_name)
                if record is not None:
                    self._bridge.validate_initial_lsn(
                        _capture_descriptor(table, _client_encoding(self.options)), value
                    )
                    if owner:
                        schema_winner = self._publish_immutable_head(
                            self._immutable_namespace(table, "schema-nodes", str(node["id"])),
                            {
                                "created_at": record.get("created_at", time.time()),
                                "schema": node,
                            },
                            record_type="schema-node",
                        )
                        self._validate_schema_node_winner(schema_winner, node, table)
                    return value, str(node["id"])
            if owner:
                value = self._bridge.prepare_initial_capture([table.native_identity])
                self._bridge.validate_initial_lsn(
                    _capture_descriptor(table, _client_encoding(self.options)), value
                )
                self._publish_immutable_head(
                    namespace,
                    {
                        "created_at": time.time(),
                        "initial_lsn": str(value),
                        "schema": _schema_state(table, value),
                        "scope": scope,
                        "table": table.native_identity,
                    },
                    record_type="initialization",
                )
                continue
            if not wait:
                return None
            if time.monotonic() >= deadline:
                role = "upsert initialization" if owner else "the table's upsert reader"
                # 318: Timed out waiting for {} to publish shared CDC state for '{}' at '{}'
                raise InformixError(_m(318, role, table.exposed_name, namespace))
            delay = _sleep_with_backoff(deadline, delay)

    def _publish_snapshot_boundary(
        self,
        table: Table,
        schema_id: str,
        initial_lsn: int,
        snapshot_lsn: int,
        pipeline_scope: str,
    ) -> None:
        winner = self._publish_immutable_head(
            self._immutable_namespace(table, "snapshots", pipeline_scope, schema_id),
            {
                "created_at": time.time(),
                "initial_lsn": str(initial_lsn),
                "scope": pipeline_scope,
                "schema_id": schema_id,
                "snapshot_lsn": str(snapshot_lsn),
            },
            record_type="snapshot",
        )
        self._validate_immutable_record_header(winner, "snapshot", table.exposed_name)
        if self._immutable_lsn(winner, "initial_lsn", table.exposed_name) != initial_lsn:
            # 319: Conflicting immutable snapshot boundary for '{}'
            raise InformixError(_m(319, table.exposed_name))
        if (
            winner.get("scope") != pipeline_scope
            or winner.get("schema_id") != schema_id
            or self._immutable_lsn(winner, "snapshot_lsn", table.exposed_name) < initial_lsn
        ):
            # 317: Invalid immutable snapshot boundary for '{}'
            raise InformixError(_m(317, table.exposed_name))
        # Publish only once the strategy has finalized its safe handoff:
        # incremental snapshots pass initial_lsn == snapshot_lsn, while a
        # blocking consistent snapshot may finish later and must seed deletes
        # from that later snapshot position.
        self._publish_upsert_channel_start(
            table,
            snapshot_lsn,
            schema_id,
            _schema_fingerprint(table),
            pipeline_scope,
        )
        # Durable floor for a delete flow's bootstrap. The per-scope upsert channel-start
        # above is GC'd with its update scope and records the upsert *resume* position,
        # which drifts forward across restarts; this floor is keyed by schema id and
        # pipeline id so it survives scope cleanup and restarts while staying isolated
        # per pipeline, and is forward-moving so a later resnapshot advances it. It is the
        # LSN the current destination rows were captured at -- the correct lower bound for
        # replaying deletes (see the bootstrap path in _read_table_deletes_attempt).
        self._publish_delete_snapshot_floor(table, schema_id, snapshot_lsn, pipeline_scope)

    def _find_immutable_schema_record(
        self, table: Table, schema_id: str, scope: str
    ) -> dict[str, object] | None:
        initialization = self._read_immutable_head(
            self._immutable_namespace(table, "initialization", scope)
        )
        if initialization is not None:
            self._validate_immutable_record_header(
                initialization, "initialization", table.exposed_name
            )
            schema = initialization.get("schema")
            if isinstance(schema, dict) and schema.get("id") == schema_id:
                return {
                    "created_at": initialization.get("created_at", time.time()),
                    "schema": schema,
                }
        # A checkpoint is emitted only after its exact schema-node head is
        # committed. Do not scan unbounded, unrelated transition history to
        # compensate for an externally removed historical node.
        return None

    def _lakebase_connection(self) -> Any:
        # Docstring: Return this connector's Postgres connection, provisioning on first use.
        #
        # The connector and its bridge each keep their own connection: the bridge's
        # serves slot operations while a read is in flight, and sharing one across
        # both would serialise state reads behind slot maintenance.

        connection = getattr(self, "_lakebase_conn", None)
        if connection is not None:
            try:
                if not connection.closed:
                    return connection
            except Exception:
                pass
        state = getattr(self, "_lakebase_state", None)
        if state is None:
            identity = "\0".join(
                (
                    self.options.get("hostname", "").strip().rstrip(".").casefold(),
                    str(int(self.options.get("port", "9088"))),
                    self.options.get("server", "").strip().casefold(),
                )
            )
            state = LakebaseState(self.options, identity)
            state.provision()
            self._lakebase_state = state
        connection = state.connect()
        self._lakebase_conn = connection
        return connection

    def _immutable_namespace(self, table: Table, *parts: str) -> str:
        # Docstring: Build the record key identifying one piece of per-table state.
        #
        # Keys are ``<connection>/<table>/<part>/...`` where both leading
        # components are hashes of the Informix identity, so a key is reproducible
        # by any worker without coordination. A component that is not already
        # restricted to a safe character set is hashed, which keeps a scope or
        # schema id containing a separator from forging a different key.

        connection_key, table_key = self._table_state_keys(table)
        safe = [connection_key, table_key]
        for part in parts:
            value = str(part)
            if not re.fullmatch(r"[A-Za-z0-9_.@-]+", value):
                value = hashlib.sha256(value.encode()).hexdigest()
            safe.append(value)
        return "/".join(safe)

    def _touch_table_state(self, table: Table) -> None:
        # Docstring: Mark a pipeline/table active and opportunistically run daily state GC.

        scope = self._pipeline_scope()
        if "_@_" not in scope:
            return
        pipeline_id, _, update_id = scope.partition("_@_")
        if not pipeline_id or not update_id:
            return
        try:
            retention_days = int(
                self.options.get("state.gc.retention.days", _DEFAULT_STATE_GC_RETENTION_DAYS)
            )
            interval_hours = float(
                self.options.get("state.gc.interval.hours", _DEFAULT_STATE_GC_INTERVAL_HOURS)
            )
        except (TypeError, ValueError) as error:
            # 320: Options 'state.gc.retention.days' and 'state.gc.interval.hours' must be numeric
            raise ValueError(_m(320)) from error
        if retention_days < 1 or not math.isfinite(interval_hours) or interval_hours <= 0:
            # 321: Option 'state.gc.retention.days' must be >= 1 and 'state.gc.interval.hours' must
            # be > 0
            raise ValueError(_m(321))
        cache_key = (table.identity, pipeline_id)
        now = time.monotonic()
        touch_seconds = interval_hours * 3600
        if now - self._activity_touched.get(cache_key, -math.inf) < touch_seconds:
            return
        prefix = self._immutable_namespace(table)
        pipeline_key = hashlib.sha256(pipeline_id.encode()).hexdigest()[:32]
        namespace = self._lakebase_state_namespace()
        self._state_op_with_reconnect(
            lambda: touch_table_activity(
                self._lakebase_connection(),
                namespace,
                f"{prefix}/activity/{pipeline_key}",
                prefix,
                pipeline_id,
                touch_seconds,
            ),
            operation="table-activity touch",
        )
        self._activity_touched[cache_key] = now
        deleted = self._state_op_with_reconnect(
            lambda: collect_stale_table_state(
                self._lakebase_connection(),
                namespace,
                "state-gc/table-activity",
                retention_days,
                interval_hours,
            ),
            operation="stale-state GC",
        )
        if deleted:
            # 322: Collected {} stale Informix Lakebase state records
            logging.getLogger(__name__).info(_m(322, deleted))
        drop_projects = self.options.get("state.gc.drop.unused.projects", "false").lower()
        if drop_projects not in {"true", "false"}:
            # 323: Option 'state.gc.drop.unused.projects' must be true or false
            raise ValueError(_m(323))
        if drop_projects == "true":
            try:
                project_retention_days = int(
                    self.options.get(
                        "state.gc.project.retention.days",
                        _DEFAULT_STATE_GC_PROJECT_RETENTION_DAYS,
                    )
                )
            except (TypeError, ValueError) as error:
                # 324: Option 'state.gc.project.retention.days' must be an integer
                raise ValueError(_m(324)) from error
            if project_retention_days < retention_days:
                # 325: Option 'state.gc.project.retention.days' must be >= state.gc.retention.days
                raise ValueError(_m(325))
            state = getattr(self, "_lakebase_state", None)
            if state is not None:
                state.collect_unused_projects(project_retention_days, interval_hours)

    def _cleanup_previous_update_scopes(
        self, table: Table, checkpoint: dict[str, Any] | None = None
    ) -> None:
        # Docstring: Clean obsolete scopes without deleting state referenced by Spark.

        if checkpoint and checkpoint.get("stage_scope"):
            # A handoff relocation is still serving staged pages that live under the
            # capturing flow's scope (carried on stage_scope). That scope's records --
            # the snapshot manifest above all -- must survive until the serve completes,
            # so skip obsolete-scope cleanup while it is present. Not cached, so normal
            # cleanup resumes on the first read after the stream transition drops it.
            return
        current = self._pipeline_scope()
        cache_key = (table.identity, current)
        if cache_key in self._cleaned_update_scopes or "_@_" not in current:
            return
        pipeline_id, _, update_id = current.partition("_@_")
        if not pipeline_id or not update_id:
            return
        retained_scope = None
        if checkpoint:
            candidate = checkpoint.get("pipeline_scope")
            if (
                isinstance(candidate, str)
                and candidate.startswith(f"{pipeline_id}_@_")
                and _PIPELINE_SCOPE.fullmatch(candidate) is not None
            ):
                retained_scope = candidate
        deleted = self._state_op_with_reconnect(
            lambda: delete_obsolete_scoped_state_records(
                self._lakebase_connection(),
                self._lakebase_state_namespace(),
                self._immutable_namespace(table),
                f"{pipeline_id}_@_",
                current,
                retained_scope,
            ),
            operation="obsolete-scope cleanup",
        )
        self._cleaned_update_scopes.add(cache_key)
        if deleted:
            # 326: Removed {} obsolete Informix update-scoped records for table={}
            logging.getLogger(__name__).info(
                _m(326, deleted, table.exposed_name),
            )

    def _lakebase_state_namespace(self) -> str:
        # Docstring: Namespace state records by the Informix *database*, not the endpoint.
        #
        # Slots are per server process because capacity is a property of that
        # process, but a table's state belongs to one database on it, so two
        # databases on one server never share a record.

        identity = "\0".join(
            (
                "v2",
                self.options.get("hostname", "").strip().rstrip(".").casefold(),
                str(int(self.options.get("port", "9088"))),
                self.options.get("server", "").strip(),
                self.options.get("database", "").strip(),
            )
        )
        return hashlib.sha256(identity.encode()).hexdigest()[:24]

    def _read_immutable_head(self, namespace: str) -> dict[str, object] | None:
        # Docstring: Return the elected record for a key, or None when unwritten.

        return self._state_op_with_reconnect(
            lambda: read_state_record(
                self._lakebase_connection(), self._lakebase_state_namespace(), namespace
            ),
            operation="head read",
        )

    def _publish_immutable_head(
        self,
        namespace: str,
        record: dict[str, object],
        *,
        record_type: str = "generic",
    ) -> dict[str, object]:
        # Docstring: Elect exactly one immutable record for a key and return the winner.
        #
        # ``INSERT ... ON CONFLICT DO NOTHING RETURNING`` is the election. The
        # return value is always the *elected* record, which may be another
        # writer's: a record is shared truth for its key, so a loser must adopt the
        # winner rather than assume its own value took effect.

        return self._state_op_with_reconnect(
            lambda: publish_state_record(
                self._lakebase_connection(),
                self._lakebase_state_namespace(),
                namespace,
                {
                    **record,
                    "format_version": _IMMUTABLE_STATE_VERSION,
                    "record_type": record_type,
                },
                record_type=record_type,
            ),
            operation="head publish",
        )

    @staticmethod
    def _validate_immutable_record_header(
        record: dict[str, object], expected_type: str, context: str
    ) -> None:
        if (
            not isinstance(record.get("format_version"), int)
            or isinstance(record.get("format_version"), bool)
            or record.get("format_version") != _IMMUTABLE_STATE_VERSION
            or record.get("record_type") != expected_type
        ):
            # 327: Unsupported or mismatched Informix immutable {} record for {}
            raise InformixError(_m(327, expected_type, context))

    def _validate_schema_node_winner(
        self,
        winner: dict[str, object],
        expected_schema: dict[str, object],
        table: Table,
    ) -> None:
        self._validate_immutable_record_header(winner, "schema-node", table.exposed_name)
        schema = winner.get("schema")
        if (
            not isinstance(schema, dict)
            or schema.get("id") != expected_schema.get("id")
            or schema.get("fingerprint") != expected_schema.get("fingerprint")
            or (
                schema.get("predecessor") is not None
                and expected_schema.get("predecessor") is not None
                and schema.get("predecessor") != expected_schema.get("predecessor")
            )
            or _table_from_schema_state(schema, table.database).native_identity
            != _table_from_schema_state(expected_schema, table.database).native_identity
        ):
            # 328: Conflicting immutable schema-node winner for '{}'
            raise InformixError(_m(328, table.exposed_name))
        if (
            _table_from_schema_state(schema, table.database).native_identity
            != table.native_identity
        ):
            # 329: Immutable schema-node table mismatch for '{}'
            raise InformixError(_m(329, table.exposed_name))

    @staticmethod
    def _immutable_lsn(record: dict[str, object], name: str, context: str) -> int:
        try:
            return _strict_lsn(record.get(name), name)
        except (TypeError, ValueError) as error:
            # 330: Invalid {} in Informix immutable record for {}
            raise InformixError(_m(330, name, context)) from error

    def _table_map(self, refresh: bool = False) -> dict[str, Table]:
        if self._tables is None or not self._tables_complete or refresh:
            result: dict[str, Table] = {}
            database = self.options.get("database", "")
            for raw in self._bridge.list_tables():
                table = Table.parse(raw, database)
                if self._selected(table):
                    if table.exposed_name in result:
                        # 331: Duplicate exposed table name {}
                        raise InformixError(_m(331, table.exposed_name))
                    result[table.exposed_name] = table
            self._tables = result
            self._tables_complete = True
        return self._tables

    def _selected(self, table: Table) -> bool:
        include = _patterns(self.options.get("table.include.list") or self.options.get("tables"))
        exclude = _patterns(self.options.get("table.exclude.list"))
        names = (table.identity, table.exposed_name, table.native_identity)
        return (
            not include or any(fnmatch.fnmatchcase(n, p) for n in names for p in include)
        ) and not any(fnmatch.fnmatchcase(n, p) for n in names for p in exclude)

    def _table(self, name: str, options: dict[str, str], refresh: bool = False) -> Table:
        exposed = options.get("qualified_source_table", name)
        if self._tables is not None and exposed in self._tables and not refresh:
            return self._apply_table_options(self._tables[exposed], options)
        parts = _split_identity(exposed)
        if len(parts) == 2 and all(_IDENTIFIER.fullmatch(part) for part in parts):
            database = self.options.get("database", "")
            table = Table.parse(
                self._bridge.get_table(_join_identity(database, parts[0], parts[1])),
                database,
            )
            if not self._selected(table):
                # 169: Unknown or excluded Informix table '{}'
                raise ValueError(_m(169, exposed))
            if self._tables is None:
                self._tables = {}
            self._tables[exposed] = table
            return self._apply_table_options(table, options)
        tables = self._table_map(refresh=refresh)
        if exposed not in tables:
            # 169: Unknown or excluded Informix table '{}'
            raise ValueError(_m(169, exposed))
        return self._apply_table_options(tables[exposed], options)


# Conventional alias used by some connector loaders.
InformixConnect = InformixLakeflowConnect


def _load_factory(path: str) -> Callable[[dict[str, str]], InformixBridge]:
    module_name, separator, attribute = path.partition(":")
    if not separator:
        module_name, separator, attribute = path.rpartition(".")
    if not module_name or not attribute:
        # 332: bridge.factory must be 'module:callable'
        raise ValueError(_m(332))
    factory = getattr(importlib.import_module(module_name), attribute)
    if not callable(factory):
        # 333: Bridge factory {!r} is not callable
        raise TypeError(_m(333, path))
    return factory


_CATALOG_TYPES = {
    0: "CHAR",
    1: "SMALLINT",
    2: "INTEGER",
    3: "FLOAT",
    4: "SMALLFLOAT",
    5: "DECIMAL",
    6: "SERIAL",
    7: "DATE",
    8: "MONEY",
    10: "DATETIME",
    11: "BYTE",
    12: "TEXT",
    13: "VARCHAR",
    14: "INTERVAL",
    15: "NCHAR",
    16: "NVARCHAR",
    17: "INT8",
    18: "SERIAL8",
    19: "SET",
    20: "MULTISET",
    21: "LIST",
    22: "ROW",
    23: "COLLECTION",
    40: "UDT_VAR",
    41: "UDT_FIXED",
    43: "LVARCHAR",
    45: "BOOLEAN",
    52: "BIGINT",
    53: "BIGSERIAL",
    101: "BLOB",
    102: "CLOB",
}


def _field(row: Any, name: str, index: int) -> Any:
    if isinstance(row, dict):
        if name in row:
            return row[name]
        lowered = {str(key).lower(): value for key, value in row.items()}
        if name.lower() in lowered:
            return lowered[name.lower()]
        # Informix names unaliased routine results after the full expression.
        # Lifecycle calls return a single scalar, so retain the positional
        # fallback used for tuple rows when a stable label is unavailable.
        return tuple(row.values())[index]
    return row[index]


def _catalog_column(row: Any) -> dict[str, Any]:
    name = str(_field(row, "colname", 0))
    raw_type = int(_field(row, "coltype", 1))
    length = int(_field(row, "collength", 2))
    base_type = raw_type & 0xFF
    type_name = _CATALOG_TYPES.get(base_type)
    if type_name is None:
        # 334: Unsupported Informix catalog coltype {} for {}
        raise InformixError(_m(334, base_type, name))
    if type_name in {"UDT_VAR", "UDT_FIXED"}:
        if isinstance(row, dict):
            lowered = {str(key).lower(): value for key, value in row.items()}
            extended_name = str(lowered.get("extended_name") or "").strip().upper()
            extended_owner = str(lowered.get("extended_owner") or "").strip().upper()
        else:
            extended_name = str(row[6] or "").strip().upper() if len(row) > 6 else ""
            extended_owner = str(row[7] or "").strip().upper() if len(row) > 7 else ""
        # BLOB and CLOB are built-in opaque types too; naming them lets the warning for a
        # column left out say which type it was. Both stay unsupported.
        builtin_extended_types = {
            ("UDT_VAR", "INFORMIX", "LVARCHAR"): "LVARCHAR",
            ("UDT_FIXED", "INFORMIX", "BOOLEAN"): "BOOLEAN",
            ("UDT_FIXED", "INFORMIX", "BLOB"): "BLOB",
            ("UDT_FIXED", "INFORMIX", "CLOB"): "CLOB",
        }
        type_name = builtin_extended_types.get(
            (type_name, extended_owner, extended_name), type_name
        )
    if type_name == "DATETIME":
        # syscolumns.collength stores the packed width in its high byte and
        # start/end qualifier nibbles in its low byte.  CDC descriptors use
        # the native extended-id layout instead: start in bits 8..11 and end in
        # bits 0..3.  For example, live YEAR TO FRACTION(5) is 0x130f in the
        # catalog and must become 0x000f for the native row decoder.
        encoded_qualifier = length & 0xFF
        length = ((encoded_qualifier >> 4) << 8) | (encoded_qualifier & 0x0F)
    precision = scale = None
    if type_name in {"DECIMAL", "MONEY"}:
        precision, scale = (length >> 8) & 0xFF, length & 0xFF
    unsupported = {
        "BYTE",
        "TEXT",
        "BLOB",
        "CLOB",
        "SET",
        "MULTISET",
        "LIST",
        "ROW",
        "COLLECTION",
        "UDT_VAR",
        "UDT_FIXED",
    }
    cdc_supported = type_name not in unsupported
    if type_name == "DATETIME":
        cdc_supported = _datetime_qualifier_supported(length)
    if type_name == "INTERVAL":
        cdc_supported = interval_layout(length) is not None
    return {
        "name": name,
        "type_name": type_name,
        "nullable": not bool(raw_type & 0x100),
        "length": length,
        "precision": precision,
        "scale": scale,
        "cdc_supported": cdc_supported,
    }


def _column_descriptor(raw: dict[str, Any]) -> ColumnDescriptor:
    return ColumnDescriptor(
        name=str(raw["name"]),
        type_name=str(raw["type_name"]),
        length=int(raw.get("length") or 0),
        precision=_optional_int(raw.get("precision")),
        scale=_optional_int(raw.get("scale")),
        encoding=str(raw.get("encoding") or "utf-8"),
    )


def _expect_zero(rows: list[Any], operation: str) -> None:
    if not rows:
        raise InformixError(f"{operation} returned no status")
    status = int(_field(rows[0], "status", 0))
    if status != 0:
        raise InformixError(f"{operation} failed with status {status}")


def _is_timeout_error(error: BaseException | None) -> bool:
    # Docstring: Report whether ``error`` (or anything it wraps) is a socket read timeout.
    #
    # A SQLI socket read timeout surfaces as a bare ``TimeoutError`` (``socket.timeout``
    # is an alias of it on Python 3.10+); it may also travel as the ``__cause__`` of a
    # wrapping connector error, so walk the cause chain rather than checking the top
    # exception alone.

    seen: set[int] = set()
    while error is not None and id(error) not in seen:
        if isinstance(error, TimeoutError):
            return True
        seen.add(id(error))
        error = error.__cause__ or error.__context__
    return False


def _optional_int(value: Any) -> int | None:
    return None if value is None or value == "" else int(value)


def _strict_int(value: object, name: str) -> int:
    if isinstance(value, bool) or not (
        isinstance(value, int) or (isinstance(value, str) and re.fullmatch(r"[+-]?\d+", value))
    ):
        # 335: {} must be an integer, not {!r}
        raise ValueError(_m(335, name, value))
    return int(value)


def _strict_lsn(value: object, name: str) -> int:
    result = _strict_int(value, name)
    if not 0 <= result < 1 << 64:
        # 336: {} is outside the unsigned 64-bit LSN domain
        raise ValueError(_m(336, name))
    return result


def _strict_tx_id(value: object, name: str = "tx_id") -> int:
    result = _strict_int(value, name)
    if not -(1 << 31) <= result < 1 << 32:
        # 337: {} is outside the native 32-bit transaction-ID domain
        raise ValueError(_m(337, name))
    return result + (1 << 32) if result < 0 else result


def _patterns(value: str | None) -> tuple[str, ...]:
    return tuple(part.strip() for part in (value or "").split(",") if part.strip())


def _cdc_streamable(table: Table) -> bool:
    # Docstring: Report whether Informix can capture this table's changes at all.
    #
    # Split from :func:`_cdc_capable` because the two questions are different and
    # conflating them made every key-less table snapshot-only. ``cdc_startcapture``
    # takes ``(session, table, columns, full_row_logging)`` -- no key -- so the
    # logical log records inserts, updates, and deletes for any table with full-row
    # logging enabled. A primary key is needed to *merge* a change into the
    # destination, not to read it.
    #
    # Missing/placeholder values are unsafe in Lakeflow table rows, especially for
    # binary and complex types, so a table containing uncaptured columns is still
    # excluded here rather than silently nulling those values.

    return all(column.cdc_supported for column in table.columns)


def _cdc_capable(table: Table) -> bool:
    # Docstring: Report whether this table can be merged into a keyed destination.
    #
    # Requires a primary key on top of :func:`_cdc_streamable`: both the upsert
    # channel's ``apply_changes`` target and the delete channel's row identification
    # need one, as does snapshot keyset pagination.

    return bool(table.primary_keys) and _cdc_streamable(table)


def _snapshot_unsupported_columns(table: Table) -> tuple[Column, ...]:
    # Docstring: Return types whose ordinary SQLI row representation is not implemented.

    return tuple(column for column in table.columns if _unsupported_column(column))


def _unsupported_column(column: Column) -> bool:
    # Docstring: Whether ``column`` has a type whose ordinary SQLI row representation is not
    # implemented.

    unsupported = {
        "BYTE",
        "TEXT",
        "BLOB",
        "CLOB",
        "SET",
        "MULTISET",
        "LIST",
        "ROW",
        "COLLECTION",
        "UDT_VAR",
        "UDT_FIXED",
    }
    return (
        column.type_name in unsupported
        or (
            column.type_name == "DATETIME" and not _datetime_qualifier_supported(column.length or 0)
        )
        or (column.type_name == "INTERVAL" and interval_layout(column.length or 0) is None)
    )


# Key types whose values Informix doesn't reliably parse back from a SQL literal, so a
# snapshot keyed on one pages by position within its transaction instead.
# Key types whose values can't be rendered back into SQL as exact keyset literals, so a
# snapshot pages them by position instead: partial DATETIME and INTERVAL literals don't
# all parse back, and a float has no exact decimal literal (nor any rendering at all).
_FLOAT_KEY_TYPES = frozenset({"FLOAT", "SMALLFLOAT"})
_LITERAL_UNSAFE_KEY_TYPES = frozenset({"DATETIME", "INTERVAL", *_FLOAT_KEY_TYPES})


def _datetime_qualifier_supported(qualifier: int) -> bool:
    start, end = (qualifier >> 8) & 0xF, qualifier & 0xF
    fields = {0, 2, 4, 6, 8, 10}
    return start in fields and end in {*fields, 11, 12, 13, 14, 15} and end >= start


_VARIABLE_DECIMAL_DEFAULT = "decimal(38,18)"
_DECIMAL_TYPE_RE = re.compile(r"^decimal\(\s*(\d+)\s*,\s*(\d+)\s*\)$")


def _parse_variable_decimal_type(spec: str, *, option: str) -> tuple[str, int | None, int | None]:
    # Docstring: Normalize a variable-DECIMAL target-type spec.
    #
    # Accepts ``string``, ``double``, ``integer`` or ``decimal(p,s)`` and returns a
    # ``(kind, precision, scale)`` tuple where ``kind`` is one of ``string``,
    # ``double``, ``integer`` or ``decimal``.  ``precision``/``scale`` are populated
    # only for ``decimal``.

    normalized = spec.strip().lower()
    if normalized in {"string", "double", "integer"}:
        return normalized, None, None
    match = _DECIMAL_TYPE_RE.match(normalized)
    if match:
        precision, scale = int(match.group(1)), int(match.group(2))
        if not (1 <= precision <= 38 and 0 <= scale <= precision):
            # 338: Option '{}' decimal(p,s) requires 1<=p<=38 and 0<=s<=p, got decimal({},{})
            raise ValueError(_m(338, option, precision, scale))
        return "decimal", precision, scale
    # 339: Option '{}' must be one of: string, double, integer, decimal(p,s); got {!r}
    raise ValueError(_m(339, option, spec))


def _variable_decimal_column_overrides(
    options: dict[str, str],
) -> dict[str, tuple[str, int | None, int | None]]:
    # Docstring: Parse ``decimal.variable.column.type`` into a per-column target map.

    raw = options.get("decimal.variable.column.type", "").strip()
    if not raw:
        return {}
    overrides: dict[str, tuple[str, int | None, int | None]] = {}
    # Entries are comma-separated, but decimal(p,s) also contains a comma; split
    # only on commas that are not inside parentheses.
    for entry in re.split(r",(?![^(]*\))", raw):
        entry = entry.strip()
        if not entry:
            continue
        name, sep, spec = entry.partition(":")
        name = name.strip()
        if not sep or not name:
            # 340: Option 'decimal.variable.column.type' entries must be 'column:type' pairs; got
            # {!r}
            raise ValueError(_m(340, entry))
        overrides[name] = _parse_variable_decimal_type(spec, option="decimal.variable.column.type")
    return overrides


def _variable_decimal_target(
    column: Column, options: dict[str, str]
) -> tuple[str, int | None, int | None]:
    # Docstring: Resolve the target type for one variable-scale DECIMAL/NUMERIC column.
    #
    # A per-column ``decimal.variable.column.type`` entry wins over the global
    # ``decimal.variable.type``; the default is ``decimal(38,18)``.

    overrides = _variable_decimal_column_overrides(options)
    if column.name in overrides:
        return overrides[column.name]
    return _parse_variable_decimal_type(
        options.get("decimal.variable.type", _VARIABLE_DECIMAL_DEFAULT),
        option="decimal.variable.type",
    )


def _validate_variable_decimal_options(options: dict[str, str]) -> None:
    # Docstring: Eagerly validate the variable-DECIMAL options so bad specs fail fast.

    _parse_variable_decimal_type(
        options.get("decimal.variable.type", _VARIABLE_DECIMAL_DEFAULT),
        option="decimal.variable.type",
    )
    _variable_decimal_column_overrides(options)


def _variable_decimal_spark_type(kind: str, precision: int | None, scale: int | None):
    if kind == "string":
        return StringType()
    if kind == "double":
        return DoubleType()
    if kind == "integer":
        return LongType()
    return DecimalType(precision, scale)


def _is_variable_scale_decimal(column: Column) -> bool:
    name = column.type_name.split("(", 1)[0].strip()
    return name in {"DECIMAL", "NUMERIC"} and column.scale == 0xFF


def _ensure_materializable(table: Table, options: dict[str, str] | None = None) -> None:
    unsupported = _snapshot_unsupported_columns(table)
    if unsupported:
        details = _unsupported_column_list(unsupported)
        # 341: Table '{}' contains columns that the pure-Python SQLI snapshot decoder cannot
        # materialize: {}
        raise InformixError(_m(341, table.exposed_name, details))
    options = options or {}
    _validate_variable_decimal_options(options)
    for column in table.columns:
        if column.type_name in {"DECIMAL", "NUMERIC", "MONEY"}:
            variable_scale = column.type_name in {"DECIMAL", "NUMERIC"} and (column.scale == 0xFF)
            valid_fixed = (
                column.precision is not None
                and column.scale is not None
                and 1 <= column.precision <= 38
                and 0 <= column.scale <= column.precision
            )
            # A variable-scale DECIMAL(p) always maps to a materializable target
            # (string, double, integer, or decimal(p,s)) chosen by the
            # decimal.variable.type / decimal.variable.column.type options.
            if valid_fixed or variable_scale:
                continue
            # 342: Table '{}' has invalid {} metadata for column {}: precision={}, scale={}
            raise InformixError(
                _m(
                    342,
                    table.exposed_name,
                    column.type_name,
                    column.name,
                    column.precision,
                    column.scale,
                )
            )


def _spark_type(column: Column, options: dict[str, str] | None = None):
    name = column.type_name.split("(", 1)[0].strip()
    if name in {"SMALLINT", "INT2"}:
        # The framework row converter does not support Spark ShortType. Widen
        # Informix's signed 16-bit value to IntegerType without losing data.
        return IntegerType()
    if name in {"INTEGER", "INT", "SERIAL"}:
        return IntegerType()
    if name in {"BIGINT", "INT8", "BIGSERIAL", "SERIAL8"}:
        return LongType()
    if name in {"REAL", "SMALLFLOAT"}:
        return FloatType()
    if name in {"FLOAT", "DOUBLE", "DOUBLE PRECISION"}:
        return DoubleType()
    if name in {"DECIMAL", "NUMERIC", "MONEY"}:
        precision = (
            column.precision if column.precision is not None else (19 if name == "MONEY" else 38)
        )
        scale = column.scale if column.scale is not None else (2 if name == "MONEY" else 0)
        if name in {"DECIMAL", "NUMERIC"} and scale == 0xFF:
            # Variable-scale DECIMAL(p) is decimal floating point: p is the count
            # of significant digits and the exponent floats, so the magnitude is
            # not bounded by p. Map it to the target chosen by the
            # decimal.variable.type / decimal.variable.column.type options.
            kind, target_precision, target_scale = _variable_decimal_target(column, options or {})
            return _variable_decimal_spark_type(kind, target_precision, target_scale)
        if 1 <= precision <= 38 and 0 <= scale <= precision:
            return DecimalType(precision, scale)
        return StringType()
    if name == "DATE":
        return DateType()
    if name.startswith("DATETIME") or name == "TIMESTAMP":
        start, end = ((column.length or 0) >> 8) & 0xF, (column.length or 0) & 0xF
        return TimestampType() if start == 0 and end >= 4 else StringType()
    if name in {"BOOLEAN", "BOOL"}:
        return BooleanType()
    if name in {"BYTE", "BLOB", "BINARY", "VARBINARY"}:
        return BinaryType()
    return StringType()


def _operation(record: dict[str, Any]) -> str:
    return str(record.get("op") or record.get("operation") or record.get("type") or "").upper()


def _lsn(record: dict[str, Any]) -> int:
    value = record.get("lsn", record.get("sequence", record.get("sequence_id")))
    if value is None:
        raise InformixError(f"CDC record has no LSN: {record!r}")
    try:
        return _strict_lsn(value, "CDC record LSN")
    except ValueError as error:
        # 343: CDC record has an invalid LSN: {!r}
        raise InformixError(_m(343, record)) from error


def _before_lsn(record: dict[str, Any]) -> int:
    # Docstring: The log position of an assembled UPDATE's before-image.
    #
    # Set when the transaction assembler pairs BEFORE_UPDATE with AFTER_UPDATE; the
    # merged record's own ``lsn`` is the after-image's position.

    value = record.get("before_lsn")
    if value is None:
        # 344: CDC update has no before-image LSN: {!r}
        raise InformixError(_m(344, record))
    try:
        return _strict_lsn(value, "CDC before-image LSN")
    except ValueError as error:
        # 345: CDC update has an invalid before-image LSN: {!r}
        raise InformixError(_m(345, record)) from error


def _tx_id(record: dict[str, Any]) -> int:
    value = record.get("tx_id", record.get("transaction_id"))
    if value is None:
        # 346: CDC record has no transaction ID: {!r}
        raise InformixError(_m(346, record))
    try:
        return _strict_tx_id(value, "CDC transaction ID")
    except ValueError as error:
        # 347: CDC record has an invalid transaction ID: {!r}
        raise InformixError(_m(347, record)) from error


def _normalise_record(raw: dict[str, Any]) -> dict[str, Any]:
    record = dict(raw)
    record["op"] = _operation(record)
    if record["op"] not in {"METADATA", "ERROR"}:
        record["lsn"] = _lsn(record)
    if record["op"] not in {"TIMEOUT", "METADATA", "ERROR"}:
        record["tx_id"] = _tx_id(record)
    return record


def _transaction_batch(
    records: Sequence[dict[str, Any]],
) -> tuple[list[CommittedTransaction], bool, int | None, int | None]:
    # Docstring: Assemble one poll's records: ``(committed, caught_up, open_begin, reached)``.
    #
    # ``reached`` is the LSN of the poll's TIMEOUT record -- how far Informix's log
    # reader had scanned when it went idle -- or None if the poll did not time out.
    # That can be short of the log's end (measured: idle at page 6141 while the log was
    # at 6157), so being caught up says nothing about a later position by itself.

    buffer = TransactionBuffer()
    result = []
    timed_out = False
    reached = None
    for record in records:
        if _operation(record) == "TIMEOUT":
            timed_out = True
            reached = _lsn(record)
        committed = buffer.feed(record)
        if committed is not None:
            result.append(committed)
    # Informix may interleave active transactions without returning their records
    # in one globally monotonic LSN sequence. Transaction.advance() still validates
    # monotonicity within each transaction. Order completed transactions by their
    # commit position before the caller advances its checkpoint, otherwise a higher
    # commit returned first could checkpoint past a lower commit returned later.
    result.sort(key=lambda tx: (tx.commit_lsn, tx.tx_id))
    # Open transactions are intentionally discarded.  The returned offset
    # remains before their BEGIN so a finite next call safely replays them.
    open_begin = min((tx.begin_lsn for tx in buffer.open.values()), default=None)
    return result, timed_out and not buffer.open, open_begin, reached


def _recover(
    transactions: Sequence[CommittedTransaction], checkpoint: dict[str, Any]
) -> list[CommittedTransaction]:
    commit = int(checkpoint["commit_lsn"])
    # Offsets are transaction-atomic. Replaying from the oldest open BEGIN can
    # reproduce transactions already checkpointed, but records from a newly
    # committed transaction must never be filtered using another transaction's
    # commit/change LSN.
    return [tx for tx in transactions if tx.commit_lsn > commit]


def _database_encoding(options: dict[str, str]) -> str:
    # Docstring: The database code set's Python encoding: what LENGTH counts bytes in.

    locale = options.get("db_locale") or options.get("DB_LOCALE") or options.get("db.locale")
    return informix_locale_encoding(locale or "en_US.819")


def _client_encoding(options: dict[str, str]) -> str:
    # Spark lowercases option keys, so ``CLIENT_LOCALE`` arrives as
    # ``client_locale``; check that first, then the original-case / dotted forms.
    locale = (
        options.get("client_locale")
        or options.get("CLIENT_LOCALE")
        or options.get("client.locale")
        or "en_US.utf8"
    )
    return informix_locale_encoding(locale)


def _capture_descriptor(table: Table, encoding: str = "utf-8") -> dict[str, Any]:
    return {
        "identity": table.native_identity,
        "logical_identity": table.identity,
        "columns": [column.name for column in table.columns if column.cdc_supported],
        "descriptors": [
            {
                "name": column.name,
                "type_name": column.type_name,
                "length": column.length or column.precision or 0,
                "precision": column.precision,
                "scale": column.scale,
                "encoding": encoding,
            }
            for column in table.columns
            if column.cdc_supported
        ],
    }


def _project_transaction(
    tx: CommittedTransaction,
    table: Table,
    deletes: bool,
    tombstones: bool = False,
    encoding: str = "latin-1",
) -> list[dict[str, Any]]:
    # Docstring: Project one committed transaction onto one output channel.
    #
    # ``deletes`` selects the delete channel: key-only ``d`` rows for DELETEs and for the
    # old key of a key-changing UPDATE. Otherwise this is the upsert channel, which emits
    # INSERT/UPDATE after-images as ``c``/``u``. On the keyed CDC path the upsert channel
    # deliberately skips DELETEs -- the pipeline applies deletes only through the
    # separate delete flow, and a ``d`` row on the upsert view would be merged as an
    # upsert. ``tombstones`` (the append path with ``append.delete.tombstones`` on) adds
    # each DELETE's full before-image as a ``d`` row instead: the append destination
    # lands rows as-is and never reads ``_informix_op``, so the delete stays in the
    # change log rather than vanishing. On a keyed table forced onto the append path, a
    # key-changing UPDATE is a delete of the old key too: with ``tombstones`` on it lands
    # the before-image as a ``d`` row ahead of the new key's ``u`` row, sequenced at the
    # before-image's own log position so the two never tie on the cursor. A keyless table
    # has no key to change, so its UPDATEs land only their after-image. TRUNCATE is
    # unrepresentable on either channel.

    #
    # With a row_filter, membership comes from the images: a change whose rows never match
    # is dropped, an UPDATE that moves a row out of the filter is a delete of its
    # before-image, and one that moves a row in is an upsert of its after-image alone --
    # its old key was never landed, so there is no old key to delete.

    predicate = _row_filter_predicate(table, encoding)
    output = []
    for record in tx.records:
        if not _record_matches(record, table):
            continue
        op = _operation(record)
        if op == "TRUNCATE":
            # 348: TRUNCATE on {} cannot be represented as keyed Lakeflow deletes
            raise UnsupportedChangeError(_m(348, table.exposed_name))
        before = record.get("before", record.get("row") if op == "DELETE" else None)
        after = record.get("after", record.get("row") if op == "INSERT" else None)
        entered = False
        if predicate is not None:
            # A missing image counts as in the filter, so the record reaches the shaping
            # that fails closed on it, as it does without a filter, instead of dropping or
            # reclassifying the change.
            was_in = op in {"UPDATE", "DELETE"} and (
                before is None or _row_filter_matches(predicate, before)
            )
            is_in = op in {"INSERT", "UPDATE"} and (
                after is None or _row_filter_matches(predicate, after)
            )
            if not (was_in or is_in):
                continue
            if op == "UPDATE" and not is_in:
                op = "DELETE"
            entered = op == "UPDATE" and not was_in
        key_changed = op == "UPDATE" and not entered and _key(before, table) != _key(after, table)
        if deletes:
            if op == "DELETE" or key_changed:
                output.append(_shape_delete(before, table, record, tx))
        elif op in {"INSERT", "UPDATE"}:
            if tombstones and table.primary_keys and key_changed:
                output.append(_shape_tombstone(before, table, record, tx, lsn=_before_lsn(record)))
            output.append(_shape_change(after, record, tx, "u" if op == "UPDATE" else "c"))
        elif op == "DELETE" and tombstones:
            output.append(_shape_tombstone(before, table, record, tx))
    return output


def _record_matches(record: dict[str, Any], table: Table) -> bool:
    identity = str(record.get("table") or record.get("identity") or "")
    return not identity or identity in {
        table.name,
        table.exposed_name,
        table.identity,
        table.native_identity,
    }


def _key(row: dict[str, Any] | None, table: Table) -> tuple[Any, ...]:
    if row is None:
        # 349: Missing before/after image for {}
        raise InformixError(_m(349, table.exposed_name))
    return tuple(row.get(pk) for pk in table.primary_keys)


def _shape_change(row, record, tx, op, *, lsn: int | None = None):
    # Docstring: Shape one full-row change. ``lsn`` overrides the record's own cursor position.

    if row is None:
        # 350: CDC upsert has no after image
        raise InformixError(_m(350))
    result = _framework_row(row)
    result.update(
        {
            CURSOR: _sortable_lsn(_lsn(record) if lsn is None else lsn),
            COMMIT_LSN: _sortable_lsn(tx.commit_lsn),
            TX_ID: tx.tx_id,
            OP: op,
            COMMIT_TIME: _commit_time_value(tx.commit_time),
        }
    )
    return result


def _shape_tombstone(row, table, record, tx, *, lsn: int | None = None):
    # Docstring: A full before-image as an append-path ``d`` row.
    #
    # Used for a DELETE and for the old key of a key-changing UPDATE; the latter passes
    # ``lsn``, the before-image's own position. Not :func:`_shape_delete`, which nulls
    # every non-key column and needs a primary key: an append destination does not
    # merge, so the tombstone carries the whole removed row and is told apart from a
    # live row only by ``_informix_op``.

    if row is None:
        # 351: CDC delete on append-only table {} has no before image; full-row logging is required
        # to emit a delete tombstone
        raise InformixError(_m(351, table.exposed_name))
    return _shape_change(row, record, tx, "d", lsn=lsn)


def _shape_delete(row, table, record, tx):
    # Docstring: Shape a delete-channel row: the key values, with every other column NULL.
    #
    # A NULL key value passes through when its column is declared nullable. Such a key can
    # only come from a ``primary.keys`` override (the wildcard included) or a nullable-index
    # promotion, and the pipeline's AUTO CDC delete flow matches NULL key values, for SCD1
    # and SCD2 alike.
    #
    # A NOT NULL key column -- every real catalog primary key -- can never legitimately
    # hold NULL, so a NULL there still fails closed as a corrupt or incomplete before-image.
    # So does a key column missing from the image entirely: the CDC decoder sets every
    # captured column, using None for a SQL NULL, so an absent column is never a NULL.

    if row is None:
        # 352: CDC delete has no before image; full-row logging is required
        raise InformixError(_m(352))
    result = {column.name: None for column in table.columns}
    nullable: set[str] | None = None
    for pk in table.primary_keys:
        if pk not in row:
            # 353: CDC delete on '{}' has no value for key column {}; the before image is incomplete
            raise InformixError(_m(353, table.exposed_name, pk))
        value = row[pk]
        if value is None:
            if nullable is None:
                nullable = {column.name for column in table.columns if column.nullable}
            if pk not in nullable:
                # 354: CDC delete on '{}' has NULL in NOT NULL key column {}; the before image is
                # corrupt or incomplete, or '{}=null' turned a string holding a NUL byte into NULL
                raise InformixError(_m(354, table.exposed_name, pk, _NULL_BYTE_OPTION))
        result[pk] = _framework_value(value)
    result.update(
        {
            CURSOR: _sortable_lsn(_lsn(record)),
            COMMIT_LSN: _sortable_lsn(tx.commit_lsn),
            TX_ID: tx.tx_id,
            OP: "d",
            COMMIT_TIME: _commit_time_value(tx.commit_time),
        }
    )
    return result


def _coerce_variable_decimal_value(
    value: Any,
    column: Column,
    target: tuple[str, int | None, int | None],
) -> Any:
    # Docstring: Coerce one variable-scale DECIMAL value to its resolved target type.

    kind, precision, scale = target
    if not isinstance(value, Decimal):
        try:
            value = Decimal(str(value))
        except (InvalidOperation, ValueError, TypeError) as error:
            # 355: column '{}' value {!r} is not a valid decimal
            raise InformixError(_m(355, column.name, value)) from error
    if kind == "string":
        return format(value, "f")
    if kind == "double":
        return float(value)
    if kind == "integer":
        # Truncate toward zero (ANSI DECIMAL(p,0) semantics) then bounds-check.
        truncated = int(value.to_integral_value(rounding=ROUND_DOWN))
        if not -(1 << 63) <= truncated < (1 << 63):
            # 356: column '{}' value {} exceeds the 64-bit range of integer
            raise InformixError(_m(356, column.name, (format(value, "f"))))
        return truncated
    # decimal(p,s): quantize to the target scale and confirm it fits precision.
    quantum = Decimal(1).scaleb(-(scale or 0))
    try:
        quantized = value.quantize(quantum, rounding=ROUND_DOWN)
    except InvalidOperation as error:
        # 357: column '{}' value {} cannot be represented as decimal({},{})
        raise InformixError(_m(357, column.name, (format(value, "f")), precision, scale)) from error
    digits = quantized.as_tuple()
    integer_digits = max(len(digits.digits) + digits.exponent, 0)
    allowed_digits = (precision or 0) - (scale or 0)
    if integer_digits > allowed_digits:
        # 358: column '{}' value {} exceeds decimal({},{}) (integer digits {} > {})
        raise InformixError(
            _m(
                358,
                column.name,
                (format(value, "f")),
                precision,
                scale,
                integer_digits,
                allowed_digits,
            )
        )
    return quantized


def _coerce_variable_decimal_values(
    row: dict[str, Any], table: Table, options: dict[str, str]
) -> dict[str, Any]:
    variable_columns = [column for column in table.columns if _is_variable_scale_decimal(column)]
    if not variable_columns:
        return row
    result = dict(row)
    for column in variable_columns:
        value = result.get(column.name)
        if value is None:
            continue
        target = _variable_decimal_target(column, options)
        result[column.name] = _coerce_variable_decimal_value(value, column, target)
    return result


def _unl_char(value: object, name: str, *, allow_empty: bool) -> str:
    # Docstring: Validate a `.unl`/HPL delimiter or escape option to a single character.
    #
    # HPL and UNLOAD field delimiters and escape characters are each one character. A
    # multi-character value is a configuration error, caught eagerly rather than silently
    # truncated. An empty value is rejected for the delimiter and accepted for the escape
    # (``allow_empty``), where it disables escape processing for an HPL extract that writes
    # no escapes.

    text = "" if value is None else str(value)
    if text == "":
        if allow_empty:
            return ""
        # 359: Option '{}' must be a single character
        raise ValueError(_m(359, name))
    if len(text) != 1:
        # 360: Option '{}' must be a single character, got {!r}
        raise ValueError(_m(360, name, text))
    return text


def _validate_unl_field_format(options: dict[str, str]) -> None:
    # Docstring: Eagerly validate the connection-scope `.unl`/HPL delimiter and escape options.
    #
    # Table-scope overrides are validated the same way at resolve time by
    # ``_unl_field_format``; this catches a bad connection default at construction.

    delimiter = _unl_char(
        options.get(_UNL_DELIMITER_OPTION, _UNL_DEFAULT_DELIMITER),
        _UNL_DELIMITER_OPTION,
        allow_empty=False,
    )
    escape = _unl_char(
        options.get(_UNL_ESCAPE_OPTION, _UNL_DEFAULT_ESCAPE),
        _UNL_ESCAPE_OPTION,
        allow_empty=True,
    )
    if escape and escape == delimiter:
        # 259: Options '{}' and '{}' must differ
        raise ValueError(_m(259, _UNL_DELIMITER_OPTION, _UNL_ESCAPE_OPTION))


def _parse_unload_fields(
    line: str,
    *,
    delimiter: str = _UNL_DEFAULT_DELIMITER,
    escape: str = _UNL_DEFAULT_ESCAPE,
    fields: int | None = None,
) -> list[str]:
    # Docstring: Split one UNLOAD / HPL DELIMITED record into raw field strings.
    #
    # Delimited with a single-character field ``delimiter`` (``|`` for UNLOAD) and, when
    # ``escape`` is non-empty (backslash for UNLOAD), backslash-style escaping: ``<esc>n``/
    # ``<esc>r``/``<esc>t`` decode to the control chars and ``<esc><other>`` to the literal
    # char. UNLOAD terminates each record with a trailing delimiter and HPL DELIMITED does
    # not; both are handled -- a line ending in the delimiter yields no spurious trailing
    # field (the final ``value`` is empty and dropped) and a line without one still yields
    # its last field. An empty field is the empty string here -- ``_unload_value`` maps it
    # to NULL (both writers render NULL as an empty field). An empty ``escape`` disables
    # escape processing (raw split on the delimiter), for an HPL job that writes no escapes.

    values: list[str] = []
    value: list[str] = []
    escaped = False
    for character in line.rstrip("\n").rstrip("\r"):
        if escape and escaped:
            value.append({"n": "\n", "r": "\r", "t": "\t"}.get(character, character))
            escaped = False
        elif escape and character == escape:
            escaped = True
        elif character == delimiter:
            values.append("".join(value))
            value = []
        else:
            value.append(character)
    # Short of ``fields``, an empty final field is real: HPL writes no trailing delimiter,
    # so a NULL last column leaves the record ending in a delimiter, as UNLOAD's does.
    if value or (fields is not None and len(values) < fields):
        values.append("".join(value))
    return values


def _unload_value(text: str, type_name: str, qualifier: int | None = None) -> Any:
    # Docstring: Convert one UNLOAD field to the Python value the live snapshot would yield.
    #
    # Keyed on the column's Informix ``type_name`` so ``_shape_snapshot`` (which
    # isoformats date/datetime and quantizes decimals) then produces a row
    # byte-identical to a live ``consistent_snapshot`` row. An empty field is NULL.
    # ``qualifier`` is a DATETIME column's qualifier (``Column.length``): with it, every
    # qualifier renders as the live and CDC decoders render it. Exotic/binary types and
    # locale-sensitive date formats are best-effort and must be validated against the
    # count/data-compare tool in live mode.

    if text == "":
        return None
    upper = type_name.upper()
    if upper in {"CHAR", "NCHAR"}:
        # The live decoders drop CHAR's blank padding; an extract may keep it.
        return text.rstrip(" ")
    if upper == "DATETIME" and qualifier is not None:
        return datetime_from_text(text, qualifier)
    if upper in _UNLOAD_INT_TYPES:
        return int(text)
    if upper.startswith(("DECIMAL", "NUMERIC", "MONEY")):
        return Decimal(text)
    if upper in _UNLOAD_FLOAT_TYPES:
        return float(text)
    if upper == "DATE":
        try:
            return date.fromisoformat(text)
        except ValueError:
            return datetime.strptime(text, "%m/%d/%Y").date()
    if upper.startswith("DATETIME"):
        normalized = text.replace("T", " ")
        for fmt in ("%Y-%m-%d %H:%M:%S.%f", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
            try:
                return datetime.strptime(normalized, fmt)
            except ValueError:
                continue
        return datetime.fromisoformat(text)
    if upper == "BOOLEAN":
        return text.strip().lower() in {"t", "true", "1", "y"}
    if upper == "INTERVAL":
        # UNLOAD right-aligns an INTERVAL in its field width ("  -5 10:30:00"); the
        # trimmed text is exactly what the snapshot and CDC decoders produce.
        return text.strip()
    return text


_UNL_DEFAULT_ESCAPE_BYTE = b"\\"


def _unl_escape_byte(escape: str, encoding: str) -> bytes:
    # Docstring: Encode the record escape character for the byte-level record splitter.
    #
    # The splitter scans raw bytes for record terminators, so the escape must be a
    # single byte in the extract's encoding (backslash, or an HPL job's ASCII choice).
    # An empty escape (escaping disabled) yields ``b""``: every physical newline then
    # terminates a record.

    if not escape:
        return b""
    encoded = escape.encode(encoding)
    if len(encoded) != 1:
        # 361: Option '{}' must encode to a single byte in {!r}; got {!r}
        raise InformixError(_m(361, _UNL_ESCAPE_OPTION, encoding, escape))
    return encoded


def _unl_escape_run(data: bytes, index: int, marker: int) -> int:
    # Docstring: Count the consecutive ``marker`` bytes immediately before ``data[index]``.

    run = 0
    position = index - 1
    while position >= 0 and data[position] == marker:
        run += 1
        position -= 1
    return run


def _unl_find_record_end(data: bytes, start: int, escape: bytes) -> int:
    # Docstring: Index of the first *unescaped* ``\\n`` in ``data`` at or after ``start``, else -1.
    #
    # UNLOAD writes a newline embedded in a CHAR/VARCHAR value as the escape followed
    # by a literal newline, and a literal escape as the escape doubled, so a newline
    # preceded by an odd run of escape bytes is data while an even run (including
    # none) terminates the record. ``data`` must begin at a record start: the byte
    # before any record is an unescaped newline (or the file start), so a run can never
    # extend before it.

    if not escape:
        return data.find(b"\n", start)
    marker = escape[0]
    while True:
        index = data.find(b"\n", start)
        if index == -1 or _unl_escape_run(data, index, marker) % 2 == 0:
            return index
        start = index + 1


def _unl_split_records(buffer: bytes, escape: bytes) -> tuple[list[bytes], bytes]:
    # Docstring: Split ``buffer`` (which starts at a record start) into its complete records and
    # the trailing partial record still waiting for its terminator.

    if not escape or escape not in buffer:
        # No escape byte anywhere: every newline terminates a record (C-speed split).
        parts = buffer.split(b"\n")
        return parts[:-1], parts[-1]
    records: list[bytes] = []
    cursor = 0
    while True:
        index = _unl_find_record_end(buffer, cursor, escape)
        if index == -1:
            return records, buffer[cursor:]
        records.append(buffer[cursor:index])
        cursor = index + 1


def _unl_byte_splits(
    read_chunk: Callable[[int, int], bytes],
    size: int,
    *,
    target_bytes: int = _UNL_SPLIT_TARGET_BYTES,
    chunk_bytes: int = _UNL_SCAN_CHUNK_BYTES,
    escape: bytes = _UNL_DEFAULT_ESCAPE_BYTE,
) -> list[tuple[int, int]]:
    # Docstring: Index one `.unl` file into ``[start, end)`` byte splits of ~``target_bytes`` each.
    #
    # Cheap to plan and constant-memory: for each split, seek to ``start + target_bytes``
    # and read forward via ``read_chunk`` only until the next record terminator, cutting
    # the split just after it (the next split resumes there). This reads a small window
    # near each cut point rather than the whole file -- the reason byte splitting is
    # preferred over a row cap, which cannot know row counts without reading every byte.
    #
    # A record terminator is an *unescaped* physical ``\\n``: UNLOAD escapes a newline
    # embedded in a value as ``escape`` + newline, so a newline behind an odd run of
    # escape bytes is data (see _unl_find_record_end). ``_iter_unl_records`` splits the
    # same range on the same rule, so ending a split right after a terminator keeps
    # records from spanning a boundary. A trailing unterminated record is included in the
    # final split; a split whose target lands past the last terminator runs to EOF. An
    # empty file yields no splits.

    target_bytes = max(1, target_bytes)
    splits: list[tuple[int, int]] = []
    split_start = 0
    while split_start < size:
        target = split_start + target_bytes
        if target >= size:
            splits.append((split_start, size))
            break
        boundary = _unl_next_record_boundary(read_chunk, target, size, chunk_bytes, escape)
        if boundary >= size:
            splits.append((split_start, size))
            break
        splits.append((split_start, boundary))
        split_start = boundary
    return splits


def _unl_next_record_boundary(
    read_chunk: Callable[[int, int], bytes],
    target: int,
    size: int,
    chunk_bytes: int,
    escape: bytes = _UNL_DEFAULT_ESCAPE_BYTE,
) -> int:
    # Docstring: Return the offset just after the first unescaped ``\\n`` at or after ``target``.
    #
    # Reads forward from ``target`` in ``chunk_bytes`` windows (never the whole file) and
    # returns ``size`` when no terminator remains before EOF, so the caller runs the
    # final split to the end of the file. A candidate newline's escape run may begin
    # before the window -- before ``target`` itself when the newline is its first byte
    # -- so a run that reaches the window start is extended by reading backwards.

    marker = escape[0] if escape else None
    offset = target
    while offset < size:
        chunk = read_chunk(offset, min(chunk_bytes, size - offset))
        if not chunk:
            break
        search = 0
        while True:
            index = chunk.find(b"\n", search)
            if index == -1:
                break
            if marker is not None:
                run = _unl_escape_run(chunk, index, marker)
                if run == index:
                    run += _unl_escape_run_before(read_chunk, offset, marker)
                if run % 2:
                    search = index + 1
                    continue
            return offset + index + 1
        offset += len(chunk)
    return size


def _unl_escape_run_before(
    read_chunk: Callable[[int, int], bytes], position: int, marker: int
) -> int:
    # Docstring: Count the consecutive ``marker`` bytes ending right before ``position``, reading
    # backwards in small windows (a run is normally zero or one byte long).

    run = 0
    end = position
    window = 64
    while end > 0:
        start = max(0, end - window)
        data = read_chunk(start, end - start)
        if not data:
            break
        trailing = _unl_escape_run(data, len(data), marker)
        run += trailing
        if trailing < len(data):
            break
        end = start
        window = min(window * 2, _UNL_SCAN_CHUNK_BYTES)
    return run


def _iter_unl_records(
    read_chunk: Callable[[int, int], bytes],
    start: int,
    end: int,
    *,
    chunk_bytes: int = _UNL_SCAN_CHUNK_BYTES,
    escape: bytes = _UNL_DEFAULT_ESCAPE_BYTE,
) -> Iterator[bytes]:
    # Docstring: Yield the raw record bytes (no trailing newline) whose bytes lie in ``[start,
    # end)``.
    #
    # Splits produced by :func:`_unl_byte_splits` begin at a record start and end right
    # after a record terminator, so this reads the range and splits it on unescaped
    # ``\\n`` (see _unl_find_record_end); an escaped newline stays inside its record.
    # Streaming/constant-memory. A final unterminated record (end of file) is yielded.

    offset = start
    buffer = b""
    while offset < end:
        chunk = read_chunk(offset, min(chunk_bytes, end - offset))
        if not chunk:
            break
        offset += len(chunk)
        buffer += chunk
        records, buffer = _unl_split_records(buffer, escape)
        yield from records
    if buffer:
        yield buffer


def _unl_file_is_gzip(read_chunk: Callable[[int, int], bytes]) -> bool:
    # Docstring: Whether a `.unl` file is gzip-compressed, by its two magic bytes ``1f 8b``.
    #
    # Authoritative over the file name, so a mislabelled extract is still handled
    # correctly. An empty file (no bytes) is not gzip.

    return read_chunk(0, 2) == b"\x1f\x8b"


def _iter_gzip_unl_records(
    read_chunk: Callable[[int, int], bytes],
    size: int,
    *,
    chunk_bytes: int = _UNL_SCAN_CHUNK_BYTES,
    escape: bytes = _UNL_DEFAULT_ESCAPE_BYTE,
) -> Iterator[bytes]:
    # Docstring: Yield raw record bytes from a gzip-compressed `.unl` file (whole file, streaming).
    #
    # Gzip is not seekable, so a compressed file is one non-splittable unit: read the
    # compressed bytes ``[0, size)`` in ``chunk_bytes`` windows, decompress incrementally,
    # split the decompressed stream on unescaped ``\\n`` (see _unl_find_record_end), and
    # yield records. Constant memory -- only one compressed window, the current
    # decompressed run, and the trailing partial record are held. Concatenated gzip
    # members (``cat a.gz b.gz``) are handled by starting a fresh decompressor from each
    # member's trailing ``unused_data``. A final unterminated record is yielded. An empty
    # extract (gzip of no rows) yields nothing.

    decompressor = zlib.decompressobj(16 + zlib.MAX_WBITS)
    offset = 0
    tail = b""
    while offset < size:
        compressed = read_chunk(offset, min(chunk_bytes, size - offset))
        if not compressed:
            break
        offset += len(compressed)
        while compressed:
            tail += decompressor.decompress(compressed)
            if not decompressor.eof:
                break
            # Member finished; its leftover bytes begin the next concatenated member.
            compressed = decompressor.unused_data
            decompressor = zlib.decompressobj(16 + zlib.MAX_WBITS)
        records, tail = _unl_split_records(tail, escape)
        yield from records
    tail += decompressor.flush()
    records, tail = _unl_split_records(tail, escape)
    yield from records
    if tail:
        yield tail


class _StaticStagingCredential:
    # Docstring: Fixed-bearer credential for a ``WorkspaceFilesApi`` rebuilt on an executor.
    #
    # The driver mints and refreshes the real staging token; an executor receives just
    # the bearer for one batch in its partition descriptor, so it needs no minting or
    # refresh -- only ``bearer()``, which ``WorkspaceFilesApi`` calls per request.

    def __init__(self, token: str) -> None:
        self._token = token

    def bearer(self) -> str:
        return self._token


def _unl_split_read_chunk(partition: dict) -> Callable[[int, int], bytes]:
    # Docstring: A ``(offset, length) -> bytes`` range reader for one ``unl_split`` descriptor.
    #
    # Ranged GET over the Files REST API when the descriptor carries a token+host
    # (executors have no ambient workspace credential, so the driver passes one per
    # batch); otherwise a local seek/read -- the same fallback shape as the driver's
    # ``_unl_read_chunk``, used offline or when no token could be minted. The batch's
    # token can be revoked or expire after planning; under ``auto`` (``fuse_fallback``) a
    # 401 then moves this split's remaining reads to the mount, while ``rest`` fails.

    token = partition.get("token")
    host = partition.get("host")
    path = partition["path"]

    def local(offset: int, length: int) -> bytes:
        with open(path, "rb") as handle:
            handle.seek(offset)
            return handle.read(length)

    if not (token and host):
        return local
    files_api: WorkspaceFilesApi | None = WorkspaceFilesApi(host, _StaticStagingCredential(token))

    def read(offset: int, length: int) -> bytes:
        nonlocal files_api
        if files_api is not None:
            try:
                return files_api.get_range(path, offset, offset + length)
            except WorkspaceHttpError as error:
                if error.status_code != 401 or not partition.get("fuse_fallback"):
                    raise
                # 362: The snapshot-staging token for {} was rejected; reading the split through the
                # FUSE mount
                logging.getLogger(__name__).warning(
                    _m(362, path),
                )
                files_api = None
        return local(offset, length)

    return read


def _partition_column(column: Column) -> dict[str, Any]:
    # Docstring: A column as a partition descriptor carries it; Column.parse reads it back.

    return {
        "name": column.name,
        "type_name": column.type_name,
        "nullable": column.nullable,
        "length": column.length,
        "precision": column.precision,
        "scale": column.scale,
    }


def _descriptor_columns(partition: dict) -> tuple[Column, ...]:
    # Docstring: The columns a partition descriptor carries for shaping rows on an executor.

    raw = partition.get("transform_columns") or partition.get("columns") or ()
    return tuple(Column.parse(column) for column in raw)


def _shape_unl_record(
    raw: bytes,
    table: Table,
    snapshot_lsn: int,
    options: dict[str, str],
    encoding: str,
    *,
    exposed_name: str | None = None,
    delimiter: str = _UNL_DEFAULT_DELIMITER,
    escape: str = _UNL_DEFAULT_ESCAPE,
    commit_time: int | None = None,
    predicate: tuple | None = None,
    null_byte: str = _DEFAULT_NULL_BYTE_MODE,
) -> dict[str, Any] | None:
    # Docstring: Parse, type-convert, and shape one UNLOAD / HPL DELIMITED record -- shared by both
    # serve paths.
    #
    # Fails closed on a per-record column-count mismatch (the cheap misalignment guard
    # that stands in for the absent schema-fingerprint check). ``exposed_name`` names the
    # table in the error when the caller's ``table`` is a shaping-only stand-in.
    # ``delimiter``/``escape`` select the delimited dialect (UNLOAD's ``|``/backslash by
    # default, or an HPL job's configured pair).

    #
    # An extract holds every catalog column, so fields are matched positionally against
    # ``catalog_columns`` under a column selection and only the selected ones converted.
    # ``predicate`` is the table's row_filter from :func:`_row_filter_predicate`, built once
    # per extract by the caller; a record it drops returns None. ``null_byte`` is the
    # connection's string.null.byte mode, applied as the live decoders apply it, before
    # the filter sees the row.

    catalog = table.catalog_columns or table.columns
    # Only an HPL extract (its own delimiter) can end a full record in the delimiter: with
    # UNLOAD's every record does, so a record short of a column must still fail below.
    expected = None if delimiter == _UNL_DEFAULT_DELIMITER else len(catalog)
    fields = _parse_unload_fields(
        raw.decode(encoding, "strict"), delimiter=delimiter, escape=escape, fields=expected
    )
    if len(fields) != len(catalog):
        name = exposed_name if exposed_name is not None else table.exposed_name
        # 363: UNLOAD record in snapshot.source for '{}' has {} fields but the table has {} columns
        raise InformixError(_m(363, name, len(fields), len(catalog)))
    position = {column.name: index for index, column in enumerate(catalog)}
    row = {
        column.name: apply_null_byte(
            _unload_value(fields[position[column.name]], column.type_name, column.length),
            null_byte,
        )
        for column in table.columns
    }
    if predicate is not None and not _row_filter_matches(predicate, row):
        return None
    return _shape_snapshot(row, snapshot_lsn, table, options, commit_time=commit_time)


def _commit_time_value(epoch_seconds: int | None) -> datetime | None:
    # Docstring: A UTC ``datetime`` for the ``_informix_commit_time`` column, or None.
    #
    # The source supplies commit time as epoch seconds (Informix CDC BEGIN/COMMIT records
    # and ``DBINFO('utc_current')``); TimestampType wants a ``datetime``. None stays None so
    # a row with no source time (e.g. a file-source extract without a manifest boundary_time)
    # lands as NULL.

    if epoch_seconds is None:
        return None
    return datetime.fromtimestamp(int(epoch_seconds), tz=timezone.utc)


def _shape_snapshot(
    row: dict[str, Any],
    lsn: int,
    table: Table | None = None,
    options: dict[str, str] | None = None,
    *,
    commit_time: int | None = None,
) -> dict[str, Any]:
    converted = (
        _coerce_variable_decimal_values(row, table, options or {}) if table is not None else row
    )
    result = _framework_row(converted)
    result.update(
        {
            CURSOR: _sortable_lsn(lsn),
            COMMIT_LSN: _sortable_lsn(lsn),
            TX_ID: None,
            OP: "r",
            COMMIT_TIME: _commit_time_value(commit_time),
        }
    )
    return result


def _log_lsn(uniqid: int, used_pages: int, *, page_start: bool = False) -> int:
    # Docstring: Compose an LSN from a ``sysmaster:syslogs`` row: the log file's ``uniqid`` in the
    # high word and the byte offset of ``used_pages`` 4 KiB pages in the low word.
    #
    # ``page_start`` anchors the offset at the start of the last used page instead of
    # its end -- the conservative capture boundary (see ``boundary_lsn``); a log with no
    # used page yet anchors at its beginning either way.

    pages = max(int(used_pages) - 1, 0) if page_start else int(used_pages)
    return (int(uniqid) << 32) + (pages << 12)


def _sortable_lsn(value: int) -> str:
    lsn = int(value)
    if not 0 <= lsn < 1 << 64:
        # 364: Informix LSN {} is outside the unsigned 64-bit decimal domain
        raise InformixError(_m(364, lsn))
    return f"{lsn:0{_LSN_DECIMAL_WIDTH}d}"


def _framework_row(row: dict[str, Any]) -> dict[str, Any]:
    return {name: _framework_value(value) for name, value in row.items()}


def _framework_value(value: Any) -> Any:
    # The shared Spark Python Data Source parser accepts ISO strings for DateType
    # and TimestampType, but rejects a native datetime.date.  Normalize both
    # temporal Python objects at the connector boundary for consistent snapshot
    # and CDC behavior.
    if isinstance(value, (date, datetime)):
        if value.year <= 1 and isinstance(value, datetime) and value.tzinfo is None:
            # A year-1 timestamp built here rather than decoded (a transform's TIMESTAMP
            # fallback) is tagged UTC as the decoders tag theirs (see cdc_protocol): naive,
            # next to datetime.min, it overflows PySpark's time zone conversion.
            value = value.replace(tzinfo=timezone.utc)
        return value.isoformat()
    return value


def _deep_size(value: Any, seen: set[int] | None = None) -> int:
    # Docstring: Estimate retained Python container/value memory without double counting.

    if seen is None:
        seen = set()
    identity = id(value)
    if identity in seen:
        return 0
    seen.add(identity)
    size = sys.getsizeof(value)
    if isinstance(value, dict):
        return size + sum(
            _deep_size(key, seen) + _deep_size(item, seen) for key, item in value.items()
        )
    if isinstance(value, (list, tuple, set, frozenset)):
        return size + sum(_deep_size(item, seen) for item in value)
    return size


def _skip_json_whitespace(text: str, index: int) -> int:
    # Docstring: Return the first index at or after ``index`` that is not JSON whitespace.
    #
    # Staged pages are written with ``separators=(",",":")`` (no whitespace), but
    # tolerating it keeps the hand-rolled scan robust to a compliant re-serializer.

    length = len(text)
    while index < length and text[index] in " \t\n\r":
        index += 1
    return index


# Header fields that sort *after* ``rows`` in a staged page's canonical
# (``sort_keys=True``) serialization -- see ``_publish_snapshot_stage_page``. They
# are located from the tail by ``_scan_staged_page`` rather than by walking the rows
# array. ``sha256`` is added to the record after the body and re-sorted between
# ``schema_id`` and ``snapshot_lsn``.
_SNAPSHOT_STAGE_TRAILING_KEYS = (
    "schema_id",
    "sha256",
    "snapshot_lsn",
    "table",
    "upper_pk",
    "version",
)


def _staged_page_payload(body: dict[str, Any]) -> tuple[bytes, str]:
    # Docstring: A staged page's bytes and its digest, with the body serialised once.
    #
    # A page is the canonical JSON of ``body`` plus a "sha256" field, in sorted-key order,
    # holding the digest of that canonical JSON. The fields either side of "sha256" are
    # serialised once each, hashed as joined, and the digest spliced between them: byte for
    # byte what serialising the whole record would give, and what _scan_staged_page undoes
    # by cutting out the field and its trailing comma. The body always has fields on both
    # sides (schema_id before it, snapshot_lsn after).

    options: dict[str, Any] = {"allow_nan": False, "separators": (",", ":"), "sort_keys": True}
    before = json.dumps({k: v for k, v in body.items() if k < "sha256"}, **options)[:-1]
    after = json.dumps({k: v for k, v in body.items() if k > "sha256"}, **options)[1:]
    head, tail = before.encode("utf-8"), after.encode("utf-8")
    hasher = hashlib.sha256(head)
    hasher.update(b",")
    hasher.update(tail)
    digest = hasher.hexdigest()
    return head + b',"sha256":"' + digest.encode("ascii") + b'",' + tail, digest


def _scan_staged_page(text: str) -> tuple[dict[str, Any], int, tuple[int, int]]:
    # Docstring: Locate a staged page's header fields without ever walking the ``rows`` array.
    #
    # Returns ``(header, array_start, sha_span)``. ``header`` holds every field except
    # ``rows``; ``array_start`` is the index of the ``rows`` array's opening ``[`` (the
    # single serve pass streams from there and finds the closing ``]`` itself);
    # ``sha_span`` is the ``[start, end)`` of the ``"sha256":"...",`` field including its
    # trailing comma, so the caller can excise it to recover the exact canonical body
    # the digest covers.
    #
    # The rows array is the one field with unbounded, arbitrary content, so it is never
    # scanned. Leading fields (those sorting before ``rows``) are forward-parsed with
    # ``raw_decode`` and are small; the parse stops at the ``rows`` key. Trailing fields
    # (sorting after ``rows``) are found from the tail with ``str.rfind`` on their
    # ``,"key":`` marker: each trailing field is structurally the *last* occurrence of
    # its key in the payload -- any same-named row column lives inside the earlier rows
    # array, and an unescaped ``,"key":`` only ever appears as a JSON key (a string
    # *value* containing that text is escaped as ``,\\"key\\":``) -- so the reverse find
    # lands on the real header field. Those fields occupy the payload's final few
    # hundred bytes, so the reverse finds are effectively free while the multi-hundred-MB
    # rows array is skipped entirely. Raises ``InformixError`` on any structural problem.

    length = len(text)
    index = _skip_json_whitespace(text, 0)
    if index >= length or text[index] != "{":
        # 365: Malformed staged snapshot page
        raise InformixError(_m(365))
    index += 1
    decoder = json.JSONDecoder()
    header: dict[str, Any] = {}
    array_start: int | None = None
    sha_span: tuple[int, int] | None = None
    try:
        # Forward-parse the small leading fields, stopping at the rows array.
        while True:
            index = _skip_json_whitespace(text, index)
            if index < length and text[index] == "}":
                break
            key, index = decoder.raw_decode(text, index)
            if not isinstance(key, str):
                # 365: Malformed staged snapshot page
                raise InformixError(_m(365))
            index = _skip_json_whitespace(text, index)
            if index >= length or text[index] != ":":
                # 365: Malformed staged snapshot page
                raise InformixError(_m(365))
            index = _skip_json_whitespace(text, index + 1)
            if key == "rows":
                if index >= length or text[index] != "[":
                    # 365: Malformed staged snapshot page
                    raise InformixError(_m(365))
                array_start = index
                break
            value, index = decoder.raw_decode(text, index)
            header[key] = value
            index = _skip_json_whitespace(text, index)
            if index < length and text[index] == ",":
                index += 1
            elif index >= length or text[index] != "}":
                # 365: Malformed staged snapshot page
                raise InformixError(_m(365))
        if array_start is None:
            # 365: Malformed staged snapshot page
            raise InformixError(_m(365))
        # Locate the trailing fields from the tail. Each key's last occurrence is its
        # header field (row columns of the same name sit inside the earlier array).
        for key in _SNAPSHOT_STAGE_TRAILING_KEYS:
            marker = f',"{key}":'
            marker_pos = text.rfind(marker)
            if marker_pos < array_start:
                # 365: Malformed staged snapshot page
                raise InformixError(_m(365))
            value, value_end = decoder.raw_decode(text, marker_pos + len(marker))
            header[key] = value
            if key == "sha256":
                # Excise "sha256":"...", (key through trailing comma) to recover the
                # canonical body. sha256 is never the last sorted key (snapshot_lsn,
                # table, upper_pk, version follow), so a trailing comma is present.
                if value_end >= length or text[value_end] != ",":
                    # 365: Malformed staged snapshot page
                    raise InformixError(_m(365))
                sha_span = (marker_pos + 1, value_end + 1)
    except (json.JSONDecodeError, IndexError) as error:
        # 365: Malformed staged snapshot page
        raise InformixError(_m(365)) from error
    if sha_span is None:
        # 365: Malformed staged snapshot page
        raise InformixError(_m(365))
    return header, array_start, sha_span


def _encode_snapshot_stage_value(value: Any) -> Any:
    if value is None or isinstance(value, (bool, int, str)):
        return value
    if isinstance(value, float):
        if math.isfinite(value):
            return value
        return {"$informix": "float", "value": repr(value)}
    if isinstance(value, Decimal):
        return {"$informix": "decimal", "value": str(value)}
    if isinstance(value, datetime):
        return {"$informix": "datetime", "value": value.isoformat()}
    if isinstance(value, date):
        return {"$informix": "date", "value": value.isoformat()}
    if isinstance(value, (bytes, bytearray, memoryview)):
        return {
            "$informix": "binary",
            "value": base64.b64encode(bytes(value)).decode("ascii"),
        }
    if isinstance(value, list):
        return [_encode_snapshot_stage_value(item) for item in value]
    if isinstance(value, tuple):
        return {
            "$informix": "tuple",
            "value": [_encode_snapshot_stage_value(item) for item in value],
        }
    if isinstance(value, dict) and all(isinstance(key, str) for key in value):
        if "$informix" in value:
            # 366: Snapshot row contains reserved staging key '$informix'
            raise InformixError(_m(366))
        return {key: _encode_snapshot_stage_value(item) for key, item in value.items()}
    # 367: Snapshot value of type {} cannot be staged safely
    raise InformixError(_m(367, type(value).__name__))


def _decode_snapshot_stage_value(value: Any) -> Any:
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    if isinstance(value, list):
        return [_decode_snapshot_stage_value(item) for item in value]
    if not isinstance(value, dict):
        # 368: Invalid typed value in staged snapshot page
        raise InformixError(_m(368))
    kind = value.get("$informix")
    if kind is None:
        return {str(key): _decode_snapshot_stage_value(item) for key, item in value.items()}
    if set(value) != {"$informix", "value"} or not isinstance(value["value"], str):
        if kind != "tuple" or set(value) != {"$informix", "value"}:
            # 368: Invalid typed value in staged snapshot page
            raise InformixError(_m(368))
    payload = value["value"]
    try:
        if kind == "decimal":
            return Decimal(payload)
        if kind == "datetime":
            return datetime.fromisoformat(payload)
        if kind == "date":
            return date.fromisoformat(payload)
        if kind == "binary":
            return base64.b64decode(payload, validate=True)
        if kind == "float" and payload in {"nan", "inf", "-inf"}:
            return float(payload)
        if kind == "tuple" and isinstance(payload, list):
            return tuple(_decode_snapshot_stage_value(item) for item in payload)
    except (ValueError, TypeError, ArithmeticError) as error:
        # 368: Invalid typed value in staged snapshot page
        raise InformixError(_m(368)) from error
    # 369: Unknown staged snapshot value type {!r}
    raise InformixError(_m(369, kind))


def _offset(
    commit: int,
    change: int,
    begin: int,
    tx_id: int | None,
    phase: str,
    table: Table,
    schema_id: str,
    pipeline_scope: str,
    *,
    trigger_generation: str | None = None,
    trigger_high_water: int | str | None = None,
    incremental: dict | None = None,
) -> dict:
    offset = {
        "version": _OFFSET_VERSION,
        "commit_lsn": str(commit),
        "change_lsn": str(change),
        "begin_lsn": str(begin),
        "tx_id": tx_id,
        "phase": phase,
        "schema_fingerprint": _schema_fingerprint(table),
        "schema_id": schema_id,
        "pipeline_scope": pipeline_scope,
        "trigger_generation": trigger_generation,
        "trigger_high_water": (str(trigger_high_water) if trigger_high_water is not None else None),
    }
    if incremental is not None:
        offset["incremental"] = incremental
    return offset


def _schema_fingerprint(table: Table) -> str:
    parts: tuple[Any, ...] = (
        table.database,
        table.owner,
        table.name,
        table.incarnation,
        table.primary_keys,
        tuple(
            (
                column.name,
                column.type_name,
                column.nullable,
                column.length,
                column.precision,
                column.scale,
                column.cdc_supported,
            )
            for column in table.columns
        ),
    )
    # Appended only when set, so a table using neither keeps the fingerprint every
    # existing checkpoint was written with.
    if table.column_selection is not None:
        parts += (("column_selection", table.column_selection),)
    if table.row_filter is not None:
        parts += (("row_filter", table.row_filter),)
    if table.column_renames is not None:
        parts += (("column_renames", table.column_renames),)
    if table.column_transforms is not None:
        parts += (("column_transforms", table.column_transforms, table.transform_key_id),)
    return hashlib.sha256(repr(parts).encode("utf-8")).hexdigest()


def _schema_state(
    table: Table,
    start_lsn: int,
    predecessor: str | None = None,
    *,
    schema_id: str | None = None,
) -> dict[str, object]:
    return {
        "id": schema_id or _schema_node_id(table, predecessor),
        "fingerprint": _schema_fingerprint(table),
        "start_lsn": str(start_lsn),
        "predecessor": predecessor,
        "table": {
            "database": table.database,
            "owner": table.owner,
            "name": table.name,
            "incarnation": table.incarnation,
            "primary_keys": list(table.primary_keys),
            "columns": [
                {
                    "name": column.name,
                    "type_name": column.type_name,
                    "nullable": column.nullable,
                    "length": column.length,
                    "precision": column.precision,
                    "scale": column.scale,
                    "cdc_supported": column.cdc_supported,
                }
                for column in table.columns
            ],
            **(
                {}
                if table.column_selection is None
                else {
                    "column_selection": [
                        table.column_selection[0],
                        list(table.column_selection[1]),
                    ]
                }
            ),
            **({} if table.row_filter is None else {"row_filter": table.row_filter}),
            **(
                {}
                if table.column_renames is None
                else {"column_renames": [list(pair) for pair in table.column_renames]}
            ),
            **(
                {}
                if table.column_transforms is None
                else {
                    "column_transforms": [list(pair) for pair in table.column_transforms],
                    "transform_key_id": table.transform_key_id,
                }
            ),
        },
    }


def _schema_node_id(table: Table, predecessor: str | None = None) -> str:
    # Docstring: Return the stable identity of one physical-table schema layout.
    #
    # A transition's node also hashes the node it follows. A layout can recur (a column
    # added, then dropped), and with the layout alone its return would reuse the first
    # node's id, whose recorded successor is the change it already undid: the history
    # would cycle between the two and never reach a later schema. An initial node has no
    # predecessor and keeps the layout-only id.

    parts = (table.native_identity, _schema_fingerprint(table))
    identity = "\0".join(parts if predecessor is None else (*parts, predecessor))
    return hashlib.sha256(identity.encode("utf-8")).hexdigest()[:32]


def _table_from_schema_state(state: dict[str, object], default_database: str) -> Table:
    raw = state.get("table")
    if not isinstance(raw, dict):
        # 370: Informix shared CDC schema is missing table metadata
        raise InformixError(_m(370))
    try:
        start_lsn = _strict_lsn(state["start_lsn"], "start_lsn")
    except (KeyError, TypeError, ValueError) as error:
        # 371: Informix shared CDC schema has an invalid start LSN
        raise InformixError(_m(371)) from error
    if start_lsn < 1:
        # 371: Informix shared CDC schema has an invalid start LSN
        raise InformixError(_m(371))
    table = Table.parse(raw, default_database)
    if _schema_fingerprint(table) != state.get("fingerprint"):
        # 372: Informix shared CDC schema fingerprint does not match metadata
        raise InformixError(_m(372))
    return table


def _carry_table_options(fresh: Table, previous: Table) -> Table:
    # Docstring: Re-apply ``previous``'s option-derived state to ``fresh``, re-read from
    # the catalog.
    #
    # A catalog read knows nothing of table options, so without this a refresh would
    # revert a column selection, a primary.keys override, a nullable-index promotion, or a
    # row_filter, change the fingerprint, and read as drift. The selection runs first so a
    # wildcard key re-expands over the selected columns only.

    fresh = _apply_column_selection(fresh, previous.column_selection)
    # The key the carry below gives ``fresh``: the override or promotion carried, else
    # the catalog's; a wildcard keys on whatever is ingested.
    if previous.key_wildcard:
        key = None
    elif previous.key_override or previous.key_from_nullable_index:
        key = previous.primary_keys
    else:
        key = fresh.primary_keys
    fresh = _leave_out_unsupported_columns(fresh, key)
    if previous.key_override:
        # A wildcard key is re-expanded to the fresh columns instead of kept as listed.
        fresh = _carry_key_override(fresh, previous)
    elif previous.key_from_nullable_index:
        # The catalog re-derives the table as key-less (no all-NOT-NULL index), so without
        # this the promoted key -- and its directions -- would be dropped and the
        # key-order guard would trip mid-copy.
        fresh = replace(
            fresh,
            primary_keys=previous.primary_keys,
            key_descending=previous.key_descending,
            key_from_nullable_index=True,
        )
    _ensure_key_columns_exist(fresh)
    _ensure_selected_keys(fresh)
    fresh = _apply_row_filter(fresh, previous.row_filter)
    fresh = _apply_column_renames(fresh, previous.column_renames)
    carried = _recorded_transforms(previous.column_transforms)
    return _apply_column_transforms(fresh, carried, None, key_id=previous.transform_key_id)


def _ensure_key_columns_exist(table: Table) -> None:
    # Docstring: Fail when a carried key names a column the catalog no longer has.
    #
    # A primary.keys override or a nullable-index promotion is carried as listed, so a
    # key column dropped at the source would otherwise outlive the refresh and every row
    # would then key on NULL.

    known = {column.name for column in table.columns}
    missing = [key for key in table.primary_keys if key not in known]
    if missing:
        # 373: Key column(s) {} of '{}' no longer exist at the source; run a full refresh
        raise InformixError(_m(373, (", ".join(missing)), table.exposed_name))


def _wildcard_key(columns: Iterable[Column], excepted: Iterable[str]) -> list[str]:
    # Docstring: The names of ``columns`` a wildcard key covers: all of them, in order, but
    # the ``excepted`` ones of a "* except(...)" key.
    #
    # Matched ignoring case, as Informix folds an undelimited identifier to lower case, so
    # "* except(Note)" leaves out a column catalogued as ``note``.

    folded = {name.casefold() for name in excepted}
    return [column.name for column in columns if column.name.casefold() not in folded]


def _ensure_excepted_columns_exist(table: Table, excepted: Iterable[str]) -> None:
    # Docstring: Fail when a "* except(...)" key names a column the table doesn't have.
    #
    # Checked against every catalog column, those the column selection or an unsupported
    # type leaves out included, and ignoring case as _wildcard_key matches, so a typo fails
    # instead of quietly keeping the column it meant in the key. After a named column is
    # dropped at the source, take it out of the list: the key stays as it was, so the
    # schema transition accepts that edit. A column still to be added can't be named
    # ahead; add it to the list once it exists, before the pipeline restarts.

    known = {column.name.casefold() for column in table.catalog_columns or table.columns}
    missing = [name for name in excepted if name.casefold() not in known]
    if missing:
        # 374: Option '{}' excepts column(s) that '{}' does not have: {}
        raise InformixError(_m(374, _PRIMARY_KEYS_OPTION, table.exposed_name, (", ".join(missing))))


def _carry_key_override(fresh: Table, overridden: Table) -> Table:
    # Docstring: Carry a ``primary.keys`` override from ``overridden`` onto a re-read ``fresh``
    # table.
    #
    # An explicit key list is preserved as-is, with its adopted key-index directions. A
    # wildcard key is re-expanded to ``fresh``'s columns, less any its except(...) names,
    # keeping the directions only when the key is unchanged. A name whose column was
    # dropped fails, as it does when the option is applied.

    keys = overridden.primary_keys
    descending = overridden.key_descending
    if overridden.key_wildcard:
        _ensure_excepted_columns_exist(fresh, overridden.key_wildcard_except)
        keys = tuple(_wildcard_key(fresh.columns, overridden.key_wildcard_except))
        if not keys:
            # 192: Option '{}' excepts every column of '{}', leaving no key
            raise InformixError(_m(192, _PRIMARY_KEYS_OPTION, fresh.exposed_name))
        if keys != overridden.primary_keys:
            descending = ()
    return replace(
        fresh,
        primary_keys=keys,
        key_override=True,
        key_wildcard=overridden.key_wildcard,
        key_wildcard_except=overridden.key_wildcard_except,
        key_descending=descending,
    )


_WIDENABLE_STRING_TYPES = frozenset({"CHAR", "NCHAR", "VARCHAR", "NVARCHAR", "LVARCHAR"})


def _string_capacity(column: Column) -> int:
    # VARCHAR and NVARCHAR pack their minimum reserved length into the high byte.
    length = column.length or 0
    return length & 0xFF if column.type_name in {"VARCHAR", "NVARCHAR"} else length


# Integer types by width; a change to a higher rank widens. INT8 and BIGINT share a rank:
# both are 64-bit, so a change between them is a different encoding, not a widening.
_INTEGER_RANKS = {
    "SMALLINT": 1,
    "INT2": 1,
    "INTEGER": 2,
    "INT": 2,
    "SERIAL": 2,
    "BIGINT": 3,
    "INT8": 3,
    "BIGSERIAL": 3,
    "SERIAL8": 3,
}


def _widened(previous: Column, current: Column) -> bool:
    # Docstring: Whether ``current`` widens ``previous`` so every old value still fits.
    #
    # A longer CHAR, NCHAR, VARCHAR, NVARCHAR, or LVARCHAR stays StringType, and SMALLINT to
    # INTEGER stays IntegerType, so neither changes what the destination holds. The
    # numeric widenings change the Spark type -- SMALLINT or INTEGER to BIGINT/INT8
    # (IntegerType to LongType), SMALLFLOAT to FLOAT (FloatType to DoubleType), a
    # fixed-scale DECIMAL or MONEY gaining precision without losing integer digits, and
    # an integer to a fixed-scale DECIMAL or MONEY with room for all its digits (10 for
    # SMALLINT and INTEGER, which land as IntegerType; 20 for the 64-bit types) or, for
    # SMALLINT and INTEGER, to FLOAT -- and match what Delta type widening accepts, so
    # the destination widens the column in place when the pipeline sets
    # pipelines.enableTypeWidening. Nullability must not change, and a variable-scale
    # DECIMAL never widens.

    if (previous.name, previous.nullable, previous.cdc_supported) != (
        current.name,
        current.nullable,
        current.cdc_supported,
    ):
        return False
    old_type, new_type = previous.type_name, current.type_name
    if old_type == new_type in _WIDENABLE_STRING_TYPES:
        return _string_capacity(current) >= _string_capacity(previous)
    if old_type in _INTEGER_RANKS and new_type in _INTEGER_RANKS:
        return _INTEGER_RANKS[new_type] > _INTEGER_RANKS[old_type]
    if old_type in _INTEGER_RANKS and new_type in {"DECIMAL", "NUMERIC", "MONEY"}:
        if current.precision is None or current.scale in (None, 0xFF):
            return False
        # Delta's minimum: decimal(10,0) for IntegerType, decimal(20,0) for LongType,
        # with any scale added on top of those integer digits.
        digits = 20 if _INTEGER_RANKS[old_type] == 3 else 10
        return current.precision <= 38 and current.precision - current.scale >= digits
    if old_type in _INTEGER_RANKS and new_type in {"FLOAT", "DOUBLE", "DOUBLE PRECISION"}:
        # IntegerType to DoubleType is exact; Delta doesn't widen LongType to DoubleType.
        return _INTEGER_RANKS[old_type] < 3
    if old_type in {"SMALLFLOAT", "REAL"}:
        return new_type in {"FLOAT", "DOUBLE", "DOUBLE PRECISION"}
    if old_type == new_type in {"DECIMAL", "NUMERIC", "MONEY"}:
        scales = (previous.scale, current.scale)
        if None in (previous.precision, current.precision, *scales) or 0xFF in scales:
            return False
        # Delta's rule: the scale may grow only as far as the precision grows with it.
        return (
            current.precision <= 38
            and current.scale >= previous.scale
            and current.precision - current.scale >= previous.precision - previous.scale
        )
    return False


# String types Informix 14.10 shortens in place: the table keeps its tabid, so the stream
# carries on. LVARCHAR is not one, nor is a narrower number or DATETIME qualifier: Informix
# rebuilds the table under a new tabid for those, which reads as a new table.
_SHORTENABLE_STRING_TYPES = frozenset({"CHAR", "NCHAR", "VARCHAR", "NVARCHAR"})


def _shortened(previous: Column, current: Column) -> bool:
    # Docstring: Whether ``current`` is ``previous`` made shorter and nothing else.
    #
    # The destination column is a string either way, so it stays as it is and is never
    # shrunk. Informix's ALTER truncates existing values longer than the
    # new length without logging a change per row, so those rows keep their old values in
    # the destination until they next change or a full refresh. For a key column that
    # divergence breaks matching, so _ensure_compatible_schema_change rejects it there.

    return (
        (previous.name, previous.type_name, previous.nullable, previous.cdc_supported)
        == (current.name, current.type_name, current.nullable, current.cdc_supported)
        and previous.type_name in _SHORTENABLE_STRING_TYPES
        and _string_capacity(current) < _string_capacity(previous)
    )


def _ensure_compatible_schema_change(
    previous: Table,
    current: Table,
    *,
    extend_wildcard_key: bool = False,
    shrink_wildcard_key: bool = False,
    wildcard_except: tuple[str, ...] = (),
) -> None:
    # Docstring: Fail closed unless the stream can adopt ``current`` without a full refresh.
    #
    # Columns are matched by name. Allowed, in any combination:
    #
    # - widening a column so every old value still fits (see :func:`_widened`); a numeric
    #   widening also widens the Spark type, which the destination adopts in place when
    #   the pipeline enables type widening, and otherwise fails that update loudly;
    # - shortening a CHAR, NCHAR, VARCHAR, or NVARCHAR column that isn't part of the key
    #   (see :func:`_shortened`), which is a string in the destination either way. A key
    #   column -- any column, under a wildcard key -- fails closed: Informix truncates its
    #   existing values without logging a change, so landed keys would stop matching;
    # - dropping a non-key column, NOT NULL or not -- the connector stops reporting it, and
    #   the destination keeps it: an SCD1 row updated afterwards keeps its last value there,
    #   while rows inserted and SCD2 versions written afterwards hold NULL. AUTO CDC creates
    #   every target column nullable, even from a NOT NULL source, so NULL always fits;
    # - appending nullable, CDC-supported columns after every surviving one. A column of a
    #   type the connector can't read is left out of ``current`` before this runs, so
    #   adding one changes nothing here.
    #
    # Anything else -- reordering, another type change (a column changed to a type the
    # connector can't read would otherwise pass as dropped), a key column dropped, a NOT NULL
    # or key column added -- fails closed, and so does changing include_columns /
    # exclude_columns or row_filter: rows already landed were selected under the old
    # setting, and the new one cannot be applied to them without a re-read. The selection
    # edits accepted leave the ingested columns as they were: taking out a name whose
    # column no longer exists, or adding or taking out an exclude_columns name of a column
    # the connector leaves out anyway (see _selection_cleanup_only). The key
    # must be unchanged, except that with ``extend_wildcard_key`` a wildcard key -- the whole
    # row, or the whole row but its except(...) columns -- may grow by exactly the appended
    # columns that join it (and nothing dropped), and with ``shrink_wildcard_key`` as well
    # -- the first read of a new update -- shrink by exactly the dropped columns (and
    # nothing appended). A running update keeps merging on the key it started with,
    # so a shorter key mid-update fails until the pipeline restarts with it.

    name = current.exposed_name
    current_names = {column.name for column in current.columns}
    survivors = [column for column in previous.columns if column.name in current_names]
    dropped = [column for column in previous.columns if column.name not in current_names]
    additions = current.columns[len(survivors) :]
    # The identity first: a re-created table can pass for a dropped column, a key that
    # shrank, or a retyped column, and its new table ID is the change to report.
    if (previous.database, previous.owner, previous.name, previous.incarnation) != (
        current.database,
        current.owner,
        current.name,
        current.incarnation,
    ):
        # 375: Informix schema change for '{}' changed table identity or primary keys; run a full
        # refresh
        raise InformixError(_m(375, name))
    # Then a retyped column, ahead of the key: under a whole-row key one left out would
    # otherwise pass for a column dropped from the key. Informix can't convert a column
    # to TEXT or BYTE in place (-608), so this is mostly a DATETIME or INTERVAL qualifier
    # the decoder doesn't handle. A column the history already records with an
    # unsupported type (a build that kept it in the schema) didn't change type: leaving
    # it out now is a drop, accepted below like any other.
    unsupported = {column.name: column for column in current.unsupported_columns}
    retyped = [
        unsupported[column.name]
        for column in dropped
        if column.name in unsupported and not _unsupported_column(column)
    ]
    if retyped:
        # 376: Informix schema change for '{}' changed column(s) to a type the connector can't read:
        # {}; run a full refresh
        raise InformixError(_m(376, name, _unsupported_column_list(retyped)))
    keys_match = previous.primary_keys == current.primary_keys
    shrunk = False
    # A wildcard key is the columns in catalog order, less the ``wildcard_except`` names of
    # a "* except(...)" one (the live table's, since schema history keeps only the key), and
    # every appended column it doesn't except joins it. A changed except list fails here
    # as any other key change does.
    wildcard_shaped = previous.primary_keys == tuple(
        _wildcard_key(previous.columns, wildcard_except)
    )
    if not keys_match and extend_wildcard_key and wildcard_shaped:
        added = tuple(_wildcard_key(additions, wildcard_except))
        removed = {column.name for column in dropped}
        if added and not dropped:
            keys_match = current.primary_keys == previous.primary_keys + added
        elif (
            dropped
            and not added
            and current.primary_keys
            == tuple(key for key in previous.primary_keys if key not in removed)
        ):
            if not shrink_wildcard_key:
                # 377: Informix schema change for '{}' dropped {} from its {}='{}' key during a
                # running update; stop and restart the pipeline so the destination merges on the
                # shorter key
                raise InformixError(
                    _m(
                        377,
                        name,
                        (", ".join(column.name for column in dropped)),
                        _PRIMARY_KEYS_OPTION,
                        _PRIMARY_KEYS_WILDCARD,
                    )
                )
            keys_match = shrunk = True
    if not keys_match:
        # 375: Informix schema change for '{}' changed table identity or primary keys; run a full
        # refresh
        raise InformixError(_m(375, name))
    if [column.name for column in current.columns[: len(survivors)]] != [
        column.name for column in survivors
    ]:
        # 378: Informix schema change for '{}' reordered existing columns or added one before them;
        # run a full refresh
        raise InformixError(_m(378, name))
    for old, new in zip(survivors, current.columns):
        if old == new or _widened(old, new):
            continue
        if not _shortened(old, new):
            # 379: Informix schema change for '{}' changed column {} other than by widening it or
            # shortening a string; run a full refresh
            raise InformixError(_m(379, name, old.name))
        if old.name in previous.primary_keys or old.name in current.primary_keys:
            # Informix truncates the existing values without logging a change, so the
            # keys already landed would no longer match the source's.
            wildcard = previous.key_wildcard or current.key_wildcard
            excepting = previous.key_wildcard_except or current.key_wildcard_except
            raise InformixError(
                f"Informix schema change for '{name}' shortened key column {old.name}"
                + (
                    f" (every column it doesn't except is in its {_PRIMARY_KEYS_OPTION}="
                    f"'{_PRIMARY_KEYS_WILDCARD} except(...)' key)"
                    if excepting
                    else f" (every column is in its {_PRIMARY_KEYS_OPTION}="
                    f"'{_PRIMARY_KEYS_WILDCARD}' key)"
                    if wildcard
                    else ""
                )
                + ": Informix truncates existing values without logging a change, so rows "
                "already landed would no longer match by key; run a full refresh"
            )
    if any(not column.nullable or not column.cdc_supported for column in additions):
        # 380: Informix schema change for '{}' added a non-nullable or CDC-unsupported column; run a
        # full refresh
        raise InformixError(_m(380, name))
    for column in dropped:
        if not shrunk and (
            column.name in previous.primary_keys or column.name in current.primary_keys
        ):
            # Whatever its nullability: a primary.keys override or a nullable-index key can
            # name a nullable column, and every row would then key on NULL. A whole-row
            # key that shrank above no longer names the column.
            # 381: Informix schema change for '{}' dropped key column {}; run a full refresh
            raise InformixError(_m(381, name, column.name))
    if previous.column_selection != current.column_selection and not _selection_cleanup_only(
        previous, current
    ):
        # 382: '{}' / '{}' changed for '{}'; run a full refresh so every row is read under the new
        # selection
        raise InformixError(_m(382, _INCLUDE_COLUMNS_OPTION, _EXCLUDE_COLUMNS_OPTION, name))
    if previous.row_filter != current.row_filter:
        # 383: '{}' changed for '{}'; run a full refresh so every row is read under the new filter
        raise InformixError(_m(383, _ROW_FILTER_OPTION, name))
    if (
        previous.column_transforms != current.column_transforms
        and not _transforms_cleanup_only(previous, current)
    ) or (
        # A key id only where HASH is used: taking out the last HASH entry with its dropped
        # column leaves none to compare, and adding one is not a cleanup.
        previous.transform_key_id is not None
        and current.transform_key_id is not None
        and previous.transform_key_id != current.transform_key_id
    ):
        # 384: '{}' or '{}' changed for '{}'; run a full refresh so every row lands under the new
        # transforms
        raise InformixError(_m(384, _TRANSFORM_COLUMNS_OPTION, _TRANSFORM_HASH_KEY_OPTION, name))
    if previous.column_renames != current.column_renames and not _renames_cleanup_only(
        previous, current
    ):
        # 385: '{}' changed for '{}'; run a full refresh so every row lands under the new names
        raise InformixError(_m(385, _RENAME_COLUMNS_OPTION, name))


def _selection_cleanup_only(previous: Table, current: Table) -> bool:
    # Docstring: Whether the selection only changed by names that leave the ingested columns
    # as they were.
    #
    # That is a name whose column the table no longer has, or, under exclude_columns, a
    # column of a type the connector leaves out anyway: listing one only silences its
    # warning, and taking it out again leaves it out all the same. Such an exclude_columns
    # entry may also be the whole list, so the selection appears or goes. include_columns
    # can't name such a column, so a change there stays strict.

    before, after = previous.column_selection, current.column_selection
    catalog = {column.name: column for column in current.catalog_columns or current.columns}

    def needless(name: str) -> bool:
        column = catalog.get(name)
        return column is None or _unsupported_column(column)

    if before is None or after is None:
        selection = before or after
        return (
            selection is not None
            and selection[0] == "exclude"
            and all(needless(name) for name in selection[1])
        )
    if before[0] != after[0]:
        return False
    changed = set(before[1]) ^ set(after[1])
    if before[0] == "include":
        return not changed & catalog.keys()
    return all(needless(name) for name in changed)


def _transforms_cleanup_only(previous: Table, current: Table) -> bool:
    # Docstring: Whether the transforms only lost entries for columns the table no longer has.

    before, after = set(previous.column_transforms or ()), set(current.column_transforms or ())
    catalog = {column.name for column in current.catalog_columns or current.columns}
    return after <= before and all(name not in catalog for name, _ in before - after)


def _recorded_transforms(recorded: tuple | None) -> tuple | None:
    # Docstring: Parse recorded (column, canonical) transforms back to (column, text, operand).

    if recorded is None:
        return None
    return tuple(
        (
            name,
            canonical,
            _RowFilterParser(canonical, _TRANSFORM_COLUMNS_OPTION, "transform").parse_expression(),
        )
        for name, canonical in recorded
    )


def _renames_cleanup_only(previous: Table, current: Table) -> bool:
    # Docstring: Whether the renames only lost entries for columns the table no longer has.

    before, after = set(previous.column_renames or ()), set(current.column_renames or ())
    catalog = {column.name for column in current.catalog_columns or current.columns}
    return after <= before and all(source not in catalog for source, _ in before - after)


def _unl_position(offset: dict[str, Any], *, terminal: int | None = None) -> tuple[int, int]:
    # Docstring: ``(split index, record index)`` a file-snapshot offset points at.
    #
    # An empty offset is the start of the extract. A stream-phase offset is past its end:
    # ``terminal`` (the split count) when given -- the end of a window that finished the
    # extract -- and an error otherwise.

    if not offset:
        return 0, 0
    checkpoint = _validated_offset(offset)
    if checkpoint.get("phase") != "snapshot":
        if terminal is None:
            # 386: A file snapshot window cannot start at a stream-phase offset
            raise InformixError(_m(386))
        return terminal, 0
    snapshot = checkpoint["snapshot"]
    return int(snapshot["page_index"]), int(snapshot.get("record_index", 0))


def _validated_offset(offset: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(offset, dict):
        # 387: Informix offset must be a dictionary
        raise ValueError(_m(387))
    result = dict(offset)
    if "shared_state_retry_count" in result:
        result["shared_state_retry_count"] = _shared_state_retry_count(result)
    if "dropped_mount_retry_count" in result:
        result["dropped_mount_retry_count"] = _dropped_mount_retry_count(result)
    if "trigger_boundary_retry_count" in result:
        result["trigger_boundary_retry_count"] = _trigger_boundary_retry_count(result)
    if "schema_transition_retry_count" in result:
        result["schema_transition_retry_count"] = _schema_transition_retry_count(result)
    if "schema_node_fallback_retry_count" in result:
        result["schema_node_fallback_retry_count"] = _schema_node_fallback_retry_count(result)
    if "capacity_retry_count" in result:
        result["capacity_retry_count"] = _capacity_retry_count(result)
    if "capacity_pressure" in result:
        result["capacity_pressure"] = _capacity_pressure(result)
    if "backlog_rank" in result:
        result["backlog_rank"] = _backlog_rank_value(result)
    if "backlog_streak" in result:
        result["backlog_streak"] = _backlog_streak(result)
    if result.get("version") != _OFFSET_VERSION:
        # 388: Informix offset version {!r} is unsupported; run a full refresh with this connector
        # version
        raise ValueError(_m(388, result.get("version")))
    values = {}
    for key in ("commit_lsn", "change_lsn", "begin_lsn"):
        if key not in result:
            # 389: Informix stream offset is missing '{}'
            raise ValueError(_m(389, key))
        values[key] = _strict_lsn(result[key], key)
    if not values["begin_lsn"] <= values["change_lsn"] <= values["commit_lsn"]:
        # 390: Informix offset must satisfy begin_lsn <= change_lsn <= commit_lsn
        raise ValueError(_m(390))
    phase = result.get("phase")
    if phase not in {"snapshot", "stream"}:
        # 391: Informix offset phase must be 'snapshot' or 'stream'
        raise ValueError(_m(391))
    fingerprint = result.get("schema_fingerprint")
    if fingerprint is not None and (
        not isinstance(fingerprint, str)
        or len(fingerprint) != 64
        or any(character not in "0123456789abcdef" for character in fingerprint)
    ):
        # 392: Informix offset has an invalid schema_fingerprint
        raise ValueError(_m(392))
    layout = result.get("update_fingerprint")
    if layout is not None and (
        not isinstance(layout, str)
        or len(layout) != 64
        or any(character not in "0123456789abcdef" for character in layout)
    ):
        # 424: Informix offset has an invalid update_fingerprint
        raise ValueError(_m(424))
    schema_id = result.get("schema_id")
    if not isinstance(schema_id, str) or not re.fullmatch(r"[0-9a-f]{32}", schema_id):
        # 393: Informix offset has an invalid schema_id; run a full refresh with this connector
        # version
        raise ValueError(_m(393))
    pipeline_scope = result.get("pipeline_scope")
    if not isinstance(pipeline_scope, str) or _PIPELINE_SCOPE.fullmatch(pipeline_scope) is None:
        # 394: Informix offset has an invalid pipeline_scope; run a full refresh with this connector
        # version
        raise ValueError(_m(394))
    # stage_scope, when present, redirects a handoff relocation's staged-page reads to
    # the capturing flow's scope. Only valid on a snapshot-phase offset (it is dropped at
    # the stream transition) and must be a well-formed scope.
    stage_scope = result.get("stage_scope")
    if stage_scope is not None:
        if not isinstance(stage_scope, str) or _PIPELINE_SCOPE.fullmatch(stage_scope) is None:
            # 395: Informix offset has an invalid stage_scope; run a full refresh with this
            # connector version
            raise ValueError(_m(395))
        if phase != "snapshot":
            # 396: Informix offset stage_scope requires the snapshot phase
            raise ValueError(_m(396))
    trigger_generation = result.get("trigger_generation")
    if trigger_generation is not None and (
        not isinstance(trigger_generation, str)
        or not re.fullmatch(r"[0-9a-f]{32}", trigger_generation)
    ):
        # 397: Informix offset has an invalid trigger_generation
        raise ValueError(_m(397))
    trigger_high_water = result.get("trigger_high_water")
    if trigger_generation is None:
        if trigger_high_water is not None:
            # 398: Informix offset trigger_high_water requires trigger_generation
            raise ValueError(_m(398))
    elif trigger_high_water is None:
        # 399: Informix offset trigger_generation requires trigger_high_water
        raise ValueError(_m(399))
    else:
        parsed_trigger_high_water = _strict_lsn(trigger_high_water, "trigger_high_water")
        result["trigger_high_water"] = str(parsed_trigger_high_water)
    tx_id = result.get("tx_id")
    if tx_id is not None:
        result["tx_id"] = _strict_tx_id(tx_id)
    if phase == "snapshot":
        if "snapshot_lsn" not in result or _strict_lsn(result["snapshot_lsn"], "snapshot_lsn") < 0:
            # 400: Informix snapshot offset has an invalid snapshot_lsn
            raise ValueError(_m(400))
        if any(
            value != _strict_lsn(result["snapshot_lsn"], "snapshot_lsn")
            for value in values.values()
        ):
            # 401: Informix snapshot offset requires snapshot_lsn, begin_lsn, change_lsn, and
            # commit_lsn to be equal
            raise ValueError(_m(401))
        snapshot = result.get("snapshot")
        if not isinstance(snapshot, dict) or not isinstance(snapshot.get("last_pk"), list):
            # 402: Informix snapshot offset is missing snapshot.last_pk
            raise ValueError(_m(402))
        page_index = snapshot.get("page_index")
        if isinstance(page_index, bool) or not isinstance(page_index, int) or page_index < 0:
            # 403: Informix snapshot offset has an invalid snapshot.page_index
            raise ValueError(_m(403))
        record_index = snapshot.get("record_index", 0)
        if isinstance(record_index, bool) or not isinstance(record_index, int) or record_index < 0:
            # 404: Informix snapshot offset has an invalid snapshot.record_index
            raise ValueError(_m(404))
    incremental = result.get("incremental")
    if incremental is not None:
        if phase != "stream":
            # 405: Informix incremental snapshot state requires the stream phase
            raise ValueError(_m(405))
        if not isinstance(incremental, dict):
            # 406: Informix incremental snapshot state must be a dictionary
            raise ValueError(_m(406))
        if not isinstance(incremental.get("started"), bool):
            # 407: Informix incremental snapshot state must record a boolean 'started'
            raise ValueError(_m(407))
        chunk_lsn = incremental.get("chunk_lsn")
        if chunk_lsn is not None:
            result["incremental"]["chunk_lsn"] = str(_strict_lsn(chunk_lsn, "chunk_lsn"))
        for key in ("last_pk", "max_pk"):
            value = incremental.get(key)
            if value is not None and not isinstance(value, list):
                # 408: Informix incremental snapshot {} must be a list or null
                raise ValueError(_m(408, key))
        if not incremental["started"] and (
            incremental.get("last_pk") is not None or incremental.get("max_pk") is not None
        ):
            # 409: Informix incremental snapshot state cannot carry bounds before it starts
            raise ValueError(_m(409))
        # Provenance stamped by _seed_incremental_block. Absent on offsets written
        # before it existed, which is exactly the "cannot be validated" case the
        # resume path re-seeds rather than trusts.
        boundary_lsn = incremental.get("boundary_lsn")
        if boundary_lsn is not None:
            result["incremental"]["boundary_lsn"] = str(
                _strict_lsn(boundary_lsn, "incremental boundary_lsn")
            )
        stamped_scope = incremental.get("scope")
        if stamped_scope is not None and (
            not isinstance(stamped_scope, str) or _PIPELINE_SCOPE.fullmatch(stamped_scope) is None
        ):
            # 410: Informix incremental snapshot scope has an invalid identity
            raise ValueError(_m(410))
        chunk_exprs = incremental.get("chunk_exprs")
        if chunk_exprs is not None and (
            not isinstance(chunk_exprs, dict)
            or not all(
                isinstance(key, str) and isinstance(value, str)
                for key, value in chunk_exprs.items()
            )
        ):
            # 411: Informix incremental snapshot chunk_exprs must map strings to strings
            raise ValueError(_m(411))
        snapshot_filter = incremental.get("snapshot_filter")
        if snapshot_filter is not None:
            if not isinstance(snapshot_filter, str):
                # 412: Informix incremental snapshot filter must be a string or null
                raise ValueError(_m(412))
            result["incremental"]["snapshot_filter"] = _snapshot_filter(
                {"snapshot.filter": snapshot_filter}
            )
    return result


def _shared_state_retry_count(offset: dict[str, Any]) -> int:
    value = offset.get("shared_state_retry_count", 0)
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        # 413: Informix offset has an invalid shared_state_retry_count
        raise ValueError(_m(413))
    return value


def _dropped_mount_retry_count(offset: dict[str, Any]) -> int:
    value = offset.get("dropped_mount_retry_count", 0)
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        # 414: Informix offset has an invalid dropped_mount_retry_count
        raise ValueError(_m(414))
    return value


def _schema_node_fallback_retry_count(offset: dict[str, Any]) -> int:
    value = offset.get("schema_node_fallback_retry_count", 0)
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        # 415: Informix offset has an invalid schema_node_fallback_retry_count
        raise ValueError(_m(415))
    return value


def _capacity_retry_count(offset: dict[str, Any]) -> int:
    value = offset.get("capacity_retry_count", 0)
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        # 416: Informix offset has an invalid capacity_retry_count
        raise ValueError(_m(416))
    return value


def _capacity_pressure(offset: dict[str, Any]) -> int:
    # Docstring: Decaying acquisition-pressure signal that feeds the yield budget.
    #
    # Distinct from ``capacity_retry_count``: that counts *consecutive* misses and
    # resets to zero the instant a read gets a slot, because it is the failure
    # guard (a permanently starved flow fails at ``capacity.retry.max.retries``).
    # Pressure instead *decays* on success rather than resetting, so a flow that is
    # contended but occasionally served keeps some of the elevated budget it earned
    # while starved instead of dropping straight back to the least-patient value.
    # Optional and backward compatible: an offset written before this field existed
    # defaults to zero.

    value = offset.get("capacity_pressure", 0)
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        # 417: Informix offset has an invalid capacity_pressure
        raise ValueError(_m(417))
    return value


def _backlog_streak(offset: dict[str, Any]) -> int:
    # Docstring: Validate the run of consecutive reads that filled their row budget.
    #
    # Optional and backward compatible: an offset written before the streak existed,
    # or by a flow that has never truncated, simply has no key and reads as zero.

    value = offset.get("backlog_streak", 0)
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        # 418: Informix offset has an invalid backlog_streak
        raise ValueError(_m(418))
    return value


def _with_backlog_streak(end: dict, start: dict, row_budget_reached: bool) -> dict:
    # Docstring: Record whether this read ended at its row budget rather than the log's end.
    #
    # A read that filled its budget has *proved* more changes are waiting for this
    # table, which is the only first-hand backlog evidence a reader has: the
    # published hint is the server's global log position, so it measures staleness
    # and cannot tell a quiet table from a lagging one. Counting consecutive
    # truncations distinguishes a sustained backlog from one busy read, and draining
    # the log clears the streak outright so a caught-up flow never keeps priority it
    # no longer needs.
    #
    # The count saturates so it cannot grow without bound in an offset that a
    # permanently backlogged flow persists on every batch.

    if not row_budget_reached:
        if "backlog_streak" not in end:
            return end
        end = dict(end)
        end.pop("backlog_streak", None)
        return end
    end = dict(end)
    end["backlog_streak"] = min(_backlog_streak(start) + 1, _CONNECTION_BACKLOG_TRUNCATION_LEVELS)
    return end


def _backlog_rank(backlog: int, streak: int = 0) -> int:
    # Docstring: Bucket an estimated backlog onto a small, bounded, log-scaled rank.
    #
    # Two signals combine, because each is blind where the other sees.
    #
    # ``backlog`` is derived from a published *global* log position, so its
    # magnitude reflects whole-server write volume rather than this table's row
    # count; a log scale absorbs that bias so only order-of-magnitude differences
    # move the rank. It is comparable *across* readers, which is what ordering a
    # contended queue needs, but it over-states a quiet table's lag.
    #
    # ``streak`` counts consecutive reads that ended at their row budget. That is
    # first-hand proof this table has work outstanding, so it discriminates a
    # genuinely backlogged flow from a merely stale one -- the discrimination the
    # global signal cannot supply (measured in production: every waiter ranked
    # identically because all checkpoints were recent). It is only a self
    # assessment, so it cannot order one reader against another on its own.
    #
    # The streak takes the *high* band of the rank space and the estimate the low
    # one, rather than the two being combined by a maximum. A maximum cannot
    # separate readers whose estimates have already saturated, which is exactly the
    # observed failure: when every waiter's hint-derived estimate lands on the same
    # high rank, a proven backlog has to be able to outrank it. Banding guarantees
    # that any truncating flow outranks every non-truncating one, while the estimate
    # still orders readers within each band.

    proven_floor = _CONNECTION_BACKLOG_RANK_LEVELS // 2
    estimated = 0 if backlog <= 0 else min(proven_floor - 1, backlog.bit_length() // 4)
    if streak <= 0:
        return estimated
    # Scale the streak across the upper band so a saturated streak reaches the top
    # rank, matching what "provably behind on every read" deserves.
    span = _CONNECTION_BACKLOG_RANK_LEVELS - 1 - proven_floor
    return proven_floor + min(span, streak * span // max(1, _CONNECTION_BACKLOG_TRUNCATION_LEVELS))


def _backlog_rank_value(offset: dict[str, Any]) -> int:
    # Docstring: Validate an optional persisted backlog rank.
    #
    # Optional and backward compatible: an offset written before hints existed, or
    # by a reader that found no usable hint, simply has no rank and reads as zero.

    value = offset.get("backlog_rank", 0)
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        # 419: Informix offset has an invalid backlog_rank
        raise ValueError(_m(419))
    if value >= _CONNECTION_BACKLOG_RANK_LEVELS:
        # 420: Informix offset has an out-of-range backlog_rank
        raise ValueError(_m(420))
    return value


def _trigger_boundary_retry_count(offset: dict[str, Any]) -> int:
    value = offset.get("trigger_boundary_retry_count", 0)
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        # 421: Informix offset has an invalid trigger_boundary_retry_count
        raise ValueError(_m(421))
    return value


def _schema_transition_retry_count(offset: dict[str, Any]) -> int:
    value = offset.get("schema_transition_retry_count", 0)
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        # 422: Informix offset has an invalid schema_transition_retry_count
        raise ValueError(_m(422))
    return value


__all__ = [
    "InformixConnect",
    "InformixLakeflowConnect",
    "InformixBridge",
    "InformixError",
    "SharedStateAccessUnavailable",
    "TriggerBoundaryUnavailable",
    "SchemaTransitionUnavailable",
    "PurePythonInformixBridge",
    "LogRetentionError",
    "TransactionBuffer",
    "UnsupportedChangeError",
    "set_bridge_factory",
]


def _shorten_merged_definitions(namespace: dict[str, Any]) -> None:
    # Docstring: In the merged single file, strip ``register_lakeflow_source.<locals>.``
    # from every definition's qualname and drop function annotations.
    #
    # The merge nests the whole connector inside register_lakeflow_source, so Spark
    # pickles every function and class by value. Each function carries that prefix twice
    # (on the function and on its code object, nested code included) and an annotations
    # dict nothing reads at run time: about 67 KB of the 1 MiB the planner accepts.
    # Tracebacks still show each function's name, file and line. Imported as a module,
    # nothing carries the prefix, so this changes nothing.
    prefix = "register_lakeflow_source.<locals>."
    seen: set[int] = set()
    codes: dict[int, types.CodeType] = {}

    def shorten(code: types.CodeType) -> types.CodeType:
        if id(code) not in codes:
            consts = tuple(
                shorten(c) if isinstance(c, types.CodeType) else c for c in code.co_consts
            )
            qualname = getattr(code, "co_qualname", None)
            if qualname is None:  # Python 3.10: only the function carries a qualname
                codes[id(code)] = code.replace(co_consts=consts)
            else:
                codes[id(code)] = code.replace(
                    co_consts=consts, co_qualname=qualname.removeprefix(prefix)
                )
        return codes[id(code)]

    def visit(value: Any) -> None:
        if id(value) in seen:
            return
        seen.add(id(value))
        if isinstance(value, (staticmethod, classmethod)):
            visit(value.__func__)
        elif isinstance(value, property):
            for accessor in (value.fget, value.fset, value.fdel):
                visit(accessor)
        elif isinstance(value, types.FunctionType):
            if prefix in value.__qualname__ or prefix in getattr(value.__code__, "co_qualname", ""):
                value.__code__ = shorten(value.__code__)
                value.__qualname__ = value.__qualname__.removeprefix(prefix)
                value.__annotations__ = {}
                for cell in value.__closure__ or ():
                    with contextlib.suppress(ValueError):  # an unfilled cell
                        visit(cell.cell_contents)
        elif isinstance(value, type):
            if value.__qualname__.startswith(prefix):
                value.__qualname__ = value.__qualname__.removeprefix(prefix)
                for member in list(vars(value).values()):
                    visit(member)
        elif isinstance(value, dict):
            for member in list(value.values()):
                visit(member)
        elif isinstance(value, (list, tuple, set, frozenset)):
            for member in list(value):
                visit(member)

    for value in list(namespace.values()):
        visit(value)


# The merged file keeps a few of its definitions as module globals (the AvailableNow
# reader base), so both namespaces are visited.
_shorten_merged_definitions({**globals(), **locals()})
